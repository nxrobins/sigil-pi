"""Long conversation through actual HTTP, compiled SIGIL, storage and restart."""

import json
import os
from pathlib import Path

from acceptance.capacity_evidence import assert_returned, inspect_capacity
from api_support import TOKEN_A
from automatic_support import wait_operation
from conftest import FIXED_EVALUATOR_BIN, MCP_BIN, SIGIL_ROOT
from scripts.build_context_window_deployment import build
from test_completion_capacity_service import AUDIT_KEY, setup_env, prepared_service
from test_history_archive_service import archived_profile, read_rows, response
from turn_support import fields


def context_profile():
    if os.environ.get("PI_CONTEXT_PROFILE"):
        return json.loads(Path(os.environ["PI_CONTEXT_PROFILE"]).read_text())
    return {**archived_profile(), "public_archive_export": "v1", "context_window": "v1", "model_thinking": "disabled"}


def test_long_conversation_reduces_context_but_preserves_all_archived_turns(scripted_llm, tmp_path, monkeypatch):
    setup_env(monkeypatch)
    evaluator = Path(os.environ.get("PI_ARCHIVE_EXPORT_EVALUATOR", str(FIXED_EVALUATOR_BIN)))
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    root = tmp_path / "deployment"
    build(root, workspace, MCP_BIN, evaluator, SIGIL_ROOT, TOKEN_A,
          context_profile(), endpoint=scripted_llm.url)
    replies = [f"retained-turn-{i}:" + "x" * 6000 for i in range(8)]
    scripted_llm.script = [response(reply) for reply in replies]
    accepted = []
    with prepared_service(root) as api:
        for i, expected in enumerate(replies):
            code, op = api.request(body={"session": "long", "submission_key": f"turn-{i}", "message": f"User turn {i}"})
            assert code == 202, op
            result = wait_operation(api, op["operation"])
            assert result["status"] == "done" and result["reply"] == expected, result
            accepted.append(op)
        assert len(read_rows(root, "workspace.state.archive")) == 7
        state = fields(read_rows(root, "workspace.state")[0][2], "PT1\n", 17)
        current = json.loads(state[5])
        assert current[0]["content"].startswith("[SIGIL context notice]")
        assert replies[0] not in state[5] and replies[-1] in state[5]
        assert len(state[5].encode()) < 42000
        # Every acknowledged response remains exactly retrievable, including
        # turns removed from the current model context.
        for op, expected in zip(accepted[:-1], replies[:-1]):
            status, archive = api.request("GET", "/v1/sessions/long/archives?operation=" + op["operation"])
            assert status == 200, archive
            assert archive["operation_result"]["reply"] == expected
        status, messages = api.request("GET", "/v1/sessions/long/messages")
        assert status == 200 and messages["messages"][0]["content"][0]["text"].startswith("[SIGIL context notice]")
        assert_returned(inspect_capacity(root, AUDIT_KEY))
    calls = len(scripted_llm.requests)
    with prepared_service(root, mode="open") as api:
        status, archive = api.request("GET", "/v1/sessions/long/archives?operation=" + accepted[0]["operation"])
        assert status == 200 and archive["operation_result"]["reply"] == replies[0]
        assert api.request("GET", "/v1/sessions/long/messages")[0] == 200
    assert len(scripted_llm.requests) == calls == 8
    assert all(request["thinking"] == {"type": "disabled"} for request in scripted_llm.requests)
