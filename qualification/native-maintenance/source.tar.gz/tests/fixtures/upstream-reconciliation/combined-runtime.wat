(module
  (import "ffi" "http_get"
    (func $get (param i32 i32) (result i64)))
  (memory (export "memory") 1)
  (global (export "BUMP_PTR") (mut i32) (i32.const 1024))
  (func (export "tool__tool_main")
    (param $p i64) (param $n i64) (param $handle i32)
    (result i64)
    (if (i32.ne (local.get $handle) (i32.const 0))
      (then unreachable))
    (call $get
      (i32.wrap_i64 (local.get $p))
      (i32.wrap_i64 (local.get $n)))))
