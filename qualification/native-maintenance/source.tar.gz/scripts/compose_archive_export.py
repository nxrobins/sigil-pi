"""Grantless archive projection; API authorization remains a separate boundary."""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource, compose_application
from scripts.compose_bootstrap_admission import compact
from scripts.compose_lifecycle import compose_lifecycle
from scripts.compose_identity import identity_helper

ROOT = Path(__file__).resolve().parent.parent


def compose_archive_export_api(stdlib):
    base = compose_lifecycle("api_discovery", stdlib)
    body, inputs = base.text, dict(base.input_hashes)

    def replace(old, new):
        nonlocal body
        if body.count(old) != 1:
            raise ValueError("archive API composition site changed: " + old)
        body = body.replace(old, new)

    replace("arr_len(get(x,10))!= 4", "arr_len(get(x,10))!= 5")
    for index, name in ((3, "storage"), (2, "listing"), (1, "history")):
        replace(f'item(get(x,10),{index}),"{name}"', f'item(get(x,10),{index + 1}),"{name}"')
    replace('!is_text(item(get(x,10),0),"admission")',
            '!is_text(item(get(x,10),0),"admission")|| !is_text(item(get(x,10),1),"archive_export")')
    replace('ends(history_path(path),"/messages")', '(ends(history_path(path),"/messages")|| ends(history_path(path),"/archives"))')
    replace("let submitting: bool @Internal =",
            'if is_text(get(x,0),"GET")&& starts(get(x,1),"/v1/sessions/")&& ends(history_path(get(x,1)),"/archives"){return archive_export_api(x,c);}'
            + "let submitting: bool @Internal =")
    path = ROOT / "app/pi/archive_export_api.sigil"
    raw = path.read_bytes()
    body = compact(body + "\n" + raw.decode())
    inputs[str(path.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
    inputs["scripts/compose_archive_export.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("archive API exceeds entry/source contract")
    return ApplicationSource(body, inputs, base.stdlib_hash)


def compose_archive_export(stdlib):
    base = compose_application("history", stdlib)
    body, inputs = base.text, dict(base.input_hashes)
    old = "pub fn tool_main(input_ptr: i64, input_len: i64)"
    assert body.count(old) == 1
    body = body.replace(old, "fn archive_history(input_ptr: i64 @Internal, input_len: i64 @Internal)")
    body = body.replace("retained_context", "operation_context_snapshot")
    # Project terminal pending observations without rewriting the immutable PT1.
    # The original state/outcome binding is checked before archive_history runs.
    history_site = "let history: i64 @Internal = get(s, 5);"
    if body.count(history_site) != 1:
        raise ValueError("archive history projection site changed")
    body = body.replace(history_site,
                        "let history: i64 @Internal = workspace_history(s);if history < 0{return history;}")
    # Use the exact CF2 tenant grammar, including Unicode and punctuation. The
    # tenant is an authenticated identity, never a storage key or namespace.
    identity, identity_inputs = identity_helper(ROOT, "archive_identity_text")
    body += "\n" + identity
    inputs.update(identity_inputs)
    for relative in ("app/pi/workspace_continuation.sigil", "app/pi/operation_records.sigil", "app/pi/archive_export.sigil"):
        raw = (ROOT / relative).read_bytes()
        inputs[relative] = hashlib.sha256(raw).hexdigest()
        body += "\n" + raw.decode()
    body = body.replace("pub fn tool_main(input_ptr: i64, input_len: i64)",
                        "fn archive_projection(input_ptr: i64 @Internal, input_len: i64 @Internal)")
    raw = (ROOT / "app/pi/archive_index.sigil").read_bytes()
    inputs["app/pi/archive_index.sigil"] = hashlib.sha256(raw).hexdigest()
    body += "\n" + raw.decode()
    body = compact(body)
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("archive projection exceeds entry/source contract")
    inputs["scripts/compose_archive_export.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body, inputs, base.stdlib_hash)
