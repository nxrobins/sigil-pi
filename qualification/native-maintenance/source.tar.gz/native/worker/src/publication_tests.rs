use super::*;
use std::fs;
use std::os::unix::fs::{PermissionsExt, symlink};
use std::process::Command;

fn root() -> tempfile::TempDir {
    // macOS advertises /var/... through a symlink. Trusted bootstrap supplies
    // the actual directory path; sink admission must keep rejecting aliases.
    let root = tempfile::tempdir_in(std::env::temp_dir().canonicalize().unwrap()).unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    root
}
fn sink(root: &Path) -> FixedSink {
    FixedSink::admit(root, "v1", 256).unwrap()
}

#[cfg(target_os = "macos")]
fn add_acl(path: &Path) {
    let rule = if path.is_dir() {
        "everyone allow read,execute,file_inherit,directory_inherit"
    } else {
        "everyone allow read,execute"
    };
    assert!(
        Command::new("/bin/chmod")
            .args(["+a", rule])
            .arg(path)
            .status()
            .unwrap()
            .success()
    );
    assert_eq!(fs::metadata(path).unwrap().mode() & 0o077, 0);
}

#[cfg(target_os = "linux")]
fn add_posix_acl(path: &Path, default: bool) {
    // Linux POSIX ACL xattr v2: named nobody read entry plus a zero group mask.
    // Unix mode bits remain private, yet there is an explicit extended ACL.
    let mut bytes = 2_u32.to_le_bytes().to_vec();
    for (tag, permissions, id) in [
        (1_u16, 7_u16, u32::MAX),
        (2, 4, 65534),
        (4, 0, u32::MAX),
        (16, 0, u32::MAX),
        (32, 0, u32::MAX),
    ] {
        bytes.extend(tag.to_le_bytes());
        bytes.extend(permissions.to_le_bytes());
        bytes.extend(id.to_le_bytes());
    }
    let file = File::open(path).unwrap();
    let name = if default {
        c"system.posix_acl_default"
    } else {
        c"system.posix_acl_access"
    };
    // SAFETY: live fd, static name, and a readable initialized byte buffer.
    assert_eq!(
        unsafe {
            libc::fsetxattr(
                file.as_raw_fd(),
                name.as_ptr(),
                bytes.as_ptr().cast(),
                bytes.len(),
                0,
            )
        },
        0,
        "{}",
        std::io::Error::last_os_error()
    );
    assert_eq!(file.metadata().unwrap().mode() & 0o077, 0);
}

#[cfg(target_os = "linux")]
fn add_acl(path: &Path) {
    add_posix_acl(path, false);
}

#[test]
fn extended_root_acl_refuses_at_admission_and_after_admission_before_any_write() {
    let root = root();
    let mut held = sink(root.path());
    add_acl(root.path());
    assert!(matches!(
        FixedSink::admit(root.path(), "v1", 256),
        Err(Error::Invalid)
    ));
    assert_eq!(
        held.publish(b"must remain private").unwrap_err(),
        Error::Invalid
    );
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 0);
}

#[test]
fn extended_staging_acl_refuses_without_repairing_or_publishing_bytes() {
    let root = root();
    let mut held = sink(root.path());
    let temporary = root.path().join(held.temporary.to_str().unwrap());
    fs::write(&temporary, b"prior partial bytes").unwrap();
    fs::set_permissions(&temporary, fs::Permissions::from_mode(0o600)).unwrap();
    add_acl(&temporary);
    assert_eq!(
        held.publish(b"secret prepared bytes").unwrap_err(),
        Error::Invalid
    );
    assert_eq!(fs::read(&temporary).unwrap(), b"prior partial bytes");
    assert!(!root.path().join("v1").exists());
}

#[test]
fn extended_destination_acl_cannot_receive_an_idempotent_success_receipt() {
    let root = root();
    let mut held = sink(root.path());
    held.publish(b"original").unwrap();
    let target = root.path().join("v1");
    add_acl(&target);
    assert_eq!(held.publish(b"original").unwrap_err(), Error::Conflict);
    assert_eq!(fs::read(&target).unwrap(), b"original");
}

#[cfg(target_os = "linux")]
#[test]
fn inheritable_posix_default_acl_refuses_before_creating_any_file() {
    let root = root();
    add_posix_acl(root.path(), true);
    assert!(matches!(
        FixedSink::admit(root.path(), "v1", 256),
        Err(Error::Invalid)
    ));
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 0);
}

#[test]
fn exact_publication_and_reopen_are_durable_and_idempotent() {
    let root = root();
    let mut sink = sink(root.path());
    let identity = sink.identity().to_owned();
    let first = sink.publish(b"exact prepared payload").unwrap();
    assert!(!first.already_present());
    assert_eq!(first.destination(), identity);
    assert_eq!(
        first.payload_sha256(),
        crate::digest(b"exact prepared payload")
    );
    assert_eq!(first.payload_bytes(), 22);
    let original = fs::metadata(root.path().join("v1")).unwrap();
    drop(sink);
    let mut reopened = FixedSink::admit(root.path(), "v1", 256).unwrap();
    let repeated = reopened.publish(b"exact prepared payload").unwrap();
    assert!(repeated.already_present());
    assert!(same(
        &original,
        &fs::metadata(root.path().join("v1")).unwrap()
    ));
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 1);
    assert_eq!(
        fs::read(root.path().join("v1")).unwrap(),
        b"exact prepared payload"
    );
}

#[test]
fn conflicts_never_replace_existing_bytes() {
    let root = root();
    let mut sink = sink(root.path());
    sink.publish(b"original").unwrap();
    assert_eq!(sink.publish(b"different").unwrap_err(), Error::Conflict);
    assert_eq!(fs::read(root.path().join("v1")).unwrap(), b"original");
    assert!(sink.publish(b"original").unwrap().already_present());
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 1);
}

#[test]
fn bounds_and_path_admission_refuse_before_publication() {
    let root = root();
    for key in ["", "../escape", "a/b", ".hidden", "a\0b", "é"] {
        assert!(matches!(
            FixedSink::admit(root.path(), key, 256),
            Err(Error::Invalid)
        ));
    }
    assert!(matches!(
        FixedSink::admit(root.path(), "v1", 0),
        Err(Error::Invalid)
    ));
    assert!(matches!(
        FixedSink::admit(root.path(), "v1", MAX_BYTES + 1),
        Err(Error::Invalid)
    ));
    let mut sink = sink(root.path());
    assert_eq!(sink.publish(b"").unwrap_err(), Error::Invalid);
    assert_eq!(sink.publish(&[b'x'; 257]).unwrap_err(), Error::Invalid);
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 0);
    assert!(sink.publish(&[b'x'; 256]).is_ok());
}

#[test]
fn symlink_ancestors_and_replaced_roots_are_not_admission() {
    let base = root();
    let original = base.path().join("original");
    fs::create_dir(&original).unwrap();
    fs::set_permissions(&original, fs::Permissions::from_mode(0o700)).unwrap();
    symlink(&original, base.path().join("alias")).unwrap();
    assert!(matches!(
        FixedSink::admit(&base.path().join("alias"), "v1", 256),
        Err(Error::Invalid)
    ));
    let mut sink = sink(&original);
    fs::rename(&original, base.path().join("moved")).unwrap();
    fs::create_dir(&original).unwrap();
    fs::set_permissions(&original, fs::Permissions::from_mode(0o700)).unwrap();
    assert_eq!(sink.publish(b"payload").unwrap_err(), Error::Invalid);
    assert!(!original.join("v1").exists());
    assert!(!base.path().join("moved/v1").exists());
}

#[test]
fn foreign_symlink_hardlink_and_nonprivate_target_are_refused() {
    for kind in ["symlink", "hardlink", "permissions"] {
        let root = root();
        let outside = tempfile::NamedTempFile::new().unwrap();
        fs::write(outside.path(), b"protected").unwrap();
        let target = root.path().join("v1");
        match kind {
            "symlink" => symlink(outside.path(), &target).unwrap(),
            "hardlink" => fs::hard_link(outside.path(), &target).unwrap(),
            _ => {
                fs::write(&target, b"protected").unwrap();
                fs::set_permissions(&target, fs::Permissions::from_mode(0o644)).unwrap();
            }
        }
        assert!(sink(root.path()).publish(b"protected").is_err(), "{kind}");
        assert_eq!(fs::read(outside.path()).unwrap(), b"protected");
    }
}

#[test]
fn hostile_temporary_paths_cannot_modify_another_file() {
    let root = root();
    let outside = tempfile::NamedTempFile::new().unwrap();
    fs::write(outside.path(), b"protected").unwrap();
    let mut sink = sink(root.path());
    let temporary = root.path().join(sink.temporary.to_str().unwrap());
    symlink(outside.path(), &temporary).unwrap();
    assert_eq!(sink.publish(b"new").unwrap_err(), Error::Invalid);
    fs::remove_file(&temporary).unwrap();
    fs::hard_link(outside.path(), &temporary).unwrap();
    assert_eq!(sink.publish(b"new").unwrap_err(), Error::Conflict);
    assert_eq!(fs::read(outside.path()).unwrap(), b"protected");
    assert!(!root.path().join("v1").exists());
}

#[test]
fn live_temporary_owner_prevents_a_second_writer() {
    let root = root();
    let mut first = sink(root.path());
    let mut second = sink(root.path());
    first
        .publish_inner(b"one", |stage| {
            if stage == 1 {
                assert_eq!(second.publish(b"two").unwrap_err(), Error::Busy);
            }
            Ok(())
        })
        .unwrap();
    assert_eq!(fs::read(root.path().join("v1")).unwrap(), b"one");
}

#[test]
fn partial_temporary_write_can_be_repaired_from_exact_prepared_bytes() {
    let root = root();
    let mut sink = sink(root.path());
    let path = root.path().join(sink.temporary.to_str().unwrap());
    fs::write(&path, b"part").unwrap();
    fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
    assert!(
        !sink
            .publish(b"full prepared value")
            .unwrap()
            .already_present()
    );
    assert_eq!(
        fs::read(root.path().join("v1")).unwrap(),
        b"full prepared value"
    );
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 1);
}

#[test]
fn destination_created_between_prepare_and_link_is_never_overwritten() {
    for contents in [b"same".as_slice(), b"other".as_slice()] {
        let root = root();
        let mut sink = sink(root.path());
        let path = root.path().join("v1");
        let mut original = None;
        let result = sink.publish_inner(b"same", |stage| {
            if stage == 2 {
                fs::write(&path, contents).unwrap();
                fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
                original = Some(fs::metadata(&path).unwrap());
            }
            Ok(())
        });
        if contents == b"same" {
            assert!(result.unwrap().already_present());
        } else {
            assert_eq!(result.unwrap_err(), Error::Conflict);
        }
        assert!(same(&original.unwrap(), &fs::metadata(&path).unwrap()));
        assert_eq!(fs::read(&path).unwrap(), contents);
    }
}

#[test]
fn root_replacement_before_publication_withholds_receipt_and_target() {
    let base = root();
    let root = base.path().join("destination");
    fs::create_dir(&root).unwrap();
    fs::set_permissions(&root, fs::Permissions::from_mode(0o700)).unwrap();
    let mut sink = sink(&root);
    let moved = base.path().join("old");
    let result = sink.publish_inner(b"payload", |stage| {
        if stage == 2 {
            fs::rename(&root, &moved).unwrap();
            fs::create_dir(&root).unwrap();
            fs::set_permissions(&root, fs::Permissions::from_mode(0o700)).unwrap();
        }
        Ok(())
    });
    assert_eq!(result.unwrap_err(), Error::Invalid);
    assert!(!root.join("v1").exists() && !moved.join("v1").exists());
}

#[test]
fn a_fifo_cannot_block_regular_file_readback() {
    let root = root();
    let path = CString::new(root.path().join("v1").to_str().unwrap()).unwrap();
    // SAFETY: valid terminated path, fixed permission bits; test owns directory.
    assert_eq!(unsafe { libc::mkfifo(path.as_ptr(), 0o600) }, 0);
    assert_eq!(
        sink(root.path()).publish(b"payload").unwrap_err(),
        Error::Conflict
    );
}

#[test]
fn crash_child() {
    let Some(root) = std::env::var_os("SIGIL_PUBLICATION_TEST_ROOT") else {
        return;
    };
    let stage: u8 = std::env::var("SIGIL_PUBLICATION_TEST_CUT")
        .unwrap()
        .parse()
        .unwrap();
    sink(Path::new(&root))
        .publish_inner(b"durably prepared bytes", |cut| {
            if cut == stage {
                std::process::exit(91);
            }
            Ok(())
        })
        .unwrap();
    panic!("the requested real process cut was not reached");
}

#[test]
fn process_death_at_each_publication_boundary_recovers_without_duplicate_or_overwrite() {
    for stage in 1..=6 {
        let root = root();
        let status = Command::new(std::env::current_exe().unwrap())
            .args(["--exact", "publication::tests::crash_child", "--nocapture"])
            .env("SIGIL_PUBLICATION_TEST_ROOT", root.path())
            .env("SIGIL_PUBLICATION_TEST_CUT", stage.to_string())
            .status()
            .unwrap();
        assert_eq!(status.code(), Some(91), "stage {stage}");
        let before = fs::metadata(root.path().join("v1")).ok();
        let mut sink = sink(root.path());
        let receipt = sink.publish(b"durably prepared bytes").unwrap();
        assert_eq!(receipt.already_present(), stage >= 3);
        if let Some(before) = before {
            assert!(same(
                &before,
                &fs::metadata(root.path().join("v1")).unwrap()
            ));
        }
        assert_eq!(
            fs::read(root.path().join("v1")).unwrap(),
            b"durably prepared bytes"
        );
        for _ in 0..5 {
            assert!(
                sink.publish(b"durably prepared bytes")
                    .unwrap()
                    .already_present()
            );
        }
        assert_eq!(fs::read_dir(root.path()).unwrap().count(), 1);
    }
}
