//! Real reservation/claim/effect machinery with controlled protocol processes.
//! Grantless compiled export policy and successor publication are separate gates.
use super::*;
use crate::claimed::audit_tests::formatter;
use crate::claimed::completion_tests::{fund_parent_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, process_guard};
use std::os::unix::fs::PermissionsExt;

fn unchanged(
    actual: sigil_durable_store::store::reservation::witness::Snapshot,
    expected: &sigil_durable_store::store::reservation::witness::Snapshot,
) {
    assert_eq!(actual.revision, expected.revision);
    assert_eq!(actual.binding, expected.binding);
    assert_eq!(actual.origin, expected.origin);
    assert_eq!(actual.credits, expected.credits);
    assert_eq!(actual.assignment, expected.assignment);
}

fn budget() -> Budget {
    Budget {
        payload_bytes: 512,
        preparation: Credits {
            records: 3,
            live_bytes: 40_000,
        },
        acknowledgement: Credits {
            records: 3,
            live_bytes: 25_000,
        },
    }
}
fn ledger(store: &Store) -> Ledger {
    Ledger::new(
        store,
        "exports",
        "exports.heads",
        "exports.entries",
        &"b".repeat(64),
        ChainLimits {
            payload_bytes: 1024,
            records: 10,
            bytes: 1_000_000,
        },
        b"native-export-test-key-never-a-pilot-0123456789",
    )
    .unwrap()
}
fn setup(
    records: u64,
) -> (
    Fixture,
    Recorder,
    CompletionCredit,
    FixedSink,
    crate::WorkerConfig,
) {
    setup_fixture(Fixture::export_fenced(records))
}

fn setup_fixture(
    fixture: Fixture,
) -> (
    Fixture,
    Recorder,
    CompletionCredit,
    FixedSink,
    crate::WorkerConfig,
) {
    let (f, mut recorder, mut credit, _) = fund_parent_fixture(fixture);
    credit.budget.claim = Credits {
        records: 4,
        live_bytes: 20_000,
    };
    credit.budget.result = Credits {
        records: 3,
        live_bytes: 25_000,
    };
    credit = credit.with_result_limit(1024).unwrap();
    recorder.enable_dispatch_journal(&f.store, "api").unwrap();
    let path = f.directory.path().join("sink");
    std::fs::create_dir(&path).unwrap();
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700)).unwrap();
    let sink = FixedSink::admit(&path.canonicalize().unwrap(), "delivery", 512).unwrap();
    let policy_root = f.directory.path().join("export-policy");
    std::fs::create_dir(&policy_root).unwrap();
    let policy = formatter(&policy_root, 0);
    (f, recorder, credit, sink, policy)
}

#[test]
fn guarded_permit_refuses_missing_changed_or_replaced_source_before_claim() {
    let _serial = process_guard();
    for case in ["missing_capability", "changed", "replaced", "restored"] {
        let (mut f, mut recorder, credit, sink, policy) = setup(64);
        let root = f.directory.path().join("external");
        std::fs::create_dir(&root).unwrap();
        std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
        let path = root.join("intent");
        std::fs::write(&path, b"original").unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
        let source = FixedSource::admit(&root.canonicalize().unwrap(), "intent", 1024).unwrap();
        let observation = source.observe().unwrap();
        let scope = owner(&f.store);
        let l = ledger(&f.store);
        let before = f
            .store
            .reservation_snapshot(&scope, "funds", "operation:1")
            .unwrap();
        let permit = l
            .reserve_amounts_inner(
                &mut f.store,
                &scope,
                &credit,
                &sink,
                &policy,
                budget(),
                Some(&observation),
            )
            .unwrap();
        let export_key = format!("funds:{}", permit.intent_binding());
        let export_before = f
            .store
            .reservation_snapshot(&l.scope, "exports", &export_key)
            .unwrap();
        match case {
            "changed" => std::fs::write(&path, b"modified").unwrap(),
            "restored" => {
                std::fs::write(&path, b"modified").unwrap();
                std::fs::write(&path, b"original").unwrap();
            }
            "replaced" => {
                let other = root.join("other");
                std::fs::write(&other, b"original").unwrap();
                std::fs::set_permissions(&other, std::fs::Permissions::from_mode(0o600)).unwrap();
                std::fs::rename(&other, &path).unwrap();
            }
            _ => {}
        }
        let mut attempt = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            execution(),
        )
        .unwrap();
        attempt.attach_funding(credit).unwrap();
        let result = if case == "missing_capability" {
            permit.run_recorded(&mut attempt, &mut recorder, &AtomicBool::new(false))
        } else {
            permit.run_recorded_guarded(
                &mut attempt,
                &mut recorder,
                &AtomicBool::new(false),
                &source,
            )
        };
        assert_eq!(result.err(), Some("export_external_source"));
        drop(attempt);
        assert_eq!(
            f.store
                .get(&scope, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
        assert!(!f.directory.path().join("started").exists());
        unchanged(
            f.store
                .reservation_snapshot(&scope, "funds", "operation:1")
                .unwrap(),
            &before,
        );
        unchanged(
            f.store
                .reservation_snapshot(&l.scope, "exports", &export_key)
                .unwrap(),
            &export_before,
        );
    }
}

#[test]
fn future_export_transaction_limits_refuse_before_funding_or_effect() {
    use sigil_durable_store::store::Limits;
    let _serial = process_guard();
    for (items, value_bytes, batch_bytes) in [
        (6, 2 * 1024 * 1024, 8 * 1024 * 1024),
        (7, 2 * 1024 * 1024, 8 * 1024 * 1024),
        (9, 2 * 1024 * 1024, 8 * 1024 * 1024),
        (64, 8192, 8 * 1024 * 1024),
        (64, 10000, 18431),
    ] {
        let fixture = Fixture::export_fenced_with_limits(
            64,
            Limits {
                batch_items: items,
                value_bytes,
                batch_bytes,
                ..Limits::default()
            },
        );
        let (mut f, _recorder, credit, sink, policy) = setup_fixture(fixture);
        let l = ledger(&f.store);
        let scope = owner(&f.store);
        let before = f
            .store
            .reservation_snapshot(&scope, "funds", "operation:1")
            .unwrap();
        assert_eq!(
            l.reserve_amounts(&mut f.store, &scope, &credit, &sink, &policy, budget())
                .err(),
            Some("export_limits")
        );
        assert_eq!(
            f.store
                .get(&l.scope, "exports.heads", &l.chain)
                .unwrap()
                .revision,
            0
        );
        assert_eq!(
            f.store
                .get(&scope, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
        unchanged(
            f.store
                .reservation_snapshot(&scope, "funds", "operation:1")
                .unwrap(),
            &before,
        );
        assert!(!f.directory.path().join("started").exists());
    }
}

#[test]
fn separate_export_obligation_precedes_claim_and_survives_execution_credit_return() {
    let _serial = process_guard();
    let (mut f, mut recorder, credit, sink, policy) = setup(64);
    let owner = owner(&f.store);
    let ledger = ledger(&f.store);
    let original = f
        .store
        .reservation_snapshot(&owner, "funds", "operation:1")
        .unwrap();
    let permit = ledger
        .reserve_amounts(&mut f.store, &owner, &credit, &sink, &policy, budget())
        .unwrap();
    let export_key = format!("funds:{}", permit.intent_binding());
    let before = f
        .store
        .reservation_snapshot(&ledger.scope, "exports", &export_key)
        .unwrap();
    assert_eq!(
        before.credits,
        Credits {
            records: 6,
            live_bytes: 65_000,
        },
    );
    unchanged(
        f.store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap(),
        &original,
    );
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert!(!f.directory.path().join("started").exists());
    assert!(!f.directory.path().join("sink/delivery").exists());
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(credit).unwrap();
    let recorded = permit
        .run_recorded(&mut attempt, &mut recorder, &AtomicBool::new(false))
        .unwrap();
    assert_eq!(recorded.phase.as_deref(), Some("2"));
    assert!(recorded.recording_error.is_none());
    assert!(attempt.take_returned_credit().is_some());
    drop(attempt);
    assert!(f.directory.path().join("started").exists());
    unchanged(
        f.store
            .reservation_snapshot(&ledger.scope, "exports", &export_key)
            .unwrap(),
        &before,
    );
    assert!(
        f.store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap()
            .assignment
            .is_empty()
    );
    assert!(!f.directory.path().join("sink/delivery").exists());
    assert_eq!(
        ledger
            .log
            .verify(
                &mut f.store,
                &ledger.scope,
                &ledger.chain,
                None,
                Instant::now() + Duration::from_secs(1)
            )
            .unwrap()
            .count,
        1
    );
}

#[test]
fn exhausted_or_invalid_export_obligation_leaves_original_execution_untouched() {
    let _serial = process_guard();
    for case in [
        "full_pool",
        "preparation_records",
        "preparation_bytes",
        "ack_bytes",
        "guest_grant",
        "changed_policy",
        "scope",
    ] {
        let (mut f, _recorder, credit, sink, mut policy) =
            setup(if case == "full_pool" { 13 } else { 64 });
        let owner = owner(&f.store);
        let ledger = ledger(&f.store);
        let original = f
            .store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap();
        let mut budget = budget();
        match case {
            "preparation_records" => budget.preparation.records = 2,
            "preparation_bytes" => budget.preparation.live_bytes = 1,
            "ack_bytes" => budget.acknowledgement.live_bytes = 1,
            "guest_grant" => policy.net.push("127.0.0.1".into()),
            "changed_policy" => {
                std::fs::write(&policy.source, "changed").unwrap();
            }
            _ => {}
        }
        let empty = f
            .store
            .scope(BTreeMap::from([("api".into(), Access::Read)]))
            .unwrap();
        assert!(
            ledger
                .reserve_amounts(
                    &mut f.store,
                    if case == "scope" { &empty } else { &owner },
                    &credit,
                    &sink,
                    &policy,
                    budget
                )
                .is_err(),
            "{case}"
        );
        unchanged(
            f.store
                .reservation_snapshot(&owner, "funds", "operation:1")
                .unwrap(),
            &original,
        );
        assert_eq!(
            f.store
                .get(&ledger.scope, "exports.heads", &ledger.chain)
                .unwrap()
                .revision,
            0,
            "{case}"
        );
        assert_eq!(
            f.store
                .get(&owner, "claim", "operation:1")
                .unwrap()
                .revision,
            0,
            "{case}"
        );
        assert!(!f.directory.path().join("started").exists(), "{case}");
        assert!(!f.directory.path().join("sink/delivery").exists(), "{case}");
    }
}

#[test]
fn changed_export_admission_cannot_arm_an_effect() {
    let _serial = process_guard();
    let (mut f, mut recorder, credit, sink, policy) = setup(64);
    let owner = owner(&f.store);
    let ledger = ledger(&f.store);
    let permit = ledger
        .reserve_amounts(&mut f.store, &owner, &credit, &sink, &policy, budget())
        .unwrap();
    f.store
        .commit(
            &ledger.scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "exports".into(),
                    key: format!("admit:{}", permit.intent_binding()),
                    revision: 1,
                    value: Some("replaced admission".into()),
                }],
            },
        )
        .unwrap();
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(credit).unwrap();
    assert_eq!(
        permit
            .run_recorded(&mut attempt, &mut recorder, &AtomicBool::new(false))
            .err(),
        Some("export_admission")
    );
    drop(attempt);
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert!(!f.directory.path().join("started").exists());
}

#[test]
#[ignore = "actual compiled SIGIL policy supplied by the Python fixture"]
fn actual_sigil_export_budget_precedes_dispatch_and_is_independently_checked() {
    let _serial = process_guard();
    let fixture: serde_json::Value = serde_json::from_slice(
        &std::fs::read(std::env::var("SIGIL_EXPORT_POLICY_FIXTURE").unwrap()).unwrap(),
    )
    .unwrap();
    let (mut f, mut recorder, credit, sink, _) = setup(64);
    let caller = owner(&f.store);
    let ledger = ledger(&f.store);
    let config: crate::WorkerConfig = serde_json::from_value(fixture["policy"].clone()).unwrap();
    let mut policy = Policy::new(config).unwrap();
    let permit = ledger.reserve(&mut f.store, &caller, &credit, &sink, &mut policy);
    assert!(!f.directory.path().join("started").exists());
    assert!(!f.directory.path().join("sink/delivery").exists());
    if fixture["expect"] == "underfunded" {
        assert_eq!(permit.err(), Some("export_budget"));
        assert_eq!(
            f.store
                .get(&caller, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
        assert_eq!(
            f.store
                .get(&ledger.scope, "exports.heads", &ledger.chain)
                .unwrap()
                .revision,
            0
        );
    } else {
        assert_eq!(fixture["expect"], "admitted");
        let permit = permit.unwrap();
        assert_eq!(permit.admission.payload_bytes, 512);
        let held_before = permit.held.credits();
        let mut attempt = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            execution(),
        )
        .unwrap();
        attempt.attach_funding(credit).unwrap();
        let completed = permit
            .run_recorded(&mut attempt, &mut recorder, &AtomicBool::new(false))
            .unwrap();
        assert_eq!(completed.phase.as_deref(), Some("2"));
        assert!(completed.recording_error.is_none());
        assert!(attempt.take_returned_credit().is_some());
        drop(attempt);
        assert_eq!(
            f.store
                .reservation_snapshot(
                    &ledger.scope,
                    "exports",
                    &format!("funds:{}", permit.intent_binding())
                )
                .unwrap()
                .credits,
            held_before
        );
    }
}
