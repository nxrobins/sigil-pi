"""One real local-model follow-up on a completed synthetic long-history fixture.

The eight priming turns are fixtures, not real-model benchmark successes. The
unchanged admitted service is reopened and its existing loopback endpoint is
served by a fixed local relay. No application state or configuration is edited.
"""

import argparse
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import select
import sqlite3
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
from acceptance.capacity_evidence import inspect_capacity, assert_returned
from api_support import TOKEN_A
from test_completion_capacity_service import AUDIT_KEY
from turn_support import fields


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def request(port, method, path, body=None, token=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=65)
    try:
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = "Bearer " + token
        conn.request(method, path, json.dumps(body).encode() if body is not None else None, headers)
        response = conn.getresponse()
        raw = response.read(2**21 + 1)
        assert len(raw) <= 2**21
        return response.status, json.loads(raw)
    finally:
        conn.close()


def capture(deployment):
    with sqlite3.connect(f"file:{deployment / 'records/records.sqlite'}?mode=ro", uri=True) as db:
        return [{"namespace": ns, "key": key, "revision": rev, "value": bytes(value).decode()}
                for ns, key, rev, value in db.execute("SELECT namespace,key,revision,value FROM records ORDER BY namespace,key")]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deployment", required=True, type=Path)
    parser.add_argument("--host", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--profile", type=Path, default=ROOT / "config/context-window-development.json")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        parser.error("--execute is required for a real local-model call")
    root, deployment = args.output.resolve(), args.deployment.resolve(strict=True)
    root.mkdir(parents=True, exist_ok=False)
    config_path = deployment / "service.json"
    config = json.loads(config_path.read_text())
    credential = fields(config["credentials"][0]["facts"], "CF2\n", 15)
    cfg = fields(fields(credential[14], "BP1\n", 5)[0], "PC1\n", 7)
    endpoint = urlsplit(fields(config["automatic"]["participants"][0]["effects"]["provider"]["policy"]["binding"], "EB1\n", 7)[4])
    assert endpoint.scheme == "http" and endpoint.hostname == "127.0.0.1" and endpoint.path == "/v1/messages"
    assert endpoint.port and endpoint.port != 11434
    assert config["credentials"][0]["sha256"] == hashlib.sha256(TOKEN_A.encode()).hexdigest()
    profile = json.loads(args.profile.read_text())
    code, installed = request(11434, "GET", "/api/tags")
    assert code == 200 and cfg[0] == profile["model"]
    model = next(m for m in installed["models"] if m["name"] == cfg[0])
    assert model["digest"] == profile["model_digest"]
    before = capture(deployment)
    save(root / "records-before.json", before)
    current = next(row for row in before if row["namespace"] == "workspace.state")
    history = fields(current["value"], "PT1\n", 17)[5]
    assert "[SIGIL context notice]" in history and "retained-turn-7:" in history and "retained-turn-0:" not in history
    archives = [r for r in before if r["namespace"] == "workspace.state.archive"]
    assert len(archives) == 7
    report = {"status": "started", "qualification": False, "model": model,
              "limitations": ["Eight synthetic priming turns; only this follow-up uses the real model",
                              "One API context-continuity case, not the frozen MVP benchmark",
                              "Older-context retrieval is exercised through the API; no model recall tool is claimed"],
              "inputs": {str(config_path): hashlib.sha256(config_path.read_bytes()).hexdigest(),
                         str(args.profile.resolve()): hashlib.sha256(args.profile.read_bytes()).hexdigest(),
                         str(args.host.resolve()): hashlib.sha256(args.host.read_bytes()).hexdigest()}, "relay": []}
    for p in deployment.glob("*.sigil"):
        report["inputs"][str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    save(root / "report.json", report)

    class Relay(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_POST(self):
            assert self.path == "/v1/messages"
            self.connection.settimeout(65)
            size = int(self.headers.get("Content-Length", "0"))
            assert 0 < size <= 2**20
            raw = self.rfile.read(size)
            body = json.loads(raw)
            assert body["model"] == cfg[0]
            conn = http.client.HTTPConnection("127.0.0.1", 11434, timeout=65)
            started = time.monotonic()
            try:
                conn.request("POST", "/v1/messages", raw, {"Content-Type": "application/json", "anthropic-version": "2023-06-01"})
                response = conn.getresponse()
                output = response.read(2**20 + 1)
                assert len(output) <= 2**20
                report["relay"].append({"request": body, "response": json.loads(output),
                                        "status": response.status, "elapsed_s": time.monotonic() - started})
                self.send_response(response.status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(output)))
                self.end_headers()
                self.wfile.write(output)
            finally:
                conn.close()

    relay = ThreadingHTTPServer(("127.0.0.1", endpoint.port), Relay)
    threading.Thread(target=relay.serve_forever, daemon=True).start()
    proc = None
    err = (root / "host-stderr.log").open("w")
    try:
        env = {**os.environ, "SIGIL_PI_LOCAL_PROVIDER_TOKEN": "local-placeholder", "SIGIL_PI_AUDIT_KEY": AUDIT_KEY.decode()}
        proc = subprocess.Popen([str(args.host), "open", str(config_path), "0"], stdout=subprocess.PIPE, stderr=err, text=True, env=env)
        ready, _, _ = select.select([proc.stdout], [], [], 45)
        assert ready, "service startup timeout"
        service = json.loads(proc.stdout.readline())
        assert service["status"] == "ready"
        port = int(service["address"].split(":")[-1])
        prompt = "From the immediately preceding assistant reply, what exact label appeared before the long filler? Reply only with that label, including its numeric suffix. Do not use tools or repeat the filler."
        code, accepted = request(port, "POST", "/v1/operations", {"session": "long", "submission_key": "real-continuity-1", "message": prompt}, TOKEN_A)
        report["acceptance"] = {"code": code, "body": accepted}
        assert code == 202
        deadline = time.monotonic() + 330
        while time.monotonic() < deadline:
            code, result = request(port, "GET", accepted["status_url"], token=TOKEN_A)
            assert code == 200
            if result["status"] != "accepted":
                break
            time.sleep(0.5)
        else:
            raise TimeoutError("real follow-up did not settle")
        report["result"] = result
        assert result["status"] == "done" and result["reply"].strip().strip('`') in {"retained-turn-7", "retained-turn-7:"}, result
        first = next(r for r in archives if fields(fields(r["value"], "HA1\n", 6)[4], "PT1\n", 17)[9].startswith("retained-turn-0:"))
        code, archived = request(port, "GET", "/v1/sessions/long/archives?operation=" + first["key"].split(":")[1], token=TOKEN_A)
        assert code == 200 and archived["operation_result"]["reply"].startswith("retained-turn-0:")
        report["older_archive"] = archived
        report["capacity"] = inspect_capacity(deployment, AUDIT_KEY)
        assert_returned(report["capacity"])
        assert report["relay"] and all(r["status"] == 200 for r in report["relay"])
        report["status"] = "passed"
    except BaseException as exc:
        report["status"] = "failed"
        report["error"] = repr(exc)
        raise
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        err.close()
        relay.shutdown()
        relay.server_close()
        save(root / "records-after.json", capture(deployment))
        save(root / "report.json", report)


if __name__ == "__main__":
    main()
