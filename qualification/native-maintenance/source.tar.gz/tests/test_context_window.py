"""Real compiled SIGIL reduction, with exact pre-reduction archive assertions."""

import json
import pytest

from conftest import SIGIL_ROOT, forge_ok
from scripts.compose_context_window import compose_context_window
from scripts.compose_lifecycle import compose_lifecycle
from scripts.compose_workspace import compose_workspace
from scripts.build_workspace_deployment import specifications
from test_admission import incoming
from test_history_archive import preceding
from turn_support import FUEL, configuration, event, fields, record, run, submission


@pytest.fixture(scope="module")
def program():
    return compose_context_window("admission", SIGIL_ROOT).text


def user(text):
    return {"role": "user", "content": text}


def assistant(text):
    return {"role": "assistant", "content": [{"type": "text", "text": text}]}


def proposal(mcp, program, history, *, phase="done"):
    args = preceding(mcp, compose_lifecycle("admission", SIGIL_ROOT).text, phase=phase)
    state = fields(args["prior"], "PT1\n", 17)
    state[5] = json.dumps(history, ensure_ascii=False, separators=(",", ":"))
    args["prior"] = record("PT1\n", state)
    answer = fields(forge_ok(mcp, program, incoming(**args), fuel=FUEL), "AD2\n", 4)
    assert answer[0] == "ok"
    writes = json.loads(answer[1])["writes"]
    assert fields(writes[-1]["value"], "HA1\n", 6)[4] == args["prior"]
    current = fields(writes[2]["value"], "PT1\n", 17)
    intent = fields(writes[3]["value"], "SI1\n", 5)
    model_request = json.loads(intent[4])
    assert model_request["thinking"] == {"type": "disabled"}
    sent = model_request["messages"]
    assert sent == json.loads(current[5])
    assert sent[-1] == user("Follow up")
    return sent


def test_small_followup_context_is_exactly_preserved(mcp, program):
    history = [user("Remember café 一"), assistant("I remember café 一")]
    assert proposal(mcp, program, history)[:-1] == history


@pytest.mark.parametrize("count,width", [(40, 20), (8, 6000)])
def test_context_keeps_recent_complete_turns_with_explicit_retrieval_notice(mcp, program, count, width):
    history = []
    for i in range(count):
        history.extend([user(f"question-{i}"), assistant(f"answer-{i}:" + "x" * width)])
    sent = proposal(mcp, program, history)
    assert sent[0]["content"].startswith("[SIGIL context notice]")
    assert "/v1/sessions/same-session/archives" in sent[0]["content"]
    assert "uncertain" in sent[0]["content"]
    assert sent[-3:-1] == history[-2:]
    assert len(sent) <= 66
    assert len(json.dumps(sent, separators=(",", ":")).encode()) < 34000
    assert len(sent) < len(history) + 1


def test_one_oversized_prior_turn_is_archived_whole_and_omitted_whole(mcp, program):
    history = [user("large prior task"), assistant("x" * 40000)]
    sent = proposal(mcp, program, history)
    assert len(sent) == 2 and sent[0]["content"].startswith("[SIGIL context notice]")
    assert "x" * 100 not in json.dumps(sent)


def test_window_never_cuts_between_model_calls_and_observed_results(mcp, program):
    history = [user("old"), assistant("x" * 33000), user("recent task")]
    history.extend([
        {"role": "assistant", "content": [{"type": "tool_use", "id": "read-1", "name": "read_file", "input": {"path": "README.md"}}]},
        {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "read-1", "content": "observed marker"}]},
        assistant("recent answer"),
    ])
    sent = proposal(mcp, program, history)
    assert sent[1:-1] == history[2:]


@pytest.mark.parametrize("phase", ["failed", "uncertain", "cancelled"])
def test_reduction_keeps_latest_truthful_terminal_notice(mcp, program, phase):
    sent = proposal(mcp, program, [user("old"), assistant("x" * 40000)], phase=phase)
    assert sent[-2]["content"] == f"Previous operation ended with status {phase} and reason interrupted"
    assert sent[0]["content"].startswith("[SIGIL context notice]")


def test_actual_unknown_tool_transition_stays_paired_after_reduction(mcp):
    source = compose_context_window("turn", SIGIL_ROOT).text
    cfg = configuration(tools=specifications(), history_cap=131072)
    first = run(mcp, source, event(config=cfg))
    call = {"type": "tool_use", "id": "edit-1", "name": "edit_file",
            "input": {"path": "a", "old": "x", "new": "y"}}
    pending = run(mcp, source, first.result(json.dumps({"content": [call]})))
    stopped = run(mcp, source, pending.result(kind="unknown"))
    state = fields(stopped.state, "PT1\n", 17)
    retained = json.loads(state[5])
    state[5] = json.dumps([user("older exchange"), assistant("x" * 33000), *retained])
    follow = run(mcp, source, event(prior=record("PT1\n", state), config=cfg,
        operation="new-operation", payload=submission("Inspect actual state", key="new-key")))
    messages = json.loads(follow.input)["messages"]
    assert messages[0]["content"].startswith("[SIGIL context notice]")
    assert messages[-4]["content"] == [call]
    result = messages[-3]["content"][0]
    assert result["tool_use_id"] == "edit-1" and result["is_error"] is True
    assert "may have run" in result["content"]
    assert "uncertain" in messages[-2]["content"]


def test_truncated_model_tool_proposal_is_paired_as_not_executed_on_followup(mcp):
    source = compose_context_window("turn", SIGIL_ROOT).text
    cfg = configuration(tools=specifications(), history_cap=131072)
    first = run(mcp, source, event(config=cfg))
    call = {"type": "tool_use", "id": "edit-never-sent", "name": "edit_file",
            "input": {"path": "a", "old": "x", "new": "y"}}
    stopped = run(mcp, source, first.result(json.dumps({"content": [call], "stop_reason": "max_tokens",
        "usage": {"input_tokens": 4, "output_tokens": 8}})))
    assert stopped.action == "failed" and stopped.tool == stopped.input == ""
    assert stopped.values[14] == "model_output_limit" and stopped.values[6] == "[]"
    follow = run(mcp, source, event(prior=stopped.state, config=cfg,
        operation="new-operation", payload=submission("Continue", key="new-key")))
    messages = json.loads(follow.input)["messages"]
    assert messages[-4]["content"] == [call]
    result = messages[-3]["content"][0]
    assert result["tool_use_id"] == call["id"] and result["is_error"]
    assert result["content"].startswith("Not executed:") and "before dispatch" in result["content"]
    assert "may have run" not in result["content"]
    assert "model_output_limit" in messages[-2]["content"]


def test_retained_previous_build_result_never_authorizes_current_turn(mcp, program):
    call = {"type": "tool_use", "id": "check", "name": "build_project", "input": {"path": "."}}
    result = {"type": "tool_result", "tool_use_id": "check", "content": '[build_project path="."]\nPASS: command exited 0.'}
    history = [user("old"), assistant("x" * 33000), user("repair"),
               {"role": "assistant", "content": [call]}, {"role": "user", "content": [result]}, assistant("done")]
    sent = proposal(mcp, program, history)
    assert result in sent[-3]["content"]
    source = compose_workspace("dispatch_cancellable", SIGIL_ROOT).text.replace("pub fn tool_main(", "fn dispatch_main(")
    source += '''
pub fn tool_main(input_ptr: i64, input_len: i64) -> i64 @Internal ! { Alloc } {
    let s: i64 @Internal = alloc(136);
    put(s,5,slice(input_ptr,input_len));put(s,6,text("[]"));put(s,8,text("[]"));
    if workspace_baseline(s) { return text("yes"); } return text("no");
}
'''
    assert forge_ok(mcp, source, json.dumps(sent), fuel=FUEL) == "no"
    assert forge_ok(mcp, source, json.dumps(sent[:-1]), fuel=FUEL) == "yes"
