use super::*;
use crate::policy::Key;
use crate::reservation_identity::Identity;
use sigil_durable_store::store::{
    Limits, Mutation, OpenMode,
    capacity::{Allocation, Pool},
    reservation::{Credits, Request},
};
use std::os::unix::fs::PermissionsExt;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Fixture {
    worker: WorkerConfig,
    facts: String,
    bundle: String,
    operation: String,
    terminal: Vec<Mutation>,
    report: std::path::PathBuf,
}

#[test]
#[ignore = "requires compiled SIGIL fixture and pinned evaluator"]
fn actual_sigil_retirement_requires_fresh_owner() {
    let fixture: Fixture = serde_json::from_slice(
        &std::fs::read(std::env::var("SIGIL_RETIREMENT_FIXTURE").unwrap()).unwrap(),
    )
    .unwrap();
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let p = d.path().join(name);
        std::fs::create_dir(&p).unwrap();
        std::fs::set_permissions(p, std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let data = d.path().join("data").canonicalize().unwrap();
    let authority = d.path().join("authority").canonicalize().unwrap();
    let open = |mode| {
        Store::open_anchored_reserved_bound(
            &data,
            &authority,
            mode,
            Limits::default(),
            Allocation {
                version: 1,
                pools: vec![Pool {
                    id: "pool".into(),
                    namespaces: vec![
                        "a.operations".into(),
                        "a.reservation".into(),
                        "a.budget".into(),
                    ],
                    records: 100,
                    live_bytes: 1_000_000,
                }],
            },
            [3; 32],
            BTreeMap::from([("pool".into(), 1)]),
        )
    };
    let grants = || {
        BTreeMap::from([
            ("a.operations".into(), Access::ReadWrite),
            ("a.reservation".into(), Access::ReadWrite),
            ("a.budget".into(), Access::ReadWrite),
        ])
    };
    let mut store = open(OpenMode::CreateNew).unwrap();
    let scope = store.scope(grants()).unwrap();
    let bound = frame(
        "GB1\n",
        &[
            "a.reservation",
            &fixture.operation,
            "pool",
            "0",
            "1",
            &fixture.operation,
        ],
    )
    .unwrap();
    let key = format!("generation:{}", fixture.operation);
    let mut seed = fixture.terminal.clone();
    for row in &mut seed {
        row.revision = 0;
    }
    seed.push(Mutation {
        namespace: "a.reservation".into(),
        key: key.clone(),
        revision: 0,
        value: Some(bound),
    });
    let request = Request {
        namespace: "a.reservation".into(),
        key: fixture.operation.clone(),
        binding: crate::digest_bytes(&fixture.operation).unwrap(),
        credits: Credits {
            records: 1,
            live_bytes: 4096,
        },
    };
    let old = store
        .commit_reserving(
            &scope,
            &Batch {
                checks: vec![],
                writes: seed,
            },
            &request,
        )
        .unwrap()
        .held
        .unwrap();
    // The operation and budget records are the actual pure settlement output.
    store
        .commit_spending(
            &scope,
            &Batch {
                checks: vec![],
                writes: fixture.terminal.clone(),
            },
            &old,
            old.credits(),
        )
        .unwrap();
    let previous = Identity::observe(&store, &scope, "a.reservation", &fixture.operation).unwrap();
    let budget = store.get(&scope, "a.budget", "active").unwrap();
    let operation = store
        .get(&scope, "a.operations", &fixture.operation)
        .unwrap();
    let accounting = store
        .get(&scope, "a.reservation", &fixture.operation)
        .unwrap();
    let transaction = |store: &Store| {
        let read = |namespace: &str, key| Input::Read {
            namespace: namespace.into(),
            key,
        };
        Transaction::new(
            Config {
                worker: fixture.worker.clone(),
                marker: "RM1\n".into(),
                values: 1,
                grants: grants(),
                inputs: vec![
                    Input::Literal {
                        value: fixture.facts.clone(),
                    },
                    Input::Literal {
                        value: fixture.bundle.clone(),
                    },
                    Input::Value { index: 0 },
                    Input::Clock,
                    read("a.operations", Key::Value { index: 0 }),
                    read("a.reservation", Key::Value { index: 0 }),
                    read(
                        "a.reservation",
                        Key::PrefixedValue {
                            prefix: "generation:".into(),
                            index: 0,
                        },
                    ),
                    Input::Reservation {
                        namespace: "a.reservation".into(),
                        key: Key::Value { index: 0 },
                    },
                ],
            },
            store,
        )
        .unwrap()
    };
    let lease = store.execution_lease().unwrap();
    let values = [fixture.operation.clone()];
    let mut policy = transaction(&store);
    assert!(matches!(
        policy.retire_generation(&mut store, &mut 0, &values),
        Err("retirement_refused")
    ));
    assert_eq!(
        store.get(&scope, "a.reservation", &key).unwrap().revision,
        1
    );
    drop(policy);
    drop(store);
    // The surviving actual lease holds the lock; dropping only SQLite is insufficient.
    assert!(open(OpenMode::Existing).is_err());
    drop(lease);
    let mut store = open(OpenMode::Existing).unwrap();
    let scope = store.scope(grants()).unwrap();
    let applied = transaction(&store)
        .retire_generation(&mut store, &mut 0, &values)
        .unwrap();
    assert_eq!(applied.context, ["retired", "unknown"]);
    assert!(applied.receipt.is_some());
    let fence = store.get(&scope, "a.reservation", &key).unwrap();
    assert_eq!(fence.revision, 2);
    assert_eq!(
        fields(fence.value.as_ref().unwrap(), "GB2\n", 9).unwrap()[4],
        "1"
    );
    assert!(
        previous
            .resume(&store, &scope, "a.reservation", &fixture.operation)
            .is_err()
    );
    assert_eq!(store.get(&scope, "a.budget", "active").unwrap(), budget);
    assert_eq!(
        store
            .get(&scope, "a.operations", &fixture.operation)
            .unwrap(),
        operation
    );
    assert_eq!(
        store
            .get(&scope, "a.reservation", &fixture.operation)
            .unwrap(),
        accounting
    );
    let next = store
        .next_reservation_generation(&scope, "a.reservation", &fixture.operation)
        .unwrap();
    assert_eq!((next.slot, next.generation), (0, 2));
    store
        .commit_reserving_generation_audited(
            &scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "a.reservation".into(),
                    key: "another-admission".into(),
                    revision: 0,
                    value: Some("new".into()),
                }],
            },
            &request,
            &[],
            &next,
        )
        .unwrap();
    assert!(
        previous
            .resume(&store, &scope, "a.reservation", &fixture.operation)
            .is_err()
    );
    assert!(
        transaction(&store)
            .retire_generation(&mut store, &mut 0, &values)
            .is_err()
    );
    std::fs::write(fixture.report, serde_json::to_vec_pretty(&serde_json::json!({
        "actual_sigil": true, "fresh_owner": true, "used_owner_refused": true,
        "old_generation_refused": true, "unknown_accounting_preserved": true, "next_generation": 2
    })).unwrap()).unwrap();
}
