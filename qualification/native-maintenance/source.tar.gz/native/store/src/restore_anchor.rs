//! Candidate protocol core. Filesystem durability and Store integration follow
//! separately; these values are private facts, never execution authority.
use sha2::{Digest, Sha256};

const MAGIC: &[u8; 16] = b"SIGIL_ANCHOR_V1\0";
pub(super) const FRAME_BYTES: usize = 256;
pub(super) type Root = [u8; 32];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Kind {
    Prepared = 1,
    Confirmed = 2,
    Aborted = 3,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Frame {
    pub(super) kind: Kind,
    pub(super) revision: u64,
    pub(super) issued: u64,
    pub(super) lineage: Root,
    pub(super) parent: Root,
    pub(super) prior: Root,
    pub(super) root: Root,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Failure {
    Corrupt,
    Domain,
    Conflict,
    Ambiguous,
    RootMismatch,
    Exhausted,
    Io,
    Denied,
    Busy,
    ReopenRequired,
}

#[path = "restore_anchor_file.rs"]
mod files;
pub(super) use files::{Anchor, Mode, cut};

impl Frame {
    pub(super) fn initial(lineage: Root, root: Root) -> Self {
        Self {
            kind: Kind::Confirmed,
            revision: 0,
            issued: 0,
            lineage,
            parent: [0; 32],
            prior: root,
            root,
        }
    }

    fn valid(&self) -> bool {
        if self.issued == 0 {
            return self.kind == Kind::Confirmed
                && self.revision == 0
                && self.parent == [0; 32]
                && self.prior == self.root;
        }
        let Some(twice) = self.issued.checked_mul(2) else {
            return false;
        };
        self.parent != [0; 32]
            && match self.kind {
                Kind::Prepared => self.revision == twice - 1 && self.prior != self.root,
                Kind::Confirmed => self.revision == twice && self.prior != self.root,
                Kind::Aborted => self.revision == twice && self.prior == self.root,
            }
    }

    pub(super) fn encode(&self) -> Result<[u8; FRAME_BYTES], Failure> {
        if !self.valid() {
            return Err(Failure::Corrupt);
        }
        let mut bytes = [0; FRAME_BYTES];
        bytes[..16].copy_from_slice(MAGIC);
        bytes[16] = self.kind as u8;
        bytes[24..32].copy_from_slice(&self.revision.to_be_bytes());
        bytes[32..40].copy_from_slice(&self.issued.to_be_bytes());
        for (at, value) in [
            (40, self.lineage),
            (72, self.parent),
            (104, self.prior),
            (136, self.root),
        ] {
            bytes[at..at + 32].copy_from_slice(&value);
        }
        let hash = Sha256::digest(&bytes[..224]);
        bytes[224..].copy_from_slice(&hash);
        Ok(bytes)
    }

    pub(super) fn decode(bytes: &[u8; FRAME_BYTES], lineage: Root) -> Result<Self, Failure> {
        if &bytes[..16] != MAGIC
            || bytes[17..24] != [0; 7]
            || bytes[168..224] != [0; 56]
            || Sha256::digest(&bytes[..224])[..] != bytes[224..]
        {
            return Err(Failure::Corrupt);
        }
        let kind = match bytes[16] {
            1 => Kind::Prepared,
            2 => Kind::Confirmed,
            3 => Kind::Aborted,
            _ => return Err(Failure::Corrupt),
        };
        let value = Self {
            kind,
            revision: u64::from_be_bytes(bytes[24..32].try_into().unwrap()),
            issued: u64::from_be_bytes(bytes[32..40].try_into().unwrap()),
            lineage: bytes[40..72].try_into().unwrap(),
            parent: bytes[72..104].try_into().unwrap(),
            prior: bytes[104..136].try_into().unwrap(),
            root: bytes[136..168].try_into().unwrap(),
        };
        if value.lineage != lineage {
            return Err(Failure::Domain);
        }
        if !value.valid() {
            return Err(Failure::Corrupt);
        }
        Ok(value)
    }

    pub(super) fn digest(&self) -> Root {
        Sha256::digest(self.encode().expect("validated internal anchor frame")).into()
    }

    pub(super) fn prepare(&self, proposed: Root) -> Result<Self, Failure> {
        if !self.valid() || self.kind == Kind::Prepared || proposed == self.root {
            return Err(Failure::Conflict);
        }
        let issued = self.issued.checked_add(1).ok_or(Failure::Exhausted)?;
        let revision = issued.checked_mul(2).ok_or(Failure::Exhausted)? - 1;
        Ok(Self {
            kind: Kind::Prepared,
            revision,
            issued,
            lineage: self.lineage,
            parent: self.digest(),
            prior: self.root,
            root: proposed,
        })
    }

    pub(super) fn resolve(&self, observed: Root) -> Result<Self, Failure> {
        if !self.valid() || self.kind != Kind::Prepared {
            return Err(Failure::Conflict);
        }
        let kind = if observed == self.root {
            Kind::Confirmed
        } else if observed == self.prior {
            Kind::Aborted
        } else {
            return Err(Failure::RootMismatch);
        };
        Ok(Self {
            kind,
            revision: self.revision.checked_add(1).ok_or(Failure::Exhausted)?,
            issued: self.issued,
            lineage: self.lineage,
            parent: self.digest(),
            prior: self.prior,
            root: observed,
        })
    }
}

/// Select authority before considering database contents. A lone prepared frame
/// is deliberately quarantined: its lost companion might contain a resolution.
pub(super) fn select(slots: &[Option<Frame>; 2]) -> Result<usize, Failure> {
    match (&slots[0], &slots[1]) {
        (None, None) => Err(Failure::Ambiguous),
        (Some(frame), None) | (None, Some(frame)) => {
            if !frame.valid() {
                return Err(Failure::Corrupt);
            }
            if frame.kind == Kind::Prepared {
                return Err(Failure::Ambiguous);
            }
            Ok(usize::from(slots[0].is_none()))
        }
        (Some(a), Some(b)) => {
            if !a.valid() || !b.valid() {
                return Err(Failure::Corrupt);
            }
            if a.lineage != b.lineage {
                return Err(Failure::Domain);
            }
            if a == b {
                return if a.kind == Kind::Prepared {
                    Err(Failure::Conflict)
                } else {
                    Ok(0)
                };
            }
            let (old, new, index) = if a.revision < b.revision {
                (a, b, 1)
            } else {
                (b, a, 0)
            };
            if old.revision.checked_add(1) != Some(new.revision) || new.parent != old.digest() {
                return Err(Failure::Conflict);
            }
            let related = if new.kind == Kind::Prepared {
                old.kind != Kind::Prepared
                    && old.issued.checked_add(1) == Some(new.issued)
                    && new.prior == old.root
            } else {
                old.kind == Kind::Prepared
                    && old.issued == new.issued
                    && old.prior == new.prior
                    && match new.kind {
                        Kind::Confirmed => new.root == old.root,
                        Kind::Aborted => new.root == old.prior,
                        Kind::Prepared => false,
                    }
            };
            if !related {
                return Err(Failure::Conflict);
            }
            Ok(index)
        }
    }
}

pub(super) fn reconcile(slots: &[Option<Frame>; 2], observed: Root) -> Result<Frame, Failure> {
    let index = select(slots)?;
    let frame = slots[index].as_ref().ok_or(Failure::Ambiguous)?;
    if frame.kind == Kind::Prepared {
        frame.resolve(observed)
    } else if frame.root == observed {
        Ok(frame.clone())
    } else {
        Err(Failure::RootMismatch)
    }
}

#[cfg(test)]
#[path = "restore_anchor_tests.rs"]
mod tests;

#[cfg(test)]
#[path = "restore_anchor_file_tests.rs"]
mod file_tests;
