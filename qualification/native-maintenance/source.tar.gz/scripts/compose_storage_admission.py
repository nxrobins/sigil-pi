"""Add the explicit SA1 storage policy to the fixed grantless admission module.

No runtime policy in Python. AV1/AP2/AV2 and the v9 entry retain their bytes;
the new host profile binds this separately composed function's exact source.
"""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact, compose_bootstrap_admission


def compose_storage_admission(repo, stdlib):
    repo = Path(repo)
    base = compose_bootstrap_admission(repo, stdlib)
    signature = compact("pub fn tool_main(input_ptr: i64, input_len: i64)")
    if base.text.count(signature) != 1:
        raise ValueError("exact original bootstrap admission entry required")
    body = base.text.replace(signature,
        "fn storage_base_admission(input_ptr: i64 @Internal, input_len: i64 @Internal)")
    fragment = repo / "app/pi/storage_admission.sigil"
    raw = fragment.read_bytes()
    text = compact(body + raw.decode())
    if len(text.encode()) > 65536 or text.count("pub fn tool_main(") != 1:
        raise ValueError("storage admission must retain source and entry ceilings")
    inputs = {**base.input_hashes,
              "app/pi/storage_admission.sigil": hashlib.sha256(raw).hexdigest(),
              "scripts/compose_storage_admission.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    return ApplicationSource(text, inputs, base.stdlib_hash)
