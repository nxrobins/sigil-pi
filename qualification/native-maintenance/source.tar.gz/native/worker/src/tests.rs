use super::*;
use std::os::unix::fs::PermissionsExt;
use std::sync::{Mutex, MutexGuard};

// These fixtures deliberately saturate pipes or hold a child until a short
// deadline. Run one at a time so another fixture's flood/spawn workload cannot
// prevent this test from reaching the phase whose behavior it is asserting.
// Concurrent cancellation remains explicitly exercised within its own fixture.
static PROCESS_FIXTURE: Mutex<()> = Mutex::new(());
pub(super) struct Fixture {
    directory: tempfile::TempDir,
    _serial: MutexGuard<'static, ()>,
}
impl std::ops::Deref for Fixture {
    type Target = tempfile::TempDir;
    fn deref(&self) -> &Self::Target {
        &self.directory
    }
}
pub(super) fn fixture(script: &str) -> (Fixture, Bridge) {
    let serial = PROCESS_FIXTURE.lock().unwrap_or_else(|e| e.into_inner());
    let dir = tempfile::tempdir().unwrap();
    let runtime = dir.path().join("runtime");
    let body = format!("#!/bin/sh\n{script}\n")
        .replace("@MARKER@", dir.path().join("seen").to_str().unwrap());
    std::fs::write(&runtime, &body).unwrap();
    std::fs::set_permissions(&runtime, std::fs::Permissions::from_mode(0o700)).unwrap();
    let source = dir.path().join("program.sigil");
    std::fs::write(&source, "module fixture;").unwrap();
    let bridge = Bridge::new(Config {
        version: 1,
        runtime,
        runtime_sha256: digest(body.as_bytes()),
        source,
        source_sha256: digest(b"module fixture;"),
        max_fuel: 300_000_000,
        max_timeout_ms: 5000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    })
    .unwrap();
    (
        Fixture {
            directory: dir,
            _serial: serial,
        },
        bridge,
    )
}
// Protocol-shape tests must reach the reply before asserting its rejection.
// Use the existing fixture ceiling; deadline-specific tests keep their short
// budgets and all expected faults and no-send assertions remain unchanged.
const PROTOCOL_TIMEOUT_MS: u64 = 5000;

const HANDSHAKE: &str =
    "read -r line\nprintf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}'\nread -r line\n";
const OK: &str = "printf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"{\\\"status\\\":\\\"ok\\\",\\\"data\\\":{\\\"output_text\\\":\\\"ok\\\"}}\"}]}}'\nwhile :; do /bin/sleep 1; done";

#[test]
fn duplicate_keys_at_any_depth_are_rejected() {
    for bad in [
        r#"{"x":1,"x":2}"#,
        r#"{"x":{"a":1,"\u0061":2}}"#,
        r#"[{"a":1,"a":2}]"#,
    ] {
        assert!(strict::parse(bad.as_bytes()).is_err());
    }
}
#[test]
fn worker_facts_are_an_explicit_non_secret_projection() {
    let (_dir, mut b) = fixture("exit 99");
    b.config.net = vec!["example.test".into()];
    b.config.fs = vec!["/workspace".into()];
    b.config
        .secret_env
        .insert("provider".into(), "PRIVATE_ENV_NAME".into());
    b.grants = json!({"secret":["provider=private-value-canary"]});
    let actual = serde_json::to_value(b.facts().unwrap()).unwrap();
    assert_eq!(
        actual,
        json!({
            "source_sha256": b.config.source_sha256,
            "runtime_sha256": b.config.runtime_sha256,
            "net":["example.test"], "fs":["/workspace"], "secret_names":["provider"],
            "max_fuel":300_000_000, "max_timeout_ms":5000,
        })
    );
    assert!(!actual.to_string().contains("PRIVATE_ENV_NAME"));
    assert!(!actual.to_string().contains("private-value-canary"));
    b.poisoned = true;
    assert!(matches!(b.facts(), Err(Fault::CleanupUnconfirmed)));
    b.poisoned = false;
    b.owner = b.owner.wrapping_add(1);
    assert!(matches!(b.facts(), Err(Fault::WrongProcess)));
}
#[test]
fn ticket_is_consumed_once_and_next_worker_is_fresh() {
    let (_dir, mut b) = fixture(&format!("{HANDSHAKE}{OK}"));
    let p = b.prepare("input".into(), 100, 2000).unwrap();
    assert_eq!(
        b.prepare("other".into(), 100, 2000).err(),
        Some(Fault::Busy)
    );
    assert_eq!(
        b.execute("wrong-ticket", &AtomicBool::new(false)).err(),
        Some(Fault::Ticket)
    );
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, None);
    assert!(o.worker_reaped && o.request_may_have_run);
    assert_eq!(o.result.unwrap()["data"]["output_text"], "ok");
    assert_eq!(
        b.execute(&p.ticket, &AtomicBool::new(false)).err(),
        Some(Fault::Ticket)
    );
    assert_ne!(
        b.prepare("next".into(), 100, 2000).unwrap().ticket,
        p.ticket
    );
}
#[test]
fn cancellation_before_start_does_not_spawn() {
    let (dir, mut b) = fixture(": > '@MARKER@'");
    let p = b.prepare("input".into(), 100, 1000).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(true)).unwrap();
    assert_eq!(o.fault, Some(Fault::Cancelled));
    assert!(!o.request_may_have_run);
    assert!(!dir.path().join("seen").exists());
}
#[test]
fn expired_ticket_never_sends_and_cannot_replay() {
    let (_dir, mut b) = fixture("exit 99");
    let p = b.prepare("input".into(), 100, 1).unwrap();
    std::thread::sleep(Duration::from_millis(5));
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Deadline));
    assert!(!o.request_may_have_run && o.worker_reaped);
    assert_eq!(
        b.execute(&p.ticket, &AtomicBool::new(false)).err(),
        Some(Fault::Ticket)
    );
}
#[test]
fn partial_response_cannot_bypass_deadline() {
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}: > '@MARKER@'; printf '{{'; /bin/sleep 20"
    ));
    // This whole-worker check must reach the partial effect response. A one-
    // second preparation can expire during startup and test another boundary.
    // Keep the existing fixture ceiling and require actual receipt and reaping;
    // the separate transport check below retains the one-second response bound.
    let start = Instant::now();
    let p = b.prepare("input".into(), 100, PROTOCOL_TIMEOUT_MS).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Deadline));
    assert!(
        o.request_may_have_run && o.worker_reaped,
        "{}",
        serde_json::to_string(&o).unwrap()
    );
    assert!(dir.path().join("seen").exists());
    // Five-second original preparation plus two-second cleanup and scheduling.
    // The fixture sleeps for twenty seconds, so merely waiting for exit fails.
    assert!(start.elapsed() < Duration::from_secs(8));
}
#[test]
fn partial_response_transport_keeps_one_second_deadline_after_handshake() {
    let (dir, b) = fixture(&format!(
        "{HANDSHAKE}: > '@MARKER@'; printf '{{'; /bin/sleep 20"
    ));
    // Exercise the actual transport after an observed handshake. This does not
    // reset a Bridge preparation: the whole-Bridge check above covers that path.
    let mut command = Command::new(&b.config.runtime);
    command.env_clear().env("LANG", "C.UTF-8").current_dir("/");
    let mut worker = Worker::spawn(&mut command).unwrap();
    let cancel = AtomicBool::new(false);
    let mut handshake_sent = false;
    assert_eq!(
        worker
            .exchange(
                &json!({"jsonrpc":"2.0","id":1,"method":"initialize"}),
                1,
                Instant::now() + Duration::from_secs(5),
                &cancel,
                &mut handshake_sent
            )
            .unwrap(),
        json!({})
    );
    assert!(handshake_sent);
    let start = Instant::now();
    let mut effect_sent = false;
    assert_eq!(
        worker.exchange(
            &json!({"jsonrpc":"2.0","id":2,"method":"tools/call"}),
            2,
            start + Duration::from_secs(1),
            &cancel,
            &mut effect_sent
        ),
        Err(Fault::Deadline)
    );
    assert!(effect_sent && dir.path().join("seen").exists());
    assert!(worker.stop());
    assert!(start.elapsed() < Duration::from_secs(4));
}
#[test]
fn partial_handshake_is_definitely_before_forge() {
    let (_dir, mut b) = fixture("printf '{'; /bin/sleep 20");
    let p = b.prepare("input".into(), 100, 100).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Deadline));
    assert!(!o.request_may_have_run && o.worker_reaped);
}
#[test]
fn blocked_request_write_is_deadline_bounded() {
    let (_dir, mut b) = fixture(
        "read -r line; printf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}'; /bin/sleep 20",
    );
    let p = b.prepare("x".repeat(1024 * 1024), 100, 1000).unwrap();
    let start = Instant::now();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Deadline));
    // A non-reading pipe may accept a prefix or refuse the entire first write;
    // neither behavior may block the deadline. Do not invent successful bytes.
    assert!(o.worker_reaped);
    assert!(start.elapsed() < Duration::from_secs(4));
}
#[test]
fn cancellation_interrupts_a_running_partial_reply() {
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}: > '@MARKER@'; printf '{{'; /bin/sleep 20"
    ));
    let p = b.prepare("input".into(), 100, 3000).unwrap();
    let cancel = std::sync::Arc::new(AtomicBool::new(false));
    let signal = cancel.clone();
    let marker = dir.path().join("seen");
    let thread = std::thread::spawn(move || {
        let until = Instant::now() + Duration::from_secs(2);
        while !marker.exists() && Instant::now() < until {
            std::thread::sleep(Duration::from_millis(2));
        }
        assert!(
            marker.exists(),
            "worker did not reach the cancellation boundary"
        );
        signal.store(true, Ordering::Release);
    });
    let o = b.execute(&p.ticket, &cancel).unwrap();
    thread.join().unwrap();
    assert_eq!(o.fault, Some(Fault::Cancelled));
    assert!(o.worker_reaped && o.request_may_have_run);
}
#[test]
fn wrong_id_duplicates_and_multiple_frames_are_retired() {
    for reply in [
        r#"{"jsonrpc":"2.0","id":3,"result":{}}"#,
        r#"{"jsonrpc":"2.0","id":2,"id":2,"result":{}}"#,
        "{\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{}}\n{}",
    ] {
        let (dir, mut b) = fixture(&format!(
            "{HANDSHAKE}: > '@MARKER@'; printf '%s\\n' '{reply}'; /bin/sleep 20"
        ));
        let p = b.prepare("input".into(), 100, PROTOCOL_TIMEOUT_MS).unwrap();
        let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
        assert_eq!(
            o.fault,
            Some(Fault::Protocol),
            "reply={reply}; received={}; sent={}",
            dir.path().join("seen").exists(),
            o.request_may_have_run
        );
        assert!(o.worker_reaped);
    }
}
#[test]
fn stderr_flood_is_bounded_and_not_returned() {
    let (_dir, mut b) = fixture(&format!(
        "{HANDSHAKE}while :; do printf 'private-stderr-canary-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\\n' >&2; done"
    ));
    let p = b.prepare("input".into(), 100, 2000).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::StderrLimit));
    assert!(o.worker_reaped);
    assert!(
        !serde_json::to_string(&o)
            .unwrap()
            .contains("private-stderr-canary")
    );
}
#[test]
fn oversized_stdout_without_a_frame_is_retired() {
    let (_dir, mut b) = fixture(&format!(
        "{HANDSHAKE}/usr/bin/head -c 16777217 /dev/zero; /bin/sleep 20"
    ));
    let p = b.prepare("input".into(), 100, 3000).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Limit));
    assert!(o.worker_reaped && o.request_may_have_run);
    assert!(o.result.is_none());
}
#[test]
fn changed_runtime_hash_prevents_start() {
    let (_dir, mut b) = fixture("exit 99");
    let p = b.prepare("input".into(), 100, 1000).unwrap();
    std::fs::write(&b.config.runtime, "changed").unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, Some(Fault::Invalid));
    assert!(!o.request_may_have_run);
}
#[test]
fn unverified_override_and_parent_secret_environment_are_not_inherited() {
    // The environment is empty regardless of ambient variables; test a generic
    // variable without mutating process-global environment in concurrent tests.
    let (_dir, mut b) = fixture(&format!(
        "{HANDSHAKE}if [ -n \"$HOME$SIGIL_ALLOW_UNVERIFIED_CERT\" ]; then exit 9; fi\n{OK}"
    ));
    let p = b.prepare("input".into(), 100, 1000).unwrap();
    let o = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(o.fault, None);
}

fn budget_schema() -> Value {
    json!({"tools":[{"name":"sigil_forge","inputSchema":{"properties":{"grants":{"properties":{
        "http_timeout_ms":{"type":"integer","minimum":1,"maximum":60000,
                           "x-sigil-http-budget":"single-request-v1"}
    }}}}}]})
}

#[test]
fn budget_worker_requires_the_versioned_single_request_contract() {
    assert_eq!(require_http_budget(&budget_schema()), Ok(()));
    for value in [json!({}), json!({"tools":[]}), json!({"tools":[{},{}]})] {
        assert_eq!(require_http_budget(&value), Err(Fault::Protocol));
    }
    for (field, bad) in [
        ("type", json!("number")),
        ("minimum", json!(0)),
        ("maximum", json!(60001)),
        ("x-sigil-http-budget", json!(null)),
    ] {
        let mut schema = budget_schema();
        schema["tools"][0]["inputSchema"]["properties"]["grants"]["properties"]["http_timeout_ms"]
            [field] = bad;
        assert_eq!(require_http_budget(&schema), Err(Fault::Protocol));
    }
    let mut duplicate = budget_schema();
    let tool = duplicate["tools"][0].clone();
    duplicate["tools"].as_array_mut().unwrap().push(tool);
    assert_eq!(require_http_budget(&duplicate), Err(Fault::Protocol));
}

#[test]
fn budget_negotiation_failure_never_sends_an_effect() {
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}printf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":3,\"result\":{{\"tools\":[]}}}}'\nread -r line\n: > '@MARKER@'"
    ));
    b.config.version = 2;
    let p = b
        .prepare("private effect input".into(), 100, PROTOCOL_TIMEOUT_MS)
        .unwrap();
    let observed = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(observed.fault, Some(Fault::Protocol));
    assert!(!observed.request_may_have_run && observed.worker_reaped);
    assert!(!dir.path().join("seen").exists());
}

#[test]
fn budget_negotiation_cannot_restart_the_prepared_deadline() {
    let (dir, mut b) = fixture(&format!("{HANDSHAKE}/bin/sleep 2\n: > '@MARKER@'"));
    b.config.version = 2;
    let p = b.prepare("input".into(), 100, 150).unwrap();
    let observed = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(observed.fault, Some(Fault::Deadline));
    assert!(!observed.request_may_have_run && observed.worker_reaped);
    assert!(!dir.path().join("seen").exists());
}

#[test]
fn budget_sent_to_runtime_uses_only_time_remaining_after_negotiation() {
    let reply = json!({"jsonrpc":"2.0","id":3,"result":budget_schema()});
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}/bin/sleep 0.1\nprintf '%s\\n' '{reply}'\nread -r line\nprintf '%s' \"$line\" > '@MARKER@'\n{OK}"
    ));
    b.config.version = 2;
    let p = b.prepare("input".into(), 100, 1500).unwrap();
    std::thread::sleep(Duration::from_millis(100));
    let observed = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(observed.fault, None);
    assert!(observed.request_may_have_run && observed.worker_reaped);
    let sent: Value =
        serde_json::from_slice(&std::fs::read(dir.path().join("seen")).unwrap()).unwrap();
    let budget = sent["params"]["arguments"]["grants"]["http_timeout_ms"]
        .as_u64()
        .unwrap();
    assert!((1..=1300).contains(&budget), "{budget}");
    assert_eq!(sent["params"]["arguments"]["input"], "input");
}

#[test]
fn budgeted_effect_is_still_killed_at_the_original_worker_deadline() {
    let reply = json!({"jsonrpc":"2.0","id":3,"result":budget_schema()});
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}printf '%s\\n' '{reply}'\nread -r line\n: > '@MARKER@'\n/bin/sleep 15\n{OK}"
    ));
    b.config.version = 2;
    // The one-second fixture could expire during startup on a busy host, which
    // exercises a different boundary. Use the existing fixture ceiling, then
    // require both actual effect receipt and bounded elapsed time: classifying
    // a late reply as Deadline without killing the worker must not pass.
    let started = Instant::now();
    let p = b.prepare("input".into(), 100, 5000).unwrap();
    let observed = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(observed.fault, Some(Fault::Deadline));
    assert!(
        observed.request_may_have_run && observed.worker_reaped,
        "{}",
        serde_json::to_string(&observed).unwrap()
    );
    assert!(dir.path().join("seen").exists());
    // Five seconds for the prepared deadline, two seconds for successful
    // cleanup, and one second of scheduling margin; the fixture replies at 15s.
    assert!(started.elapsed() < Duration::from_secs(8));
}

#[test]
fn pure_evaluation_cannot_silently_ignore_a_budgeted_effect_configuration() {
    let (_dir, b) = fixture("exit 99");
    let mut config = b.config.clone();
    config.version = 2;
    assert!(matches!(PureBridge::new(config), Err(Fault::Invalid)));
}

#[test]
fn budget_is_capped_at_the_runtime_ceiling_even_for_a_longer_preparation() {
    let reply = json!({"jsonrpc":"2.0","id":3,"result":budget_schema()});
    let (dir, mut b) = fixture(&format!(
        "{HANDSHAKE}printf '%s\\n' '{reply}'\nread -r line\nprintf '%s' \"$line\" > '@MARKER@'\n{OK}"
    ));
    b.config.version = 2;
    b.config.max_timeout_ms = 120_000;
    let p = b.prepare("input".into(), 100, 90_000).unwrap();
    let observed = b.execute(&p.ticket, &AtomicBool::new(false)).unwrap();
    assert_eq!(observed.fault, None);
    assert!(observed.worker_reaped);
    let sent: Value =
        serde_json::from_slice(&std::fs::read(dir.path().join("seen")).unwrap()).unwrap();
    assert_eq!(
        sent["params"]["arguments"]["grants"]["http_timeout_ms"],
        60_000
    );
}

#[test]
fn write_grants_require_explicit_version_and_cannot_enter_pure_workers() {
    let (_directory, bridge) = fixture("exit 99");
    let mut config = bridge.config.clone();
    config.fs_write = vec!["/workspace".into()];
    for version in [1, 2] {
        config.version = version;
        assert!(matches!(Bridge::new(config.clone()), Err(Fault::Invalid)));
    }
    config.version = 3;
    assert!(matches!(
        PureBridge::new(config.clone()),
        Err(Fault::Invalid)
    ));
    let admitted = Bridge::new(config.clone()).unwrap();
    assert_eq!(admitted.grants["fs_write"], json!(["/workspace"]));
    assert_eq!(admitted.facts().unwrap().fs_write, &["/workspace"]);
    config.fs_write = vec!["relative".into()];
    assert!(matches!(Bridge::new(config), Err(Fault::Invalid)));
}

#[test]
fn write_grants_reach_only_the_fresh_versioned_effect_worker() {
    let reply = json!({"jsonrpc":"2.0","id":3,"result":budget_schema()});
    let (dir, bridge) = fixture(&format!(
        "{HANDSHAKE}printf '%s\\n' '{reply}'\nread -r line\nprintf '%s' \"$line\" > '@MARKER@'\n{OK}"
    ));
    let mut config = bridge.config.clone();
    config.version = 3;
    config.fs = vec!["/workspace".into()];
    config.fs_write = vec!["/workspace/config".into()];
    let mut admitted = Bridge::new(config).unwrap();
    let prepared = admitted.prepare("input".into(), 100, 5000).unwrap();
    let seen = admitted
        .execute(&prepared.ticket, &AtomicBool::new(false))
        .unwrap();
    assert!(seen.worker_reaped && seen.fault.is_none());
    let sent: Value =
        serde_json::from_slice(&std::fs::read(dir.path().join("seen")).unwrap()).unwrap();
    assert_eq!(
        sent["params"]["arguments"]["grants"]["fs_write"],
        json!(["/workspace/config"])
    );
    assert_eq!(
        sent["params"]["arguments"]["grants"]["fs"],
        json!(["/workspace"])
    );
}
