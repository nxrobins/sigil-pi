# Native dispatch and terminal observations

The opt-in `dispatch_journal: "v1"` development profile retains native facts for a
funded effect. Application orchestration, allowance amounts, result classification
and recovery decisions remain in SIGIL. This component does not authorize export
or establish MVP readiness.

Bootstrap allocates a private journal namespace inside the same immutable pool as
the participant's funding and effect audit. It rejects domain, claim, delivery and
audit aliases. No credential, coordinator, transaction or effect receives a guest
write grant to the journal. Only native coupling receives create-only authority.

The actual validated claim transaction atomically writes a start fact, its signed
audit binding, the SIGIL claim and the original assignment/debit. The fact retains
the original execution domain/epoch, ticket, input/source/runtime identities and
actual clock sample. Its key identifies the individual intent, not the reusable
parent reservation. A start fact establishes the local claim boundary; it does
not establish network initiation or delivery.

The terminal transaction likewise retains a terminal clock sample and exact
terminal batch digest in a distinct create-only record. The authenticated audit
envelope binds the journal digest and complete related mutation set while keeping
the SIGIL-selected audit payload separate. Result, journal, audit and credit
updates commit together. Neither clock is reconstructed later or truncated to a
consumer codec. Clock regression causes the terminal observer to refuse.

The SIGIL profile reserves two additional records per permitted action and debits
four claim records and three result records conservatively. Before dispatch, the
native mechanism independently requires enough terminal credit for the selected,
natively enforced result limit, journal overhead and signed audit entry. Free pool
space cannot substitute for a missing held obligation. Oversized observations
remain limit faults; no partial output becomes success.

`TerminalCompletion::observe` uses existing read scopes. It verifies both complete
authenticated chains under bounded read budgets and binds the retained intent,
claim, delivery and original assignment. It remains usable after the parent
assignment clears. It exposes retained phase, status, output and clock samples
without interpreting application success. `check_prior_owner` requires the actual
same-domain store under a different execution epoch and rechecks all retained
source records. Acquiring that store still refuses while an old worker holds its
execution lease. These observations create no worker, spending or I/O authority.

A future export-only successor must bind the intended caller, source, schema and
fixed destination; reserve its own preparation/receipt obligations; revalidate
source observations at publication; persist exact prepared bytes before I/O; and
persist the real publication receipt before acknowledgment. Replays after a
consumer removes a delivered file must consult that acknowledgment. None of those
requirements is satisfied merely by possessing a terminal observation. Complete
valid rollback remains indistinguishable without an independent trusted checkpoint.
