use super::*;
use crate::claimed::completion_tests::{fund_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, process_guard};
use sigil_durable_store::store::{Access, Batch, Mutation};
use std::collections::BTreeMap;

#[test]
fn anchored_claim_witness_carries_the_actual_reservation_generation() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) =
        super::completion_tests::fund_parent_fixture(Fixture::anchored(64));
    let owner = owner(&f.store);
    let generation = funding.held.as_ref().unwrap().generation().unwrap().clone();
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared.ticket.clone();
    a.claim_recorded(&mut recorder).unwrap();
    let retained = AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").unwrap();
    assert_eq!(retained.witness.format, SLOT_FORMAT);
    assert_eq!(
        retained.witness.reservation_generation.as_ref(),
        Some(&generation)
    );
    assert_eq!(retained.snapshot.generation.as_ref(), Some(&generation));
    assert_eq!(retained.origin(), origin);
    assert!(
        a.store
            .resume_reservation(
                &owner,
                "funds",
                "operation:1",
                retained.reservation_revision(),
                retained.binding()
            )
            .is_err()
    );
    let resumed = retained.resume(a.store, &owner).unwrap();
    assert_eq!(resumed.generation(), Some(&generation));
    let observation = a.execute(&ticket, &AtomicBool::new(false)).unwrap();
    assert!(observation.worker_reaped);
    a.persist_observation(&mut recorder, Some(&observation), None)
        .unwrap();
    let returned = a.take_returned_credit().unwrap();
    assert_eq!(returned.generation(), Some(&generation));
}

#[test]
fn whole_turn_parent_is_distinct_from_and_bound_to_the_actual_intent() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) =
        super::completion_tests::fund_parent_fixture(Fixture::fenced(13));
    let owner = owner(&f.store);
    let actual = funding.intent_binding.unwrap();
    assert_ne!(actual, origin);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let retained = AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").unwrap();
    assert_eq!(retained.origin(), origin);
    assert_eq!(retained.witness.format, PARENT_FORMAT);
    assert_eq!(
        crate::digest_bytes(retained.witness.intent_binding.as_ref().unwrap()).unwrap(),
        actual
    );
    // An existing assignment cannot be used as funding for any fresh intent.
    let held = a
        .store
        .resume_reservation(
            &owner,
            "funds",
            "operation:1",
            retained.reservation_revision(),
            retained.binding(),
        )
        .unwrap();
    assert!(!held.unassigned());
    // Retaining the same reservation does not make a substituted intent valid.
    a.store
        .commit(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: "operation:1".into(),
                    revision: 1,
                    value: Some("substituted intent".into()),
                }],
            },
        )
        .unwrap();
    assert!(AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").is_err());
}

#[test]
fn actual_preparation_is_bound_to_canonical_witness_and_completion_clears_it() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) = fund_fixture(Fixture::witnessed(13), 2, "2");
    let owner = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared.ticket.clone();
    let prepared_hash = digest(a.prepared_audit.as_bytes());
    a.claim_recorded(&mut recorder).unwrap();
    let retained = AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").unwrap();
    assert_eq!(retained.origin(), origin);
    assert_ne!(retained.binding(), origin);
    assert_eq!(retained.generation(), a.prepared.generation);
    assert_eq!(retained.witness.ticket, ticket);
    assert_eq!(retained.witness.input_sha256, a.prepared.input_sha256);
    assert_eq!(retained.witness.prepared_audit_sha256, prepared_hash);
    assert_eq!(
        retained.witness.source_sha256,
        a.worker.facts().unwrap().source_sha256
    );
    assert_eq!(
        retained.witness.runtime_sha256,
        a.worker.facts().unwrap().runtime_sha256
    );
    assert_eq!(retained.reservation_revision(), 2);
    assert_eq!(
        retained.result_budget(),
        Credits {
            records: 2,
            live_bytes: 5000
        }
    );
    let observation = a.execute(&ticket, &AtomicBool::new(false)).unwrap();
    assert!(observation.worker_reaped && observation.request_may_have_run);
    a.persist_observation(&mut recorder, Some(&observation), None)
        .unwrap();
    let remaining = a.take_returned_credit().unwrap();
    drop(a);
    f.store
        .check_reservation_binding(&remaining, origin)
        .unwrap();
    let snapshot = f
        .store
        .reservation_snapshot(&owner, "funds", "operation:1")
        .unwrap();
    assert_eq!(snapshot.revision, 3);
    assert_eq!(snapshot.origin, origin);
    assert_eq!(snapshot.binding, origin);
    assert!(snapshot.assignment.is_empty());
    assert!(AssignedCompletion::observe(&f.store, &owner, "funds", "operation:1").is_err());
}

#[test]
fn retained_facts_survive_reopen_but_do_not_create_spending_authority() {
    use sigil_durable_store::store::capacity::{Allocation, Pool};
    use sigil_durable_store::store::{Limits, OpenMode};
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) = fund_fixture(Fixture::witnessed(13), 2, "2");
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let generation = a.prepared.generation.clone();
    drop(a);
    assert!(!f.directory.path().join("started").exists());
    let Fixture {
        directory, store, ..
    } = f;
    drop(store);
    let store = Store::open_witnessed_reserved_bound(
        &directory.path().join("store"),
        OpenMode::Existing,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records: 13,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
    .unwrap();
    let read = store
        .scope(
            ["intent", "claim", "funds"]
                .into_iter()
                .map(|n| (n.into(), Access::Read))
                .collect(),
        )
        .unwrap();
    let facts = AssignedCompletion::observe(&store, &read, "funds", "operation:1").unwrap();
    assert_eq!(facts.generation(), generation);
    assert_eq!(facts.origin(), origin);
    assert!(
        store
            .resume_reservation(
                &read,
                "funds",
                "operation:1",
                facts.reservation_revision(),
                facts.binding()
            )
            .is_err()
    );
    let denied = store
        .scope(BTreeMap::from([("funds".into(), Access::Read)]))
        .unwrap();
    assert!(AssignedCompletion::observe(&store, &denied, "funds", "operation:1").is_err());
}

#[test]
fn changed_actual_intent_and_mismatched_witness_cannot_be_read_as_valid_assignment() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, _) = fund_fixture(Fixture::witnessed(13), 2, "2");
    let owner = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let retained = AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").unwrap();
    drop(a);
    // A trusted native writer can supply opaque ledger bytes. Even with a
    // matching hash, noncanonical retained metadata is refused by the consumer.
    let held = f
        .store
        .resume_reservation(&owner, "funds", "operation:1", 2, retained.binding())
        .unwrap();
    let mut bytes = retained.snapshot.assignment.clone();
    bytes.push(b' ');
    let next = f
        .store
        .commit_assigning_witness(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 1,
                    value: Some("budget admitted".into()),
                }],
            },
            &held,
            Credits {
                records: 0,
                live_bytes: 0,
            },
            &[],
            assigned(retained.origin(), &bytes),
            &bytes,
        )
        .unwrap()
        .held
        .unwrap();
    assert!(AssignedCompletion::observe(&f.store, &owner, "funds", "operation:1").is_err());
    f.store
        .commit_assigning_witness(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 2,
                    value: Some("budget admitted".into()),
                }],
            },
            &next,
            Credits {
                records: 0,
                live_bytes: 0,
            },
            &[],
            retained.binding(),
            &retained.snapshot.assignment,
        )
        .unwrap();
    assert!(AssignedCompletion::observe(&f.store, &owner, "funds", "operation:1").is_ok());
    f.store
        .commit(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: "operation:1".into(),
                    revision: 1,
                    value: Some("changed".into()),
                }],
            },
        )
        .unwrap();
    assert!(AssignedCompletion::observe(&f.store, &owner, "funds", "operation:1").is_err());
}

#[test]
fn fenced_assignment_binds_actual_store_domain_epoch_and_finishes_with_actual_cleanup() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) = fund_fixture(Fixture::fenced(13), 2, "2");
    let owner = owner(&f.store);
    let (domain, epoch) = f.store.execution_identity().unwrap();
    let (domain, epoch) = (domain.to_owned(), epoch.to_owned());
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared.ticket.clone();
    a.claim_recorded(&mut recorder).unwrap();
    let retained = AssignedCompletion::observe(a.store, &owner, "funds", "operation:1").unwrap();
    assert_eq!(retained.witness.format, FENCED_FORMAT);
    let identity = retained.witness.execution.as_ref().unwrap();
    assert_eq!(identity.domain, domain);
    assert_eq!(identity.epoch, epoch);
    assert_eq!(
        retained.check_prior_owner(a.store, &owner),
        Err("execution_fence")
    );
    let observation = a.execute(&ticket, &AtomicBool::new(false)).unwrap();
    assert!(observation.worker_reaped && observation.request_may_have_run);
    a.persist_observation(&mut recorder, Some(&observation), None)
        .unwrap();
    let returned = a.take_returned_credit().unwrap();
    drop(a);
    f.store
        .check_reservation_binding(&returned, origin)
        .unwrap();
    assert!(
        f.store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap()
            .assignment
            .is_empty()
    );
}

#[test]
fn fenced_retained_assignment_needs_actual_new_owner_and_refuses_stale_recovery_facts() {
    use sigil_durable_store::store::capacity::{Allocation, Pool};
    use sigil_durable_store::store::{Limits, OpenMode};
    let _serial = process_guard();
    let (mut f, mut recorder, funding, _) = fund_fixture(Fixture::fenced(13), 2, "2");
    let owner_scope = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let retained =
        AssignedCompletion::observe(a.store, &owner_scope, "funds", "operation:1").unwrap();
    assert_eq!(
        retained.check_prior_owner(a.store, &owner_scope),
        Err("execution_fence")
    );
    drop(a);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    let old = store.execution_identity().unwrap().1.to_owned();
    drop(store);
    let reopen = || {
        Store::open_fenced_reserved_bound(
            &directory.path().join("store"),
            OpenMode::Existing,
            Limits::default(),
            Allocation {
                version: 1,
                pools: vec![Pool {
                    id: "tenant".into(),
                    namespaces: [
                        "intent",
                        "claim",
                        "delivery",
                        "funds",
                        "audit.heads",
                        "audit.entries",
                        "api",
                    ]
                    .into_iter()
                    .map(String::from)
                    .collect(),
                    records: 13,
                    live_bytes: 4_000_000,
                }],
            },
            [3; 32],
            BTreeMap::from([("tenant".into(), 8)]),
        )
    };
    assert!(matches!(
        reopen(),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    drop(worker);
    let mut store = reopen().unwrap();
    assert_ne!(store.execution_identity().unwrap().1, old);
    let owner_scope = owner(&store);
    retained.check_prior_owner(&store, &owner_scope).unwrap();
    assert!(matches!(
        recorder.recover(&mut store, &owner_scope, binding()),
        Err("funding_recovery_required")
    ));
    let held = store
        .resume_reservation(
            &owner_scope,
            "funds",
            "operation:1",
            retained.reservation_revision(),
            retained.binding(),
        )
        .unwrap();
    // A separately committed debit changes the retained generation. Merely
    // keeping an earlier observed assignment cannot authorize a later recovery.
    store
        .commit_spending(
            &owner_scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 1,
                    value: Some("budget admitted".into()),
                }],
            },
            &held,
            Credits {
                records: 0,
                live_bytes: 1,
            },
        )
        .unwrap();
    assert_eq!(
        retained.check_prior_owner(&store, &owner_scope),
        Err("funding_witness")
    );
    assert!(!directory.path().join("started").exists());
}

#[test]
fn fenced_store_refuses_unleased_and_other_domain_workers_before_preparation() {
    let _serial = process_guard();
    for leased in [false, true] {
        let mut f = Fixture::fenced(13);
        let mut other = if leased {
            Fixture::fenced(13)
        } else {
            Fixture::new()
        };
        assert!(matches!(
            Attempt::begin(
                &mut f.store,
                &f.scope,
                &mut other.worker,
                &mut f.clock,
                binding(),
                execution()
            ),
            Err("execution_fence")
        ));
        assert!(!other.directory.path().join("started").exists());
        assert_eq!(
            f.store
                .get(&f.scope, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
    }
}

#[test]
fn fenced_store_cannot_fall_back_to_unfunded_claim_or_legacy_recovery() {
    let _serial = process_guard();
    let (mut f, mut recorder, _funding, _) = fund_fixture(Fixture::fenced(13), 2, "2");
    let owner_scope = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    assert!(matches!(
        a.claim_recorded(&mut recorder),
        Err("funding_profile")
    ));
    drop(a);
    assert!(matches!(
        recorder.recover(&mut f.store, &owner_scope, binding()),
        Err("funding_recovery_required")
    ));
    assert_eq!(
        f.store
            .get(&owner_scope, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .get(&owner_scope, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        0
    );
    assert!(!f.directory.path().join("started").exists());
}
