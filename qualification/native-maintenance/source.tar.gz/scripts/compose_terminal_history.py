"""Read-only current history with the same terminal facts as archive projection."""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource, compose_application
from scripts.compose_bootstrap_admission import compact

ROOT = Path(__file__).resolve().parent.parent


def compose_terminal_history(stdlib):
    base = compose_application("history", stdlib)
    site = "let history: i64 @Internal = get(s, 5);"
    if base.text.count(site) != 1:
        raise ValueError("current history projection site changed")
    body = base.text.replace(site, """
        let mut history: i64 @Internal = get(s, 5);
        if workspace_terminal(get(s, 1)) { history = workspace_history(s); }
        if history < 0 { return history; }
    """)
    relative = "app/pi/workspace_continuation.sigil"
    raw = (ROOT / relative).read_bytes()
    body = compact(body + "\n" + raw.decode())
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("current history exceeds source/entry contract")
    inputs = {**base.input_hashes, relative: hashlib.sha256(raw).hexdigest(),
              "scripts/compose_terminal_history.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    return ApplicationSource(body, inputs, base.stdlib_hash)
