//! Native process/receipt tests, not compiler or real-service qualification.
mod lifetime;
use super::*;
use crate::claimed::tests::{
    Fixture, HELD_TIMEOUT_MS, HELD_WAIT, binding, execution, fixture_recorder, recorded_scope,
};
use sigil_durable_store::store::{Access, Batch, Mutation};
use sigil_worker_bridge::{Config, Fault};
use std::collections::BTreeMap;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::sync::MutexGuard;
use tempfile::TempDir;

fn serial() -> MutexGuard<'static, ()> {
    crate::claimed::tests::process_guard()
}

#[test]
fn known_unsent_owned_thread_refusal_returns_credit_after_signed_terminal() {
    let _serial = serial();
    let (mut f, mut recorder, funding, origin) =
        crate::claimed::completion_tests::fund_retirement_fixture(Fixture::fenced(13), 3, "3");
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    let mut bound = attempt.handoff(&mut recorder).unwrap();
    let ticket = bound.ticket.clone();
    // Actual owned thread rechecks this expired authority before invoking Bridge.
    bound.guard = ExecutionGuard::parse(&frame("TG1\n", &["0", "1"]).unwrap()).unwrap();
    let Fixture {
        directory,
        mut store,
        scope,
        worker,
        mut clock,
    } = f;
    let owner = crate::claimed::completion_tests::owner(&store);
    let mut lane = OwnedWorker::new_funded(worker, recorder, scope);
    lane.launch(bound, "known-unsent".into());
    assert!(lane.take_returned_credit().is_none());
    let until = Instant::now() + HELD_WAIT;
    let result = loop {
        if let Some(result) = lane.poll(&mut store, &mut clock).unwrap() {
            break result;
        }
        assert!(Instant::now() < until);
        std::thread::sleep(Duration::from_millis(5));
    };
    assert!(!result.owner_lost);
    assert_eq!(result.completion.refused, Some("time_guard"));
    assert!(result.completion.observation.is_none());
    assert_eq!(result.completion.phase.as_deref(), Some("3"));
    assert!(result.completion.recording_error.is_none());
    assert!(result.completion.delivery_receipt.is_some());
    let returned = lane
        .take_returned_credit()
        .expect("known-unsent owner report must return original credit");
    assert!(lane.take_returned_credit().is_none());
    store.check_reservation_binding(&returned, origin).unwrap();
    let retained = store
        .reservation_snapshot(&owner, "funds", "operation:1")
        .unwrap();
    assert_eq!(retained.binding, origin);
    assert_eq!(retained.revision, 3);
    assert!(retained.assignment.is_empty());
    assert!(!directory.path().join("started").exists());
    assert!(
        lane.worker
            .as_mut()
            .unwrap()
            .execute(&ticket, &AtomicBool::new(false))
            .is_err()
    );
}

fn component(directory: &Path, name: &str, body: &str) -> Config {
    use sha2::{Digest, Sha256};
    let runtime = directory.join(format!("{name}-runtime"));
    fs::write(&runtime, body).unwrap();
    fs::set_permissions(&runtime, fs::Permissions::from_mode(0o700)).unwrap();
    let source = directory.join(format!("{name}-source"));
    let code = "native protocol fixture, not SIGIL";
    fs::write(&source, code).unwrap();
    Config {
        version: 1,
        runtime,
        runtime_sha256: format!("{:x}", Sha256::digest(body)),
        source,
        source_sha256: format!("{:x}", Sha256::digest(code)),
        max_fuel: 1000,
        max_timeout_ms: 5000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    }
}

fn response(output: &str) -> String {
    serde_json::json!({"jsonrpc":"2.0","id":2,"result":{"content":[{"type":"text",
        "text":serde_json::json!({"status":"ok","data":{"output_text":output}}).to_string()}]}})
    .to_string()
}

fn held_worker(directory: &Path) -> Bridge {
    let body = format!(
        "#!/bin/sh\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nread -r line\n: > '{}'\nwhile [ ! -f '{}' ]; do /bin/sleep 0.01; done\nprintf '%s\\n' '{}'\nwhile :; do /bin/sleep 1; done\n",
        directory.join("effect-received").display(),
        directory.join("release").display(),
        response("observed"),
    );
    let mut config = component(directory, "held", &body);
    config.max_timeout_ms = HELD_TIMEOUT_MS;
    Bridge::new(config).unwrap()
}

struct Running {
    directory: TempDir,
    store: Store,
    owner: Scope,
    lane: OwnedWorker,
    started: Started,
    clock: u64,
}
impl Running {
    fn new(phase: &str, expire: bool) -> Self {
        Self::with_guard(phase, expire, false)
    }
    fn with_guard(phase: &str, expire: bool, milliseconds: bool) -> Self {
        let mut f = Fixture::new();
        recorded_scope(&mut f, Access::CreateOnly);
        let Fixture {
            directory,
            mut store,
            scope,
            mut worker,
            mut clock,
        } = f;
        // Replace only this test's admitted effect fixture, before preparation.
        let mut execution = execution();
        if milliseconds {
            execution.time_guard =
                frame("TG2\n", &["0", "9007199254740991"]).expect("millisecond guard");
        }
        if !expire {
            worker = held_worker(directory.path());
            // The deadline is `Instant::now() + timeout_ms` from the request; the
            // config maximum above is only its ceiling.
            execution.timeout_ms = HELD_TIMEOUT_MS;
        }
        let attempt = Attempt::begin(
            &mut store,
            &scope,
            &mut worker,
            &mut clock,
            binding(),
            execution,
        )
        .unwrap();
        let mut recorder =
            fixture_recorder(directory.path(), &attempt.prepared.generation, phase, 0);
        let mut bound = attempt.handoff(&mut recorder).unwrap();
        if expire {
            // Deterministic fault at the handoff/thread-start boundary, after an
            // actual claim. No wall-clock scheduling race or timeout relaxation.
            bound.guard = ExecutionGuard::parse(
                &frame(if milliseconds { "TG2\n" } else { "TG1\n" }, &["0", "1"]).unwrap(),
            )
            .unwrap();
        }
        let owner = store
            .scope(BTreeMap::from([
                ("intent".into(), Access::ReadWrite),
                ("claim".into(), Access::ReadWrite),
                ("delivery".into(), Access::ReadWrite),
                ("api".into(), Access::ReadWrite),
            ]))
            .unwrap();
        let mut lane = OwnedWorker::new(worker, recorder, scope);
        let started = lane.launch(bound, "opaque SIGIL context".into());
        Self {
            directory,
            store,
            owner,
            lane,
            started,
            clock,
        }
    }
    fn wait_received(&self) {
        wait_until(|| self.directory.path().join("effect-received").exists());
    }
    fn release(&self) {
        fs::write(self.directory.path().join("release"), b"").unwrap();
    }
    fn finish(&mut self) -> OwnedCompletion {
        let deadline = Instant::now() + HELD_WAIT;
        loop {
            if let Some(result) = self.lane.poll(&mut self.store, &mut self.clock).unwrap() {
                return result;
            }
            assert!(Instant::now() < deadline, "effect did not finish");
            thread::sleep(Duration::from_millis(5));
        }
    }
    fn get(&self, namespace: &str) -> Record {
        self.store
            .get(&self.owner, namespace, "operation:1")
            .unwrap()
    }
    fn write(&mut self, namespace: &str, revision: u64, value: &str) {
        self.store
            .commit(
                &self.owner,
                &Batch {
                    checks: vec![],
                    writes: vec![Mutation {
                        namespace: namespace.into(),
                        key: "operation:1".into(),
                        revision,
                        value: Some(value.into()),
                    }],
                },
            )
            .unwrap();
    }
    fn received_facts(&self) -> Vec<String> {
        let raw = fs::read_to_string(self.directory.path().join("recorder-input")).unwrap();
        let actual: serde_json::Value = serde_json::from_str(&raw).unwrap();
        let input = actual["params"]["arguments"]["input"].as_str().unwrap();
        let wrapped = crate::fields(input, "WR1\n", 10).unwrap();
        crate::fields(wrapped[9], "WF1\n", 9)
            .unwrap()
            .into_iter()
            .map(str::to_owned)
            .collect()
    }
}

fn wait_until(mut predicate: impl FnMut() -> bool) {
    let deadline = Instant::now() + HELD_WAIT;
    while !predicate() {
        assert!(
            Instant::now() < deadline,
            "fixture did not reach held boundary"
        );
        thread::sleep(Duration::from_millis(5));
    }
}

#[test]
fn pending_effect_releases_store_and_records_actual_result_once() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    r.wait_received();
    assert_eq!(r.started.claim_receipt.revision, 2);
    assert_eq!(r.get("claim").revision, 1);
    let recorder_input = fs::read(r.directory.path().join("recorder-input")).unwrap();
    for _ in 0..10 {
        assert!(r.lane.poll(&mut r.store, &mut r.clock).unwrap().is_none());
    }
    assert_eq!(
        fs::read(r.directory.path().join("recorder-input")).unwrap(),
        recorder_input
    );
    // A real commit on the SAME store succeeds while the worker is still held.
    r.write("api", 0, "another request committed");
    assert_eq!(
        r.get("api").value.as_deref(),
        Some("another request committed")
    );
    r.release();
    let finished = r.finish();
    assert!(!finished.owner_lost);
    assert_eq!(finished.context, "opaque SIGIL context");
    assert_eq!(finished.completion.claim_receipt.revision, 2);
    assert_eq!(finished.completion.delivery_receipt.unwrap().revision, 4);
    assert_eq!(finished.completion.phase.as_deref(), Some("2"));
    let seen = finished.completion.observation.unwrap();
    assert!(seen.request_may_have_run && seen.worker_reaped);
    assert_eq!(seen.generation, r.started.generation);
    assert_eq!(seen.result.unwrap()["data"]["output_text"], "observed");
    assert_eq!(r.lane.poll(&mut r.store, &mut r.clock).err(), Some("idle"));
    assert!(!r.lane.request_cancel());
    assert_eq!(r.get("claim").revision, 2);
    assert_eq!(r.get("delivery").revision, 1);
}

#[test]
fn owner_inspection_observes_in_flight_work_without_join_cancel_or_dispatch() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    r.wait_received();
    let claim = r.get("claim");
    let before = fs::read(r.directory.path().join("recorder-input")).unwrap();
    assert_eq!(r.lane.inspect_owners(), Ok(1));
    assert_eq!(r.get("claim"), claim);
    assert_eq!(
        fs::read(r.directory.path().join("recorder-input")).unwrap(),
        before
    );
    assert!(
        !r.lane
            .flight
            .as_ref()
            .unwrap()
            .cancel
            .load(Ordering::Acquire)
    );
    r.release();
    assert!(!r.finish().owner_lost);
    assert_eq!(r.lane.inspect_owners(), Ok(0));
    let worker = r.lane.worker.take().unwrap();
    assert_eq!(r.lane.inspect_owners(), Err("owner_unavailable"));
    r.lane.worker = Some(worker);
    assert_eq!(r.lane.inspect_owners(), Ok(0));
}

#[test]
fn cancellation_signals_actual_held_worker_and_preserves_possible_delivery() {
    let _serial = serial();
    let mut r = Running::new("4", false);
    r.wait_received();
    assert!(r.lane.request_cancel());
    let finished = r.finish();
    let seen = finished.completion.observation.unwrap();
    assert_eq!(seen.fault, Some(Fault::Cancelled));
    assert!(seen.request_may_have_run && seen.worker_reaped);
    assert_eq!(finished.completion.phase.as_deref(), Some("4"));
    let facts = r.received_facts();
    assert_eq!(facts[0], "observed");
    assert_eq!(&facts[2..5], ["1", "1", "cancelled"]);
    assert!(!r.directory.path().join("release").exists());
}

#[test]
fn authority_is_checked_again_on_execution_thread_before_worker_start() {
    let _serial = serial();
    let mut r = Running::new("3", true);
    let result = r.finish();
    assert_eq!(result.completion.refused, Some("time_guard"));
    assert!(result.completion.observation.is_none());
    assert_eq!(result.completion.phase.as_deref(), Some("3"));
    assert!(!r.directory.path().join("started").exists());
    assert_eq!(
        &r.received_facts()[0..5],
        ["refused", &r.started.generation, "0", "1", "time_guard"]
    );
}

#[test]
fn newer_claim_cannot_be_overwritten_by_late_completion() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    r.wait_received();
    r.write("claim", 1, "newer recovery state");
    r.release();
    let result = r.finish();
    assert_eq!(result.completion.recording_error, Some("claim"));
    assert!(result.completion.delivery_receipt.is_none());
    assert_eq!(
        r.get("claim").value.as_deref(),
        Some("newer recovery state")
    );
    assert_eq!(r.get("delivery").revision, 0);
}

#[test]
fn changed_intent_cannot_receive_an_old_observation() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    r.wait_received();
    r.write("intent", 1, "changed immutable intent");
    r.release();
    let result = r.finish();
    assert_eq!(result.completion.recording_error, Some("intent"));
    assert_eq!(r.get("claim").revision, 1);
    assert_eq!(r.get("delivery").revision, 0);
}

#[test]
fn occupied_delivery_slot_is_not_overwritten() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    r.wait_received();
    r.write("delivery", 0, "already retained delivery");
    r.release();
    let result = r.finish();
    assert_eq!(result.completion.recording_error, Some("delivery"));
    assert_eq!(
        r.get("delivery").value.as_deref(),
        Some("already retained delivery")
    );
    assert_eq!(r.get("claim").revision, 1);
}

#[test]
fn completion_cannot_use_the_same_namespace_names_in_a_different_store() {
    let _serial = serial();
    let mut r = Running::new("2", false);
    let mut other = Fixture::new();
    r.wait_received();
    r.release();
    wait_until(|| {
        r.lane
            .flight
            .as_ref()
            .unwrap()
            .thread
            .as_ref()
            .unwrap()
            .is_finished()
    });
    let result = r
        .lane
        .poll(&mut other.store, &mut r.clock)
        .unwrap()
        .unwrap();
    assert_eq!(result.completion.recording_error, Some("storage"));
    assert!(result.completion.delivery_receipt.is_none());
    assert_eq!(r.get("claim").revision, 1);
    assert_eq!(
        other
            .store
            .get(&other.scope, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
}

#[test]
fn dropping_a_lane_requests_cleanup_but_leaves_claim_consumed() {
    let _serial = serial();
    let mut r = Running::new("4", false);
    r.wait_received();
    // Retain the real join handle only to verify cleanup in this test. Production
    // callers cannot take it and Drop itself does not claim a cleanup receipt.
    let handle = r.lane.flight.as_mut().unwrap().thread.take().unwrap();
    let cancel = Arc::clone(&r.lane.flight.as_ref().unwrap().cancel);
    drop(r.lane);
    assert!(cancel.load(Ordering::Acquire));
    let report = handle.join().unwrap();
    let observation = report.observation.unwrap();
    assert_eq!(observation.fault, Some(Fault::Cancelled));
    assert!(observation.worker_reaped && observation.request_may_have_run);
    assert_eq!(
        r.store
            .get(&r.owner, "claim", "operation:1")
            .unwrap()
            .revision,
        1
    );
    assert_eq!(
        r.store
            .get(&r.owner, "delivery", "operation:1")
            .unwrap()
            .revision,
        0
    );
}

#[test]
fn lost_execution_owner_records_uncertainty_and_cannot_supply_a_replacement_worker() {
    let _serial = serial();
    let mut r = Running::new("4", false);
    r.wait_received();
    r.lane.request_cancel();
    let original = r.lane.flight.as_mut().unwrap().thread.take().unwrap();
    // Fault injection at the private ownership channel, after verifying fixture
    // cleanup. No production method accepts this handle or a supplied result.
    let observed = original.join().unwrap();
    assert!(observed.observation.unwrap().worker_reaped);
    let failed = thread::spawn(|| -> WorkerReport { panic!("injected controller loss") });
    wait_until(|| failed.is_finished());
    r.lane.flight.as_mut().unwrap().thread = Some(failed);
    let result = r.finish();
    assert!(result.owner_lost);
    assert!(result.completion.refused.is_none() && result.completion.observation.is_none());
    assert_eq!(result.completion.phase.as_deref(), Some("4"));
    assert!(r.lane.worker.is_none());
    let facts = r.received_facts();
    assert_eq!(facts[0], "abandoned");
    assert_eq!(&facts[2..5], ["1", "0", "owner_unavailable"]);
}

#[test]
fn millisecond_authority_is_rechecked_in_owned_thread_before_invocation() {
    let _serial = serial();
    let mut r = Running::with_guard("3", true, true);
    let result = r.finish();
    assert_eq!(result.completion.refused, Some("time_guard"));
    assert!(result.completion.observation.is_none());
    assert_eq!(result.completion.phase.as_deref(), Some("3"));
    assert!(!r.directory.path().join("started").exists());
    assert_eq!(
        &r.received_facts()[0..5],
        ["refused", &r.started.generation, "0", "1", "time_guard"]
    );
}

#[test]
fn millisecond_guard_preserves_owned_observation_and_original_claim() {
    let _serial = serial();
    let mut r = Running::with_guard("2", false, true);
    r.wait_received();
    r.release();
    let result = r.finish();
    assert!(result.completion.refused.is_none());
    let observed = result
        .completion
        .observation
        .expect("actual worker observation");
    assert!(observed.request_may_have_run && observed.worker_reaped);
    assert_eq!(result.completion.phase.as_deref(), Some("2"));
}

#[test]
fn funded_owned_handoff_holds_credit_until_actual_reap_and_terminal_commit() {
    let _serial = serial();
    let (mut f, mut recorder, funding, parent) = crate::claimed::completion_tests::setup(2);
    f.worker = held_worker(f.directory.path());
    let mut request = execution();
    request.timeout_ms = HELD_TIMEOUT_MS;
    let mut rival = Fixture::new();
    let prepared_rival = rival.worker.prepare("rival".into(), 100, 5000).unwrap();
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        request,
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    let bound = attempt.handoff(&mut recorder).unwrap();
    let assigned = bound.funding.as_ref().unwrap().assigned.unwrap();
    let Fixture {
        directory,
        mut store,
        scope,
        worker,
        mut clock,
    } = f;
    let owner = crate::claimed::completion_tests::owner(&store);
    let mut lane = OwnedWorker::new_funded(worker, recorder, scope);
    lane.launch(bound, "funded native fixture".into());
    wait_until(|| directory.path().join("effect-received").exists());
    assert!(lane.take_returned_credit().is_none());
    assert!(
        store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_err()
    );
    assert!(
        store
            .resume_reservation(&owner, "funds", "operation:1", 2, assigned)
            .is_ok()
    );
    assert!(matches!(
        lane.recover(&mut store, binding()),
        Err("funding_recovery_required")
    ));
    // A separately prepared real ticket cannot obtain another committed claim.
    assert!(matches!(
        Attempt::begin(
            &mut store,
            &lane.scope,
            &mut rival.worker,
            &mut rival.clock,
            binding(),
            execution()
        ),
        Err("claimed")
    ));
    assert!(!rival.directory.path().join("started").exists());
    rival.worker.cancel_pending(&prepared_rival.ticket).unwrap();
    fs::write(directory.path().join("release"), b"").unwrap();
    let until = Instant::now() + HELD_WAIT;
    let result = loop {
        if let Some(result) = lane.poll(&mut store, &mut clock).unwrap() {
            break result;
        }
        assert!(Instant::now() < until);
        std::thread::sleep(Duration::from_millis(5));
    };
    assert!(result.completion.delivery_receipt.is_some());
    assert!(result.completion.recording_error.is_none());
    assert!(result.completion.observation.unwrap().worker_reaped);
    let returned = lane.take_returned_credit().unwrap();
    assert!(lane.take_returned_credit().is_none());
    store.check_reservation_binding(&returned, parent).unwrap();
    assert_eq!(returned.revision(), 3);
    assert_eq!(
        store
            .get(&owner, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        2
    );
}

#[test]
fn funded_cancellation_keeps_budget_until_observed_worker_cleanup_and_signed_result() {
    let _serial = serial();
    let (mut f, mut recorder, funding, parent) =
        crate::claimed::completion_tests::setup_phase(2, "4");
    f.worker = held_worker(f.directory.path());
    let mut request = execution();
    request.timeout_ms = HELD_TIMEOUT_MS;
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        request,
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    let bound = attempt.handoff(&mut recorder).unwrap();
    let Fixture {
        directory,
        mut store,
        scope,
        worker,
        mut clock,
    } = f;
    let mut lane = OwnedWorker::new_funded(worker, recorder, scope);
    lane.launch(bound, "funded cancellation fixture".into());
    wait_until(|| directory.path().join("effect-received").exists());
    assert!(lane.request_cancel());
    assert!(lane.take_returned_credit().is_none());
    let until = Instant::now() + HELD_WAIT;
    let result = loop {
        if let Some(result) = lane.poll(&mut store, &mut clock).unwrap() {
            break result;
        }
        assert!(Instant::now() < until);
        std::thread::sleep(Duration::from_millis(5));
    };
    let observation = result.completion.observation.unwrap();
    assert_eq!(observation.fault, Some(Fault::Cancelled));
    assert!(observation.request_may_have_run && observation.worker_reaped);
    assert!(result.completion.delivery_receipt.is_some());
    assert_eq!(result.completion.phase.as_deref(), Some("4"));
    store
        .check_reservation_binding(&lane.take_returned_credit().unwrap(), parent)
        .unwrap();
}

#[test]
fn explicit_funded_start_uses_actual_dispatch_policy_and_cannot_silently_switch_profiles() {
    let _serial = serial();
    for funded_profile in [false, true] {
        let (f, recorder, funding, parent) = crate::claimed::completion_tests::setup(2);
        let output = frame(
            "DW1\n",
            &[
                "fixture",
                "exact frozen input",
                "intent",
                "operation:1",
                "1",
                &execution().time_guard,
                "funded policy context",
            ],
        )
        .unwrap();
        let (mut policy, _, _) = crate::claimed::audit_tests::policy_fixture(&f, &output);
        let Fixture {
            directory,
            mut store,
            scope,
            worker,
            mut clock,
        } = f;
        let owner = crate::claimed::completion_tests::owner(&store);
        let mut lane = if funded_profile {
            OwnedWorker::new_funded(worker, recorder, scope)
        } else {
            OwnedWorker::new(worker, recorder, scope)
        };
        let values = ["operation:1".into()];
        if !funded_profile {
            assert!(matches!(
                lane.start_funded(&mut policy, &mut store, &mut clock, &values, funding),
                Err("funding_profile")
            ));
            assert!(!directory.path().join("policy-input").exists());
            assert!(!directory.path().join("started").exists());
            assert!(
                store
                    .resume_reservation(&owner, "funds", "operation:1", 1, parent)
                    .is_ok()
            );
            continue;
        }
        assert!(matches!(
            lane.start(&mut policy, &mut store, &mut clock, &values),
            Err("funding_profile")
        ));
        assert!(!directory.path().join("policy-input").exists());
        let started = lane
            .start_funded(&mut policy, &mut store, &mut clock, &values, funding)
            .unwrap();
        assert_eq!(started.context, "funded policy context");
        let until = Instant::now() + HELD_WAIT;
        let result = loop {
            if let Some(result) = lane.poll(&mut store, &mut clock).unwrap() {
                break result;
            }
            assert!(Instant::now() < until);
            std::thread::sleep(Duration::from_millis(5));
        };
        assert!(result.completion.delivery_receipt.is_some());
        assert!(result.completion.recording_error.is_none());
        store
            .check_reservation_binding(&lane.take_returned_credit().unwrap(), parent)
            .unwrap();
        assert!(directory.path().join("policy-input").exists());
    }
}

#[test]
fn funded_drop_and_lost_owner_cannot_release_capacity_on_an_unobserved_cleanup() {
    let _serial = serial();
    for lose_owner in [false, true] {
        let (mut f, mut recorder, funding, parent) =
            crate::claimed::completion_tests::setup_phase(2, "4");
        f.worker = held_worker(f.directory.path());
        let mut request = execution();
        request.timeout_ms = HELD_TIMEOUT_MS;
        let mut attempt = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            request,
        )
        .unwrap();
        attempt.attach_funding(funding).unwrap();
        let bound = attempt.handoff(&mut recorder).unwrap();
        let assigned = bound.funding.as_ref().unwrap().assigned.unwrap();
        let Fixture {
            directory,
            mut store,
            scope,
            worker,
            mut clock,
        } = f;
        let owner = crate::claimed::completion_tests::owner(&store);
        let mut lane = OwnedWorker::new_funded(worker, recorder, scope);
        lane.launch(bound, "funded owner loss".into());
        wait_until(|| directory.path().join("effect-received").exists());
        // Retain the real private handle solely to avoid leaving a test worker
        // alive. The service is not given this discarded cleanup observation.
        let original = lane.flight.as_mut().unwrap().thread.take().unwrap();
        if !lose_owner {
            let cancelled = Arc::clone(&lane.flight.as_ref().unwrap().cancel);
            drop(lane);
            assert!(cancelled.load(Ordering::Acquire));
            assert!(original.join().unwrap().observation.unwrap().worker_reaped);
            assert!(
                store
                    .resume_reservation(&owner, "funds", "operation:1", 2, assigned)
                    .is_ok()
            );
            assert_eq!(
                store
                    .get(&owner, "delivery", "operation:1")
                    .unwrap()
                    .revision,
                0
            );
            assert!(
                store
                    .resume_reservation(&owner, "funds", "operation:1", 2, parent)
                    .is_err()
            );
        } else {
            lane.request_cancel();
            assert!(original.join().unwrap().observation.unwrap().worker_reaped);
            let failed =
                thread::spawn(|| -> WorkerReport { panic!("injected funded controller loss") });
            wait_until(|| failed.is_finished());
            lane.flight.as_mut().unwrap().thread = Some(failed);
            let result = lane.poll(&mut store, &mut clock).unwrap().unwrap();
            assert!(result.owner_lost);
            assert!(result.completion.observation.is_none());
            assert_eq!(result.completion.phase.as_deref(), Some("4"));
            assert!(result.completion.delivery_receipt.is_some());
            assert!(lane.take_returned_credit().is_none());
            assert!(
                store
                    .resume_reservation(&owner, "funds", "operation:1", 3, assigned)
                    .is_ok()
            );
            assert!(
                store
                    .resume_reservation(&owner, "funds", "operation:1", 3, parent)
                    .is_err()
            );
        }
    }
}

#[test]
fn witnessed_owned_cleanup_drop_and_owner_loss_preserve_actual_assignment_until_observed_reap() {
    let _serial = serial();
    for mode in ["cancel", "drop", "owner_loss"] {
        let (mut f, mut recorder, funding, origin) =
            crate::claimed::completion_tests::fund_fixture(Fixture::witnessed(13), 2, "4");
        f.worker = held_worker(f.directory.path());
        let mut request = execution();
        request.timeout_ms = HELD_TIMEOUT_MS;
        let mut a = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            request,
        )
        .unwrap();
        a.attach_funding(funding).unwrap();
        let bound = a.handoff(&mut recorder).unwrap();
        let Fixture {
            directory,
            mut store,
            scope,
            worker,
            mut clock,
        } = f;
        let owner = crate::claimed::completion_tests::owner(&store);
        let before = store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap();
        assert_eq!(
            AssignedCompletion::observe(&store, &owner, "funds", "operation:1")
                .unwrap()
                .generation(),
            bound.generation
        );
        let mut lane = OwnedWorker::new_funded(worker, recorder, scope);
        lane.launch(bound, "witnessed owned fixture".into());
        wait_until(|| directory.path().join("effect-received").exists());
        assert!(lane.take_returned_credit().is_none());
        if mode == "drop" {
            let original = lane.flight.as_mut().unwrap().thread.take().unwrap();
            let cancelled = Arc::clone(&lane.flight.as_ref().unwrap().cancel);
            drop(lane);
            assert!(cancelled.load(Ordering::Acquire));
            assert!(original.join().unwrap().observation.unwrap().worker_reaped);
        } else {
            assert!(lane.request_cancel());
            if mode == "owner_loss" {
                let original = lane.flight.as_mut().unwrap().thread.take().unwrap();
                // The actual report is deliberately discarded; production has
                // no evidence of this test-only join and must retain assignment.
                assert!(original.join().unwrap().observation.unwrap().worker_reaped);
                let failed = thread::spawn(|| -> WorkerReport { panic!("injected owner loss") });
                wait_until(|| failed.is_finished());
                lane.flight.as_mut().unwrap().thread = Some(failed);
            }
            let until = Instant::now() + HELD_WAIT;
            let completion = loop {
                if let Some(result) = lane.poll(&mut store, &mut clock).unwrap() {
                    break result;
                }
                assert!(Instant::now() < until);
                thread::sleep(Duration::from_millis(5));
            };
            assert!(completion.completion.delivery_receipt.is_some());
            assert!(completion.completion.recording_error.is_none());
            if mode == "owner_loss" {
                assert!(completion.owner_lost);
                assert!(completion.completion.observation.is_none());
                assert!(lane.take_returned_credit().is_none());
            } else {
                let observation = completion.completion.observation.unwrap();
                assert!(observation.worker_reaped && observation.request_may_have_run);
                assert_eq!(observation.fault, Some(Fault::Cancelled));
                store
                    .check_reservation_binding(&lane.take_returned_credit().unwrap(), origin)
                    .unwrap();
                assert!(lane.take_returned_credit().is_none());
            }
        }
        let after = store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap();
        assert_eq!(after.origin, origin);
        assert_eq!(after.revision, if mode == "drop" { 2 } else { 3 });
        if mode == "cancel" {
            assert_eq!(after.binding, origin);
            assert!(after.assignment.is_empty());
        } else {
            assert_eq!(after.binding, before.binding);
            assert_eq!(after.assignment, before.assignment);
            assert_ne!(after.binding, origin);
        }
    }
}
