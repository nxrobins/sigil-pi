use super::*;
use crate::shared_pure_tests::fixture_output;

#[test]
fn warm_shared_evaluation_projector_refuses_second_caller_boot() {
    let (dir, worker) = crate::shared_pure_tests::fixture_rejecting_input(
        "evaluation_audit_admitted",
        &"b".repeat(64),
        "evaluation_audit_denied",
    );
    let mut cache = crate::PureCache::new();
    let a = Projector::admit_with_cache(worker.clone(), &"a".repeat(64), "{}", Some(&mut cache))
        .unwrap();
    assert!(matches!(
        Projector::admit_with_cache(worker.clone(), &"b".repeat(64), "{}", Some(&mut cache)),
        Err("config")
    ));
    let again =
        Projector::admit_with_cache(worker, &"a".repeat(64), "{}", Some(&mut cache)).unwrap();
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    assert_eq!(
        std::fs::read_to_string(dir.path().join("calls"))
            .unwrap()
            .lines()
            .count(),
        3
    );
    drop(a);
    drop(again);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}

#[test]
fn shared_projector_boot_checks_each_chain_and_grant_set() {
    let (dir, worker) = fixture_output("evaluation_audit_admitted");
    let mut cache = crate::PureCache::new();
    let chain_a = "a".repeat(64);
    let chain_b = "b".repeat(64);
    let grants_a = r#"{"a.domain":"read_write"}"#;
    let grants_b = r#"{"b.domain":"read_write"}"#;
    let a =
        Projector::admit_with_cache(worker.clone(), &chain_a, grants_a, Some(&mut cache)).unwrap();
    let b =
        Projector::admit_with_cache(worker.clone(), &chain_b, grants_b, Some(&mut cache)).unwrap();
    let (crate::PureExecution::SharedCached(wa), crate::PureExecution::SharedCached(wb)) =
        (&a.function.worker, &b.function.worker)
    else {
        panic!("expected sharing");
    };
    assert!(std::sync::Arc::ptr_eq(wa, wb));
    let calls = std::fs::read_to_string(dir.path().join("calls")).unwrap();
    let decoded: Vec<serde_json::Value> = calls
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(decoded.len(), 2);
    for (row, (chain, grants)) in decoded
        .iter()
        .zip([(&chain_a, grants_a), (&chain_b, grants_b)])
    {
        let input = row["params"]["arguments"]["input"].as_str().unwrap();
        let parts = fields(input, "EB1\n", 3).unwrap();
        assert_eq!(&parts[0], chain);
        assert_eq!(parts[2], grants);
    }
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    std::fs::write(&worker.source, "changed source").unwrap();
    assert!(Projector::admit_with_cache(worker, &chain_b, grants_b, Some(&mut cache)).is_err());
    drop(a);
    drop(b);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}
