"""Pure terminal eligibility and a retained causal fence; no owner-handoff claim."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource, strip_line_comments
from scripts.compose_reservation_identity import compose_reservation_identity

ROOT = Path(__file__).resolve().parent.parent


def compose_generation_retirement(stdlib, *, root=ROOT):
    root=Path(root)
    base=compose_reservation_identity(stdlib,root=root)
    marker="pub fn tool_main(input_ptr: i64, input_len: i64)"
    if base.text.count(marker)!=1:raise ValueError("generation entry changed")
    body=base.text.replace(marker,"fn compare_allocation(input_ptr: i64 @Internal, input_len: i64 @Internal)")
    protocol=(root/"app/shared/store_protocol.sigil").read_text()
    if protocol.count("// STORE_READ_HELPERS_END")!=1:raise ValueError("store helper region changed")
    body+=protocol.split("// STORE_READ_HELPERS_END")[1]
    inputs=dict(base.input_hashes)
    for name in ["app/pi/operation_records.sigil","app/pi/generation_retirement.sigil"]:
        raw=(root/name).read_bytes();body+=raw.decode();inputs[name]=hashlib.sha256(raw).hexdigest()
    body=strip_line_comments(body,compact_indent=True)
    if len(body.encode())>65536 or body.count("pub fn tool_main(")!=1:raise ValueError("retirement source/entry limit")
    inputs["scripts/compose_generation_retirement.py"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body,inputs,base.stdlib_hash)
