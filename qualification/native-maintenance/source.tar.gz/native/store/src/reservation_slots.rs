//! Fixed catalog: a free slot retains its last allocation generation forever.
use super::*;

pub(in crate::store) const SQL: &str = "CREATE TABLE reservation_slots (pool TEXT NOT NULL, slot INTEGER NOT NULL CHECK(slot>=0), generation INTEGER NOT NULL CHECK(generation>=0), occupied INTEGER NOT NULL CHECK(occupied IN(0,1)), PRIMARY KEY(pool,slot)) WITHOUT ROWID";
pub(super) const ROW_BYTES: u64 = 96;

/// Public identity facts; possession does not grant scope, credits or cleanup.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Generation {
    pub pool: String,
    pub slot: u16,
    pub generation: u64,
}

pub struct Retirement {
    pub namespace: String,
    pub key: String,
    pub revision: u64,
    pub binding: [u8; 32],
    pub generation: Generation,
}

pub(in crate::store) fn initialize(c: &Connection, slots: &BTreeMap<String, u16>) -> Result<()> {
    c.execute_batch(SQL).map_err(|_| Error::Storage)?;
    for (pool, count) in slots {
        for slot in 0..*count {
            c.execute(
                "INSERT INTO reservation_slots VALUES(?1,?2,0,0)",
                params![pool, slot],
            )
            .map_err(|_| Error::Storage)?;
        }
    }
    Ok(())
}

fn next(c: &Connection, pool: &str) -> Result<Generation> {
    let (slot, old): (u16,i64) = c.query_row("SELECT slot,generation FROM reservation_slots WHERE pool=?1 AND occupied=0 AND generation<9223372036854775807 ORDER BY slot LIMIT 1",[pool],|r|Ok((r.get(0)?,r.get(1)?))).optional().map_err(|_|Error::Corrupt)?.ok_or(Error::Limit)?;
    let generation = old.checked_add(1).filter(|n| *n > 0).ok_or(Error::Limit)?;
    Ok(Generation {
        pool: pool.into(),
        slot,
        generation: generation as u64,
    })
}

pub(super) fn allocate(c: &Connection, pool: &str) -> Result<Generation> {
    let result = next(c, pool)?;
    let generation = result.generation as i64;
    if c.execute("UPDATE reservation_slots SET generation=?1,occupied=1 WHERE pool=?2 AND slot=?3 AND generation=?4 AND occupied=0",params![generation,pool,result.slot,generation-1]).map_err(|_|Error::Storage)? != 1 { return Err(Error::Conflict); }
    Ok(result)
}

pub(super) fn release(c: &Connection, g: &Generation) -> Result<()> {
    if g.generation == 0 || g.generation > i64::MAX as u64 {
        return Err(Error::Conflict);
    }
    if c.execute("UPDATE reservation_slots SET occupied=0 WHERE pool=?1 AND slot=?2 AND generation=?3 AND occupied=1",params![g.pool,g.slot,g.generation as i64]).map_err(|_|Error::Storage)? != 1 { return Err(Error::Conflict); }
    Ok(())
}

pub(super) fn validate(c: &Connection, slots: &BTreeMap<String, u16>) -> Result<()> {
    let mut stmt=c.prepare("SELECT pool,slot,generation,occupied FROM reservation_slots ORDER BY pool,slot LIMIT 1025").map_err(|_|Error::Corrupt)?;
    let mut rows = stmt.query([]).map_err(|_| Error::Corrupt)?;
    for (pool, count) in slots {
        for slot in 0..*count {
            let row = rows
                .next()
                .map_err(|_| Error::Corrupt)?
                .ok_or(Error::Corrupt)?;
            let (p, s, g, o): (String, u16, i64, i64) = (
                row.get(0).map_err(|_| Error::Corrupt)?,
                row.get(1).map_err(|_| Error::Corrupt)?,
                row.get(2).map_err(|_| Error::Corrupt)?,
                row.get(3).map_err(|_| Error::Corrupt)?,
            );
            if p != *pool || s != slot || g < 0 || !(0..=1).contains(&o) || (o == 1 && g == 0) {
                return Err(Error::Corrupt);
            }
            let matching: i64 = c
                .query_row(
                    "SELECT count(*) FROM reservations WHERE pool=?1 AND slot=?2 AND generation=?3",
                    params![pool, slot, g],
                    |r| r.get(0),
                )
                .map_err(|_| Error::Corrupt)?;
            if matching != o {
                return Err(Error::Corrupt);
            }
        }
    }
    if rows.next().map_err(|_| Error::Corrupt)?.is_some() {
        return Err(Error::Corrupt);
    }
    let unmatched:i64=c.query_row("SELECT count(*) FROM reservations r LEFT JOIN reservation_slots s ON s.pool=r.pool AND s.slot=r.slot AND s.generation=r.generation AND s.occupied=1 WHERE s.pool IS NULL",[],|r|r.get(0)).map_err(|_|Error::Corrupt)?;
    if unmatched != 0 {
        return Err(Error::Corrupt);
    }
    Ok(())
}

impl Store {
    /// Bounded coordinates of the live allocation catalog, including closed
    /// allocations awaiting retirement. This supplies facts, never eligibility.
    pub fn reservation_keys(&self, scope: &Scope, namespace: &str) -> Result<Vec<String>> {
        if self.reserving != 7 {
            return Err(Error::Invalid);
        }
        self.authorize(scope, namespace, "catalog", false, 0, false)?;
        self.verify_files()?;
        let _snapshot = self.anchored_read()?;
        let pool = self
            .allocation
            .as_ref()
            .ok_or(Error::Invalid)?
            .pools
            .iter()
            .find(|p| p.namespaces.iter().any(|n| n == namespace))
            .ok_or(Error::Denied)?;
        let limit = usize::from(
            *self
                .reservation_slots
                .as_ref()
                .and_then(|s| s.get(&pool.id))
                .ok_or(Error::Corrupt)?,
        );
        if limit == 0 || limit > ENTRIES {
            return Err(Error::Corrupt);
        }
        let query_limit = i64::try_from(limit + 1).map_err(|_| Error::Corrupt)?;
        let mut statement = self
            .connection
            .prepare("SELECT key FROM reservations WHERE namespace=?1 ORDER BY key LIMIT ?2")
            .map_err(|_| Error::Corrupt)?;
        let values = statement
            .query_map(params![namespace, query_limit], |row| {
                row.get::<_, String>(0)
            })
            .map_err(|_| Error::Corrupt)?
            .collect::<std::result::Result<Vec<_>, _>>()
            .map_err(|_| Error::Corrupt)?;
        if values.len() > limit {
            return Err(Error::Corrupt);
        }
        Ok(values)
    }

    /// A bounded page of currently retained allocation coordinates. Application
    /// records remain untouched; callers must still read their state and actual
    /// allocation identity before proposing any action.
    pub fn reservation_key_page(
        &self,
        scope: &Scope,
        namespace: &str,
        after: Option<&str>,
        limit: usize,
    ) -> Result<KeyPage> {
        if !(1..=128).contains(&limit) || after.is_some_and(|v| !valid_name(v, 256)) {
            return Err(Error::Invalid);
        }
        let keys: Vec<_> = self
            .reservation_keys(scope, namespace)?
            .into_iter()
            .filter(|key| after.is_none_or(|cursor| key.as_str() > cursor))
            .take(limit)
            .collect();
        let next = (keys.len() == limit).then(|| keys.last().unwrap().clone());
        Ok(KeyPage { keys, next })
    }

    pub fn has_reservation_generations(&self) -> bool {
        self.reserving == 7
    }

    /// Scoped facts for an optimistic allocation proposal, not a reservation.
    /// The generational commit checks this exact choice inside its transaction.
    pub fn next_reservation_generation(
        &self,
        scope: &Scope,
        namespace: &str,
        key: &str,
    ) -> Result<Generation> {
        if self.reserving != 7 {
            return Err(Error::Invalid);
        }
        self.authorize(scope, namespace, key, false, 0, false)?;
        self.verify_files()?;
        let _snapshot = self.anchored_read()?;
        if read(&self.connection, namespace, key, self.reserving)?.is_some() {
            return Err(Error::Conflict);
        }
        let pool = self
            .allocation
            .as_ref()
            .ok_or(Error::Invalid)?
            .pools
            .iter()
            .find(|p| p.namespaces.iter().any(|n| n == namespace))
            .ok_or(Error::Denied)?;
        next(&self.connection, &pool.id)
    }

    /// Retirement is admitted only before this acquisition has ever issued an
    /// execution lease. A successor must acquire the actual execution lock,
    /// which surviving workers retain. No PID, timestamp or boolean is accepted.
    pub fn commit_retiring_reservation(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Retirement,
    ) -> Result<Receipt> {
        if self.reserving != 7 || self.execution_issued.get() {
            return Err(Error::Denied);
        }
        self.verify_process()?;
        // commit_storage_reserved checks physical identity and the full current
        // root inside the write transaction before any retirement is applied.
        self.reservation_owner(scope, &request.namespace, &request.key)?;
        self.reservation_batch(scope, batch, &request.namespace)?;
        self.commit_storage_reserved(batch, Some(Change::Retire(request)), None, || {})
    }
}

#[cfg(test)]
#[path = "reservation_slots_tests.rs"]
mod tests;
