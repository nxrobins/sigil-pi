//! Native-held completion capacity. Policy chooses the amounts; these types bind
//! actual observed storage and worker identities. They are not serializable,
//! cloneable, public-request authority, or proof that an old effect has stopped.
use super::*;
use sha2::{Digest, Sha256};
use sigil_durable_store::store::reservation::{Credits, Held};

pub struct CompletionIdentity {
    intent: Check,
    snapshot: Record,
    claim_namespace: String,
    delivery_namespace: String,
    binding: [u8; 32],
}

pub struct CompletionBudget {
    pub claim: Credits,
    pub result: Credits,
}

pub struct CompletionCredit {
    identity: CompletionIdentity,
    pub(super) intent_binding: Option<[u8; 32]>,
    pub(super) held: Option<Held>,
    pub(super) budget: CompletionBudget,
    pub(super) retirement: Option<Credits>,
    pub(super) assigned: Option<[u8; 32]>,
    pub(super) returned: bool,
    pub(super) result_limit: Option<usize>,
}

pub(crate) fn hash(parts: &[&[u8]]) -> [u8; 32] {
    let mut hash = Sha256::new();
    for part in parts {
        hash.update((part.len() as u64).to_be_bytes());
        hash.update(part);
    }
    hash.finalize().into()
}

impl CompletionIdentity {
    /// Spend a whole-operation reservation on this actual next intent. The
    /// original reservation remains immutable; only one witnessed assignment
    /// may occupy it. Application policy supplies the reservation coordinate.
    pub fn fund_from_parent(
        mut self,
        store: &Store,
        held: Held,
        budget: CompletionBudget,
        retirement: Credits,
    ) -> Result<CompletionCredit> {
        if !held.unassigned() {
            return Err("funding_assigned");
        }
        let intent_binding = self.binding;
        self.binding = held.origin().ok_or("funding_witness")?;
        let mut credit = self.fund_with_retirement(store, held, budget, retirement)?;
        credit.intent_binding = Some(intent_binding);
        Ok(credit)
    }
    /// Observe the same retained intent that an Attempt must later check. The
    /// returned binding is a non-secret identity, never a credential or receipt.
    pub fn observe(
        store: &Store,
        scope: &Scope,
        binding: &Binding,
        delivery: &str,
    ) -> Result<Self> {
        use sigil_durable_store::store::Access;
        use std::collections::BTreeMap;
        if binding.intent_namespace == binding.claim_namespace
            || binding.intent_namespace == delivery
            || binding.claim_namespace == delivery
        {
            return Err("funding_identity");
        }
        Store::validate_grants(&BTreeMap::from([(delivery.to_owned(), Access::CreateOnly)]))
            .map_err(|_| "funding_identity")?;
        let snapshot = store
            .get(scope, &binding.intent_namespace, &binding.key)
            .map_err(|_| "storage")?;
        if snapshot.revision == 0 || snapshot.value.as_ref().is_none_or(String::is_empty) {
            return Err("intent");
        }
        let claim = store
            .get(scope, &binding.claim_namespace, &binding.key)
            .map_err(|_| "storage")?;
        if claim.revision != 0 || claim.value.is_some() {
            return Err("claimed");
        }
        let intent = Check {
            namespace: binding.intent_namespace.clone(),
            key: binding.key.clone(),
            revision: snapshot.revision,
        };
        let digest = hash(&[
            b"sigil-completion-intent/v1",
            intent.namespace.as_bytes(),
            intent.key.as_bytes(),
            &intent.revision.to_be_bytes(),
            snapshot.value.as_deref().unwrap().as_bytes(),
            binding.claim_namespace.as_bytes(),
            delivery.as_bytes(),
        ]);
        Ok(Self {
            intent,
            snapshot,
            claim_namespace: binding.claim_namespace.clone(),
            delivery_namespace: delivery.into(),
            binding: digest,
        })
    }
    pub fn reservation_binding(&self) -> [u8; 32] {
        self.binding
    }

    /// A valid held capability and enough caller-selected pool credit are
    /// required. The application still must prove its worst-case output budget;
    /// this constructor does not choose turn counts, retries or response sizes.
    pub fn fund(
        self,
        store: &Store,
        held: Held,
        budget: CompletionBudget,
    ) -> Result<CompletionCredit> {
        self.fund_inner(store, held, budget, None)
    }

    /// Explicit opt-in to a third originally reserved publication, needed if a
    /// terminal uncertainty record outlives unconfirmed local worker cleanup.
    /// This does not authorize retirement or choose application budget amounts.
    pub fn fund_with_retirement(
        self,
        store: &Store,
        held: Held,
        budget: CompletionBudget,
        retirement: Credits,
    ) -> Result<CompletionCredit> {
        if !store.has_execution_fence() {
            return Err("execution_fence");
        }
        if retirement.records == 0 || retirement.live_bytes == 0 {
            return Err("funding_budget");
        }
        self.fund_inner(store, held, budget, Some(retirement))
    }

    fn fund_inner(
        self,
        store: &Store,
        held: Held,
        budget: CompletionBudget,
        retirement: Option<Credits>,
    ) -> Result<CompletionCredit> {
        store
            .check_reservation_binding(&held, self.binding)
            .map_err(|_| "funding")?;
        let credits = held.credits();
        if budget.result.records == 0
            || budget.result.live_bytes == 0
            || budget
                .claim
                .records
                .checked_add(budget.result.records)
                .and_then(|n| n.checked_add(retirement.map_or(0, |v| v.records)))
                .is_none_or(|n| n > credits.records)
            || budget
                .claim
                .live_bytes
                .checked_add(budget.result.live_bytes)
                .and_then(|n| n.checked_add(retirement.map_or(0, |v| v.live_bytes)))
                .is_none_or(|n| n > credits.live_bytes)
        {
            return Err("funding_budget");
        }
        Ok(CompletionCredit {
            identity: self,
            intent_binding: None,
            held: Some(held),
            budget,
            retirement,
            assigned: None,
            returned: false,
            result_limit: None,
        })
    }
}

impl CompletionCredit {
    pub(super) fn export_source(&self, store: &Store) -> Result<super::export_capacity::Source> {
        let held = self.held.as_ref().ok_or("funding")?;
        if self.returned || self.assigned.is_some() || !held.unassigned() {
            return Err("funding_assigned");
        }
        store
            .check_reservation_binding(held, self.identity.binding)
            .map_err(|_| "funding")?;
        Ok(super::export_capacity::Source {
            intent: self.identity.intent.clone(),
            snapshot: self.identity.snapshot.clone(),
            claim_namespace: self.identity.claim_namespace.clone(),
            delivery_namespace: self.identity.delivery_namespace.clone(),
            intent_binding: self.intent_binding.unwrap_or(self.identity.binding),
            execution_funding_namespace: held.coordinate().0.into(),
            execution_generation: held.generation().cloned(),
        })
    }
    /// Native output ceiling selected by application policy. Oversized observed
    /// output is retained as a limit fault, never truncated into success.
    pub fn with_result_limit(mut self, bytes: usize) -> Result<Self> {
        if bytes == 0 || bytes > 1_048_576 {
            return Err("funding_budget");
        }
        self.result_limit = Some(bytes);
        Ok(self)
    }
    pub(super) fn origin_binding(&self) -> [u8; 32] {
        self.identity.binding
    }

    pub(super) fn check_attempt(&self, attempt: &Attempt<'_>) -> Result<()> {
        if self.returned
            || self.assigned.is_some()
            || self.identity.intent != attempt.intent
            || self.identity.snapshot != attempt.snapshot
            || self.identity.claim_namespace != attempt.claim_namespace
        {
            return Err("funding_identity");
        }
        attempt
            .store
            .check_reservation_binding(self.held.as_ref().ok_or("funding")?, self.identity.binding)
            .map_err(|_| "funding")
    }
    pub(super) fn check_delivery(&self, delivery: &str) -> Result<()> {
        if self.identity.delivery_namespace == delivery {
            Ok(())
        } else {
            Err("funding_identity")
        }
    }
    pub(super) fn attempt_assignment(&self, attempt: &Attempt<'_>) -> Result<witness::Assignment> {
        self.check_attempt(attempt)?;
        let facts = attempt.worker.facts().map_err(|_| "worker")?;
        if attempt.store.has_reservation_witnesses() {
            return witness::Assignment::observe(self, attempt);
        }
        Ok(witness::Assignment {
            witness: None,
            dispatch: None,
            binding: hash(&[
                b"sigil-completion-attempt/v1",
                &self.identity.binding,
                attempt.prepared.generation.as_bytes(),
                attempt.prepared.ticket.as_bytes(),
                attempt.prepared.input_sha256.as_bytes(),
                facts.source_sha256.as_bytes(),
                facts.runtime_sha256.as_bytes(),
                attempt.prepared_audit.as_bytes(),
            ]),
        })
    }
    pub(super) fn parent_binding(&self) -> [u8; 32] {
        self.identity.binding
    }
    pub(super) fn check_assigned(&self, store: &Store) -> Result<()> {
        if self.returned {
            return Err("funding");
        }
        store
            .check_reservation_binding(
                self.held.as_ref().ok_or("funding")?,
                self.assigned.ok_or("funding")?,
            )
            .map_err(|_| "funding")
    }
    pub(super) fn take_returned(&mut self) -> Option<Held> {
        if self.returned {
            self.held.take()
        } else {
            None
        }
    }
}

#[path = "completion_witness.rs"]
pub mod witness;

#[cfg(test)]
#[path = "retirement_funding_tests.rs"]
mod retirement_tests;
