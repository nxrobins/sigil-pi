"""Select the archive-verified CI solver and provision env-cleared Linux workers.

CI verifies the official archive SHA-256 before invoking this helper. This is
runner setup, not a product installer or permission to weaken worker env_clear.
"""
import argparse
import hashlib
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys


LIB_DIR = Path("/opt/sigil-pi-ci/z3/lib")
LOADER_CONFIG = Path("/etc/ld.so.conf.d/sigil-pi-ci-z3.conf")


def regular(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError(f"not a regular file: {path}")
    return path


def select(root, version):
    if "SIGIL_Z3_IDENTITY" in os.environ:
        raise ValueError("refusing pre-set SIGIL_Z3_IDENTITY; identity must be observed")
    binary = regular(root / "bin/z3")
    env = dict(os.environ, PATH=f"{root / 'bin'}:{os.environ.get('PATH', '')}",
               LD_LIBRARY_PATH=str(root / "bin"))
    selected = shutil.which("z3", path=env["PATH"])
    if selected is None or Path(selected).resolve() != binary:
        raise ValueError("the pinned z3 is not executable or a different solver was selected")
    result = subprocess.run([selected, "--version"], env=env, capture_output=True,
                            text=True, check=True, timeout=30)
    identity = result.stdout.strip()
    if identity != f"Z3 version {version} - 64 bit":
        raise ValueError(f"unexpected Z3 identity: {identity!r}")
    # Cargo tracks SIGIL_Z3_IDENTITY, but not changes to PATH. Persist the actual
    # observation so a restored build cache is invalidated when the solver moves.
    with Path(os.environ["GITHUB_PATH"]).open("a") as output:
        output.write(f"{root / 'bin'}\n")
    with Path(os.environ["GITHUB_ENV"]).open("a") as output:
        output.write(f"SIGIL_Z3_IDENTITY={identity}\n")
    print(identity)


def trusted_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise ValueError(f"loader directory must be root-owned and not writable by others: {path}")


def install(root):
    if sys.platform != "linux" or os.geteuid() != 0:
        raise ValueError("runtime installation requires root inside the Linux CI runner")
    source = regular(root / "bin/libz3.so")
    # Never register a runner-writable checkout in the system loader search path.
    # Validate each parent before creating its child; do not follow symlink dirs.
    for directory in [Path("/"), Path("/opt"), LIB_DIR.parent.parent, LIB_DIR.parent, LIB_DIR]:
        if not directory.exists() and not directory.is_symlink():
            directory.mkdir(mode=0o755)
        trusted_directory(directory)
    for directory in [Path("/etc"), LOADER_CONFIG.parent]:
        trusted_directory(directory)
    for destination in [LIB_DIR / "libz3.so", LOADER_CONFIG]:
        if destination.exists() or destination.is_symlink():
            info = regular(destination).stat()
            if info.st_uid != 0 or info.st_mode & 0o022:
                raise ValueError(f"unsafe existing loader file: {destination}")
    subprocess.run(["install", "-o", "root", "-g", "root", "-m", "0644",
                    str(source), str(LIB_DIR / "libz3.so")], check=True, timeout=30)
    if hashlib.sha256(source.read_bytes()).digest() != hashlib.sha256(
            (LIB_DIR / "libz3.so").read_bytes()).digest():
        raise ValueError("installed runtime library differs from the verified archive")
    LOADER_CONFIG.write_text(f"{LIB_DIR}\n")
    LOADER_CONFIG.chmod(0o644)
    subprocess.run(["/sbin/ldconfig"], check=True, timeout=30)


def verify(version):
    # A new process is essential: loader environment is consumed at exec time.
    # No LD_LIBRARY_PATH, Python import path, or ambient Z3 install is accepted.
    probe = """
import ctypes, pathlib, sys
lib = ctypes.CDLL('libz3.so')
values = [ctypes.c_uint() for _ in range(4)]
lib.Z3_get_version.argtypes = [ctypes.POINTER(ctypes.c_uint)] * 4
lib.Z3_get_version.restype = None
lib.Z3_get_version(*(ctypes.byref(value) for value in values))
assert '.'.join(str(value.value) for value in values[:3]) == sys.argv[1], 'wrong Z3 version'
loaded = {line.split()[-1] for line in pathlib.Path('/proc/self/maps').read_text().splitlines()
          if '/' in line and 'libz3.so' in line}
assert loaded == {sys.argv[2]}, f'wrong loaded library: {loaded}'
print('env-cleared Z3 loader verified: ' + sys.argv[2])
"""
    subprocess.run([sys.executable, "-I", "-c", probe, version, str(LIB_DIR / "libz3.so")],
                   cwd="/", env={"LANG": "C.UTF-8"}, check=True, timeout=30)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("select", "install", "verify"))
    parser.add_argument("--root", type=Path)
    parser.add_argument("--version", required=True)
    args = parser.parse_args()
    try:
        if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", args.version):
            raise ValueError("invalid solver version")
        if args.action == "verify":
            verify(args.version)
        else:
            if args.root is None or not args.root.is_absolute():
                raise ValueError("an absolute extracted-archive root is required")
            root = args.root.resolve(strict=True)
            if any(ord(char) < 32 or ord(char) == 127 for char in str(root)):
                raise ValueError("archive root contains a control character")
            if args.action == "select":
                select(root, args.version)
            else:
                install(root)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        parser.exit(1, f"CI Z3 setup failed: {error}\n")


if __name__ == "__main__":
    main()
