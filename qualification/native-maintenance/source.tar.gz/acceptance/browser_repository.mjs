// Public UI transport only; SIGIL makes every agent and authorization decision.
import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from 'playwright';
let raw='';for await(const c of process.stdin) raw+=c;
const config=JSON.parse(raw),base=new URL(config.url);
assert.equal(base.hostname,'127.0.0.1');
const browser=await chromium.launch({headless:true});
const report={turns:[],errors:[],submissions:[]};
const save=()=>writeFile(path.join(config.output,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
try {
  const page=await browser.newPage({viewport:{width:1280,height:900}});
  page.on('pageerror',e=>report.errors.push(e.message));
  page.on('request',r=>{if(r.method()==='POST')report.submissions.push({path:new URL(r.url()).pathname,body:r.postData()});});
  await page.route('**/*',r=>new URL(r.request().url()).origin===base.origin?r.continue():r.abort());
  await page.goto(base.href);
  const connect=async()=>{
    await page.getByLabel('Access token',{exact:true}).fill(config.token);
    await page.getByRole('button',{name:'Connect',exact:true}).click();
    await page.waitForFunction(()=>document.getElementById('notice').textContent.startsWith('Connected.'),null,{timeout:35000});
  };
  const submit=async(prompt)=>{
    const accepted=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname==='/v1/operations',{timeout:35000});
    await page.getByLabel('Message',{exact:true}).fill(prompt);
    await page.getByRole('button',{name:'Send message',exact:true}).click();
    const response=await accepted,body=await response.json();
    assert.equal(response.status(),202,JSON.stringify(body));return body;
  };
  const terminal=async(operation)=>{
    await page.waitForFunction(op=>document.getElementById('operation-id').textContent===op&&/^(Completed\.|The task failed\.|Cancelled |Outcome uncertain\.)/.test(document.getElementById('operation-state').textContent),operation,{timeout:330000});
    await page.waitForFunction(()=>!document.getElementById('refresh-history').disabled&&/committed phase (done|failed|cancelled|uncertain)\./.test(document.getElementById('history-note').textContent),null,{timeout:35000});
    return {operation,state:await page.locator('#operation-state').textContent(),reply:await page.locator('#final-answer').textContent()};
  };
  await connect();
  if(config.resume){
    await page.locator('#sessions').getByRole('button',{name:'interrupted',exact:true}).click();
    const previous=await terminal(config.resume);
    assert.ok(/^(Cancelled |Outcome uncertain\.)/.test(previous.state));
    assert.equal(report.submissions.length,0);
    const accepted=await submit('Read config/deploy.json and report the actual replica count. Do not change any files.');
    const result=await terminal(accepted.operation);
    report.turns.push(result);report.previous=previous;
    await page.screenshot({path:path.join(config.output,'continued-after-restart.png'),fullPage:true});
    await save();assert.ok(result.state.startsWith('Completed.'),JSON.stringify(result));
  } else {
    for(const task of config.tasks){
      await page.getByLabel('New conversation name',{exact:true}).fill(task.session);
      await page.getByRole('button',{name:'Start conversation',exact:true}).click();
      const accepted=await submit(task.prompt);
      const result={id:task.id,...await terminal(accepted.operation)};
      report.turns.push(result);await save();
      await page.screenshot({path:path.join(config.output,`${task.id}.png`),fullPage:true});
      assert.ok(result.state.startsWith('Completed.'),JSON.stringify(result));
      const submissions=report.submissions.length;
      await page.reload();await connect();
      await page.locator('#sessions').getByRole('button',{name:task.session,exact:true}).click();
      await terminal(accepted.operation);
      assert.equal(report.submissions.length,submissions);
      result.reopenedWithoutReplay=true;await save();
    }
    if(config.interruptAfter){
    await page.getByLabel('New conversation name',{exact:true}).fill('interrupted');
    await page.getByRole('button',{name:'Start conversation',exact:true}).click();
    const accepted=await submit('Inspect the repository and report its current configuration.');
    await page.getByRole('button',{name:'Request cancellation',exact:true}).click();
    report.interruption=await terminal(accepted.operation);
    await save();assert.ok(/^(Cancelled |Outcome uncertain\.)/.test(report.interruption.state),JSON.stringify(report.interruption));
    await page.screenshot({path:path.join(config.output,'cancelled.png'),fullPage:true});
    }
  }
  assert.deepEqual(report.errors,[]);
} finally {await save();await browser.close();}
