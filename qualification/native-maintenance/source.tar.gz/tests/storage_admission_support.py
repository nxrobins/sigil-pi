"""Explicit test envelopes for grantless storage admission, not authority issuance."""

import json

from api_support import binding, credential
from turn_support import fields, record


def fixture(rows=None):
    rows = rows or [credential()]
    names = [sorted(row["grants"]) + [f"owner{i}.claims", f"owner{i}.deliveries"]
             for i, row in enumerate(rows)]
    pools, bindings = [], []
    for row, scopes in zip(rows, names):
        tenant = fields(row["facts"], "CF2\n", 15)[1]
        existing = next((p for p, b in zip(pools, bindings) if b[0] == tenant), None)
        if existing:
            existing[1] = sorted(set(existing[1]) | set(scopes))
        else:
            pool = f"pool{len(pools)}"
            pools.append([pool, sorted(scopes), "1000", "1048576"])
            bindings.append([tenant, pool])
    return {"registry": [binding(row) for row in rows], "names": names,
            "pools": pools, "bindings": bindings, "records": "100000", "bytes": "134217728"}


def wire(value):
    pools = [record("SP1\n", [p[0], json.dumps(p[1]), p[2], p[3]]) for p in value["pools"]]
    return record("SA1\n", [json.dumps(value["registry"]),
        json.dumps([json.dumps(n) for n in value["names"]]), json.dumps(pools),
        value["records"], value["bytes"],
        json.dumps([record("ST1\n", b) for b in value["bindings"]])])
