"""Actual compiled SIGIL dispatch/completion and real compiler/test effects."""

import json
import os
import time
import subprocess
from pathlib import Path

import pytest

from acceptance.build_test_fixtures import TASKS, populate
from automatic_support import wait_operation
from test_workspace_agent import WorkspaceApi, call
from test_container_worker import PROFILE, containers
from turn_support import text_reply
from acceptance.capacity_evidence import inspect_capacity, assert_returned

if os.environ.get("PI_BUILD_TEST_PROFILE"):
    PROFILE = json.loads(Path(os.environ["PI_BUILD_TEST_PROFILE"]).read_text())

AUDIT_KEY = "capacity-test-key-never-for-a-pilot-0123456789"


@pytest.fixture(autouse=True)
def capacity_key(monkeypatch):
    if "completion_capacity" in PROFILE:
        monkeypatch.setenv("SIGIL_PI_AUDIT_KEY", AUDIT_KEY)


def check_capacity(root):
    if "completion_capacity" in PROFILE:
        assert_returned(inspect_capacity(root, AUDIT_KEY.encode()))


pytestmark = pytest.mark.skipif(
    os.environ.get("PI_CONTAINER_TESTS") != "1", reason="requires local Docker engine"
)


def reply():
    return json.loads(
        text_reply(
            "Observed results retained.",
            usage={"input_tokens": 10, "output_tokens": 10},
        )
    )


def test_actual_compiler_failure_is_seen_by_sigil_then_repaired(
    scripted_llm, tmp_path, monkeypatch
):
    monkeypatch.setenv("SIGIL_PI_LOCAL_PROVIDER_TOKEN", "local-placeholder")
    workspace = tmp_path / "workspace"
    populate(workspace, TASKS[0])
    scripted_llm.script = [
        call("edit_file", {"path": "src/scale.c", "old": "+ 32\n", "new": "+ 32;\n"}),
        call("build_project", {"path": "."}),
        call("edit_file", {"path": "src/scale.c", "old": "+ 32\n", "new": "+ 32;\n"}),
        call("build_project", {"path": "."}),
        call("test_project", {"path": "."}),
        reply(),
    ]
    with WorkspaceApi(
        tmp_path / "deployment", workspace, scripted_llm.url, profile=PROFILE
    ) as api:
        status, accepted = api.request(
            body={
                "session": "build",
                "message": "Repair and verify",
                "submission_key": "first",
            }
        )
        assert status == 202, accepted
        result = wait_operation(api, accepted["operation"])
        assert result["status"] == "done", result
        observed = [r["messages"][-1]["content"][0] for r in scripted_llm.requests[1:]]
        assert observed[0]["is_error"] and "No file changed" in observed[0]["content"]
        observed = observed[1:]
        assert (
            observed[0]["is_error"]
            and "FAIL: command exited 2" in observed[0]["content"]
        )
        assert (
            "expected" in observed[0]["content"] and "stderr:" in observed[0]["content"]
        )
        assert (
            not observed[2].get("is_error", False)
            and "PASS: command exited 0" in observed[2]["content"]
        )
        assert (
            "PASS: 3 C" in observed[3]["content"]
            and "Ran 3 tests" in observed[3]["content"]
        )
        assert not (workspace / "build").exists()
        check_capacity(api.root)


@pytest.mark.parametrize("mode", ["cancel", "kill"])
def test_active_container_interruption_is_not_replayed(
    scripted_llm, tmp_path, monkeypatch, mode
):
    monkeypatch.setenv("SIGIL_PI_LOCAL_PROVIDER_TOKEN", "local-placeholder")
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "README.md").write_text("retained")
    profile = json.loads(json.dumps(PROFILE))
    profile["commands"].update(
        build_project=[
            "/usr/bin/python3",
            "-c",
            "import os,time; os.fork(); os.setsid(); time.sleep(60)",
        ],
        wall_ms=4000,
    )
    scripted_llm.script = [
        call("build_project", {"path": "."}),
        call("build_project", {"path": "."}),
        reply(),
    ]
    root = tmp_path / "deployment"
    with WorkspaceApi(root, workspace, scripted_llm.url, profile=profile) as api:
        status, accepted = api.request(
            body={
                "session": "stopped",
                "message": "Run the approved build",
                "submission_key": "first",
            }
        )
        assert status == 202
        desc = json.loads((root / "effect-0-build_project.json").read_text())
        docker = PROFILE["commands"]["docker"]
        until = time.monotonic() + 90
        while time.monotonic() < until:
            p = subprocess.run(
                [docker, "inspect", "--format", "{{.State.Running}}", desc["slot"]],
                capture_output=True,
                text=True,
            )
            if p.returncode == 0 and p.stdout.strip() == "true":
                break
            time.sleep(0.1)
        else:
            raise AssertionError("container never started")
        count = len(scripted_llm.requests)
        if mode == "cancel":
            code, _ = api.request("POST", accepted["status_url"] + "/cancel", body={})
            assert code in (200, 202)
            stopped = wait_operation(api, accepted["operation"])
            assert stopped["status"] == "uncertain", stopped
            assert not containers(desc)
        else:
            api.proc.kill()
            api.proc.wait(timeout=5)
            time.sleep(4.5)
            state = json.loads(
                subprocess.check_output([docker, "inspect", desc["slot"]])
            )[0]
            assert (
                state["State"]["Running"] is False and state["State"]["ExitCode"] == 124
            )
    with WorkspaceApi(root, workspace, scripted_llm.url, mode="open") as api:
        recovered = wait_operation(api, accepted["operation"])
        assert recovered["status"] == "uncertain", recovered
        assert len(scripted_llm.requests) == count
        # A new explicit operation resumes the settled conversation. No old
        # command is replayed, and the original outcome remains uncertain.
        status, new = api.request(
            body={
                "session": "stopped",
                "message": "Run a new approved build now and report its actual outcome",
                "submission_key": "second",
            }
        )
        assert status == 202, new
        assert wait_operation(api, new["operation"])["status"] == "done"
        assert api.request("GET", accepted["status_url"])[1]["status"] == "uncertain"
        assert len(scripted_llm.requests) == count + 2
        assert (
            "FAIL: command exited 124"
            in scripted_llm.requests[-1]["messages"][-1]["content"][0]["content"]
        )
        assert not containers(desc)
        check_capacity(api.root)
