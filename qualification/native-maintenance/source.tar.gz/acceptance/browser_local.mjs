// Development acceptance capture using the real UI. Never advances agent policy.
import assert from 'node:assert/strict';
import {mkdir, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from 'playwright';

let raw = '';
for await (const chunk of process.stdin) raw += chunk;
const config = JSON.parse(raw), base = new URL(config.url);
assert.equal(base.hostname, '127.0.0.1');
const browser = await chromium.launch({headless: true});
const report = {cases: [], errors: [], foreign: [], submissions: [], score: null, review_status: 'unreviewed'};
const save = () => writeFile(path.join(config.output, 'ui-report.json'), JSON.stringify(report, null, 2) + '\n');
const screenshotDir = path.join(config.output, 'screenshots');
await mkdir(screenshotDir, {recursive: true});

async function connect(page, index) {
  await page.getByLabel('Access token', {exact: true}).fill(config.tokens[index]);
  await page.getByRole('button', {name: 'Connect', exact: true}).click();
  await page.waitForFunction(() => document.getElementById('notice').textContent.startsWith('Connected.'), null, {timeout: 35000});
}

try {
  const pages = [];
  for (let index = 0; index < 2; index++) {
    const context = await browser.newContext({viewport: {width: 1280, height: 900}});
    const page = await context.newPage();
    page.on('console', m => { if (m.type() === 'error') report.errors.push(m.text()); });
    page.on('pageerror', e => report.errors.push(e.message));
    page.on('request', request => {
      const url = new URL(request.url());
      if (url.origin !== base.origin && url.protocol !== 'data:') report.foreign.push(url.href);
      if (request.method() === 'POST') report.submissions.push({tenant: index, path: url.pathname, body: request.postData()});
    });
    await context.route('**/*', route => new URL(route.request().url()).origin === base.origin ? route.continue() : route.abort());
    assert.equal((await page.goto(base.href, {waitUntil: 'networkidle'})).status(), 200);
    await connect(page, index);
    pages.push(page);
  }
  for (const task of config.tasks) {
    const number = Number(task.id.slice(1)) - 1, tenant = number % 2, page = pages[tenant];
    const session = `case-${String(Math.floor(number / 2) + 1).padStart(2, '0')}`;
    const row = {id: task.id, tenant: 'ab'[tenant], session, turns: [], review_status: 'unreviewed'};
    report.cases.push(row);
    await save();
    await page.getByLabel('New conversation name', {exact: true}).fill(session);
    await page.getByRole('button', {name: 'Start conversation', exact: true}).click();
    for (let index = 0; index < task.prompts.length; index++) {
      const turn = {prompt: task.prompts[index]}, started = Date.now();
      row.turns.push(turn);
      try {
        if (task.reopen_before_prompt === index + 1) {
          const before = report.submissions.length;
          const previous = row.turns[index - 1].operation;
          await page.reload({waitUntil: 'networkidle'});
          assert.equal(await page.getByLabel('Access token', {exact: true}).inputValue(), '');
          await connect(page, tenant);
          await page.locator('#sessions').getByRole('button', {name: session, exact: true}).click();
          await page.waitForFunction(op => document.getElementById('operation-id').textContent === op, previous, {timeout: 35000});
          assert.equal(report.submissions.length, before);
          turn.reopened_without_resubmit = true;
        }
        const previous = await page.locator('#operation-id').textContent();
        const acceptance = page.waitForResponse(r => r.request().method() === 'POST' && new URL(r.url()).pathname === '/v1/operations', {timeout: 35000});
        await page.getByLabel('Message', {exact: true}).fill(turn.prompt);
        await page.getByRole('button', {name: 'Send message', exact: true}).click();
        const response = await acceptance;
        turn.acceptance = {status: response.status(), body: await response.json()};
        await save();
        assert.equal(turn.acceptance.status, 202);
        await page.waitForFunction(prior => {
          const id = document.getElementById('operation-id').textContent;
          const state = document.getElementById('operation-state').textContent;
          return id && id !== prior && /^(Completed\.|The task failed\.|Cancelled |Outcome uncertain\.)/.test(state);
        }, previous, {timeout: config.timeout_ms});
        turn.operation = await page.locator('#operation-id').textContent();
        turn.state = await page.locator('#operation-state').textContent();
        turn.reply = await page.locator('#final-answer').textContent();
        turn.usage = await page.locator('#operation-usage').textContent();
        // The terminal card renders before its asynchronous retained-history
        // refresh. Capture the settled UI, not that intermediate render.
        await page.waitForFunction(() => !document.getElementById('refresh-history').disabled
          && /committed phase (done|failed|cancelled|uncertain)\./.test(
          document.getElementById('history-note').textContent), null, {timeout: 35000});
        turn.history_note = await page.locator('#history-note').textContent();
        turn.messages = await page.locator('#messages').textContent();
        turn.completed = turn.state.startsWith('Completed.');
      } catch (error) {
        turn.error = error.message;
      } finally {
        turn.elapsed_s = (Date.now() - started) / 1000;
        await page.screenshot({path: path.join(screenshotDir, `${task.id}-${index + 1}.png`), fullPage: true});
        await save();
        console.log(JSON.stringify({case: task.id, prompt: index + 1, completed: turn.completed ?? false, error: turn.error, elapsed_s: turn.elapsed_s}));
      }
      if (!turn.completed) break; // No repeat, injected result or replacement turn.
    }
  }
  report.client_storage = [];
  for (const page of pages) {
    report.client_storage.push(await page.evaluate(() => ({local: localStorage.length, session: sessionStorage.length})));
    assert.deepEqual(await page.context().cookies(), []);
  }
  assert.deepEqual(report.foreign, []);
  assert.deepEqual(report.errors, []);
} finally {
  await save();
  await browser.close();
}
