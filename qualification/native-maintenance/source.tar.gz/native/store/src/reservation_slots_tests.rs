use super::*;
use std::os::unix::fs::PermissionsExt;

fn fixture() -> tempfile::TempDir {
    let d = tempfile::tempdir().unwrap();
    for n in ["data", "authority"] {
        let p = d.path().join(n);
        fs::create_dir(&p).unwrap();
        fs::set_permissions(p, fs::Permissions::from_mode(0o700)).unwrap();
    }
    d
}
fn open(p: &Path, mode: OpenMode) -> Store {
    try_open(p, mode).unwrap()
}
fn try_open(p: &Path, mode: OpenMode) -> Result<Store> {
    Store::open_anchored_reserved_bound(
        &p.join("data").canonicalize().unwrap(),
        &p.join("authority").canonicalize().unwrap(),
        mode,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "p".into(),
                namespaces: vec!["a".into()],
                records: 1000,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("p".into(), 128)]),
    )
}
fn grants(s: &Store) -> Scope {
    s.scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap()
}
fn batch(key: &str, revision: u64, value: &str) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: key.into(),
            revision,
            value: Some(value.into()),
        }],
    }
}
fn request() -> Request {
    Request {
        namespace: "a".into(),
        key: "reusable".into(),
        binding: [9; 32],
        credits: Credits {
            records: 1,
            live_bytes: 1000,
        },
    }
}
fn closed(s: &Store, scope: &Scope) -> Retirement {
    let r = s.reservation_snapshot(scope, "a", "reusable").unwrap();
    Retirement {
        namespace: "a".into(),
        key: "reusable".into(),
        revision: r.revision,
        binding: r.binding,
        generation: r.generation.unwrap(),
    }
}
fn finish(s: &mut Store, scope: &Scope, held: &Held, key: &str) {
    assert!(
        s.commit_spending(scope, &batch(key, 1, "completed"), held, held.credits())
            .unwrap()
            .held
            .is_none()
    );
}

#[test]
fn allocation_catalog_is_scoped_and_excludes_retired_history() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    assert!(s.reservation_keys(&scope, "a").unwrap().is_empty());
    let held = s
        .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    assert_eq!(s.reservation_keys(&scope, "a").unwrap(), ["reusable"]);
    let page = s.reservation_key_page(&scope, "a", None, 1).unwrap();
    assert_eq!(page.keys, ["reusable"]);
    assert_eq!(page.next.as_deref(), Some("reusable"));
    assert!(
        s.reservation_key_page(&scope, "a", page.next.as_deref(), 1)
            .unwrap()
            .keys
            .is_empty()
    );
    let denied = s
        .scope(BTreeMap::from([("a".into(), Access::CreateOnly)]))
        .unwrap();
    assert_eq!(s.reservation_keys(&denied, "a"), Err(Error::Denied));
    assert_eq!(s.reservation_keys(&scope, "other"), Err(Error::Denied));
    assert_eq!(
        s.reservation_key_page(&denied, "a", None, 1),
        Err(Error::Denied)
    );
    assert_eq!(
        s.reservation_key_page(&scope, "other", None, 1),
        Err(Error::Denied)
    );
    for limit in [0, 129] {
        assert_eq!(
            s.reservation_key_page(&scope, "a", None, limit),
            Err(Error::Invalid)
        );
    }
    assert_eq!(
        s.reservation_key_page(&scope, "a", Some("../outside"), 1),
        Err(Error::Invalid)
    );
    finish(&mut s, &scope, &held, "intent");
    assert_eq!(s.reservation_keys(&scope, "a").unwrap(), ["reusable"]);
    let retirement = closed(&s, &scope);
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &retirement)
        .unwrap();
    assert!(s.reservation_keys(&scope, "a").unwrap().is_empty());
    assert!(
        s.reservation_key_page(&scope, "a", None, 1)
            .unwrap()
            .keys
            .is_empty()
    );
    assert_eq!(
        s.get(&scope, "a", "intent").unwrap().value.as_deref(),
        Some("retired")
    );
}

#[test]
fn allocation_catalog_accepts_129_entries_with_the_exact_admitted_bound() {
    let d = fixture();
    let mut s = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "p".into(),
                namespaces: vec!["a".into()],
                records: 1000,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("p".into(), 129)]),
    )
    .unwrap();
    let scope = grants(&s);
    for i in 0..129 {
        let mut request = request();
        request.key = format!("funds-{i:03}");
        s.commit_reserving(
            &scope,
            &batch(&format!("intent-{i}"), 0, "accepted"),
            &request,
        )
        .unwrap();
        if i == 127 {
            assert_eq!(s.reservation_keys(&scope, "a").unwrap().len(), 128);
        }
    }
    let keys = s.reservation_keys(&scope, "a").unwrap();
    assert_eq!(keys.len(), 129);
    assert_eq!(keys.first().unwrap(), "funds-000");
    assert_eq!(keys.last().unwrap(), "funds-128");
    let first = s.reservation_key_page(&scope, "a", None, 128).unwrap();
    assert_eq!(first.keys, keys[..128]);
    assert_eq!(first.next.as_deref(), Some("funds-127"));
    let second = s
        .reservation_key_page(&scope, "a", first.next.as_deref(), 128)
        .unwrap();
    assert_eq!(second.keys, ["funds-128"]);
    assert!(second.next.is_none());
    assert_eq!(
        s.reservation_key_page(&scope, "a", Some("funds-127x"), 128)
            .unwrap()
            .keys,
        ["funds-128"]
    );
    let denied = s
        .scope(BTreeMap::from([("a".into(), Access::CreateOnly)]))
        .unwrap();
    assert_eq!(s.reservation_keys(&denied, "a"), Err(Error::Denied));
    let mut extra = request();
    extra.key = "extra".into();
    assert!(matches!(
        s.commit_reserving(&scope, &batch("overflow", 0, "denied"), &extra),
        Err(Error::Limit)
    ));
    assert_eq!(s.get(&scope, "a", "overflow").unwrap().revision, 0);
}

#[test]
fn allocation_pages_tolerate_insertions_retired_cursor_and_unfinished_reopen() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let mut a = request();
    a.key = "a".into();
    let held = s
        .commit_reserving(&scope, &batch("intent-a", 0, "accepted"), &a)
        .unwrap()
        .held
        .unwrap();
    let mut c = request();
    c.key = "c".into();
    s.commit_reserving(&scope, &batch("intent-c", 0, "accepted"), &c)
        .unwrap();
    let first = s.reservation_key_page(&scope, "a", None, 1).unwrap();
    assert_eq!(first.keys, ["a"]);
    finish(&mut s, &scope, &held, "intent-a");
    let r = s.reservation_snapshot(&scope, "a", "a").unwrap();
    s.commit_retiring_reservation(
        &scope,
        &batch("intent-a", 2, "retired"),
        &Retirement {
            namespace: "a".into(),
            key: "a".into(),
            revision: r.revision,
            binding: r.binding,
            generation: r.generation.unwrap(),
        },
    )
    .unwrap();
    for key in ["0", "b"] {
        let mut pending = request();
        pending.key = key.into();
        s.commit_reserving(
            &scope,
            &batch(&format!("intent-{key}"), 0, "accepted"),
            &pending,
        )
        .unwrap();
    }
    assert_eq!(
        s.reservation_key_page(&scope, "a", first.next.as_deref(), 128)
            .unwrap()
            .keys,
        ["b", "c"]
    );
    assert!(
        s.reservation_key_page(&scope, "a", Some("c"), 128)
            .unwrap()
            .keys
            .is_empty()
    );
    assert_eq!(
        s.reservation_key_page(&scope, "a", None, 128).unwrap().keys,
        ["0", "b", "c"]
    );
    assert_eq!(
        s.get(&scope, "a", "intent-a").unwrap().value.as_deref(),
        Some("retired")
    );
    drop(s);
    let s = open(d.path(), OpenMode::Existing);
    let scope = grants(&s);
    assert_eq!(
        s.reservation_key_page(&scope, "a", None, 128).unwrap().keys,
        ["0", "b", "c"]
    );
    for key in ["0", "b", "c"] {
        let actual = s.reservation_snapshot(&scope, "a", key).unwrap();
        assert_eq!(actual.credits, request().credits);
        assert!(actual.assignment.is_empty());
        assert_eq!(
            s.get(&scope, "a", &format!("intent-{key}"))
                .unwrap()
                .value
                .as_deref(),
            Some("accepted")
        );
    }
}

#[test]
fn two_hundred_fifty_six_cycles_keep_128_slots_and_all_application_records() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let mut stale: Option<Held> = None;
    for n in 1..=256u64 {
        let key = format!("intent-{n}");
        let held = s
            .commit_reserving(&scope, &batch(&key, 0, "accepted"), &request())
            .unwrap()
            .held
            .unwrap();
        let g = held.generation().unwrap();
        assert_eq!(g.slot, 0);
        assert_eq!(g.generation, n);
        if let Some(old) = stale.as_ref() {
            assert!(matches!(
                s.commit_spending(&scope, &batch(&key, 1, "stale result"), old, old.credits()),
                Err(Error::Conflict)
            ));
            assert!(matches!(
                s.resume_reservation_generation(
                    &scope,
                    "a",
                    "reusable",
                    1,
                    [9; 32],
                    old.generation().unwrap()
                ),
                Err(Error::Conflict)
            ));
            assert!(matches!(
                s.resume_reservation(&scope, "a", "reusable", 1, [9; 32]),
                Err(Error::Denied)
            ));
        }
        finish(&mut s, &scope, &held, &key);
        let retired = closed(&s, &scope);
        s.commit_retiring_reservation(&scope, &batch(&key, 2, "retired"), &retired)
            .unwrap();
        assert!(matches!(
            s.commit_retiring_reservation(&scope, &batch(&key, 3, "duplicate"), &retired),
            Err(Error::Conflict)
        ));
        stale = Some(held);
    }
    assert_eq!(
        s.connection
            .query_row("SELECT count(*) FROM reservation_slots", [], |r| r
                .get::<_, i64>(0))
            .unwrap(),
        128
    );
    assert_eq!(
        s.connection
            .query_row("SELECT count(*) FROM reservations", [], |r| r
                .get::<_, i64>(0))
            .unwrap(),
        0
    );
    assert_eq!(
        s.connection
            .query_row("SELECT count(*) FROM records", [], |r| r.get::<_, i64>(0))
            .unwrap(),
        256
    );
    drop(s);
    let s = open(d.path(), OpenMode::Existing);
    let scope = grants(&s);
    for n in 1..=256 {
        assert_eq!(
            s.get(&scope, "a", &format!("intent-{n}"))
                .unwrap()
                .value
                .as_deref(),
            Some("retired")
        );
    }
}

#[test]
fn retirement_requires_zero_credit_exact_identity_and_atomic_application_check() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let held = s
        .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    let mut r = closed(&s, &scope);
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 1, "retired"), &r),
        Err(Error::Conflict)
    );
    finish(&mut s, &scope, &held, "intent");
    r = closed(&s, &scope);
    r.generation.generation += 1;
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r),
        Err(Error::Conflict)
    );
    r.generation.generation -= 1;
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 1, "bad causal fence"), &r),
        Err(Error::Conflict)
    );
    assert_eq!(
        s.reservation_snapshot(&scope, "a", "reusable")
            .unwrap()
            .revision,
        r.revision
    );
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r)
        .unwrap();
}

#[test]
fn an_issued_lease_requires_a_new_actual_acquisition_even_after_drop() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let held = s
        .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    finish(&mut s, &scope, &held, "intent");
    let r = closed(&s, &scope);
    let lease = s.execution_lease().unwrap();
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r),
        Err(Error::Denied)
    );
    drop(lease);
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r),
        Err(Error::Denied)
    );
    drop(s);
    let mut s = open(d.path(), OpenMode::Existing);
    let scope = grants(&s);
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r)
        .unwrap();
}

#[test]
fn a_live_inherited_execution_holder_blocks_reopen_and_retirement() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let held = s
        .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    finish(&mut s, &scope, &held, "intent");
    let r = closed(&s, &scope);
    let lease = s.execution_lease().unwrap();
    // The child makes only async-signal-safe calls after fork and keeps the
    // inherited native exclusion descriptor open until actual kernel exit.
    let pid = unsafe { libc::fork() };
    assert!(pid >= 0);
    if pid == 0 {
        loop {
            unsafe { libc::pause() };
        }
    }
    drop(lease);
    drop(s);
    let blocked = matches!(try_open(d.path(), OpenMode::Existing), Err(Error::Busy));
    unsafe {
        libc::kill(pid, libc::SIGKILL);
        libc::waitpid(pid, std::ptr::null_mut(), 0);
    }
    assert!(blocked);
    let mut s = open(d.path(), OpenMode::Existing);
    let scope = grants(&s);
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r)
        .unwrap();
}

#[test]
fn exhausted_generation_never_wraps_and_missing_catalog_rows_never_reinitialize() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    // Reach the unreachable-in-test-time boundary through private test-only
    // state construction, with the same actual authority prepare/commit/confirm.
    let before = anchored::snapshot(&s.connection, 7).unwrap();
    let tx = s.connection.transaction().unwrap();
    tx.execute(
        "UPDATE reservation_slots SET generation=9223372036854775807",
        [],
    )
    .unwrap();
    let after = anchored::root(&tx, 7).unwrap();
    let ticket = s.anchor.as_mut().unwrap().prepare(before, after).unwrap();
    tx.commit().unwrap();
    s.anchor.as_mut().unwrap().confirm(ticket, after).unwrap();
    assert!(matches!(
        s.commit_reserving(&scope, &batch("intent", 0, "accepted"), &request()),
        Err(Error::Limit)
    ));
    assert_eq!(s.get(&scope, "a", "intent").unwrap().revision, 0);
    drop(s);
    let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
    c.execute("DELETE FROM reservation_slots WHERE slot=0", [])
        .unwrap();
    drop(c);
    assert!(try_open(d.path(), OpenMode::Existing).is_err());
}

#[test]
fn pool_exhaustion_and_retirement_cannot_reallocate_another_pools_slot() {
    let d = fixture();
    let allocation = capacity::Allocation {
        version: 1,
        pools: [("p", "a"), ("q", "b")]
            .into_iter()
            .map(|(id, ns)| capacity::Pool {
                id: id.into(),
                namespaces: vec![ns.into()],
                records: 20,
                live_bytes: 100_000,
            })
            .collect(),
    };
    let mut s = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        allocation,
        [3; 32],
        BTreeMap::from([("p".into(), 1), ("q".into(), 1)]),
    )
    .unwrap();
    let scope = s
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("b".into(), Access::ReadWrite),
        ]))
        .unwrap();
    let a = s
        .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    let b_batch = Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "b".into(),
            key: "intent".into(),
            revision: 0,
            value: Some("accepted".into()),
        }],
    };
    let mut b_request = request();
    b_request.namespace = "b".into();
    let b = s
        .commit_reserving(&scope, &b_batch, &b_request)
        .unwrap()
        .held
        .unwrap();
    let mut extra = request();
    extra.key = "extra".into();
    assert!(matches!(
        s.commit_reserving(&scope, &batch("extra", 0, "no capacity"), &extra),
        Err(Error::Limit)
    ));
    finish(&mut s, &scope, &a, "intent");
    let mut retirement = closed(&s, &scope);
    retirement.generation.pool = "q".into();
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 2, "wrong pool"), &retirement),
        Err(Error::Conflict)
    );
    retirement.generation.pool = "p".into();
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &retirement)
        .unwrap();
    let next = s
        .commit_reserving(&scope, &batch("new", 0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    assert_eq!(next.generation().unwrap().generation, 2);
    assert!(s.check_reservation_binding(&b, [9; 32]).is_ok());
    assert_eq!(b.generation().unwrap().generation, 1);
}

#[test]
fn audit_allowances_must_be_zero_before_reclamation_and_history_survives() {
    use crate::store::authenticated_log::{AuthenticatedLog, ChainLimits};
    let d = fixture();
    let mut s = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "p".into(),
                namespaces: vec!["a".into(), "heads".into(), "audit".into()],
                records: 1000,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("p".into(), 128)]),
    )
    .unwrap();
    let scope = s
        .scope(
            ["a", "heads", "audit"]
                .into_iter()
                .map(|n| (n.into(), Access::ReadWrite))
                .collect(),
        )
        .unwrap();
    let log = AuthenticatedLog::new(
        &s,
        "heads",
        "audit",
        ChainLimits {
            payload_bytes: 1024,
            records: 10,
            bytes: 30_000,
        },
        &[5; 32],
    )
    .unwrap();
    let chain = "a".repeat(64);
    let allowance = log
        .prepare_allowance(&s, &scope, &chain, 0, 2, 10_000)
        .unwrap();
    let held = s
        .commit_reserving_audited(
            &scope,
            &batch("intent", 0, "accepted"),
            &request(),
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let held = s
        .commit_spending(
            &scope,
            &batch("intent", 1, "data credits spent"),
            &held,
            held.credits(),
        )
        .unwrap()
        .held
        .unwrap();
    let retirement = closed(&s, &scope);
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("intent", 2, "premature"), &retirement),
        Err(Error::Conflict)
    );
    let publication = log
        .append_spending(
            &mut s,
            &scope,
            &chain,
            0,
            "terminal fact",
            &batch("intent", 2, "observed"),
            &held,
            Credits {
                records: 0,
                live_bytes: 0,
            },
        )
        .unwrap();
    let held = publication.held.unwrap();
    s.commit_spending_audited(
        &scope,
        &batch("intent", 3, "released"),
        &held,
        Credits {
            records: 0,
            live_bytes: 0,
        },
        &held.remaining_audit_debits(),
    )
    .unwrap();
    let retirement = closed(&s, &scope);
    s.commit_retiring_reservation(&scope, &batch("intent", 4, "retired"), &retirement)
        .unwrap();
    let checkpoint = log
        .verify(
            &mut s,
            &scope,
            &chain,
            Some(&publication.publication.checkpoint),
            std::time::Instant::now() + Duration::from_secs(1),
        )
        .unwrap();
    assert_eq!(checkpoint.count, 1);
    assert_eq!(
        s.get(&scope, "a", "intent").unwrap().value.as_deref(),
        Some("retired")
    );
}

#[test]
fn retirement_crash_child() {
    let Ok(path) = std::env::var("SIGIL_TEST_RETIRE_PATH") else {
        return;
    };
    let path = Path::new(&path);
    let mut s = open(path, OpenMode::Existing);
    let scope = grants(&s);
    let r = closed(&s, &scope);
    s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r)
        .unwrap();
    fs::write(path.join("receipt"), b"retired").unwrap();
    fs::File::open(path.join("receipt"))
        .unwrap()
        .sync_all()
        .unwrap();
    super::super::super::restore_anchor::cut("after_retirement_receipt");
}

#[test]
fn process_death_never_separates_causal_state_and_slot_retirement() {
    use std::os::unix::process::ExitStatusExt;
    let mut stages = vec![
        "before_store_database_commit".to_string(),
        "after_store_database_commit".to_string(),
        "before_store_receipt".to_string(),
        "after_retirement_receipt".to_string(),
    ];
    for record in ["prepared", "confirmed_first", "confirmed_mirror"] {
        stages.extend([
            format!("before_{record}_write"),
            format!("after_{record}_write"),
            format!("after_{record}_sync"),
        ]);
    }
    for stage in stages {
        let d = fixture();
        let mut s = open(d.path(), OpenMode::CreateNew);
        let scope = grants(&s);
        let held = s
            .commit_reserving(&scope, &batch("intent", 0, "accepted"), &request())
            .unwrap()
            .held
            .unwrap();
        finish(&mut s, &scope, &held, "intent");
        drop(s);
        let previous = fs::read(d.path().join("data/records.sqlite")).unwrap();
        let result = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::reservation::slots::tests::retirement_crash_child",
                "--nocapture",
            ])
            .env("SIGIL_TEST_RETIRE_PATH", d.path())
            .env("SIGIL_TEST_ANCHOR_CUT", &stage)
            .output()
            .unwrap();
        assert_eq!(
            result.status.signal(),
            Some(libc::SIGKILL),
            "{stage}: {}",
            String::from_utf8_lossy(&result.stderr)
        );
        let mut s = open(d.path(), OpenMode::Existing);
        let scope = grants(&s);
        let row = s.get(&scope, "a", "intent").unwrap();
        if row.value.as_deref() == Some("completed") {
            assert!(!d.path().join("receipt").exists());
            let r = closed(&s, &scope);
            s.commit_retiring_reservation(&scope, &batch("intent", 2, "retired"), &r)
                .unwrap();
        } else {
            assert_eq!(row.value.as_deref(), Some("retired"));
            assert!(matches!(
                s.reservation_snapshot(&scope, "a", "reusable"),
                Err(Error::Missing)
            ));
        }
        let held = s
            .commit_reserving(&scope, &batch("next", 0, "accepted"), &request())
            .unwrap()
            .held
            .unwrap();
        assert_eq!(held.generation().unwrap().generation, 2);
        drop(s);
        fs::write(d.path().join("data/records.sqlite"), previous).unwrap();
        assert!(matches!(
            try_open(d.path(), OpenMode::Existing),
            Err(Error::Denied)
        ));
    }
}

#[test]
fn allocation_proposal_is_read_only_and_exactly_checked_with_application_publication() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew);
    let scope = grants(&s);
    let read_only = s
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    let create_only = s
        .scope(BTreeMap::from([("a".into(), Access::CreateOnly)]))
        .unwrap();
    let before = anchored::snapshot(&s.connection, 7).unwrap();
    let proposal = s
        .next_reservation_generation(&read_only, "a", "first")
        .unwrap();
    assert_eq!(
        proposal,
        Generation {
            pool: "p".into(),
            slot: 0,
            generation: 1
        }
    );
    assert_eq!(anchored::snapshot(&s.connection, 7).unwrap(), before);
    assert!(matches!(
        s.next_reservation_generation(&create_only, "a", "first"),
        Err(Error::Denied)
    ));
    let mut first = request();
    first.key = "first".into();
    let identity_record = serde_json::to_string(&proposal).unwrap();
    assert!(matches!(
        s.commit_reserving_generation_audited(
            &read_only,
            &batch("first.identity", 0, &identity_record),
            &first,
            &[],
            &proposal
        ),
        Err(Error::Denied)
    ));
    let held = s
        .commit_reserving_generation_audited(
            &scope,
            &batch("first.identity", 0, &identity_record),
            &first,
            &[],
            &proposal,
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(held.generation(), Some(&proposal));
    assert_eq!(
        s.get(&scope, "a", "first.identity")
            .unwrap()
            .value
            .as_deref(),
        Some(identity_record.as_str())
    );
    assert!(matches!(
        s.next_reservation_generation(&scope, "a", "first"),
        Err(Error::Conflict)
    ));
    let mut second = request();
    second.key = "second".into();
    let before = anchored::snapshot(&s.connection, 7).unwrap();
    assert!(matches!(
        s.commit_reserving_generation_audited(
            &scope,
            &batch("second.identity", 0, &identity_record),
            &second,
            &[],
            &proposal
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(anchored::snapshot(&s.connection, 7).unwrap(), before);
    assert_eq!(s.get(&scope, "a", "second.identity").unwrap().revision, 0);
    let available = s
        .next_reservation_generation(&scope, "a", "second")
        .unwrap();
    assert_eq!(available.slot, 1);
    assert_eq!(available.generation, 1);
    let mut foreign = available.clone();
    foreign.pool = "foreign".into();
    assert!(matches!(
        s.commit_reserving_generation_audited(
            &scope,
            &batch("second.identity", 0, "foreign"),
            &second,
            &[],
            &foreign
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(anchored::snapshot(&s.connection, 7).unwrap(), before);
    let identity_record = serde_json::to_string(&available).unwrap();
    let held = s
        .commit_reserving_generation_audited(
            &scope,
            &batch("second.identity", 0, &identity_record),
            &second,
            &[],
            &available,
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(held.generation(), Some(&available));
}

#[test]
fn authenticated_allocation_rejects_stale_generation_without_publishing_record_or_log() {
    let d = fixture();
    let mut s = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "p".into(),
                namespaces: vec!["a".into(), "heads".into(), "entries".into()],
                records: 1000,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("p".into(), 128)]),
    )
    .unwrap();
    let scope = s
        .scope(
            ["a", "heads", "entries"]
                .into_iter()
                .map(|n| (n.into(), Access::ReadWrite))
                .collect(),
        )
        .unwrap();
    let log = authenticated_log::AuthenticatedLog::new(
        &s,
        "heads",
        "entries",
        authenticated_log::ChainLimits {
            payload_bytes: 1024,
            records: 8,
            bytes: 100_000,
        },
        b"generation-admission-fixture-key-0123456789",
    )
    .unwrap();
    let chain = "a".repeat(64);
    let expected = s
        .next_reservation_generation(&scope, "a", "reusable")
        .unwrap();
    let mut stale = expected.clone();
    stale.generation += 1;
    let before = anchored::snapshot(&s.connection, 7).unwrap();
    let allowance = log
        .prepare_allowance(&s, &scope, &chain, 0, 2, 2 * log.encoded_entry_ceiling())
        .unwrap();
    assert!(matches!(
        log.append_reserving_generation(
            &mut s,
            &scope,
            &chain,
            0,
            "admission",
            &batch("identity", 0, "retained generation"),
            &request(),
            &[allowance],
            &stale
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(anchored::snapshot(&s.connection, 7).unwrap(), before);
    assert_eq!(s.get(&scope, "a", "identity").unwrap().revision, 0);
    assert_eq!(s.get(&scope, "heads", &chain).unwrap().revision, 0);
    let allowance = log
        .prepare_allowance(&s, &scope, &chain, 0, 2, 2 * log.encoded_entry_ceiling())
        .unwrap();
    let publication = log
        .append_reserving_generation(
            &mut s,
            &scope,
            &chain,
            0,
            "admission",
            &batch("identity", 0, "retained generation"),
            &request(),
            &[allowance],
            &expected,
        )
        .unwrap();
    assert_eq!(publication.held.unwrap().generation(), Some(&expected));
    let (_, payload) = log
        .verified_payload(
            &mut s,
            &scope,
            &chain,
            0,
            std::time::Instant::now() + std::time::Duration::from_secs(5),
        )
        .unwrap();
    assert_eq!(payload, "admission");
}
