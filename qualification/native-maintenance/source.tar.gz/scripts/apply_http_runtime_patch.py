"""Apply/verify the development HTTP-budget patch in a disposable SIGIL checkout.

Never downloads, builds, changes SIGIL_REV, or treats a patch as release approval.
The base trees, affected source bytes, patch bytes and resulting bytes are checked.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


MANIFEST = Path(__file__).resolve().parents[1] / "runtime-patches/http-budget-v1.json"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def run(root, mode, manifest_path=MANIFEST):
    manifest = json.loads(manifest_path.read_text())
    patch = manifest_path.parent / manifest["patch"]
    if sha(patch.read_bytes()) != manifest["patch_sha256"]:
        raise ValueError("runtime patch differs from its manifest")
    for name in ("crates", "stdlib"):
        tree = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "HEAD:" + name], text=True).strip()
        if tree != manifest[name + "_tree"]:
            raise ValueError("wrong base " + name + " tree")
    changed = set(subprocess.check_output(
        ["git", "-C", str(root), "diff", "HEAD", "--name-only", "-z"]
    ).decode().rstrip("\0").split("\0")) - {""}
    allowed = {row["path"] for row in manifest["files"]} if mode == "verify" else set()
    if changed - allowed:
        raise ValueError("unrelated or pre-existing tracked source changes")
    untracked = subprocess.check_output([
        "git", "-C", str(root), "ls-files", "--others", "--exclude-standard", "-z",
        "crates", "stdlib", "proofs", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml",
    ])
    if untracked:
        raise ValueError("untracked build source in the checkout")
    field = "after_sha256" if mode == "verify" else "before_sha256"
    for row in manifest["files"]:
        path = root / row["path"]
        if path.is_symlink() or sha(path.read_bytes()) != row[field]:
            raise ValueError("source mismatch: " + row["path"])
    if mode in {"check", "apply"}:
        subprocess.run(["git", "-C", str(root), "apply", "--check",
                        "--whitespace=error-all", str(patch)], check=True)
    if mode == "apply":
        subprocess.run(["git", "-C", str(root), "apply", "--whitespace=error-all",
                        str(patch)], check=True)
        run(root, "verify", manifest_path)
    print("HTTP runtime patch " + mode + ": verified")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path)
    parser.add_argument("--mode", choices=("check", "apply", "verify"), default="check")
    parser.add_argument("--manifest", type=Path, default=MANIFEST)
    args = parser.parse_args()
    run(args.checkout.resolve(strict=True), args.mode, args.manifest.resolve(strict=True))
