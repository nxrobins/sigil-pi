"""Fresh version 14 assembly; generic observations plus SIGIL admission policy."""
import hashlib
import json
from pathlib import Path

from scripts.build_modular_maintenance_deployment import build as modular_build
from scripts.compose_dispatch_journal import with_dispatch_journal
from scripts.compose_generation_facts import compose_generation_facts
from scripts.compose_http_entry import HEADER_NAMES
from scripts.workspace_deployment import fields


def build(root, workspace, runtime, evaluator, stdlib, token, profile, **kwargs):
    programs = compose_generation_facts(stdlib)
    if profile.get('dispatch_journal') is not None:
        programs = {name: with_dispatch_journal(value) for name, value in programs.items()}
    config, path = modular_build(root, workspace, runtime, evaluator, stdlib, token, profile, **kwargs)
    root = Path(root).resolve()
    if config['version'] != 13 or len(config['functions']) != 7:
        raise ValueError('explicit modular maintenance baseline required')
    config['version'] = 14
    config['http'] = {'response_headers': HEADER_NAMES}
    namespaces = [fields(row['facts'], 'CF2\n', 15)[12] for row in config['credentials']]
    config['process_facts'] = dict(namespaces=namespaces,
        per_namespace=dict(value_bytes=1024, records=2, live_bytes=2048),
        lifecycle={'source': 'posix_sigusr1'})
    for name, worker in [('api_discovery', config['worker']), ('cancel_core', config['functions']['cancel_core']),
                         ('generation_admission', config['functions']['generation_admission'])]:
        source = root / (name + '.sigil'); source.write_text(programs[name].text)
        worker.update(source=str(source), source_sha256=programs[name].compiler_input_sha256)
    path.write_text(json.dumps(config, indent=2) + '\n')
    inventory = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'build-inputs.json'}
    (root / 'build-inputs.json').write_text(json.dumps(inventory, indent=2) + '\n')
    return config, path
