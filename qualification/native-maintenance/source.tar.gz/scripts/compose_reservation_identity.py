"""Compose the pure generation comparison without changing legacy modules."""
import hashlib
from pathlib import Path

from sigil_compose import compose_with_stdlib
from scripts.compose_application import ApplicationSource, strip_line_comments

ROOT = Path(__file__).resolve().parent.parent


def compose_reservation_identity(stdlib, *, root=ROOT):
    inputs = {}

    def read(name):
        raw = (Path(root) / name).read_bytes()
        inputs[name] = hashlib.sha256(raw).hexdigest()
        return raw.decode()

    def splice(body, marker, value):
        if body.count(marker) != 1:
            raise ValueError(f"expected one marker: {marker}")
        return body.replace(marker, value)

    body = read("app/pi/reservation_identity.sigil")
    body = splice(body, "// TURN_HELPERS", read("app/pi/turn_helpers.sigil"))
    body = splice(body, "// RECORD_HELPERS", read("app/shared/record_helpers.sigil"))
    body = splice(body, "// UTF8_VALIDATOR", read("app/shared/utf8.sigil"))
    protocol = read("app/shared/store_protocol.sigil")
    begin, end = "// STORE_READ_HELPERS_BEGIN", "// STORE_READ_HELPERS_END"
    if protocol.count(begin) != 1 or protocol.count(end) != 1:
        raise ValueError("store helper region changed")
    body = splice(body, "// STORE_READ_HELPERS", protocol.split(begin)[1].split(end)[0])
    compiled = compose_with_stdlib(body, ["json"], stdlib)
    text = strip_line_comments(compiled.text, compact_indent=True)
    if len(text.encode()) > 65536 or text.count("pub fn tool_main(") != 1:
        raise ValueError("generation comparator exceeds source/entry limits")
    inputs["scripts/compose_reservation_identity.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(text, inputs, compiled.stdlib_hash)
