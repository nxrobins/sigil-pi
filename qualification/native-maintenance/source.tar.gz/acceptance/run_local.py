"""Opt-in development acceptance capture, never an MVP qualification verdict.

Only static deployment assembly, public HTTP/browser transport and evidence
collection live here. The real native/SIGIL service runs every model/tool turn.
No paid endpoint, scripted model output, automatic retry or rubric editing.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time


PI = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(PI / "tests"), str(PI)]


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def local_get(path):
    connection = http.client.HTTPConnection("127.0.0.1", 11434, timeout=10)
    try:
        connection.request("GET", path)
        response = connection.getresponse()
        raw = response.read(2**20 + 1)
        assert response.status == 200 and len(raw) <= 2**20, "local metadata unavailable"
        return json.loads(raw)
    finally:
        connection.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True, help="Built single-request-v1 development sigil-mcp")
    parser.add_argument("--profile", type=Path, default=PI / "config/local-model-flint-cited-development.json")
    parser.add_argument("--interfaces", choices=("api", "browser"), nargs="+", default=["api", "browser"])
    parser.add_argument("--cases", nargs="+", help="Development subset; omitted cases never count as passes")
    parser.add_argument("--execute", action="store_true", help="Actually invoke the installed local model")
    args = parser.parse_args()
    if not args.execute:
        parser.error("--execute is required; this diagnostic makes real local model calls")
    from api_support import TOKEN_A, TOKEN_B, credential
    import automatic_support
    import browser_support
    import service_info_support
    from automatic_audit_support import audit_key, effect_audit_key, events
    from conftest import API_KEY, SIGIL_ROOT
    from scripts.compose_application import compose_application
    from sigil_compose import compose_with_stdlib
    from turn_support import configuration, record

    profile = json.loads(args.profile.read_text())
    assert profile["endpoint"] == "http://127.0.0.1:11434/v1/messages", "local endpoint only"
    reader_contract = profile.get("reader_contract", "raw-v1")
    assert reader_contract in ("raw-v1", "read-file-result-v1"), "unsupported reader contract"
    installed = next(x for x in local_get("/api/tags")["models"] if x["name"] == profile["model"])
    assert installed["digest"] == profile["model_digest"], "installed model changed"
    tasks = json.loads((PI / "acceptance/tasks.json").read_text())
    selected = tasks["tasks"]
    if args.cases:
        assert set(args.cases) <= {x["id"] for x in selected}, "unknown case"
        selected = [x for x in selected if x["id"] in args.cases]
    root = Path(tempfile.mkdtemp(prefix="sigil-pi-local-acceptance-", dir="/private/tmp"))
    report = {"kind": "development-local-model-acceptance-not-MVP-qualification", "root": str(root),
              "started_at": datetime.now(timezone.utc).isoformat(), "profile": profile,
              "installed_model": installed, "server_version": local_get("/api/version"),
              "loaded_before": local_get("/api/ps"), "cases_selected": [x["id"] for x in selected],
              "qualification": False, "score": None, "review_status": "unreviewed",
              "limitations": ["Not an approved/frozen pilot candidate or independent rubric review",
                              "Existing local native binaries copied and hashed; not a clean Linux build"],
              "interfaces": {}}
    save(root / "report.json", report)
    print(json.dumps({"root": str(root), "status": "started"}), flush=True)

    def checkpoint():
        save(root / "report.json", report)

    try:
        shutil.copytree(PI / "acceptance/workspace", root / "workspace-a")
        shutil.copytree(PI / "acceptance/workspace", root / "workspace-b")
        shutil.copy2(PI / "acceptance/tasks.json", root / "tasks.json")
        shutil.copy2(args.profile, root / "profile.json")
        artifacts = root / "artifacts"
        artifacts.mkdir()
        for name, source in {"sigil-mcp": args.runtime.resolve(),
                "sigil-application-host": PI / "native/service/target/release/sigil-application-host",
                "sigil-fixed-evaluator": PI / "native/evaluator/target/release/sigil-fixed-evaluator"}.items():
            shutil.copy2(source, artifacts / name)
        automatic_support.MCP_BIN = artifacts / "sigil-mcp"
        automatic_support.FIXED_EVALUATOR_BIN = artifacts / "sigil-fixed-evaluator"
        browser_support.FIXED_EVALUATOR_BIN = artifacts / "sigil-fixed-evaluator"
        original = service_info_support.audited_configuration

        def configure(*pos, **kw):
            config, path = original(*pos, **kw)
            for participant in config["automatic"]["participants"]:
                participant["effects"]["provider"]["worker"].update(
                    version=profile["provider_worker_version"], max_timeout_ms=profile["provider_timeout_ms"])
                for role in ("transaction_audit", "effect_audit"):
                    participant[role]["limits"] = profile["audit_limits"]
            save(path, config)
            return config, path

        service_info_support.audited_configuration = configure
        os.environ["PI_AUTOMATIC_FIXTURE_SECRET"] = API_KEY
        for index in range(2):
            os.environ[f"PI_AUTOMATIC_AUDIT_FIXTURE_KEY_{index}"] = audit_key(index)
            os.environ[f"PI_AUTOMATIC_EFFECT_AUDIT_FIXTURE_KEY_{index}"] = effect_audit_key(index)
        programs = {"provider": compose_with_stdlib((PI / "tools/agent_turn.sigil").read_text(), ["http"], SIGIL_ROOT).text,
                    "read_file": (PI / "tools/read_file.sigil").read_text()}
        if reader_contract == "read-file-result-v1":
            programs["read_file"] = compose_application("read_file_result", SIGIL_ROOT).text

            def component(name, *pos, **kw):
                return compose_application("turn_completion_read_result" if name == "turn_completion" else name, *pos, **kw)

            automatic_support.compose_application = component
        bp = record("BP1\n", [configuration(model=profile["model"], system=profile["system"],
                    max_tokens=profile["max_tokens"], max_steps=profile["max_steps"]), "8", "160000", "32768", "20000"])
        rows = [credential(profile=bp, turn_seconds=profile["operation_timeout_s"]),
                credential(TOKEN_B, principal="bob", tenant="tenant-b", prefix="b", profile=bp,
                           turn_seconds=profile["operation_timeout_s"])]
        runtime_manifest = PI / profile["runtime_patch_manifest"]
        runtime_patch = runtime_manifest.parent / json.loads(runtime_manifest.read_text())["patch"]
        inputs = [PI / "acceptance/run_local.py", PI / "acceptance/browser_local.mjs",
                  runtime_manifest, runtime_patch,
                  *sorted((PI / "tests").glob("*_support.py")), PI / "tests/conftest.py",
                  *sorted((PI / "scripts").glob("*.py")), PI / "sigil_compose.py"]
        report["harness_inputs"] = {str(p.relative_to(PI)): digest(p) for p in inputs}
        harness = artifacts / "harness"
        for source in inputs:
            target = harness / source.relative_to(PI)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            assert digest(target) == report["harness_inputs"][str(source.relative_to(PI))]
        # Retain and execute these exact driver bytes even if the working tree
        # changes during a long capture. Dependencies remain the local install.
        (harness / "node_modules").symlink_to(PI / "node_modules", target_is_directory=True)
        report["frozen_inputs"] = {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob("*"))
                                   if p.is_file() and p.name != "report.json"}
        checkpoint()
        for interface in dict.fromkeys(args.interfaces):
            area = root / interface
            area.mkdir()
            current = {"cases": [], "status": "running"}
            report["interfaces"][interface] = current
            checkpoint()
            asset_path = browser_support.assets(area) if interface == "browser" else None
            try:
                with service_info_support.ServiceInfoApi(artifacts / "sigil-application-host", area / "service",
                        programs, profile["endpoint"], [root / "workspace-a", root / "workspace-b"], rows=rows,
                        public_assets=asset_path, version="local-acceptance-development") as api:
                    current["ready"] = api.ready
                    current["config_sha256"] = digest(area / "service/service.json")
                    current["sources"] = {p.name: digest(p) for p in sorted((area / "service").glob("*.sigil"))}
                    checkpoint()
                    if interface == "browser":
                        gate = subprocess.run(["node", str(PI / "scripts/browser_runtime.mjs")],
                                              capture_output=True, text=True, timeout=30, cwd=PI)
                        assert gate.returncode == 0, gate.stderr
                        current["browser_runtime"] = json.loads(gate.stdout)
                        config = {"url": "http://" + api.ready["address"] + "/", "tokens": [TOKEN_A, TOKEN_B],
                                  "tasks": selected, "output": str(area), "timeout_ms": 135000}
                        with (area / "driver.log").open("w") as log:
                            result = subprocess.run(["node", str(harness / "acceptance/browser_local.mjs")],
                                input=json.dumps(config), stdout=log, stderr=subprocess.STDOUT, text=True,
                                timeout=7200, cwd=PI)
                        current["driver_exit"] = result.returncode
                        current.update(json.loads((area / "ui-report.json").read_text()))
                        assert result.returncode == 0, "browser capture driver failed; retained report/log"
                    else:
                        for task in selected:
                            number = int(task["id"][1:]) - 1
                            token = [TOKEN_A, TOKEN_B][number % 2]
                            session = f"case-{number // 2 + 1:02d}"
                            case = {"id": task["id"], "tenant": "ab"[number % 2], "session": session,
                                    "turns": [], "review_status": "unreviewed"}
                            current["cases"].append(case)
                            for index, prompt in enumerate(task["prompts"]):
                                turn = {"prompt": prompt}
                                case["turns"].append(turn)
                                if index + 1 == task.get("reopen_before_prompt"):
                                    turn["reopen_listing"] = api.request("GET", "/v1/sessions", token=token, raw=b"")
                                    turn["reopen_history"] = api.request("GET", f"/v1/sessions/{session}/messages", token=token, raw=b"")
                                start = time.monotonic()
                                status, accepted = api.request(token=token, body={"session": session,
                                    "message": prompt, "submission_key": f"{task['id']}-{index + 1}"})
                                turn["acceptance"] = {"status": status, "body": accepted}
                                checkpoint()
                                if status != 202:
                                    turn["error"] = "submission_not_accepted"
                                    break
                                deadline = time.monotonic() + 135
                                while time.monotonic() < deadline:
                                    status, outcome = api.request("GET", accepted["status_url"], token=token, raw=b"")
                                    if status != 200 or outcome["status"] != "accepted":
                                        turn["terminal"] = {"status": status, "body": outcome}
                                        break
                                    time.sleep(1.5)
                                else:
                                    turn["error"] = "observation_deadline_no_retry"
                                turn["elapsed_s"] = time.monotonic() - start
                                turn["history"] = api.request("GET", f"/v1/sessions/{session}/messages", token=token, raw=b"")
                                checkpoint()
                                print(json.dumps({"interface": interface, "case": task["id"], "prompt": index + 1,
                                    "status": turn.get("terminal", {}).get("body", {}).get("status", turn.get("error")),
                                    "elapsed_s": turn["elapsed_s"]}), flush=True)
                                if turn.get("error") or turn.get("terminal", {}).get("body", {}).get("status") != "done":
                                    break
                    for index in range(2):
                        for effects in (False, True):
                            save(area / f"verified-{'effects' if effects else 'transactions'}-{index}.json",
                                 events(area / "service", api.config, index, effects=effects))
                    current["status"] = "captured_pending_review"
            except Exception as exc:
                current.update(status="capture_error", error={"type": type(exc).__name__, "message": str(exc)})
                raise
            finally:
                db_path = area / "service/records/records.sqlite"
                if db_path.is_file():
                    with sqlite3.connect(f"file:{db_path}?mode=ro", uri=True) as db:
                        records = [{"namespace": ns, "key": key, "revision": rev,
                                    "value": bytes(value).hex() if isinstance(value, bytes) else value}
                                   for ns, key, rev, value in db.execute("SELECT namespace,key,revision,value FROM records ORDER BY namespace,key")]
                    save(area / "records.json", {"byte_values_encoding": "hex", "records": records})
                checkpoint()
        if set(report["interfaces"]) == {"api", "browser"}:
            report["same_compiled_sources_per_interface"] = report["interfaces"]["api"]["sources"] == report["interfaces"]["browser"]["sources"]
            assert report["same_compiled_sources_per_interface"], "interface source inventory changed during capture"
    except Exception as exc:
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        raise
    finally:
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        checkpoint()
        save(root / "retained-files.json", {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob("*"))
                                            if p.is_file() and p.name != "retained-files.json"})
        print(json.dumps({"report": str(root / "report.json")}), flush=True)


if __name__ == "__main__":
    main()
