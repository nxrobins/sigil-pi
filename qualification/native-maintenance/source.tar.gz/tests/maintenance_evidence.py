"""Fail-closed accounting for the independently observed maintenance costs."""
from collections import Counter
import hashlib
import json
import math

TIMING_REPORTS = ["two-tenant-request-metrics.json", "request-metrics.json", "restart-metrics.json"] + [
    f"drain-{case}-{phase}-metrics.json"
    for case in ["complete-direct", "cancel-direct", "complete-deferred"]
    for phase in ["request", "restart"]
]


def validate_timings(paths):
    paths = list(paths)
    assert Counter(p.name for p in paths) == Counter(TIMING_REPORTS), "incomplete or duplicate timing reports"
    reports = [json.loads(p.read_text()) for p in paths]
    for report in reports:
        at = report["startup_ms"]
        assert isinstance(at, (int, float)) and math.isfinite(at) and 0 <= at < 35000
        assert report["requests"], "service open has no measured requests"
        for request in report["requests"]:
            elapsed = request["elapsed_ms"]
            assert isinstance(elapsed, (int, float)) and math.isfinite(elapsed) and 0 <= elapsed < 30000
            assert request["status"] in {200, 202, 401, 404}, "unexpected measured response"
    return reports


def validate_monitor(exit_code, summary_path, raw_path):
    assert exit_code == 0, "process monitor failed"
    summary = json.loads(summary_path.read_text())
    assert summary["valid_process_selection_observed"] and summary["samples"] > 0
    assert summary["stop_reason"] == "requested" and not summary["coverage_truncated"]
    assert summary["observed_host_instances"] == 9, "not all service opens were observed"
    assert hashlib.sha256(raw_path.read_bytes()).hexdigest() == summary["raw_sha256"]
    return summary
