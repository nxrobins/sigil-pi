"""Static audited v10 configuration and transport; SIGIL decides admission/turns."""

import json
import select
import subprocess

from automatic_audit_support import configure as audited_configuration
from conftest import PI_ROOT, SIGIL_ROOT
from http_service_support import HttpApi
from scripts.compose_service_info_entry import compose_service_info_entry
from scripts.compose_storage_admission import compose_storage_admission
from test_evaluation_audit_publication import enable
from turn_support import fields, record


def configure_storage(root, programs, endpoint, workspace, *, rows=None, patch=None):
    def configure(config):
        built = compose_service_info_entry(PI_ROOT, SIGIL_ROOT, request_limit=10000,
                                          version="storage-fixture")
        source = root / "service-info-entry.sigil"
        source.write_text(built.text)
        config["worker"].update(source=str(source), source_sha256=built.compiler_input_sha256)
        policy = compose_storage_admission(PI_ROOT, SIGIL_ROOT)
        source = root / "storage-admission.sigil"
        source.write_text(policy.text)
        config["functions"]["admission"].update(source=str(source), source_sha256=policy.compiler_input_sha256)
        pools, tenants = {}, {}
        for row, participant in zip(config["credentials"], config["automatic"]["participants"]):
            tenant = fields(row["facts"], "CF2\n", 15)[1]
            if tenant not in tenants:
                tenants[tenant] = f"pool{len(tenants)}"
                pools[tenant] = set()
            names = pools[tenant]
            names.update(row["grants"])
            names.update([participant["claim_namespace"], participant["delivery_namespace"]])
            for role in ("transaction_audit", "effect_audit"):
                enable(participant[role], root)
                names.update([participant[role]["heads"], participant[role]["records"]])
        config["version"] = 10
        config["storage"] = {"policy": "admission",
            "parameters": json.dumps([record("ST1\n", [tenant, pool]) for tenant, pool in tenants.items()]),
            "allocation": {"version": 1, "pools": [
                {"id": tenants[tenant], "namespaces": sorted(names), "records": 1000, "live_bytes": 8 * 1024 * 1024}
                for tenant, names in pools.items()]}}
        if patch:
            patch(config)
    return audited_configuration(root, programs, endpoint, workspace, rows=rows,
                                 patch=configure, audit_effects=True)


class StorageAdmissionApi(HttpApi):
    def __init__(self, binary, root, programs, endpoint, workspace, *, rows=None,
                 mode="init", patch=None, public_assets=None):
        self.root = root
        self.config, path = configure_storage(root, programs, endpoint, workspace,
                                             rows=rows, patch=patch)
        command = [str(binary), mode, str(path), "0"]
        if public_assets is not None:
            command += ["--public-assets", str(public_assets)]
        self.proc = subprocess.Popen(command, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True)
        try:
            readable, _, _ = select.select([self.proc.stdout], [], [], 40)
            assert readable, "allocated service startup timed out"
            line = self.proc.stdout.readline()
            assert line, self.proc.stderr.read()
            self.ready = json.loads(line)
            assert self.ready["status"] == "ready" and self.ready["protocol"] == "sigil-application-host/v10"
            host, port = self.ready["address"].split(":")
            assert host == "127.0.0.1"
            self.port = int(port)
        except BaseException:
            self.close()
            raise
