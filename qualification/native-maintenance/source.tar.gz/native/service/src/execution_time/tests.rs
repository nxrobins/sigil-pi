use super::*;
use crate::frame;

fn guard(before: &str, until: &str) -> MillisecondGuard {
    let parsed = ExecutionGuard::parse(&frame("TG2\n", &[before, until]).expect("guard frame"))
        .expect("millisecond guard");
    let ExecutionGuard::Milliseconds(guard) = parsed else {
        panic!("wrong clock units");
    };
    guard
}

fn future() -> Instant {
    Instant::now() + Duration::from_secs(5)
}

#[test]
fn versions_do_not_reinterpret_legacy_entry_or_execution_units() {
    let raw = frame("TG1\n", &["1", "2"]).expect("legacy frame");
    assert!(matches!(
        ExecutionGuard::parse(&raw),
        Ok(ExecutionGuard::Seconds(_))
    ));
    let ms = frame("TG2\n", &["1", "2"]).expect("millisecond frame");
    assert!(Guard::parse(&ms).is_err(), "entry ABI remains TG1-only");
    assert!(matches!(
        ExecutionGuard::parse(&ms),
        Ok(ExecutionGuard::Milliseconds(_))
    ));
    assert!(ExecutionGuard::parse(&frame("TG3\n", &["1", "2"]).expect("unknown version")).is_err());
}

#[test]
fn codec_rejects_noncanonical_overflow_empty_or_extra_fields() {
    for (before, until) in [
        ("", "2"),
        ("01", "2"),
        ("+1", "2"),
        ("-1", "2"),
        (" 1", "2"),
        ("1.0", "2"),
        ("١", "2"),
        ("1", "02"),
        ("1", "9007199254740992"),
        ("1", "18446744073709551616"),
        ("2", "2"),
        ("2", "1"),
        ("0", "0"),
    ] {
        assert!(ExecutionGuard::parse(&frame("TG2\n", &[before, until]).expect("frame")).is_err());
    }
    let raw = frame("TG2\n", &["0", "9007199254740991"]).expect("maximum frame");
    assert!(ExecutionGuard::parse(&raw).is_ok());
    assert!(ExecutionGuard::parse(&(raw + "x")).is_err());
    assert!(
        ExecutionGuard::parse(&frame("TG2\n", &["1", "2", "3"]).expect("extra field")).is_err()
    );
}

#[test]
fn one_millisecond_window_has_exact_inclusive_start_and_exclusive_end() {
    for (at_ns, expected) in [
        (1_000_999_999, Err("time_guard")),
        (1_001_000_000, Ok(())),
        (1_001_999_999, Ok(())),
        (1_002_000_000, Err("time_guard")),
    ] {
        let mut seconds = 0;
        assert_eq!(
            guard("1001", "1002")
                .admit_with(&mut seconds, future(), || Ok(Duration::from_nanos(at_ns))),
            expected
        );
        assert_eq!(seconds, 1, "host watermark stays in seconds");
    }
}

#[test]
fn millisecond_rollback_is_refused_even_within_the_same_second_and_after_clone() {
    let guard = guard("1000", "2000");
    let mut seconds = 0;
    guard
        .admit_with(&mut seconds, future(), || Ok(Duration::from_millis(1501)))
        .expect("first sample");
    let handoff = guard.clone();
    assert_eq!(
        handoff.admit_with(&mut seconds, future(), || Ok(Duration::from_millis(1500))),
        Err("clock")
    );
    assert_eq!(
        handoff.admit_with(&mut seconds, future(), || Ok(Duration::from_millis(1501))),
        Ok(())
    );
    assert_eq!(
        guard.admit_with(&mut 2, future(), || Ok(Duration::from_millis(1502))),
        Err("clock")
    );
}

#[test]
fn clock_error_and_unrepresentable_time_are_refused() {
    let guard = guard("0", "9007199254740991");
    assert_eq!(
        guard.admit_with(&mut 0, future(), || Err("clock")),
        Err("clock")
    );
    assert_eq!(
        guard.admit_with(&mut 0, future(), || Ok(Duration::from_secs(u64::MAX))),
        Err("clock")
    );
}

#[test]
fn expired_monotonic_budget_is_not_renewed_or_observed() {
    let observed = Cell::new(false);
    let result = guard("0", "2000").admit_with(&mut 0, Instant::now(), || {
        observed.set(true);
        Ok(Duration::from_millis(1000))
    });
    assert_eq!(result, Err("deadline"));
    assert!(!observed.get());
}

#[test]
fn clock_read_overrun_cannot_pass_a_previously_live_budget() {
    let deadline = Instant::now() + Duration::from_millis(5);
    let result = guard("0", "2000").admit_with(&mut 0, deadline, || {
        std::thread::sleep(Duration::from_millis(10));
        Ok(Duration::from_millis(1000))
    });
    assert_eq!(result, Err("deadline"));
}

#[test]
fn retained_clock_fact_is_the_same_sample_checked_at_both_window_edges() {
    for (marker, before, until, at, expected) in [
        ("TG2\n", "1001", "1002", 1000, Err("time_guard")),
        ("TG2\n", "1001", "1002", 1001, Ok(1001)),
        ("TG2\n", "1001", "1002", 1002, Err("time_guard")),
        ("TG1\n", "1", "2", 999, Err("time_guard")),
        ("TG1\n", "1", "2", 1999, Ok(1999)),
        ("TG1\n", "1", "2", 2000, Err("time_guard")),
    ] {
        let guard = ExecutionGuard::parse(&frame(marker, &[before, until]).unwrap()).unwrap();
        let calls = Cell::new(0);
        assert_eq!(
            guard.observe_millis_with(&mut 0, future(), || {
                calls.set(calls.get() + 1);
                Ok(Duration::from_millis(at))
            }),
            expected
        );
        assert_eq!(calls.get(), 1);
    }
    let guard = ExecutionGuard::parse(&frame("TG2\n", &["1000", "2000"]).unwrap()).unwrap();
    guard
        .observe_millis_with(&mut 0, future(), || Ok(Duration::from_millis(1501)))
        .unwrap();
    assert_eq!(
        guard.observe_millis_with(&mut 0, future(), || Ok(Duration::from_millis(1500))),
        Err("clock")
    );
    assert_eq!(
        guard.observe_millis_with(&mut 0, Instant::now(), || panic!(
            "expired budget must not read clock"
        )),
        Err("deadline")
    );
}
