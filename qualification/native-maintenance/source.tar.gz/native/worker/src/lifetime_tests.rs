use super::*;
use std::fs;
use std::os::unix::fs::PermissionsExt;

struct Release(std::path::PathBuf);
impl Drop for Release {
    fn drop(&mut self) {
        let _ = fs::write(&self.0, b"release");
    }
}

// Controlled native-runtime fixture, not a SIGIL guest exploit. Its detached
// descendant retains all inherited descriptors, including the execution lease.
// A private release file and independent ten-second ceiling ensure cleanup even
// when an assertion fails; no signal is sent using an unowned/recycled PID.
fn descendant_fixture(detached: bool) -> (tempfile::TempDir, Release, Bridge) {
    let root = tempfile::tempdir().unwrap();
    let release = root.path().join("release");
    let ready = root.path().join("ready");
    let runtime = root.path().join("runtime");
    let code = format!(
        r##"#!/usr/bin/python3
import json, os, sys, time
release = {release:?}
ready = {ready:?}
json.loads(sys.stdin.readline())
print('{{"jsonrpc":"2.0","id":1,"result":{{}}}}', flush=True)
json.loads(sys.stdin.readline())
pid = os.fork()
if pid == 0:
    if {detached}: os.setsid()
    for fd in (0, 1, 2): os.close(fd)
    with open(ready, 'w') as stream: stream.write('ready')
    until = time.monotonic() + 10
    while not os.path.exists(release) and time.monotonic() < until: time.sleep(0.01)
    os._exit(0)
while not os.path.exists(ready): time.sleep(0.001)
inner = dict(status='ok', data=dict(output_text='observed'))
reply = dict(jsonrpc='2.0', id=2, result=dict(content=[dict(type='text', text=json.dumps(inner))]))
print(json.dumps(reply), flush=True)
time.sleep(10)
"##,
        release = release.to_str().unwrap(),
        ready = ready.to_str().unwrap(),
        detached = if detached { "True" } else { "False" },
    );
    fs::write(&runtime, &code).unwrap();
    fs::set_permissions(&runtime, fs::Permissions::from_mode(0o700)).unwrap();
    let source = root.path().join("program");
    fs::write(&source, "controlled native lifetime fixture").unwrap();
    let config = Config {
        version: 1,
        runtime,
        runtime_sha256: digest(code.as_bytes()),
        source,
        source_sha256: digest(b"controlled native lifetime fixture"),
        max_fuel: 1000,
        max_timeout_ms: 5000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    };
    let bridge = Bridge::new(config).unwrap();
    (root, Release(release), bridge)
}

#[test]
fn detached_descendant_cannot_be_reported_as_stopped_execution() {
    let (_root, _release, mut bridge) = descendant_fixture(true);
    let prepared = bridge.prepare("input".into(), 1000, 5000).unwrap();
    let observed = bridge
        .execute(&prepared.ticket, &AtomicBool::new(false))
        .unwrap();
    assert!(observed.request_may_have_run);
    assert!(
        !observed.worker_reaped,
        "leader exit is not descendant exclusion"
    );
    assert_eq!(observed.fault, Some(Fault::CleanupUnconfirmed));
}

#[test]
fn ordinary_process_group_descendants_are_confirmed_stopped() {
    let (_root, _release, mut bridge) = descendant_fixture(false);
    let prepared = bridge.prepare("input".into(), 1000, 5000).unwrap();
    let observed = bridge
        .execute(&prepared.ticket, &AtomicBool::new(false))
        .unwrap();
    assert!(observed.request_may_have_run && observed.worker_reaped);
    assert_eq!(observed.fault, None);
}
