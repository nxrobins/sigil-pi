"""Real SIGIL projection of historical codec vectors; no effect is executed.

ET1 inputs here are explicit test fixtures, not native authority or M6 evidence.
Native successor and unchanged-consumer integration are separate gates.
"""
import hashlib
import json
import pytest

from conftest import PI_ROOT, SIGIL_ROOT, needs_toolchain
from scripts.compose_control_plane_export import compose_control_plane_export
from turn_support import FUEL, fields, record


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


@pytest.fixture(scope="module")
def projection():
    needs_toolchain()
    row = json.loads((PI_ROOT / "tests/fixtures/control-plane-adapter-v1/captured.json").read_text())["vectors"][0]
    intent = bytes.fromhex(row["intent"]["hex"])
    app, source, nonce = "a" * 64, "b" * 64, "e" * 32
    boot = record("BO1\n", [app, "1", "1", source])
    key = sha(record("CK1\n", ["shared503/logical-effect/v1", app, "1", nonce]).encode()) + ":1"
    start = int.from_bytes(intent[16:22], "little")
    deadline = int.from_bytes(intent[22:28], "little")
    cp = record("CP1\n", [app, sha(("shared503/publication/v1:" + nonce).encode()), nonce,
        "1", "1", "adapter_intent", "application/adapter-intent/v1", source,
        intent.hex(), sha(intent), intent[40:72].hex(), intent[8:16].hex(), str(start), str(deadline),
        str(int.from_bytes(intent[28:34], "little"))])
    native = ["cp.intent", key, "1", cp, "c" * 64, "4", "", "",
              str(start + 1), str(start + 3), "d" * 64, "1" * 64, "2" * 64]
    source = compose_control_plane_export(SIGIL_ROOT, boot)
    return source.text, native, intent


def invoke(mcp, source, mode, facts, marker):
    intent = fields(facts[3], "CP1\n", 15)[8]
    source_guard = record("SG1\n", ["9" * 64, sha(bytes.fromhex(intent)), intent])
    return mcp.forge(source, input=record("XP1\n", [mode,
        record("GX1\n", [record(marker, facts), source_guard])]), fuel=FUEL)


def test_compiled_policy_funds_and_projects_truthful_unknown(mcp, projection):
    source, native, intent = projection
    budget = invoke(mcp, source, "budget", native[:5] + ["f" * 64, "96", "10000"], "EX1\n")
    assert budget["status"] == "ok", budget
    assert fields(budget["data"]["output_text"], "EB1\n", 5) == ["96", "3", "18768", "3", "18192"]
    response = invoke(mcp, source, "project", native, "ET1\n")
    assert response["status"] == "ok", response
    action, value = fields(response["data"]["output_text"], "EP1\n", 2)
    assert action == "publish"
    out = bytes.fromhex(value)
    expected = (bytes([1, 4, 1, 0]) + intent[8:16] + intent[40:72] + hashlib.sha256(intent).digest()
        + bytes(4) + int(native[8]).to_bytes(6, "little") + int(native[9]).to_bytes(6, "little")
        + bytes([2, 0, 255, 255]))
    assert out == expected and len(out) == 96


def test_compiled_policy_preserves_retained_503_times(mcp, projection):
    source, original, intent = projection
    native = original.copy()
    native[5:8] = ["2", "returned", record("HO1\n", [native[1], sha(intent), "503",
        str(int(native[8]) + 1), native[9], "1", "1"])]
    response = invoke(mcp, source, "project", native, "ET1\n")
    assert response["status"] == "ok", response
    action, value = fields(response["data"]["output_text"], "EP1\n", 2)
    assert action == "publish"
    out = bytes.fromhex(value)
    assert out[:4] == bytes([1, 2, 247, 1])
    assert out[4:76] == intent[8:16] + intent[40:72] + hashlib.sha256(intent).digest()
    assert int.from_bytes(out[80:86], "little") == int(native[8]) + 1
    assert int.from_bytes(out[86:92], "little") == int(native[9])
    assert out[92:96] == bytes([1, 0, 1, 0])


@pytest.mark.parametrize("change", ["zero_start", "zero_terminal", "regression", "late_start",
    "wrong_tenant", "wrong_nonce", "wrong_source", "wrong_key", "unknown_with_output", "unknown_with_status",
    "fake_503_count", "wrong_503_digest", "unsupported_phase"])
def test_compiled_projection_rejects_unbound_or_untruthful_facts(mcp, projection, change):
    source, original, intent = projection
    native = original.copy()
    if change in {"zero_start", "zero_terminal", "regression", "late_start"}:
        if change == "zero_start": native[8] = "0"
        if change == "zero_terminal": native[9] = "0"
        if change == "regression": native[9] = str(int(native[8]) - 1)
        if change == "late_start": native[8] = str(int.from_bytes(intent[22:28], "little"))
    elif change in {"wrong_tenant", "wrong_nonce", "wrong_source"}:
        cp = fields(native[3], "CP1\n", 15)
        index = {"wrong_tenant": 4, "wrong_nonce": 2, "wrong_source": 7}[change]
        cp[index] = "2" if index == 4 else "f" * len(cp[index])
        native[3] = record("CP1\n", cp)
    elif change == "wrong_key": native[1] = "f" * 64
    elif change == "unknown_with_output": native[7] = "503"
    elif change == "unknown_with_status": native[6] = "returned"
    elif change == "unsupported_phase": native[5] = "6"
    else:
        native[5:8] = ["2", "returned", record("HO1\n", [native[1],
            "0" * 64 if change == "wrong_503_digest" else sha(intent), "503", native[8], native[9],
            "0" if change == "fake_503_count" else "1", "1"])]
    response = invoke(mcp, source, "project", native, "ET1\n")
    assert response["status"] == "error", response


@pytest.mark.parametrize("case", ["absent", "changed_bytes", "changed_digest"])
def test_compiled_policy_requires_exact_observed_external_intent(mcp, projection, case):
    source, facts, intent = projection
    native = record("ET1\n", facts)
    if case != "absent":
        raw = (intent + b"changed") if case == "changed_bytes" else intent
        guard = record("SG1\n", ["9" * 64, "0" * 64 if case == "changed_digest" else sha(raw), raw.hex()])
        native = record("GX1\n", [native, guard])
    response = mcp.forge(source, input=record("XP1\n", ["project", native]), fuel=FUEL)
    assert response["status"] == "error", response


@pytest.mark.parametrize("suffix", ["", ":0", ":2", ":01", ":-1"])
def test_compiled_projection_requires_the_exact_audited_first_step(mcp, projection, suffix):
    source, original, intent = projection
    native = original.copy()
    native[1] = original[1].split(":")[0] + suffix
    for mode, facts, marker in [
        ("budget", native[:5] + ["f" * 64, "96", "10000"], "EX1\n"),
        ("project", native, "ET1\n"),
    ]:
        response = invoke(mcp, source, mode, facts, marker)
        assert response["status"] == "error", response
