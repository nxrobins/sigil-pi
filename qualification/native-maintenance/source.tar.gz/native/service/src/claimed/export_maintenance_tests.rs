//! A real acknowledged export and a PI allocation share the same fixed pool.
//! PI maintenance must preserve the foreign execution/export allocations.
use super::*;
use crate::policy::{Input, Key};
use crate::transaction::{Config, Transaction};
use sigil_durable_store::store::reservation::{Request, witness::Snapshot};

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct MaintenanceFixture {
    worker: crate::WorkerConfig,
    facts: String,
    bundle: String,
    operation: String,
    terminal: Vec<Mutation>,
    report: std::path::PathBuf,
}

fn same_allocation(actual: Snapshot, expected: &Snapshot) {
    assert_eq!(actual.revision, expected.revision);
    assert_eq!(actual.generation, expected.generation);
    assert_eq!(actual.binding, expected.binding);
    assert_eq!(actual.origin, expected.origin);
    assert_eq!(actual.credits, expected.credits);
    assert_eq!(actual.assignment, expected.assignment);
}

#[test]
#[ignore = "requires an explicitly pinned compiled PI maintenance fixture"]
fn actual_pi_retirement_preserves_acknowledged_foreign_export() {
    let _serial = process_guard();
    let f: MaintenanceFixture = serde_json::from_slice(
        &std::fs::read(std::env::var("SIGIL_MIXED_RETIREMENT_FIXTURE").unwrap()).unwrap(),
    )
    .unwrap();
    let (effect, mut sink, mut policy, intent, _) = executed_with_profile(None, 512, false, true);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = effect;
    drop(store);
    drop(worker);
    let mut store = reopen_profile(directory.path(), true);
    let ledger = ledger(&store);
    let source_scope = owner(&store);
    let terminal_effect = terminal(&mut store, &intent);
    let ack = ledger
        .export_terminal(
            &mut store,
            &source_scope,
            &intent,
            &terminal_effect,
            &mut sink,
            &mut policy,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap();
    assert!(!ack.replayed);
    let export_key = format!("funds:{intent}");
    let foreign_export = store
        .reservation_snapshot(&ledger.scope, "exports", &export_key)
        .unwrap();
    assert_eq!(
        foreign_export.credits,
        Credits {
            records: 0,
            live_bytes: 0
        }
    );
    let foreign_execution = store
        .reservation_snapshot(&source_scope, "funds", "operation:1")
        .unwrap();
    let scope = store
        .scope(BTreeMap::from([
            ("api".into(), Access::ReadWrite),
            ("funds".into(), Access::ReadWrite),
            ("delivery".into(), Access::ReadWrite),
        ]))
        .unwrap();
    let generation = store
        .next_reservation_generation(&scope, "funds", &f.operation)
        .unwrap();
    let bound_key = format!("generation:{}", f.operation);
    let bound = frame(
        "GB1\n",
        &[
            "funds",
            &f.operation,
            &generation.pool,
            &generation.slot.to_string(),
            &generation.generation.to_string(),
            &f.operation,
        ],
    )
    .unwrap();
    let mut seed = f.terminal.clone();
    for row in &mut seed {
        row.revision = 0;
    }
    seed.push(Mutation {
        namespace: "funds".into(),
        key: bound_key.clone(),
        revision: 0,
        value: Some(bound),
    });
    let held = store
        .commit_reserving_generation_audited(
            &scope,
            &Batch {
                checks: vec![],
                writes: seed,
            },
            &Request {
                namespace: "funds".into(),
                key: f.operation.clone(),
                binding: crate::digest_bytes(&f.operation).unwrap(),
                credits: Credits {
                    records: 1,
                    live_bytes: 4096,
                },
            },
            &[],
            &generation,
        )
        .unwrap()
        .held
        .unwrap();
    store
        .commit_spending(
            &scope,
            &Batch {
                checks: vec![],
                writes: f.terminal.clone(),
            },
            &held,
            held.credits(),
        )
        .unwrap();
    let retained = f
        .terminal
        .iter()
        .map(|r| store.get(&scope, &r.namespace, &r.key).unwrap())
        .collect::<Vec<_>>();
    let producer = |store: &Store, namespace: &str| {
        let read = |ns: &str, key| Input::Read {
            namespace: ns.into(),
            key,
        };
        Transaction::new(
            Config {
                worker: f.worker.clone(),
                marker: "RM2\n".into(),
                values: 1,
                grants: BTreeMap::from([
                    ("api".into(), Access::Read),
                    (namespace.into(), Access::ReadWrite),
                ]),
                inputs: vec![
                    Input::Literal {
                        value: f.facts.clone(),
                    },
                    Input::Literal {
                        value: f.bundle.clone(),
                    },
                    Input::Value { index: 0 },
                    Input::Clock,
                    read("api", Key::Value { index: 0 }),
                    read(namespace, Key::Value { index: 0 }),
                    read(
                        namespace,
                        Key::PrefixedValue {
                            prefix: "generation:".into(),
                            index: 0,
                        },
                    ),
                    Input::Reservation {
                        namespace: namespace.into(),
                        key: Key::Value { index: 0 },
                    },
                ],
            },
            store,
        )
        .unwrap()
    };
    let mut clock = 0;
    let mut pi = producer(&store, "funds");
    let other = pi
        .retire_generation(&mut store, &mut clock, &["operation:1".into()])
        .unwrap();
    assert_eq!(other.context[0], "retained");
    assert!(other.receipt.is_none());
    let mut exports = producer(&store, "exports");
    let other = exports
        .retire_generation(&mut store, &mut clock, std::slice::from_ref(&export_key))
        .unwrap();
    assert_eq!(other.context[0], "retained");
    assert!(other.receipt.is_none());
    let retired = pi
        .retire_generation(&mut store, &mut clock, std::slice::from_ref(&f.operation))
        .unwrap();
    assert_eq!(retired.context[0], "retired");
    assert!(retired.receipt.is_some());
    assert!(
        store
            .reservation_snapshot(&scope, "funds", &f.operation)
            .is_err()
    );
    assert!(
        store
            .get(&scope, "funds", &bound_key)
            .unwrap()
            .value
            .unwrap()
            .starts_with("GB2\n")
    );
    for (row, expected) in f.terminal.iter().zip(&retained) {
        assert_eq!(
            &store.get(&scope, &row.namespace, &row.key).unwrap(),
            expected
        );
    }
    same_allocation(
        store
            .reservation_snapshot(&ledger.scope, "exports", &export_key)
            .unwrap(),
        &foreign_export,
    );
    same_allocation(
        store
            .reservation_snapshot(&source_scope, "funds", "operation:1")
            .unwrap(),
        &foreign_execution,
    );
    assert!(
        ledger
            .replay_ack(
                &mut store,
                &intent,
                &sink,
                &policy,
                Instant::now() + Duration::from_secs(5)
            )
            .unwrap()
            .unwrap()
            .replayed
    );
    drop(pi);
    drop(exports);
    drop(store);
    let mut store = reopen_profile(directory.path(), true);
    let ledger = super::ledger(&store);
    same_allocation(
        store
            .reservation_snapshot(&ledger.scope, "exports", &export_key)
            .unwrap(),
        &foreign_export,
    );
    assert!(
        ledger
            .replay_ack(
                &mut store,
                &intent,
                &sink,
                &policy,
                Instant::now() + Duration::from_secs(5)
            )
            .unwrap()
            .unwrap()
            .replayed
    );
    std::fs::write(
        f.report,
        serde_json::to_vec_pretty(&serde_json::json!({
            "actual_export_acknowledged":true,"actual_compiled_pi_maintenance":true,
            "shared_pool_slots":8,"pi_allocation_retired":true,"foreign_allocations_unchanged":true,
            "historical_export_ack_replay":true,"export_reclaimed":false,"product_qualified":false
        }))
        .unwrap(),
    )
    .unwrap();
}
