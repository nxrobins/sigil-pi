use super::*;
use std::os::unix::fs::PermissionsExt;

fn allocation(records: u64, bytes: u64) -> capacity::Allocation {
    capacity::Allocation {
        version: 1,
        pools: vec![
            capacity::Pool {
                id: "alpha".into(),
                namespaces: vec!["a".into(), "aa".into()],
                records,
                live_bytes: bytes,
            },
            capacity::Pool {
                id: "beta".into(),
                namespaces: vec!["b".into()],
                records: 10,
                live_bytes: 10000,
            },
        ],
    }
}
fn temp_root() -> tempfile::TempDir {
    let root = tempfile::tempdir().unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    root
}
fn open(root: &Path, mode: OpenMode, records: u64, bytes: u64) -> Store {
    Store::open_reserved_bound(
        root,
        mode,
        Limits::default(),
        allocation(records, bytes),
        [3; 32],
    )
    .unwrap()
}
fn scope(store: &Store, names: &[(&str, Access)]) -> Scope {
    store
        .scope(
            names
                .iter()
                .map(|(name, access)| (name.to_string(), *access))
                .collect(),
        )
        .unwrap()
}
fn write(namespace: &str, key: &str, revision: u64, value: Option<&str>) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: namespace.into(),
            key: key.into(),
            revision,
            value: value.map(str::to_owned),
        }],
    }
}
fn request(records: u64, live_bytes: u64) -> Request {
    Request {
        namespace: "a".into(),
        key: "hold".into(),
        binding: [7; 32],
        credits: Credits {
            records,
            live_bytes,
        },
    }
}
type DataRow = (String, String, i64, Option<Vec<u8>>, Vec<u8>);
type LedgerRow = (
    String,
    String,
    rusqlite::types::Value,
    Vec<u8>,
    rusqlite::types::Value,
    rusqlite::types::Value,
    Vec<u8>,
);
type Snapshot = (i64, Vec<DataRow>, Vec<LedgerRow>);
fn snapshot(store: &Store) -> Snapshot {
    let revision = store
        .connection
        .query_row("SELECT revision FROM meta", [], |r| r.get(0))
        .unwrap();
    let rows = store
        .connection
        .prepare("SELECT namespace,key,revision,value,digest FROM records ORDER BY namespace,key")
        .unwrap()
        .query_map([], |r| {
            Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?))
        })
        .unwrap()
        .collect::<std::result::Result<_, _>>()
        .unwrap();
    let held=store.connection.prepare("SELECT namespace,key,revision,binding,records,bytes,digest FROM reservations ORDER BY namespace,key").unwrap()
        .query_map([],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?,r.get(4)?,r.get(5)?,r.get(6)?))).unwrap().collect::<std::result::Result<_,_>>().unwrap();
    (revision, rows, held)
}

#[test]
fn ordinary_writes_cannot_steal_credits_and_other_pool_still_works() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 3, 10000);
    let owner = scope(
        &store,
        &[
            ("a", Access::ReadWrite),
            ("aa", Access::ReadWrite),
            ("b", Access::ReadWrite),
        ],
    );
    let publication = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("intent")),
            &request(1, 500),
        )
        .unwrap();
    let held = publication.held.unwrap();
    assert_eq!(publication.receipt.revision, 1);
    assert_eq!(
        store.get(&owner, "aa", "delivery").unwrap(),
        Record {
            revision: 0,
            value: None
        }
    );
    let before = snapshot(&store);
    assert_eq!(
        store.commit(&owner, &write("aa", "interloper", 0, Some("bad"))),
        Err(Error::Limit)
    );
    assert_eq!(snapshot(&store), before);
    store
        .commit(&owner, &write("b", "work", 0, Some("independent")))
        .unwrap();
    let published = store
        .commit_spending(
            &owner,
            &write("aa", "delivery", 0, Some("result")),
            &held,
            held.credits(),
        )
        .unwrap();
    assert!(published.held.is_none());
    assert_eq!(
        store
            .get(&owner, "aa", "delivery")
            .unwrap()
            .value
            .as_deref(),
        Some("result")
    );
    assert!(matches!(
        store.resume_reservation(&owner, "a", "hold", 2, [7; 32]),
        Err(Error::Conflict)
    ));
    assert_eq!(
        store.commit(&owner, &write("a", "extra", 0, Some("bad"))),
        Err(Error::Limit)
    );
}

#[test]
fn reservation_and_intent_failure_are_atomic() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 2, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(1, 500)
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    assert_eq!(store.get(&owner, "a", "intent").unwrap().revision, 0);
}

#[test]
fn failed_debit_preserves_all_credits_data_and_revision() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(2, 500),
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "intent", 0, Some("stale")),
            &held,
            Credits {
                records: 1,
                live_bytes: 250
            }
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "done", 0, Some("x")),
            &held,
            Credits {
                records: 3,
                live_bytes: 0
            }
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    // Debit one slot while attempting two new rows. No partial debit survives.
    let mut two = write("a", "one", 0, Some("x"));
    two.writes.extend(write("a", "two", 0, Some("x")).writes);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &two,
            &held,
            Credits {
                records: 1,
                live_bytes: 250
            }
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn spending_does_not_mint_data_write_scope_or_cross_pool_credit() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(
        &store,
        &[
            ("a", Access::ReadWrite),
            ("aa", Access::ReadWrite),
            ("b", Access::ReadWrite),
        ],
    );
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(2, 500),
        )
        .unwrap()
        .held
        .unwrap();
    let denied = scope(&store, &[("aa", Access::Read)]);
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending(
            &denied,
            &write("aa", "done", 0, Some("x")),
            &held,
            held.credits()
        ),
        Err(Error::Denied)
    ));
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("b", "done", 0, Some("x")),
            &held,
            held.credits()
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    let writer = scope(&store, &[("aa", Access::CreateOnly)]);
    store
        .commit_spending(
            &writer,
            &write("aa", "done", 0, Some("x")),
            &held,
            held.credits(),
        )
        .unwrap();
}

#[test]
fn partial_consumption_invalidates_old_generation_and_binding_cannot_change() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(2, 500),
        )
        .unwrap()
        .held
        .unwrap();
    let next = store
        .commit_spending(
            &owner,
            &write("a", "one", 0, Some("x")),
            &held,
            Credits {
                records: 1,
                live_bytes: 250,
            },
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(next.revision(), 2);
    assert_eq!(
        next.credits(),
        Credits {
            records: 1,
            live_bytes: 250
        }
    );
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "two", 0, Some("x")),
            &held,
            Credits {
                records: 1,
                live_bytes: 250
            }
        ),
        Err(Error::Conflict)
    ));
    assert!(matches!(
        store.resume_reservation(&owner, "a", "hold", 2, [8; 32]),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    store
        .commit_spending(
            &owner,
            &write("a", "two", 0, Some("x")),
            &next,
            next.credits(),
        )
        .unwrap();
}

#[test]
fn restart_preserves_credits_but_old_process_handle_cannot_spend() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 3, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(1, 500),
        )
        .unwrap()
        .held
        .unwrap();
    drop(store);
    let mut store = open(root.path(), OpenMode::Existing, 3, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    assert_eq!(
        store.commit(&owner, &write("a", "steal", 0, Some("x"))),
        Err(Error::Limit)
    );
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "done", 0, Some("x")),
            &held,
            held.credits()
        ),
        Err(Error::Denied)
    ));
    let read_only = scope(&store, &[("a", Access::Read)]);
    assert!(matches!(
        store.resume_reservation(&read_only, "a", "hold", 1, [7; 32]),
        Err(Error::Denied)
    ));
    let resumed = store
        .resume_reservation(&owner, "a", "hold", 1, [7; 32])
        .unwrap();
    store
        .commit_spending(
            &owner,
            &write("a", "done", 0, Some("x")),
            &resumed,
            resumed.credits(),
        )
        .unwrap();
}

#[test]
fn reservation_metadata_and_utf8_growth_are_metered_exactly() {
    // intent a/i value x = 99; ledger a/hold =149; held bytes=2: total250.
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 10, 250);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let held = store
        .commit_reserving(&owner, &write("a", "i", 0, Some("x")), &request(0, 2))
        .unwrap()
        .held
        .unwrap();
    assert_eq!(
        store.commit(&owner, &write("a", "i", 1, Some("é"))),
        Err(Error::Limit)
    );
    let next = store
        .commit_spending(
            &owner,
            &write("a", "i", 1, Some("é")),
            &held,
            Credits {
                records: 0,
                live_bytes: 1,
            },
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(next.credits().live_bytes, 1);
    store
        .commit_spending(
            &owner,
            &write("a", "i", 2, Some("éx")),
            &next,
            next.credits(),
        )
        .unwrap();
    assert_eq!(
        store.commit(&owner, &write("a", "i", 3, Some("éxx"))),
        Err(Error::Limit)
    );
}

#[test]
fn explicit_schema_cannot_adopt_or_bypass_older_admission() {
    let root = temp_root();
    drop(open(root.path(), OpenMode::CreateNew, 4, 10000));
    assert!(matches!(
        Store::open_allocated_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(4, 10000),
            [3; 32]
        ),
        Err(Error::Corrupt)
    ));
    let old = temp_root();
    drop(
        Store::open_allocated_bound(
            old.path(),
            OpenMode::CreateNew,
            Limits::default(),
            allocation(4, 10000),
            [3; 32],
        )
        .unwrap(),
    );
    assert!(matches!(
        Store::open_reserved_bound(
            old.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(4, 10000),
            [3; 32]
        ),
        Err(Error::Corrupt)
    ));
}

#[test]
fn corruption_is_refused_by_inspection_and_reopen() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(1, 500),
        )
        .unwrap();
    store
        .inspect_namespaces(
            &owner,
            &["a".into()],
            std::time::Instant::now() + Duration::from_secs(2),
        )
        .unwrap();
    store
        .connection
        .execute("UPDATE reservations SET bytes=bytes+1", [])
        .unwrap();
    assert!(
        store
            .inspect_namespaces(
                &owner,
                &["a".into()],
                std::time::Instant::now() + Duration::from_secs(2)
            )
            .is_err()
    );
    drop(store);
    assert!(matches!(
        Store::open_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(4, 10000),
            [3; 32]
        ),
        Err(Error::Corrupt)
    ));
}

#[test]
fn two_reopened_handles_cannot_double_debit_or_recreate_a_closed_coordinate() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(2, 500),
        )
        .unwrap();
    let first = store
        .resume_reservation(&owner, "a", "hold", 1, [7; 32])
        .unwrap();
    let second = store
        .resume_reservation(&owner, "a", "hold", 1, [7; 32])
        .unwrap();
    store
        .commit_spending(
            &owner,
            &write("a", "done", 0, Some("x")),
            &first,
            first.credits(),
        )
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "duplicate", 0, Some("x")),
            &second,
            second.credits()
        ),
        Err(Error::Conflict)
    ));
    let mut new = request(1, 100);
    new.binding = [9; 32];
    assert!(matches!(
        store.commit_reserving(&owner, &write("a", "new", 0, Some("x")), &new),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn other_store_handle_and_wrong_process_are_refused_without_storage_mutation() {
    let r1 = temp_root();
    let mut first = open(r1.path(), OpenMode::CreateNew, 4, 10000);
    let r2 = temp_root();
    let mut second = open(r2.path(), OpenMode::CreateNew, 4, 10000);
    let a = scope(&first, &[("a", Access::ReadWrite)]);
    let b = scope(&second, &[("a", Access::ReadWrite)]);
    let held = first
        .commit_reserving(&a, &write("a", "intent", 0, Some("x")), &request(1, 100))
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&second);
    assert!(matches!(
        second.commit_spending(&b, &write("a", "done", 0, Some("x")), &held, held.credits()),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&second), before);
    let before = snapshot(&first);
    let process = first.owner.process;
    first.owner.process = process.wrapping_add(1);
    assert!(matches!(
        first.resume_reservation(&a, "a", "hold", 1, [7; 32]),
        Err(Error::Denied)
    ));
    assert!(matches!(
        first.commit_spending(&a, &write("a", "done", 0, Some("x")), &held, held.credits()),
        Err(Error::Denied)
    ));
    first.owner.process = process;
    assert_eq!(snapshot(&first), before);
}

#[test]
fn zero_overflow_and_unauthorized_reservation_requests_are_rejected() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    let create = scope(&store, &[("a", Access::CreateOnly)]);
    let before = snapshot(&store);
    for req in [request(0, 0), request(u64::MAX, 1), request(1, u64::MAX)] {
        assert!(matches!(
            store.commit_reserving(&owner, &write("a", "intent", 0, Some("x")), &req),
            Err(Error::Limit)
        ));
        assert_eq!(snapshot(&store), before);
    }
    assert!(matches!(
        store.commit_reserving(
            &create,
            &write("a", "intent", 0, Some("x")),
            &request(1, 100)
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn ordinary_authenticated_publication_cannot_bypass_held_capacity() {
    use crate::store::authenticated_log::{AuthenticatedLog, ChainLimits};
    let root = temp_root();
    let mut selected = allocation(4, 10000);
    selected.pools[0].namespaces = vec!["a".into(), "ah".into(), "ar".into()];
    let mut store = Store::open_reserved_bound(
        root.path(),
        OpenMode::CreateNew,
        Limits::default(),
        selected,
        [3; 32],
    )
    .unwrap();
    let owner = scope(
        &store,
        &[
            ("a", Access::ReadWrite),
            ("ah", Access::ReadWrite),
            ("ar", Access::ReadWrite),
        ],
    );
    store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(2, 500),
        )
        .unwrap();
    let log = AuthenticatedLog::new(
        &store,
        "ah",
        "ar",
        ChainLimits {
            payload_bytes: 16,
            records: 10,
            bytes: 10000,
        },
        &[7; 32],
    )
    .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        log.append(
            &mut store,
            &owner,
            &"f".repeat(64),
            0,
            "{}",
            &Batch {
                checks: vec![],
                writes: vec![]
            }
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn sqlite_commit_rejection_poisoning_requires_reconciliation_for_creation_and_spending() {
    for creating in [true, false] {
        let root = temp_root();
        let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
        let owner = scope(&store, &[("a", Access::ReadWrite)]);
        let held = if creating {
            None
        } else {
            store
                .commit_reserving(
                    &owner,
                    &write("a", "intent", 0, Some("x")),
                    &request(1, 500),
                )
                .unwrap()
                .held
        };
        let before = snapshot(&store);
        // A real SQLite commit error. This controlled hook rolls back; callers
        // receive the general CommitUncertain classification and must not infer it.
        store.connection.commit_hook(Some(|| true)).unwrap();
        let result = if let Some(held) = &held {
            store.commit_spending(
                &owner,
                &write("a", "done", 0, Some("x")),
                held,
                held.credits(),
            )
        } else {
            store.commit_reserving(
                &owner,
                &write("a", "intent", 0, Some("x")),
                &request(1, 500),
            )
        };
        assert!(matches!(result, Err(Error::CommitUncertain)));
        assert_eq!(
            store.commit(&owner, &write("a", "unsafe_retry", 0, Some("x"))),
            Err(Error::ReopenRequired)
        );
        drop(store);
        let reopened = open(root.path(), OpenMode::Existing, 4, 10000);
        assert_eq!(snapshot(&reopened), before);
    }
}

struct Child(std::process::Child);
impl Drop for Child {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn kill_at(root: &Path, kind: &str, phase: &str) {
    use std::io::{BufRead, BufReader};
    use std::process::{Command, Stdio};
    let mut child = Child(
        Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::reservation::tests::reservation_process_child",
                "--nocapture",
            ])
            .env("SIGIL_RESERVATION_TEST_ROOT", root)
            .env("SIGIL_RESERVATION_TEST_KIND", kind)
            .env("SIGIL_RESERVATION_TEST_PHASE", phase)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap(),
    );
    let output = child.0.stdout.take().unwrap();
    let (tx, rx) = std::sync::mpsc::channel();
    let reader = std::thread::spawn(move || {
        for line in BufReader::new(output)
            .lines()
            .map_while(std::result::Result::ok)
        {
            if line.contains("RESERVATION_BOUNDARY") {
                let _ = tx.send(());
                break;
            }
        }
    });
    rx.recv_timeout(Duration::from_secs(15))
        .expect("actual reservation transaction boundary not reached");
    child.0.kill().unwrap();
    assert!(!child.0.wait().unwrap().success());
    reader.join().unwrap();
}
#[test]
fn reservation_process_child() {
    use std::io::Write;
    let Ok(root) = std::env::var("SIGIL_RESERVATION_TEST_ROOT") else {
        return;
    };
    let kind = std::env::var("SIGIL_RESERVATION_TEST_KIND").unwrap();
    let phase = std::env::var("SIGIL_RESERVATION_TEST_PHASE").unwrap();
    let park = || {
        println!("RESERVATION_BOUNDARY");
        std::io::stdout().flush().unwrap();
        loop {
            std::thread::park();
        }
    };
    if kind == "audit" {
        let (mut store, owner, log) = audit_open(Path::new(&root), OpenMode::Existing, 2);
        let held = store
            .resume_reservation(&owner, "a", "hold", 1, [7; 32])
            .unwrap();
        if phase == "before" {
            log.append_spending_inner(
                &mut store,
                &owner,
                &"a".repeat(64),
                0,
                "observed",
                &write("aa", "done", 0, Some("result")),
                &held,
                held.credits(),
                park,
            )
            .unwrap();
        } else {
            log.append_spending(
                &mut store,
                &owner,
                &"a".repeat(64),
                0,
                "observed",
                &write("aa", "done", 0, Some("result")),
                &held,
                held.credits(),
            )
            .unwrap();
            park();
        }
        return;
    }
    let mut store = open(Path::new(&root), OpenMode::Existing, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    if kind == "create" {
        if phase == "before" {
            store
                .commit_reserving_inner(
                    &owner,
                    &write("a", "intent", 0, Some("x")),
                    &request(1, 500),
                    park,
                )
                .unwrap();
        } else {
            store
                .commit_reserving(
                    &owner,
                    &write("a", "intent", 0, Some("x")),
                    &request(1, 500),
                )
                .unwrap();
            park();
        }
    } else {
        let held = store
            .resume_reservation(&owner, "a", "hold", 1, [7; 32])
            .unwrap();
        if phase == "before" {
            store
                .commit_spending_inner(
                    &owner,
                    &write("a", "done", 0, Some("x")),
                    &held,
                    held.credits(),
                    park,
                )
                .unwrap();
        } else {
            store
                .commit_spending(
                    &owner,
                    &write("a", "done", 0, Some("x")),
                    &held,
                    held.credits(),
                )
                .unwrap();
            park();
        }
    }
}

#[test]
fn hard_death_around_creation_and_consumption_preserves_atomic_records_and_credits() {
    for kind in ["create", "spend"] {
        for phase in ["before", "after"] {
            let root = temp_root();
            let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
            let owner = scope(&store, &[("a", Access::ReadWrite)]);
            if kind == "spend" {
                store
                    .commit_reserving(
                        &owner,
                        &write("a", "intent", 0, Some("x")),
                        &request(1, 500),
                    )
                    .unwrap();
            }
            let before = snapshot(&store);
            drop(store);
            kill_at(root.path(), kind, phase);
            let mut store = open(root.path(), OpenMode::Existing, 4, 10000);
            let owner = scope(&store, &[("a", Access::ReadWrite)]);
            if phase == "before" {
                assert_eq!(snapshot(&store), before);
            } else if kind == "create" {
                assert_eq!(store.get(&owner, "a", "intent").unwrap().revision, 1);
                let held = store
                    .resume_reservation(&owner, "a", "hold", 1, [7; 32])
                    .unwrap();
                assert_eq!(
                    held.credits(),
                    Credits {
                        records: 1,
                        live_bytes: 500
                    }
                );
                assert!(matches!(
                    store.commit_reserving(
                        &owner,
                        &write("a", "duplicate", 0, Some("x")),
                        &request(1, 500)
                    ),
                    Err(Error::Conflict)
                ));
            } else {
                assert_eq!(store.get(&owner, "a", "done").unwrap().revision, 1);
                assert!(matches!(
                    store.resume_reservation(&owner, "a", "hold", 1, [7; 32]),
                    Err(Error::Conflict)
                ));
                assert!(matches!(
                    store.resume_reservation(&owner, "a", "hold", 2, [7; 32]),
                    Err(Error::Conflict)
                ));
                assert_eq!(
                    read(&store.connection, "a", "hold", 3)
                        .unwrap()
                        .unwrap()
                        .credits,
                    Credits {
                        records: 0,
                        live_bytes: 0
                    }
                );
            }
        }
    }
}

#[test]
fn ledger_limit_counts_closed_coordinates_and_rejects_extra_entry_atomically() {
    let root = temp_root();
    let mut store = open(
        root.path(),
        OpenMode::CreateNew,
        ENTRIES as u64 + 4,
        2_000_000,
    );
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    // Retained, already consumed coordinates are valid but still bounded.
    for n in 0..ENTRIES - 1 {
        apply(
            &store.connection,
            Change::Create(
                &Request {
                    namespace: "a".into(),
                    key: format!("closed_{n}"),
                    binding: [5; 32],
                    credits: Credits {
                        records: 0,
                        live_bytes: 0,
                    },
                },
                &[],
                None,
            ),
            3,
            store.allocation.as_ref(),
        )
        .unwrap();
    }
    store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(1, 500),
        )
        .unwrap();
    store
        .inspect_namespaces(
            &owner,
            &["a".into()],
            std::time::Instant::now() + Duration::from_secs(2),
        )
        .unwrap();
    let before = snapshot(&store);
    let mut extra = request(1, 100);
    extra.key = "extra".into();
    assert!(matches!(
        store.commit_reserving(&owner, &write("a", "second", 0, Some("x")), &extra),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    drop(store);
    let reopened = open(
        root.path(),
        OpenMode::Existing,
        ENTRIES as u64 + 4,
        2_000_000,
    );
    assert_eq!(snapshot(&reopened), before);
}

#[test]
fn oversized_malformed_and_unowned_metadata_fail_closed_without_repair() {
    for sql in [
        "UPDATE reservations SET namespace=printf('%2000000s','x')",
        "UPDATE reservations SET key=printf('%2000000s','x')",
        "UPDATE reservations SET binding=zeroblob(2000000)",
        "UPDATE reservations SET digest=zeroblob(2000000)",
        "UPDATE reservations SET namespace='unknown'",
        "UPDATE reservations SET key='invalid/coordinate'",
        "UPDATE reservations SET records=-1",
        "UPDATE reservations SET revision=0",
        "UPDATE reservations SET bytes='not a number'",
    ] {
        let root = temp_root();
        let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
        let owner = scope(&store, &[("a", Access::ReadWrite)]);
        store
            .commit_reserving(
                &owner,
                &write("a", "intent", 0, Some("x")),
                &request(1, 500),
            )
            .unwrap();
        store
            .connection
            .pragma_update(None, "ignore_check_constraints", "ON")
            .unwrap();
        store.connection.execute(sql, []).unwrap();
        store
            .connection
            .pragma_update(None, "ignore_check_constraints", "OFF")
            .unwrap();
        let before = snapshot(&store);
        assert!(
            store
                .inspect_namespaces(
                    &owner,
                    &["a".into()],
                    std::time::Instant::now() + Duration::from_secs(2)
                )
                .is_err(),
            "{sql}"
        );
        assert_eq!(snapshot(&store), before, "{sql}");
        drop(store);
        assert!(
            Store::open_reserved_bound(
                root.path(),
                OpenMode::Existing,
                Limits::default(),
                allocation(4, 10000),
                [3; 32]
            )
            .is_err(),
            "{sql}"
        );
    }
}

#[test]
fn reservation_revision_exhaustion_never_wraps_or_consumes_credit() {
    let root = temp_root();
    let mut store = open(root.path(), OpenMode::CreateNew, 4, 10000);
    let owner = scope(&store, &[("a", Access::ReadWrite)]);
    store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(1, 500),
        )
        .unwrap();
    let entry = Entry {
        generation: None,
        revision: i64::MAX as u64,
        binding: [7; 32],
        credits: Credits {
            records: 1,
            live_bytes: 500,
        },
        audits: vec![],
        witness: None,
    };
    store
        .connection
        .execute(
            "UPDATE reservations SET revision=?1,digest=?2",
            params![i64::MAX, digest("a", "hold", &entry, 3).unwrap()],
        )
        .unwrap();
    let held = store
        .resume_reservation(&owner, "a", "hold", i64::MAX as u64, [7; 32])
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending(
            &owner,
            &write("a", "done", 0, Some("x")),
            &held,
            held.credits()
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
}

fn audit_open(
    root: &Path,
    mode: OpenMode,
    chain_records: u64,
) -> (Store, Scope, authenticated_log::AuthenticatedLog) {
    let mut pools = allocation(6, 100_000);
    pools.pools[0].namespaces.extend(["ah".into(), "ar".into()]);
    let store = Store::open_reserved_bound(root, mode, Limits::default(), pools, [3; 32]).unwrap();
    let owner = scope(
        &store,
        &[
            ("a", Access::ReadWrite),
            ("aa", Access::ReadWrite),
            ("ah", Access::ReadWrite),
            ("ar", Access::ReadWrite),
        ],
    );
    let log = authenticated_log::AuthenticatedLog::new(
        &store,
        "ah",
        "ar",
        authenticated_log::ChainLimits {
            payload_bytes: 1024,
            records: chain_records,
            bytes: 40_000,
        },
        &[0x63; 32],
    )
    .unwrap();
    (store, owner, log)
}

#[test]
fn authenticated_result_data_and_partial_debit_publish_as_one_commit() {
    let root = temp_root();
    let (mut store, owner, log) = audit_open(root.path(), OpenMode::CreateNew, 2);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(4, 36_000),
        )
        .unwrap()
        .held
        .unwrap();
    let chain = "a".repeat(64);
    let before = snapshot(&store);
    assert!(matches!(
        log.append(
            &mut store,
            &owner,
            &chain,
            0,
            "observed",
            &write("aa", "done", 0, Some("result"))
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let published = log
        .append_spending(
            &mut store,
            &owner,
            &chain,
            0,
            "observed",
            &write("aa", "done", 0, Some("result")),
            &held,
            Credits {
                records: 3,
                live_bytes: 18_000,
            },
        )
        .unwrap();
    assert_eq!(published.publication.receipt.revision, 2);
    assert_eq!(published.publication.checkpoint.count, 1);
    assert_eq!(
        store.get(&owner, "aa", "done").unwrap().value.as_deref(),
        Some("result")
    );
    let current = published.held.unwrap();
    assert_eq!(
        current.credits(),
        Credits {
            records: 1,
            live_bytes: 18_000
        }
    );
    log.verify(
        &mut store,
        &owner,
        &chain,
        Some(&published.publication.checkpoint),
        std::time::Instant::now() + Duration::from_secs(2),
    )
    .unwrap();
    let before = snapshot(&store);
    // A signed append can neither steal the held credit nor debit its stale generation.
    assert!(matches!(
        log.append(
            &mut store,
            &owner,
            &chain,
            1,
            "later",
            &write("aa", "done", 1, Some("later"))
        ),
        Err(Error::Limit)
    ));
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &chain,
            1,
            "later",
            &write("aa", "done", 1, Some("later")),
            &held,
            Credits {
                records: 1,
                live_bytes: 18_000
            }
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    let published = log
        .append_spending(
            &mut store,
            &owner,
            &chain,
            1,
            "later",
            &write("aa", "done", 1, Some("later")),
            &current,
            current.credits(),
        )
        .unwrap();
    assert!(published.held.is_none());
    assert_eq!(published.publication.checkpoint.count, 2);
    log.verify(
        &mut store,
        &owner,
        &chain,
        Some(&published.publication.checkpoint),
        std::time::Instant::now() + Duration::from_secs(2),
    )
    .unwrap();
}

#[test]
fn audit_failure_preserves_credit_data_and_head_and_never_weakens_chain_limits() {
    let root = temp_root();
    let (mut store, owner, log) = audit_open(root.path(), OpenMode::CreateNew, 1);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(4, 36_000),
        )
        .unwrap()
        .held
        .unwrap();
    let chain = "a".repeat(64);
    let before = snapshot(&store);
    let denied = scope(
        &store,
        &[
            ("a", Access::ReadWrite),
            ("aa", Access::ReadWrite),
            ("ah", Access::Read),
            ("ar", Access::Read),
        ],
    );
    assert!(matches!(
        log.append_spending(
            &mut store,
            &denied,
            &chain,
            0,
            "observed",
            &write("aa", "done", 0, Some("result")),
            &held,
            held.credits()
        ),
        Err(Error::Denied)
    ));
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &chain,
            0,
            &"x".repeat(1025),
            &write("aa", "done", 0, Some("result")),
            &held,
            held.credits()
        ),
        Err(Error::Limit)
    ));
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &chain,
            0,
            "observed",
            &write("a", "intent", 0, Some("stale")),
            &held,
            held.credits()
        ),
        Err(Error::Conflict)
    ));
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &chain,
            0,
            "observed",
            &write("aa", "done", 0, Some("result")),
            &held,
            Credits {
                records: 2,
                live_bytes: 18_000
            }
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let published = log
        .append_spending(
            &mut store,
            &owner,
            &chain,
            0,
            "observed",
            &write("aa", "done", 0, Some("result")),
            &held,
            Credits {
                records: 3,
                live_bytes: 18_000,
            },
        )
        .unwrap();
    let held = published.held.unwrap();
    let before = snapshot(&store);
    // Logical pool credits cannot extend a separately exhausted audit chain.
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &chain,
            1,
            "later",
            &write("aa", "done", 1, Some("later")),
            &held,
            held.credits()
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn audited_spend_commit_error_poisoning_requires_reopen_and_reconciliation() {
    let root = temp_root();
    let (mut store, owner, log) = audit_open(root.path(), OpenMode::CreateNew, 2);
    let held = store
        .commit_reserving(
            &owner,
            &write("a", "intent", 0, Some("x")),
            &request(4, 36_000),
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    store.connection.commit_hook(Some(|| true)).unwrap();
    assert!(matches!(
        log.append_spending(
            &mut store,
            &owner,
            &"a".repeat(64),
            0,
            "observed",
            &write("aa", "done", 0, Some("result")),
            &held,
            held.credits()
        ),
        Err(Error::CommitUncertain)
    ));
    assert!(matches!(
        store.resume_reservation(&owner, "a", "hold", 1, [7; 32]),
        Err(Error::ReopenRequired)
    ));
    drop(store);
    let (store, _, _) = audit_open(root.path(), OpenMode::Existing, 2);
    assert_eq!(snapshot(&store), before);
}

#[test]
fn hard_death_at_audited_consumption_keeps_result_audit_and_credit_atomic() {
    for phase in ["before", "after"] {
        let root = temp_root();
        let (mut store, owner, _) = audit_open(root.path(), OpenMode::CreateNew, 2);
        store
            .commit_reserving(
                &owner,
                &write("a", "intent", 0, Some("x")),
                &request(4, 36_000),
            )
            .unwrap();
        let before = snapshot(&store);
        drop(store);
        kill_at(root.path(), "audit", phase);
        let (mut store, owner, log) = audit_open(root.path(), OpenMode::Existing, 2);
        if phase == "before" {
            assert_eq!(snapshot(&store), before);
        } else {
            assert_eq!(
                store.get(&owner, "aa", "done").unwrap().value.as_deref(),
                Some("result")
            );
            assert_eq!(
                log.verify(
                    &mut store,
                    &owner,
                    &"a".repeat(64),
                    None,
                    std::time::Instant::now() + Duration::from_secs(2)
                )
                .unwrap()
                .count,
                1
            );
            assert!(matches!(
                store.resume_reservation(&owner, "a", "hold", 2, [7; 32]),
                Err(Error::Conflict)
            ));
            let entry = read(&store.connection, "a", "hold", 3).unwrap().unwrap();
            assert!(entry.credits.empty());
            assert_eq!(entry.revision, 2);
        }
    }
}
