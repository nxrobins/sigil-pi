"""Fail-closed external accounting of bounded profile14 qualification."""
from collections import Counter
import hashlib
import json
import math
import statistics


def finite(value, ceiling):
    assert type(value) in (int, float) and math.isfinite(value) and 0 <= value < ceiling


def validate_cases(suites, expected):
    assert sum(int(s.attrib['tests']) for s in suites) == len(expected)
    assert all(int(s.attrib[k]) == 0 for s in suites for k in ['failures','errors','skipped'])
    actual = [dict(classname=t.attrib['classname'],name=t.attrib['name']) for s in suites for t in s.findall('testcase')]
    identity = lambda row: (row['classname'], row['name'])
    assert Counter(map(identity,actual)) == Counter(map(identity,expected)), 'test identity inventory differs'
    return actual


def validate_reports(paths, performance_path, summary_path, raw_path, binaries):
    reports = [json.loads(p.read_text()) for p in paths]
    assert len(reports) == 20
    assert Counter(r['expected_profile'] for r in reports) == {14: 16, 13: 4}
    pids = set()
    for report in reports:
        assert report['completed'] is True
        assert report['protocol'] == f"sigil-application-host/v{report['expected_profile']}"
        finite(report['startup_ms'], 35000)
        assert report['pid'] not in pids
        pids.add(report['pid'])
        assert report['requests']
        for row in report['requests']:
            finite(row['elapsed_ms'], 30000)
            assert row['status'] in {200, 202, 401, 404, 501, 503}
    perf = json.loads(performance_path.read_text())
    assert perf['passed'] is True
    assert (perf['completed_turns'], perf['provider_requests'], perf['uninterrupted_turns'],
            perf['continued_after_reopen'], perf['physical_slots'], perf['final_slot_zero_generation']) == (576,576,512,64,128,18)
    assert perf['archive_results_verified'] == 575 and perf['generation_identities_verified'] == 576
    assert all(perf[k] is True for k in ['no_state_or_authority_reset','retained_history','all_dedup_keys_replayed'])
    events = perf['handoffs']; assert len(events) == 18
    assert all(e['event'] == 'owner_handoff_complete' for e in events)
    times = [e['elapsed_ms'] for e in events]
    for value in times: finite(value, 20000)
    assert statistics.median(times[:4]) > 0
    ratio = statistics.median(times[-4:]) / statistics.median(times[:4])
    assert ratio <= 1.5 and ratio == perf['last_to_first_handoff_median_ratio']
    long_pids = perf['processes']; assert len(long_pids) == len(set(long_pids)) == 3
    long_reports = [r for r in reports if r['pid'] in long_pids]; assert len(long_reports) == 3
    actual_windows = []
    for window in range(5):
        values = sorted(row['elapsed_ms'] for r in long_reports for row in r['requests'] if row['window'] == str(window))
        assert values
        result = dict(window=window,turns=128 if window < 4 else 64,requests=len(values),
            p95_ms=values[math.ceil(.95*len(values))-1],max_ms=values[-1])
        assert result['p95_ms'] < 2000
        actual_windows.append(result)
    assert perf['windows'] == actual_windows
    summary = json.loads(summary_path.read_text())
    assert summary['stop_reason'] == 'requested' and not summary['coverage_truncated']
    assert summary['valid_process_selection_observed'] and summary['samples'] > 0
    assert summary['observed_host_instances'] == summary['observed_host_identities'] == 20
    assert summary['observed_roles'] == ['evaluator','host','runtime']
    assert not summary['identity_errors'] and not summary['unverified_instances']
    assert hashlib.sha256(raw_path.read_bytes()).hexdigest() == summary['raw_sha256']
    hosts = {r['pid'] for r in summary['executable_receipts'] if r['role']=='host' and r['native_amd64']}
    assert hosts == pids
    receipts = {(r['pid'],r['start_ticks'],r['path']): r for r in summary['executable_receipts']}
    assert len(receipts) == len(summary['executable_receipts'])
    seen, actual_hosts = set(), set()
    count = peak_rss = peak_processes = 0
    for line in raw_path.read_text().splitlines():
        sample = json.loads(line); rows = sample['processes']; assert rows
        assert len({r['pid'] for r in rows}) == len(rows)
        row_ids = set()
        roots = []
        rss = 0
        for row in rows:
            assert type(row['rss_kib']) is int and row['rss_kib'] >= 0
            rss += row['rss_kib']
            key = row['pid'],row['start_ticks'],row['exe']
            assert key in receipts
            receipt = receipts[key]
            role = receipt['role']; expected = binaries[role]
            assert receipt['native_amd64'] is True and receipt['sha256'] == expected['sha256']
            assert row['exe'] == expected['path'] or (role == 'evaluator' and row['exe'].endswith('/cancel-evaluator'))
            if role == 'host':
                roots.append(row['pid']); actual_hosts.add(key)
            row_ids.add(key)
        assert sorted(roots) == sample['root_pids']
        seen.update(row_ids);count += 1
        peak_rss = max(peak_rss,rss);peak_processes=max(peak_processes,len(rows))
    assert seen == set(receipts)
    assert count == summary['samples'] and raw_path.stat().st_size == summary['bytes']
    assert peak_rss == summary['peak_sum_rss_kib'] and peak_processes == summary['peak_processes']
    assert len(actual_hosts) == 20
    finite(peak_rss, 2097152)
    return dict(opens=len(reports),requests=sum(len(r['requests']) for r in reports),
        max_startup_ms=max(r['startup_ms'] for r in reports),
        max_http_ms=max(row['elapsed_ms'] for r in reports for row in r['requests']),
        performance=perf,process_observation=summary)
