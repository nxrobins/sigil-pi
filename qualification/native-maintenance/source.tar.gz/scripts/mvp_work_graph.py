"""Validate and display the MVP dependency graph; never infer a PASS from prose."""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def inspect(path):
    graph = json.loads(path.read_text())
    if graph.get("schema") != "sigil-pi/mvp-work-graph/v1":
        raise ValueError("unknown graph schema")
    nodes = {n["id"]: n for n in graph["nodes"]}
    if len(nodes) != len(graph["nodes"]) or not set(f"M{i}" for i in range(9)) <= nodes.keys():
        raise ValueError("duplicate nodes or missing MVP gates")
    visiting, visited, order = set(), set(), []

    def visit(key):
        if key in visiting:
            raise ValueError(f"hard dependency cycle at {key}")
        if key in visited:
            return
        node = nodes[key]
        if node["state"] not in {"pending", "active", "verified"} or not node["criteria"]:
            raise ValueError(f"invalid state or absent success criteria: {key}")
        visiting.add(key)
        for dep in node["depends_on"]:
            if dep not in nodes:
                raise ValueError(f"missing dependency {key} -> {dep}")
            visit(dep)
        if node["state"] == "verified":
            if not node["evidence"] or any(nodes[d]["state"] != "verified" for d in node["depends_on"]):
                raise ValueError(f"unproved completion: {key}")
            for evidence in node["evidence"]:
                p = ROOT / evidence["path"]
                if hashlib.sha256(p.read_bytes()).hexdigest() != evidence["sha256"]:
                    raise ValueError(f"evidence changed: {key}: {p}")
            if node["kind"] in {"gate", "qualification"} and not node.get("candidate_sha256"):
                raise ValueError(f"candidate identity required: {key}")
        visiting.remove(key)
        visited.add(key)
        order.append(key)

    for key in nodes:
        visit(key)
    gates = [nodes[f"M{i}"] for i in range(9)]
    complete = all(n["state"] == "verified" for n in gates)
    if complete and len({n["candidate_sha256"] for n in gates}) != 1:
        raise ValueError("MVP gates do not qualify the same candidate")
    ready = [key for key in order if nodes[key]["state"] != "verified"
             and all(nodes[d]["state"] == "verified" for d in nodes[key]["depends_on"])]
    return {"valid": True, "complete": complete, "ready": ready,
            "active": [key for key in order if nodes[key]["state"] == "active"],
            "order": order}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", nargs="?", type=Path, default=ROOT / "config/mvp-work-graph.json")
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    result = inspect(args.path)
    print(json.dumps(result, indent=2))
    if args.require_complete and not result["complete"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
