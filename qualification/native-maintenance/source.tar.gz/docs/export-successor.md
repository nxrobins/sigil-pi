# Developing export-only successor

`sigil-export-successor CONFIG` is a one-shot native embedding for an existing
schema-6 store. The strict version-1 configuration selects the original store
admission, immutable pool allocation, reservation catalog, execution domain,
intent binding, read-only source namespaces, two authenticated journals, fixed
sink and fixed grantless SIGIL policy. It cannot accept an effect worker or an
application write grant. A surviving leased owner prevents opening the store.

The same SIGIL source/runtime identity is admitted before execution by
`export_capacity::Ledger::reserve`. Its `XP1` budget branch selects separate
preparation and acknowledgment allowances. The native layer checks actual pool
membership and conservative encoding costs. Recovery authenticates the retained
admission and reacquires exactly that export reservation, never execution credit
or new unreserved capacity. It revalidates the actual pinned policy artifacts
even if committed preparation means evaluation can be skipped.

Before execution admission, native preflight checks the opened store's immutable
transaction ceilings. Acknowledgment needs ten combined check/write items; held
record credits cannot bypass that limit. Prepared-value and combined-batch byte
ceilings are checked against the admitted payload maximum and audit encoding bound.

The projection branch receives `XP1[project, ET1]`. Native `ET1` contains original
intent namespace/key/revision/value/binding; validated phase, status and output;
actual retained start and terminal milliseconds; original epoch; and both
authenticated journal digests. The terminal observer checks the original domain,
a genuinely fresh acquisition epoch, signed records and unchanged source records.
The caller must already have read authority for those source records.

SIGIL returns `EP1[publish, lowercase_payload_hex]`. Native code validates the
bound, commits the exact payload and source-fact digest with a signed audit entry,
then invokes the admitted fixed sink. A native durable publication receipt is
required for the signed local acknowledgment. This transaction releases only the
residual export reservation. The original claim, result and execution reservation
are unchanged. A store lease and exclusive mutable borrow span the operation.

Restart first verifies and returns an existing acknowledgment, before asking for
current source records or capacity. This is historical local publication evidence;
it does not inspect or recreate a subsequently missing target. Without an
acknowledgment, restart uses the exact authenticated prepared bytes. A conflicting
destination refuses without overwrite. Failed or uncertain publication retains
the obligation. The original clocks are never sampled again for a projection.

The control-plane policy is separately composed with one fixed first-slice BO1
bootstrap. It validates the CP1 application, tenant, publication nonce, source
artifact, raw intent, request digest and opaque attempt identity. It selects only
a correlated retained HO1 503 or an empty-outcome phase-4 unknown. Unknown uses the
original native start/terminal times, source 2 and invocation count 65535. It does
not infer that a request was never sent. The unchanged 96-byte consumer encoding
and historical vector tests remain separate from native authority.

Development checks cover compiled budget/projection, normal and 65536-byte
preparation/receipt bounds, a fresh exporter process, live-owner refusal, original
source/credit preservation, changed source/policy/destination refusal, and actual
process death before preparation and after preparation/publication/acknowledgment.
The filesystem primitive has its own retained crash and adversarial tests.

Still required before this graph node completes: native-to-unchanged-consumer
integration for fresh retained-503 and witnessed-unknown work; an admitted
single-lane lifetime; full frozen verification
and independent review. There is no cross-store transaction or general concurrent
source-slot reuse guarantee. A local publication acknowledgment is not a source
interpretation acknowledgment. Unused-admission retirement, reservation catalog
retirement, public lifecycle APIs, M6 and overall MVP qualification remain open.

The opt-in v2 bootstrap binds a native `FixedSource` to the external intent file.
Its private descriptor observation records the root/key identity, inode, device,
length, modification/change timestamps and SHA-256 of bounded private bytes.
Admission, execution, preparation, publication and acknowledgment recheck that
observation. Replacement, changed bytes and ordinary write/restore refuse; a
refusal after publication preserves uncertainty and the held export credit.
Historical acknowledgment replay does not require a still-present source file.

Guarded policy inputs wrap EX1 or ET1 in `GX1[facts, SG1]`; SG1 contains the actual
native source identity, digest and hexadecimal bytes. The control-plane SIGIL
policy requires this profile, verifies the digest and compares the complete raw
intent with CP1. Guarded admission also binds the evaluator fuel/time ceilings.
The unguarded v1 generic protocol remains distinct. Neither file metadata nor
repeated reads creates a cross-store lock: the first-slice embedding must stop
source publication and exclude lane reuse until local acknowledgment. Concurrent
writers, arbitrary restoration and source-consumption acknowledgment are separate
contracts. These guards are development until the frozen qualification passes.

An external trusted embedding constructs the producer with
`Recorder::new_audited_with_journal(store, recorder_config, audit_config,
effect_bridge, grants, credential_facts, journal_namespace)`. This uses the same
fixed SIGIL boot admission as the automatic service. It requires the effect
bridge's actual domain and epoch to match the held store, refuses journal grants
or audit namespace aliases, and keeps the signer and audit attachment private.
Configuration is trusted deployment input; no guest/request endpoint can call
this constructor. Observations, receipts, clocks and recovery authority continue
to come from the existing native mechanisms.
