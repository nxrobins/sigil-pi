//! Actual process cleanup and funded publication, using a controlled native
//! runtime. This is not a claim that SIGIL guests can create native processes.
use super::*;
use sigil_durable_store::store::reservation::Credits;
use sigil_worker_bridge::execution_fence::{ExecutionFence, OpenMode as FenceMode};

#[test]
fn descendant_process() {
    let Some(root) = std::env::var_os("SIGIL_LIFETIME_TEST_ROOT") else {
        return;
    };
    let root = std::path::PathBuf::from(root);
    assert!(root.is_absolute() && root.is_dir());
    if std::env::var("SIGIL_LIFETIME_TEST_ESCAPE").as_deref() == Ok("1") {
        assert!(unsafe { libc::setsid() } >= 0);
    }
    fs::write(root.join("desc-ready"), b"ready").unwrap();
    let until = Instant::now() + Duration::from_secs(30);
    while Instant::now() < until && !root.join("desc-release").exists() {
        if root.join("desc-check").exists() {
            fs::write(root.join("desc-live-after-return"), b"still running").unwrap();
        }
        thread::sleep(Duration::from_millis(2));
    }
}

struct Release(std::path::PathBuf);
impl Drop for Release {
    fn drop(&mut self) {
        let _ = fs::write(self.0.join("desc-release"), b"");
    }
}

#[test]
fn funded_sync_and_owned_completion_require_all_execution_holders_to_exit() {
    let _serial = serial();
    for (owned, escape) in [(false, false), (false, true), (true, false), (true, true)] {
        let (mut f, mut recorder, funding, parent) = crate::claimed::completion_tests::fund_fixture(
            Fixture::fenced(13),
            2,
            if escape { "4" } else { "2" },
        );
        let root = f.directory.path().to_path_buf();
        let _release = Release(root.clone());
        let body = format!(
            "#!/bin/sh\nSIGIL_LIFETIME_TEST_ROOT='{}' SIGIL_LIFETIME_TEST_ESCAPE='{}' '{}' --exact claimed::owned::tests::lifetime::descendant_process --nocapture >/dev/null 2>&1 &\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nread -r line\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1000 ]; do /bin/sleep 0.01; n=$((n+1)); done\nprintf '%s\\n' '{}'\nwhile :; do /bin/sleep 1; done\n",
            root.display(),
            if escape { "1" } else { "0" },
            std::env::current_exe().unwrap().display(),
            root.join("desc-ready").display(),
            response("observed")
        );
        let mut config = component(&root, "descendant-lifetime", &body);
        config.max_timeout_ms = HELD_TIMEOUT_MS;
        f.worker = Bridge::new_fenced(config, f.store.execution_lease().unwrap()).unwrap();
        let owner = crate::claimed::completion_tests::owner(&f.store);
        let mut request = execution();
        request.timeout_ms = HELD_TIMEOUT_MS;
        let mut a = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            request,
        )
        .unwrap();
        a.attach_funding(funding).unwrap();
        let (observed, returned) = if owned {
            let bound = a.handoff(&mut recorder).unwrap();
            let dummy = Bridge::new(component(&root, "unused", "#!/bin/sh\nexit 0\n")).unwrap();
            let worker = std::mem::replace(&mut f.worker, dummy);
            let mut lane = OwnedWorker::new_funded(worker, recorder, f.scope);
            lane.launch(bound, "execution lifetime test".into());
            let until = Instant::now() + HELD_WAIT;
            let result = loop {
                if let Some(result) = lane.poll(&mut f.store, &mut f.clock).unwrap() {
                    break result;
                }
                assert!(Instant::now() < until);
                thread::sleep(Duration::from_millis(5));
            };
            assert!(!result.owner_lost);
            assert!(result.completion.delivery_receipt.is_some());
            assert!(result.completion.recording_error.is_none());
            (
                result.completion.observation.unwrap(),
                lane.take_returned_credit(),
            )
        } else {
            let ticket = a.prepared().ticket.clone();
            let result = a
                .run_recorded(&ticket, &mut recorder, &AtomicBool::new(false))
                .unwrap();
            assert!(result.delivery_receipt.is_some());
            assert!(result.recording_error.is_none());
            let returned = a.take_returned_credit();
            drop(a);
            (result.observation.unwrap(), returned)
        };
        assert!(root.join("desc-ready").exists());
        assert!(observed.request_may_have_run);
        assert_eq!(observed.worker_reaped, !escape);
        assert_eq!(observed.fault, escape.then_some(Fault::CleanupUnconfirmed));
        let snapshot = f
            .store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap();
        assert_eq!(snapshot.revision, 3);
        assert_eq!(
            snapshot.credits,
            Credits {
                records: 5,
                live_bytes: 40_000
            }
        );
        if escape {
            assert!(
                returned.is_none(),
                "a live descendant must not release reusable capacity"
            );
            assert_ne!(snapshot.binding, parent);
            assert!(!snapshot.assignment.is_empty());
            fs::write(root.join("desc-check"), b"check after completion").unwrap();
            wait_until(|| root.join("desc-live-after-return").exists());
        } else {
            let returned = returned.expect("confirmed execution exit releases capacity");
            assert!(snapshot.assignment.is_empty());
            assert_eq!(snapshot.binding, parent);
            f.store
                .check_reservation_binding(&returned, parent)
                .unwrap();
            f.store
                .commit_spending(
                    &owner,
                    &Batch {
                        checks: vec![],
                        writes: vec![Mutation {
                            namespace: "api".into(),
                            key: "legitimate-credit-reuse".into(),
                            revision: 0,
                            value: Some("confirmed execution exit".into()),
                        }],
                    },
                    &returned,
                    Credits {
                        records: 1,
                        live_bytes: 512,
                    },
                )
                .unwrap();
        }
        drop(f.worker);
        drop(f.store);
        if escape {
            assert!(matches!(
                ExecutionFence::open(&root.join("store"), FenceMode::Existing),
                Err(Fault::Busy)
            ));
        }
        fs::write(root.join("desc-release"), b"").unwrap();
        let until = Instant::now() + Duration::from_secs(5);
        loop {
            match ExecutionFence::open(&root.join("store"), FenceMode::Existing) {
                Ok(_) => break,
                Err(Fault::Busy) if Instant::now() < until => {
                    thread::sleep(Duration::from_millis(5))
                }
                _ => panic!("execution holder did not release its domain"),
            }
        }
    }
}
