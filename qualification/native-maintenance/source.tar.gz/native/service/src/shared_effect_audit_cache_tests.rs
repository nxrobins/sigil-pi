//! Native admission with a controlled responder; compiled policy is tested separately.
use super::*;
use crate::shared_pure_tests::{audit_config, audit_environment_child, fixture_output};

#[test]
fn warm_shared_effect_formatter_refuses_second_caller_boot() {
    audit_environment_child("effect_audit::cache_tests::effect_rejection_child");
}

#[test]
fn effect_rejection_child() {
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let reply = frame("WB2\n", &["effect_audit_admitted", "fixture-binding"]).unwrap();
    let denied = frame("WB2\n", &["effect_audit_denied", "fixture-binding"]).unwrap();
    let (dir, worker) =
        crate::shared_pure_tests::fixture_rejecting_input(&reply, &"b".repeat(64), &denied);
    let producer = crate::claimed::RecorderConfig {
        worker: worker.clone(),
        delivery_namespace: "delivery".into(),
    };
    let effect = Bridge::new(worker.clone()).unwrap();
    let mut cache = crate::PureCache::new();
    let domain = |side: &str| BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]);
    let a = Admitted::new_with_cache(
        audit_config(worker.clone(), "a"),
        &producer,
        &effect,
        &domain("a"),
        "credential-a",
        Some(&mut cache),
    )
    .unwrap();
    assert!(matches!(
        Admitted::new_with_cache(
            audit_config(worker.clone(), "b"),
            &producer,
            &effect,
            &domain("b"),
            "credential-b",
            Some(&mut cache)
        ),
        Err("config")
    ));
    let again = Admitted::new_with_cache(
        audit_config(worker, "a"),
        &producer,
        &effect,
        &domain("a"),
        "credential-a",
        Some(&mut cache),
    )
    .unwrap();
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    assert_eq!(
        std::fs::read_to_string(dir.path().join("calls"))
            .unwrap()
            .lines()
            .count(),
        3
    );
    drop(a);
    drop(again);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}

#[test]
fn shared_effect_formatter_keeps_scopes_keys_and_boot_inputs_per_caller() {
    audit_environment_child("effect_audit::cache_tests::effect_scope_child");
}

#[test]
fn effect_scope_child() {
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let reply = frame("WB2\n", &["effect_audit_admitted", "fixture-binding"]).unwrap();
    let (dir, worker) = fixture_output(&reply);
    let producer = crate::claimed::RecorderConfig {
        worker: worker.clone(),
        delivery_namespace: "delivery".into(),
    };
    let effect = Bridge::new(worker.clone()).unwrap();
    let mut cache = crate::PureCache::new();
    let domain = |side: &str| BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]);
    let a = Admitted::new_with_cache(
        audit_config(worker.clone(), "a"),
        &producer,
        &effect,
        &domain("a"),
        "credential-a",
        Some(&mut cache),
    )
    .unwrap();
    let b = Admitted::new_with_cache(
        audit_config(worker.clone(), "b"),
        &producer,
        &effect,
        &domain("b"),
        "credential-b",
        Some(&mut cache),
    )
    .unwrap();
    let (crate::PureExecution::SharedCached(wa), crate::PureExecution::SharedCached(wb)) =
        (&a.formatter.worker, &b.formatter.worker)
    else {
        panic!("expected sharing");
    };
    assert!(std::sync::Arc::ptr_eq(wa, wb));
    assert_ne!(&*a.key, &*b.key);
    assert!(a.scope.contains_key("a.domain") && !a.scope.contains_key("b.domain"));
    assert!(b.scope.contains_key("b.domain") && !b.scope.contains_key("a.domain"));
    assert!(a.scope.contains_key("a.heads") && !a.scope.contains_key("b.heads"));
    assert!(b.scope.contains_key("b.heads") && !b.scope.contains_key("a.heads"));
    let calls = std::fs::read_to_string(dir.path().join("calls")).unwrap();
    let decoded: Vec<serde_json::Value> = calls
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(decoded.len(), 2);
    for (row, side) in decoded.iter().zip(["a", "b"]) {
        let input = row["params"]["arguments"]["input"].as_str().unwrap();
        let parts = fields(input, "WB1\n", 7).unwrap();
        assert_eq!(parts[0], side.repeat(64));
        assert_eq!(
            serde_json::from_str::<BTreeMap<String, Access>>(parts[3]).unwrap(),
            domain(side)
        );
        assert_eq!(parts[5], format!("credential-{side}"));
        assert_eq!(parts[6], digest(&format!("credential-{side}")));
    }
    assert!(!calls.contains("test-only-key"));
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    let mut invalid = audit_config(worker, "b");
    invalid.key_env = "PI_MISSING_AUDIT_KEY".into();
    assert!(
        Admitted::new_with_cache(
            invalid,
            &producer,
            &effect,
            &domain("b"),
            "credential-b",
            Some(&mut cache)
        )
        .is_err()
    );
    drop(a);
    drop(b);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}
