"""Execute the actual workflow setup blocks, with a pre-fix control, in Linux."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import yaml

ROOT = Path('/inputs')
LIB = Path('/opt/sigil-pi-ci/z3/lib/libz3.so')
CONFIG = Path('/etc/ld.so.conf.d/sigil-pi-ci-z3.conf')
records = []
assert platform.machine() == 'x86_64', 'run this fixture with --platform linux/amd64'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name in ('baseline', 'ci', 'release'):
    workflow = yaml.safe_load((ROOT / f'{name}.yml').read_text())
    job = workflow['jobs']['build-test-attest' if name == 'release' else 'forge']
    step = next(s for s in job['steps'] if s.get('name') == 'Install pinned Z3 (official release binary, SHA256-verified)')
    work = Path('/work') / name
    (work / 'sigil-pi/scripts').mkdir(parents=True)
    shutil.copyfile(ROOT / 'ci_z3.py', work / 'sigil-pi/scripts/ci_z3.py')
    env = dict(os.environ)
    env.update({k: v for k, v in job['env'].items() if k in ('Z3_VERSION', 'Z3_ASSET', 'Z3_SHA256')})
    env.update(GITHUB_PATH=str(work / 'github-path'), GITHUB_ENV=str(work / 'github-env'))
    subprocess.run(['bash', '-e', '-o', 'pipefail', '-c', step['run']], cwd=work, env=env, check=True, timeout=180)
    source = work / 'z3-pinned/bin/libz3.so'
    probe = subprocess.run(['python3', '-I', '-c', "import ctypes; ctypes.CDLL('libz3.so')"],
                           cwd='/', env={'LANG': 'C.UTF-8'}, capture_output=True, text=True)
    if name == 'baseline':
        assert probe.returncode != 0 and 'cannot open shared object file' in probe.stderr, probe
        print('CONTROL: original workflow leaves libz3 unavailable to env-cleared child', flush=True)
    else:
        assert probe.returncode == 0, probe.stderr
        assert digest(LIB) == digest(source)
        for path in (LIB, CONFIG):
            assert path.stat().st_uid == 0 and path.stat().st_mode & 0o777 == 0o644
        for path in (LIB.parent, LIB.parent.parent, LIB.parent.parent.parent):
            assert path.stat().st_uid == 0 and path.stat().st_mode & 0o022 == 0
        assert (work / 'github-path').read_text() == f'{work}/z3-pinned/bin\n'
        assert (work / 'github-env').read_text() == 'SIGIL_Z3_IDENTITY=Z3 version 4.12.2 - 64 bit\n'
        print(f'PASS: {name} workflow setup; exact library; env-cleared child', flush=True)
    records.append({'workflow': name, 'sha256': digest(ROOT / f'{name}.yml'),
                    'library_sha256': digest(source), 'loader_returncode': probe.returncode})

source_root = Path('/work/ci/z3-pinned')
command = ['python3', str(ROOT / 'ci_z3.py'), 'install', '--root', str(source_root), '--version', '4.12.2']
before = digest(LIB), digest(CONFIG)
for path in (LIB.parent, LIB):
    original = path.stat().st_mode & 0o777
    path.chmod(0o777)
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 1, result.stdout + result.stderr
    assert (digest(LIB), digest(CONFIG)) == before
    path.chmod(original)
    print(f'PASS: refuse writable loader target {path}', flush=True)

directory = LIB.parent
saved = directory.with_name('held-lib')
directory.rename(saved)
directory.symlink_to(saved, target_is_directory=True)
result = subprocess.run(command, capture_output=True, text=True)
assert result.returncode == 1, result.stdout + result.stderr
assert (digest(LIB), digest(CONFIG)) == before
directory.unlink()
saved.rename(directory)
print('PASS: refuse symlinked loader directory', flush=True)

result = subprocess.run(['python3', str(ROOT / 'ci_z3.py'), 'verify', '--version', '9.9.9'],
                        capture_output=True, text=True)
assert result.returncode == 1 and 'wrong Z3 version' in result.stderr
print('PASS: refuse mismatched loaded runtime version', flush=True)
print(json.dumps({'helper_sha256': digest(ROOT / 'ci_z3.py'), 'records': records}, sort_keys=True), flush=True)
