//! Actual native preparation/claim/effect/recording with controlled subprocesses.
//! This is not the compiled SIGIL budget policy or production API admission.
use super::audit_tests::{admitted_recorder, formatter, grant_map};
use super::tests::{Fixture, binding, execution, process_guard, recorded_scope};
use super::*;
use crate::effect_audit::EffectAudit;
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use sigil_durable_store::store::reservation::{Credits, Request};
use sigil_durable_store::store::{Access, Batch, Mutation};

pub(super) fn owner(store: &Store) -> Scope {
    store
        .scope(
            [
                "intent",
                "claim",
                "delivery",
                "funds",
                "audit.heads",
                "audit.entries",
                "api",
            ]
            .into_iter()
            .map(|n| (n.into(), Access::ReadWrite))
            .collect(),
        )
        .unwrap()
}

#[test]
fn known_unsent_refusal_returns_credit_only_after_signed_terminal_commit() {
    let _serial = process_guard();
    for profile in [4, 5, 6, 7] {
        let fixture = match profile {
            4 => Fixture::reserved(13),
            5 => Fixture::witnessed(13),
            _ => Fixture::fenced(13),
        };
        let (mut f, mut recorder, funding, origin) = if profile == 7 {
            fund_retirement_fixture(fixture, 3, "3")
        } else {
            fund_fixture(fixture, 2, "3")
        };
        let owner = owner(&f.store);
        let mut attempt = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            execution(),
        )
        .unwrap();
        attempt.attach_funding(funding).unwrap();
        attempt.claim_recorded(&mut recorder).unwrap();
        assert!(attempt.take_returned_credit().is_none());
        // Deterministic dispatch authority expiry after the actual signed claim.
        // The real execute gate generates the refusal; no Observation is injected.
        attempt.guard = ExecutionGuard::parse(&frame("TG1\n", &["0", "1"]).unwrap()).unwrap();
        let ticket = attempt.prepared().ticket.clone();
        let refused = attempt
            .execute(&ticket, &AtomicBool::new(false))
            .err()
            .unwrap();
        assert_eq!(refused, "time_guard");
        assert!(attempt.take_returned_credit().is_none());
        let (phase, _) = attempt
            .persist_observation(&mut recorder, None, Some(refused))
            .unwrap();
        assert_eq!(phase, "3");
        let returned = attempt
            .take_returned_credit()
            .expect("known-unsent signed terminal must return original credit");
        assert!(attempt.take_returned_credit().is_none());
        assert_eq!(
            returned.credits(),
            Credits {
                records: 5,
                live_bytes: 40000
            }
        );
        assert_eq!(
            attempt
                .execute(&ticket, &AtomicBool::new(false))
                .err()
                .unwrap(),
            "unclaimed"
        );
        drop(attempt);
        f.store
            .check_reservation_binding(&returned, origin)
            .unwrap();
        assert_eq!(returned.revision(), 3);
        if profile >= 5 {
            let retained = f
                .store
                .reservation_snapshot(&owner, "funds", "operation:1")
                .unwrap();
            assert_eq!(retained.binding, origin);
            assert_eq!(retained.revision, 3);
            assert!(retained.assignment.is_empty());
        }
        assert_eq!(
            f.store
                .get(&owner, "claim", "operation:1")
                .unwrap()
                .revision,
            2
        );
        assert_eq!(
            f.store
                .get(&owner, "delivery", "operation:1")
                .unwrap()
                .revision,
            1
        );
        assert_eq!(
            f.store
                .get(&owner, "audit.heads", &"a".repeat(64))
                .unwrap()
                .revision,
            2
        );
        assert!(!f.directory.path().join("started").exists());
        assert!(f.worker.execute(&ticket, &AtomicBool::new(false)).is_err());
    }
}
pub(super) fn setup(audit_records: u64) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    setup_phase(audit_records, "2")
}
pub(super) fn setup_phase(
    audit_records: u64,
    phase: &str,
) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    fund_fixture(Fixture::reserved(13), audit_records, phase)
}
pub(super) fn fund_fixture(
    f: Fixture,
    audit_records: u64,
    phase: &str,
) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    fund_fixture_inner(f, audit_records, phase, None, false)
}
pub(super) fn fund_retirement_fixture(
    f: Fixture,
    audit_records: u64,
    phase: &str,
) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    fund_fixture_inner(
        f,
        audit_records,
        phase,
        Some(Credits {
            records: 1,
            live_bytes: 5000,
        }),
        false,
    )
}
pub(super) fn fund_parent_fixture(f: Fixture) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    fund_parent_phase_fixture(f, "2")
}
pub(super) fn fund_parent_phase_fixture(
    f: Fixture,
    phase: &str,
) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    fund_fixture_inner(
        f,
        3,
        phase,
        Some(Credits {
            records: 1,
            live_bytes: 5000,
        }),
        true,
    )
}
fn fund_fixture_inner(
    mut f: Fixture,
    audit_records: u64,
    phase: &str,
    retirement: Option<Credits>,
    whole_parent: bool,
) -> (Fixture, Recorder, CompletionCredit, [u8; 32]) {
    let audit_limit = if retirement.is_some() { 3 } else { 2 };
    recorded_scope(&mut f, Access::CreateOnly);
    let identity = CompletionIdentity::observe(&f.store, &f.scope, &binding(), "delivery").unwrap();
    let parent = if whole_parent {
        [0x91; 32]
    } else {
        identity.reservation_binding()
    };
    let owner = owner(&f.store);
    let log = AuthenticatedLog::new(
        &f.store,
        "audit.heads",
        "audit.entries",
        ChainLimits {
            payload_bytes: 1024,
            records: audit_limit,
            bytes: 1_000_000,
        },
        b"native-effect-audit-test-key-0123456789",
    )
    .unwrap();
    let allowance = log
        .prepare_allowance(
            &f.store,
            &owner,
            &"a".repeat(64),
            0,
            audit_records,
            audit_records * log.encoded_entry_ceiling(),
        )
        .unwrap();
    let held = f
        .store
        .commit_reserving_audited(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 0,
                    value: Some("budget admitted".into()),
                }],
            },
            &Request {
                namespace: "funds".into(),
                key: "operation:1".into(),
                binding: parent,
                credits: Credits {
                    records: 10,
                    live_bytes: 50_000,
                },
            },
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let budget = CompletionBudget {
        claim: Credits {
            records: 3,
            live_bytes: 5000,
        },
        result: Credits {
            records: 2,
            live_bytes: 5000,
        },
    };
    let funding = if whole_parent {
        identity.fund_from_parent(&f.store, held, budget, retirement.unwrap())
    } else if let Some(retirement) = retirement {
        identity.fund_with_retirement(&f.store, held, budget, retirement)
    } else {
        identity.fund(&f.store, held, budget)
    }
    .unwrap();
    let mut recorder = admitted_recorder(f.directory.path(), phase);
    recorder.attach_audit(EffectAudit::fixture(
        &mut f.store,
        formatter(f.directory.path(), 0),
        grant_map(),
        audit_limit,
        false,
    ));
    (f, recorder, funding, parent)
}

#[test]
fn funded_actual_turn_completes_at_full_pool_and_returns_only_current_parent_credit() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, parent) = setup(2);
    let owner = owner(&f.store);
    assert!(
        f.store
            .commit(
                &owner,
                &Batch {
                    checks: vec![],
                    writes: vec![Mutation {
                        namespace: "api".into(),
                        key: "unrelated".into(),
                        revision: 0,
                        value: Some("no free records".into())
                    }]
                }
            )
            .is_err()
    );
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared().ticket.clone();
    let result = a
        .run_recorded(&ticket, &mut recorder, &AtomicBool::new(false))
        .unwrap();
    assert_eq!(result.phase.as_deref(), Some("2"));
    assert!(result.delivery_receipt.is_some());
    assert!(result.recording_error.is_none());
    let seen = result.observation.unwrap();
    assert!(seen.request_may_have_run && seen.worker_reaped);
    let remaining = a.take_returned_credit().unwrap();
    assert!(a.take_returned_credit().is_none());
    assert_eq!(remaining.credits().records, 5);
    assert_eq!(remaining.credits().live_bytes, 40_000);
    assert_eq!(remaining.revision(), 3);
    drop(a);
    f.store
        .check_reservation_binding(&remaining, parent)
        .unwrap();
    assert!(
        f.store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_err()
    );
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        2
    );
    assert_eq!(
        f.store
            .get(&owner, "delivery", "operation:1")
            .unwrap()
            .revision,
        1
    );
    assert_eq!(
        f.store
            .get(&owner, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        2
    );
}

#[test]
fn insufficient_signed_completion_allowance_refuses_before_claim_or_effect() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, parent) = setup(1);
    let owner = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared().ticket.clone();
    assert!(matches!(
        a.run_recorded(&ticket, &mut recorder, &AtomicBool::new(false)),
        Err("funding_audit")
    ));
    assert!(a.take_returned_credit().is_none());
    drop(a);
    assert!(!f.directory.path().join("started").exists());
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .get(&owner, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        0
    );
    assert!(
        f.store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_ok()
    );
}

#[test]
fn foreign_store_credit_cannot_arm_an_identical_actual_attempt() {
    let _serial = process_guard();
    let (_original, _recorder, funding, _parent) = setup(2);
    let mut other = Fixture::reserved(13);
    recorded_scope(&mut other, Access::CreateOnly);
    let mut a = Attempt::begin(
        &mut other.store,
        &other.scope,
        &mut other.worker,
        &mut other.clock,
        binding(),
        execution(),
    )
    .unwrap();
    assert!(matches!(a.attach_funding(funding), Err("funding")));
    drop(a);
    assert!(!other.directory.path().join("started").exists());
}

#[test]
fn private_audit_grants_cannot_bypass_missing_original_delivery_authority() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, parent) = setup(2);
    recorded_scope(&mut f, Access::Read);
    let owner = owner(&f.store);
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    let ticket = a.prepared().ticket.clone();
    // The original unused-delivery-slot check refuses before claim publication.
    assert!(matches!(
        a.run_recorded(&ticket, &mut recorder, &AtomicBool::new(false)),
        Err("storage")
    ));
    assert!(a.take_returned_credit().is_none());
    drop(a);
    assert!(!f.directory.path().join("started").exists());
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .get(&owner, "delivery", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .get(&owner, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        0
    );
    assert!(
        f.store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_ok()
    );
}

#[test]
fn funding_budget_validation_cannot_turn_current_credits_into_larger_completion_promises() {
    let _serial = process_guard();
    let (f, _recorder, _funding, parent) = setup(2);
    let owner = owner(&f.store);
    let identity = CompletionIdentity::observe(&f.store, &f.scope, &binding(), "delivery").unwrap();
    let held = f
        .store
        .resume_reservation(&owner, "funds", "operation:1", 1, parent)
        .unwrap();
    assert!(matches!(
        identity.fund(
            &f.store,
            held,
            CompletionBudget {
                claim: Credits {
                    records: 9,
                    live_bytes: 5000
                },
                result: Credits {
                    records: 2,
                    live_bytes: 5000
                }
            }
        ),
        Err("funding_budget")
    ));
    assert!(
        f.store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_ok()
    );
}

#[test]
fn funding_for_an_older_intent_observation_cannot_arm_changed_work() {
    let _serial = process_guard();
    let (mut f, _recorder, funding, parent) = setup(2);
    let owner = owner(&f.store);
    f.store
        .commit(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: "operation:1".into(),
                    revision: 1,
                    value: Some("changed work".into()),
                }],
            },
        )
        .unwrap();
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    assert!(matches!(a.attach_funding(funding), Err("funding_identity")));
    drop(a);
    assert!(!f.directory.path().join("started").exists());
    assert!(
        f.store
            .resume_reservation(&owner, "funds", "operation:1", 1, parent)
            .is_ok()
    );
}
