# Experimental Wave fact grounding in the research host

The `agent.py` research host can opt in to the updated Wave sidecar with
`PI_MEMORY_FACT_GROUNDING=1`. This is **not yet validated for live deployment**:
the earlier 2026-10-16 evaluation was blocked by the pinned SIGIL runtime's
two-second HTTP limit. The local timing patch and explicit learning receipts
address that boundary; see the fresh lifecycle evidence before promotion.
The authenticated product `/v1` host still disables memory.

## Connection and safeguards

- Build `wave-memory-sidecar` from the updated Wave checkout. The new capability
  is additive to protocol 2; the host verifies it before recording anything.
- Set `PI_MEMORY_SIDECAR`, the existing loopback BGE embedding URL/model, and
  `PI_MEMORY_FACT_GROUNDING=1`. Supply `TYPESAFE_API_KEY` to the host environment.
  API keys, `PI_SECRET_*`, `PI_AUTH_TOKEN`, and `PI_AUDIT_KEY` are removed from
  the sidecar subprocess environment.
- Only fact support and stored-fact revision judgments go to Jev. The host uses
  the existing secret-injected SIGIL HTTP guest and audit chain. Extraction and
  ordinary chat still use the configured text model.
- New user messages and external observations preserve their original text in
  the grounding compiler's source-input field. Assistant replies and internal
  notes remain context, not independent source assertions. Existing records
  written without that source field are not silently reclassified.
- Wave validates the complete typed response against the original request. The
  native 0.8 proof floor, quarantine, temporal/ownership checks, and retirement
  replay barriers remain in Wave's existing memory engine. Provider probabilities
  are preserved; a missing or malformed response supplies no proof.
- Grounded roots carry a `FACT_GROUNDING` marker. Reopening one without grounding
  is rejected. Do not remove this marker to work around a startup error.
- `PiMemory.inspect_facts(session)` exposes current facts separately from pending
  quarantine, retained review evidence, retirement barriers, and receipts.
  Ordinary `inspect` is the raw experience history, not a list of current facts.

## Isolated evaluation

The Wave repository contains `scripts/eval_sigil_pi_grounding.py`. It starts the
real research-host HTTP chat, real SIGIL forges, BGE, Bonsai, and Jev with a fresh
session store. All state and redacted provider evidence go under the supplied
new output directory. It never opens the normal Wave memory file.

Use the solver-enabled pinned SIGIL checkout, not the default sibling binary:

```sh
SIGIL_ROOT=/Users/nigel/Projects/sigil-pinned-8277a1d9 \
  python3 /Users/nigel/Projects/wave-agent/scripts/eval_sigil_pi_grounding.py \
  --output /private/tmp/sigil-wave-evaluation-new
```

The harness reads only the Jev credential it needs from Wave's local `.env` when
it is absent from the environment. It does not copy or print the file. Port
8873 is used for the isolated test service; normal Wave remains on 8765.

The lifecycle plan covers correction, uncertainty, quarantine across restart,
original-record restoration, a fictional withdrawal control, explicit withdrawal,
a newly dated assertion, and a second restart. Initial admission is a required
precondition. Failed model calls or missing initial facts make dependent checks
incomplete, never successful withdrawals. A run without an admitted negative
claim does not validate the negative-to-positive retirement branch.

## Bounded provider calls and learning receipts

The local patch to `sigil-pinned-8277a1d9` adds a host-only `http_timeout_ms`
grant. It is an integer in 1..60000 and bounds the entire HTTP operation,
including redirects and response body. Network/secret grants, redirect checks,
body limits, worker limits and solver verification still apply. Ordinary tools
keep the existing two-second phase windows. The opt-in grounded host grants
30 seconds only to chat/extraction and fact support/revision calls, further
limited by the remaining whole-turn deadline. A runtime without the advertised
capability is rejected. This is a **local patch over the existing pin**, not a
claim that the upstream pinned release already contains the feature.

A review's `committed` flag describes storage durability. Read `learning.complete`
to establish that the required provider responses completed. The receipt also
counts unavailable, empty and malformed responses. In grounded mode, incomplete
learning rolls back speculative changes, commits only conservative quarantines
and proven withdrawals, and leaves the evidence cursor unchanged for retry.
The receipt survives restart and is included in `inspect_facts`. Optional
logprob capability probes do not count as failed learning.

Grounded portable reviews learn only from the unprocessed message frontier.
Previously processed inputs remain available to the compiler as bounded identity
and evidence context, but are not extracted or judged again as new learning.
A failed review does not advance that frontier. The host still caps each operation
at 64 capability callbacks. If that cap or a dead sidecar interrupts a review,
`review_receipt.complete=false` and `storage_commit=unconfirmed`; successful
individual callbacks do not establish that learning or a commit finished.

HTTP JSON and streamed replies include `memory_receipt` when grounding is enabled.
`recorded=true, status=awaiting_review, fact_verified=false` means the message
was stored as evidence, not admitted as a fact. Busy/dead buffers report
`recorded=false`; the in-memory buffer is not a durability guarantee. The user
message is recorded before reply generation, so an unavailable reply provider
does not discard an already persisted correction. Operational error responses
also carry that message receipt.

For explicit current-fact questions containing an exact known subject name,
the reply context comes from the sidecar's current/quarantined snapshot. Old
messages cannot substitute for a missing current claim. Predicates retain their
negation and temporal scope. Historical queries retain the ordinary recall path;
this renderer does not infer pronoun ownership or change admission decisions.

Earlier evidence remains in the Wave checkout's
`bench/sigil-pi/2026-10-16/report.md`. The timing-fix run evidence is under
`bench/sigil-pi/2026-10-16/timing-live-*`; interrupted or failed runs remain
failures and must not be counted as full lifecycle passes.


## Earlier 2026-10-17 lifecycle result

The fresh isolated sigil-pi run completed all lifecycle stages: 85 of 87 checks
passed across 19 HTTP chat messages and three host starts. Correction, quarantine
across restart, original-provenance restoration, fresh positive reinstatement
from an admitted negative fact, and the final restart passed. All seven reviews
returned complete learning receipts. The 64-callback cap remained unchanged.

Two earlier checkpoints failed: a fictional quote caused a false quarantine
(Jev selected unchanged at 0.79), and a subsequent genuine withdrawal admitted
the negative claim while leaving the prior positive hold unresolved. Fresh
confirmation later cleared both the negative and pending holds. That recovery
does not turn the earlier failed checkpoints into passes. One acknowledgement
also claimed a withdrawal before review, despite its truthful awaiting-review
receipt. This integration therefore remains experimental.

See the Wave checkout's `bench/sigil-pi/2026-10-17/timing-results.json` and
`open-findings.json` for reviewed evidence. The signed audit verified 244 records;
saved Jev receipts contain only fact_support and fact_revision. The 0.8 floor,
quarantine and replay safeguards stayed enabled. These are synthetic results;
production observations are unavailable. The earlier native monitor incident is
not closed by this separate sigil-pi run.

## Receipt-owned acknowledgements and bound revision checks

For recognized conversational memory updates (explicit corrections, remember/note
statements and residence updates), the research host renders the acknowledgement
from the user-message delivery receipt. The same text is returned through JSON
and SSE, saved in the conversation, and recorded as the assistant action. A model
draft cannot claim verification, withdrawal or reinstatement before review.
Buffered and failed records receive different wording. Questions, mixed requests
for other work and tool turns keep their normal response path; this is a bounded
intent renderer, not a general guarantee about all model-generated prose.

The revision verifier separates three withdrawal obligations: explicit source
withdrawal, original temporal scope (with same-event binding for historical facts),
and the continued effectiveness of the bound correction. The last check receives
that correction as its comparison target, with exact source and later-evidence
copies in its question and the complete chronology in its state. An unrelated
example formerly embedded in the withdrawal instruction has been removed.
Every required proof must still meet the native 0.8 floor.

A weak no-change proposal for an already-current record can request one independent
continuity check and at most two proposed withdrawal anchors over the same complete
evidence. Proposal probabilities never authorize changes. Every withdrawal needs
its independent source, temporal-scope and later-validity proofs at 0.8. Conflicting
proofs, or a credible correction whose later validity remains unresolved, prevent
an unchanged answer from keeping an old claim current. A confident unresolved
continuity answer also retains quarantine. This route cannot release an already-held
record. Held records still require source-bound withdrawal or restoration proofs,
including ownership, later validity and provenance where applicable.

Host-encoded records with an empty source input preserve their complete generated
metadata in the review state, but cannot supply correction/restoration anchors.
Their assertion-level externality is false; raw episode externality is preserved
separately. Redundant question copies quote the source inputs, with derivative
metadata retained in the complete state. This prevents an assistant's delivery
receipt from being repeated as though it were the user's loss of certainty about
a world claim. The bound correction's effectiveness request retains generated fields
in a separate provenance-linked metadata collection, outside its source-assertion
timeline; original source text and every source clock remain intact. Policy version 20 invalidates decisions cached under older contracts.

A resolved review of the exact current revision establishes a host-owned review
boundary. Earlier evidence remains complete under `prior_review`; new observations
remain under `later_context`. Previously resolved doubt cannot be proposed again
as a new correction. A repeated correction asserted after the boundary is new
evidence and is still reviewed. The boundary requires matching original provenance
and every prior evidence record; held records, mismatches and incomplete lineages
cannot use it. Receipt validation and replay bind the original explicit source ID
to exactly one offered new external source, rather than using its position in the
partitioned list. Old reviewed IDs, duplicate IDs and derivative records cannot
authorize changes. If the annotation exceeds the evidence budget, the verifier keeps
the original complete view rather than clipping evidence.

Dedicated fact extraction receives only source inputs with their original episode
indices. Generated summaries and acknowledgements remain available to the grounding
review, but are not additional extraction sources. Explicit signed negative claims
remain eligible even when accompanied by a retraction of the positive claim.
Extraction is only a proposal: fictional or uncertain proposals still require Jev
support and cannot bypass admission safeguards.

For explicit current-residence questions naming one known subject, the host reads
the inspector again immediately before delivering the final answer and renders
that answer from the current facts. An unavailable inspector yields an unavailable
answer; quarantine never becomes a current positive claim. Negative and historical
predicates are not converted into affirmative current residence. This bounded
renderer does not infer pronoun ownership or replace general/historical questions.
The delivered text is the text stored in conversation and assistant-action history.

## Fresh lifecycle recovery after provenance fixes

The fresh `lifecycle-fix-live-06` evaluation passes all 125 checks across
19 HTTP chat messages, seven complete reviews and 3 host/sidecar starts.
Correction replaces the old current claim; real uncertainty remains quarantined
across restart; original-record restoration retains its original source; fictional
dialogue causes no false quarantine; explicit withdrawal clears the old hold and
admits a negative fact; fresh positive reinstatement retires the negative using
new provenance and survives the final restart. Replies, receipts, current retrieval,
inspector and persisted transcript agree at the checkpoints.

The unchanged eight-case live control set and four scripted host-fault checks also
pass. Validation includes 481 memory-engine tests (one ignored), 42 facade/sidecar
tests, 103 SIGIL host tests, and 15 receipt validation tests. Scoped facade/sidecar lint and Python lint pass;
broader dependency lint still reports existing unrelated wave-core findings.

All saved Jev calls remain fact support/revision only. Every required proof keeps
the native 0.8 floor, with quarantine and replay barriers enabled on every start.
One transient Bonsai 502 was recovered by the existing bounded identical retry.
The signed audit verifies 254 records. Interrupted and failed intermediate
runs remain preserved. See the Wave checkout's
`bench/sigil-pi/2026-10-17/lifecycle-results.json` for evidence and limitations.
This is a synthetic recovery result, not a production error-rate estimate or
promotion of the authenticated product host. The earlier native monitor incident
is still open.
