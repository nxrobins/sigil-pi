//! Native mechanism tests with controlled recorder/effect processes. The
//! compiled SIGIL profile and public bootstrap admission are separate gates.
use super::*;
use crate::claimed::completion_tests::{fund_fixture, fund_parent_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, process_guard};
use serde_json::Value;
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use std::collections::BTreeMap;
use std::time::{SystemTime, UNIX_EPOCH};

fn millis() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis()
        .try_into()
        .unwrap()
}

fn key(attempt: &Attempt<'_>) -> String {
    hex(completion::hash(&[
        b"sigil-completion-intent/v1",
        attempt.intent.namespace.as_bytes(),
        attempt.intent.key.as_bytes(),
        &attempt.intent.revision.to_be_bytes(),
        attempt.snapshot.value.as_deref().unwrap().as_bytes(),
        attempt.claim_namespace.as_bytes(),
        b"delivery",
    ]))
}

#[test]
fn claim_fact_and_signed_binding_survive_result_and_assignment_clearing_at_full_pool() {
    let _serial = process_guard();
    let (mut f, mut recorder, mut funding, origin) = fund_parent_fixture(Fixture::fenced(13));
    funding.budget.claim.records = 4;
    funding.budget.claim.live_bytes = 20_000;
    funding.budget.result.records = 3;
    funding.budget.result.live_bytes = 25_000;
    funding = funding.with_result_limit(1024).unwrap();
    recorder.enable_dispatch_journal(&f.store, "api").unwrap();
    let scope = owner(&f.store);
    let before = millis();
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    let key = key(&attempt);
    assert_ne!(
        key,
        hex(origin),
        "intent identity is distinct from reusable parent"
    );
    attempt.claim_recorded(&mut recorder).unwrap();
    let after = millis();
    let fact = attempt.store.get(&scope, "api", &key).unwrap();
    assert_eq!(fact.revision, 1);
    let raw = fact.value.as_deref().unwrap();
    let value: Value = serde_json::from_str(raw).unwrap();
    assert!((before..=after).contains(&value["claimed_at_unix_ms"].as_u64().unwrap()));
    assert_eq!(value["format"], "sigil-native-dispatch-start/v1");
    let assignment: Value = serde_json::from_str(value["assignment"].as_str().unwrap()).unwrap();
    let (domain, epoch) = attempt.store.execution_identity().unwrap();
    assert_eq!(assignment["execution"]["domain"], domain);
    assert_eq!(assignment["execution"]["epoch"], epoch);
    assert_eq!(assignment["ticket"], attempt.prepared.ticket);
    assert_eq!(assignment["input_sha256"], attempt.prepared.input_sha256);
    assert_eq!(
        assignment["source_sha256"],
        attempt.worker.facts().unwrap().source_sha256
    );
    assert_eq!(
        assignment["runtime_sha256"],
        attempt.worker.facts().unwrap().runtime_sha256
    );
    let audit = attempt
        .store
        .get(
            &scope,
            "audit.entries",
            &format!("{}.0000000000000000", "a".repeat(64)),
        )
        .unwrap();
    let signed: Value = serde_json::from_str(audit.value.as_deref().unwrap()).unwrap();
    let envelope: Value =
        serde_json::from_str(signed["body"]["payload"].as_str().unwrap()).unwrap();
    assert_eq!(envelope["journal_sha256"], digest(raw.as_bytes()));
    assert_eq!(envelope["journal_key"], key);
    assert_eq!(envelope["policy_payload"], "native publication fixture");
    let ticket = attempt.prepared.ticket.clone();
    let observed = attempt.execute(&ticket, &AtomicBool::new(false)).unwrap();
    attempt
        .persist_observation(&mut recorder, Some(&observed), None)
        .unwrap();
    let returned = attempt.take_returned_credit().unwrap();
    drop(attempt);
    assert_eq!(f.store.get(&scope, "api", &key).unwrap(), fact);
    assert!(
        f.store
            .reservation_snapshot(&scope, "funds", "operation:1")
            .unwrap()
            .assignment
            .is_empty()
    );
    f.store
        .check_reservation_binding(&returned, origin)
        .unwrap();
    let log = AuthenticatedLog::new(
        &f.store,
        "audit.heads",
        "audit.entries",
        ChainLimits {
            payload_bytes: 1024,
            records: 3,
            bytes: 1_000_000,
        },
        b"native-effect-audit-test-key-0123456789",
    )
    .unwrap();
    assert_eq!(
        log.verify(
            &mut f.store,
            &scope,
            &"a".repeat(64),
            None,
            Instant::now() + Duration::from_secs(1)
        )
        .unwrap()
        .count,
        2
    );
    let reads = f
        .store
        .scope(
            [
                "intent",
                "claim",
                "delivery",
                "api",
                "audit.heads",
                "audit.entries",
            ]
            .into_iter()
            .map(|name| (name.into(), sigil_durable_store::store::Access::Read))
            .collect(),
        )
        .unwrap();
    let observed = TerminalCompletion::observe(
        &mut f.store,
        &reads,
        &log,
        &"a".repeat(64),
        "api",
        &key,
        Instant::now() + Duration::from_secs(1),
    )
    .unwrap();
    assert_eq!(observed.phase(), "2");
    assert_eq!(
        observed.claimed_at_unix_ms(),
        value["claimed_at_unix_ms"].as_u64().unwrap()
    );
    assert!(observed.terminal_at_unix_ms() >= observed.claimed_at_unix_ms());
    assert_eq!(
        observed.check_prior_owner(&f.store, &scope),
        Err("execution_fence")
    );
    // Coherent ordinary checksum is insufficient to authenticate a changed fact.
    let replacement = raw.replacen(
        &value["claimed_at_unix_ms"].to_string(),
        &(value["claimed_at_unix_ms"].as_u64().unwrap() + 1).to_string(),
        1,
    );
    replace_record_checksum(
        &f.directory.path().join("store/records.sqlite"),
        "api",
        &key,
        1,
        &replacement,
    );
    assert_eq!(
        TerminalCompletion::observe(
            &mut f.store,
            &reads,
            &log,
            &"a".repeat(64),
            "api",
            &key,
            Instant::now() + Duration::from_secs(1)
        )
        .err(),
        Some("journal_authentication")
    );
    replace_record_checksum(
        &f.directory.path().join("store/records.sqlite"),
        "api",
        &key,
        1,
        raw,
    );
    let dr = f
        .store
        .get(&scope, "delivery", "operation:1")
        .unwrap()
        .value
        .unwrap();
    let replacement = dr.replacen("observed", "tampered", 1);
    assert_ne!(replacement, dr);
    replace_record_checksum(
        &f.directory.path().join("store/records.sqlite"),
        "delivery",
        "operation:1",
        1,
        &replacement,
    );
    assert!(
        TerminalCompletion::observe(
            &mut f.store,
            &reads,
            &log,
            &"a".repeat(64),
            "api",
            &key,
            Instant::now() + Duration::from_secs(1)
        )
        .is_err()
    );
    replace_record_checksum(
        &f.directory.path().join("store/records.sqlite"),
        "delivery",
        "operation:1",
        1,
        &dr,
    );
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    let old_epoch = store.execution_identity().unwrap().1.to_owned();
    drop(store);
    assert!(matches!(
        reopen(directory.path(), 13),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    drop(worker);
    let mut store = reopen(directory.path(), 13).unwrap();
    assert_ne!(store.execution_identity().unwrap().1, old_epoch);
    let scope = owner(&store);
    observed.check_prior_owner(&store, &scope).unwrap();
    let log = AuthenticatedLog::new(
        &store,
        "audit.heads",
        "audit.entries",
        ChainLimits {
            payload_bytes: 1024,
            records: 3,
            bytes: 1_000_000,
        },
        b"native-effect-audit-test-key-0123456789",
    )
    .unwrap();
    let new = TerminalCompletion::observe(
        &mut store,
        &scope,
        &log,
        &"a".repeat(64),
        "api",
        &key,
        Instant::now() + Duration::from_secs(1),
    )
    .unwrap();
    new.check_prior_owner(&store, &scope).unwrap();
    store
        .commit(
            &scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: "operation:1".into(),
                    revision: 1,
                    value: Some("changed intent".into()),
                }],
            },
        )
        .unwrap();
    assert_eq!(new.check_prior_owner(&store, &scope), Err("terminal"));
}

#[test]
fn journal_conflict_or_insufficient_claim_capacity_publishes_no_claim_audit_or_effect() {
    let _serial = process_guard();
    for (conflict, records) in [(false, 13), (false, 20), (true, 14)] {
        let (mut f, mut recorder, mut funding, _) = fund_fixture(Fixture::fenced(records), 2, "2");
        if conflict {
            funding.budget.claim.records = 4;
            funding.budget.claim.live_bytes = 20_000;
            funding.budget.result.records = 3;
            funding.budget.result.live_bytes = 25_000;
            funding = funding.with_result_limit(1024).unwrap();
        }
        recorder.enable_dispatch_journal(&f.store, "api").unwrap();
        let scope = owner(&f.store);
        let mut attempt = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            execution(),
        )
        .unwrap();
        attempt.attach_funding(funding).unwrap();
        let key = key(&attempt);
        if conflict {
            attempt
                .store
                .commit(
                    &scope,
                    &Batch {
                        checks: vec![],
                        writes: vec![Mutation {
                            namespace: "api".into(),
                            key: key.clone(),
                            revision: 0,
                            value: Some("existing".into()),
                        }],
                    },
                )
                .unwrap();
        }
        assert!(attempt.claim_recorded(&mut recorder).is_err());
        assert_eq!(
            attempt
                .store
                .get(&scope, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
        assert_eq!(
            attempt
                .store
                .get(&scope, "audit.heads", &"a".repeat(64))
                .unwrap()
                .revision,
            0
        );
        assert!(
            attempt
                .store
                .reservation_snapshot(&scope, "funds", "operation:1")
                .unwrap()
                .assignment
                .is_empty()
        );
        assert_eq!(
            attempt.store.get(&scope, "api", &key).unwrap().value,
            if conflict {
                Some("existing".into())
            } else {
                None
            }
        );
        let ticket = attempt.prepared.ticket.clone();
        assert_eq!(
            attempt.execute(&ticket, &AtomicBool::new(false)).err(),
            Some("unclaimed")
        );
        drop(attempt);
        assert!(!f.directory.path().join("started").exists());
    }
}

#[test]
fn journal_namespace_aliases_and_missing_pool_membership_refuse() {
    let _serial = process_guard();
    for name in [
        "intent",
        "claim",
        "delivery",
        "audit.heads",
        "audit.entries",
        "unallocated",
    ] {
        let (f, mut recorder, _, _) = fund_fixture(Fixture::fenced(13), 2, "2");
        assert!(
            recorder.enable_dispatch_journal(&f.store, name).is_err(),
            "{name}"
        );
    }
    let (mut f, mut recorder, mut funding, _) = fund_fixture(Fixture::fenced(13), 2, "2");
    funding.budget.claim.records = 4;
    funding.budget.claim.live_bytes = 20_000;
    funding.budget.result.records = 3;
    funding.budget.result.live_bytes = 25_000;
    funding = funding.with_result_limit(1024).unwrap();
    recorder.enable_dispatch_journal(&f.store, "funds").unwrap();
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    assert_eq!(
        a.claim_recorded(&mut recorder).err(),
        Some("dispatch_journal")
    );
}

#[test]
fn private_journal_grant_does_not_expand_the_original_effect_scope() {
    let _serial = process_guard();
    let (mut f, mut recorder, mut funding, _) = fund_fixture(Fixture::fenced(13), 2, "2");
    funding.budget.claim.records = 4;
    funding.budget.claim.live_bytes = 20_000;
    funding.budget.result.records = 3;
    funding.budget.result.live_bytes = 25_000;
    funding = funding.with_result_limit(1024).unwrap();
    recorder.enable_dispatch_journal(&f.store, "api").unwrap();
    assert!(recorder.enable_dispatch_journal(&f.store, "api").is_err());
    assert!(f.store.get(&f.scope, "api", "anything").is_err());
    let scope = f
        .store
        .scope(BTreeMap::from([
            ("intent".into(), sigil_durable_store::store::Access::Read),
            ("claim".into(), sigil_durable_store::store::Access::Read),
            ("delivery".into(), sigil_durable_store::store::Access::Read),
        ]))
        .unwrap();
    let mut a = Attempt::begin(
        &mut f.store,
        &scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    assert!(a.claim_recorded(&mut recorder).is_err());
    drop(a);
    assert!(!f.directory.path().join("started").exists());
}

fn replace_record_checksum(
    path: &std::path::Path,
    namespace: &str,
    key: &str,
    revision: u64,
    value: &str,
) {
    let mut h = Sha256::new();
    h.update(b"sigil-store/record/v1\0");
    for s in [namespace, key] {
        h.update((s.len() as u64).to_be_bytes());
        h.update(s.as_bytes());
    }
    h.update(revision.to_be_bytes());
    h.update([1]);
    h.update(value.as_bytes());
    let digest = h.finalize().to_vec();
    let db = rusqlite::Connection::open(path).unwrap();
    assert_eq!(
        db.execute(
            "UPDATE records SET value=?1,digest=?2 WHERE namespace=?3 AND key=?4",
            rusqlite::params![value.as_bytes(), digest, namespace, key]
        )
        .unwrap(),
        1
    );
}

#[test]
fn underfunded_terminal_journal_refuses_before_claim_even_with_free_pool_space() {
    let _serial = process_guard();
    for (records, bytes) in [(2, 25_000), (3, 10_000)] {
        let (mut f, mut recorder, mut funding, _) = fund_fixture(Fixture::fenced(20), 2, "2");
        funding.budget.claim.records = 4;
        funding.budget.claim.live_bytes = 20_000;
        funding.budget.result.records = records;
        funding.budget.result.live_bytes = bytes;
        funding = funding.with_result_limit(1024).unwrap();
        recorder.enable_dispatch_journal(&f.store, "api").unwrap();
        let scope = owner(&f.store);
        let mut a = Attempt::begin(
            &mut f.store,
            &f.scope,
            &mut f.worker,
            &mut f.clock,
            binding(),
            execution(),
        )
        .unwrap();
        a.attach_funding(funding).unwrap();
        assert_eq!(
            a.claim_recorded(&mut recorder).err(),
            Some("funding_budget")
        );
        assert_eq!(
            a.store
                .get(&scope, "claim", "operation:1")
                .unwrap()
                .revision,
            0
        );
        assert_eq!(
            a.store
                .get(&scope, "audit.heads", &"a".repeat(64))
                .unwrap()
                .revision,
            0
        );
        assert!(
            a.store
                .reservation_snapshot(&scope, "funds", "operation:1")
                .unwrap()
                .assignment
                .is_empty()
        );
        drop(a);
        assert!(!f.directory.path().join("started").exists());
    }
}

fn reopen(
    root: &std::path::Path,
    records: u64,
) -> std::result::Result<Store, sigil_durable_store::store::Error> {
    use sigil_durable_store::store::capacity::{Allocation, Pool};
    use sigil_durable_store::store::{Limits, OpenMode};
    Store::open_fenced_reserved_bound(
        &root.join("store"),
        OpenMode::Existing,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
}
