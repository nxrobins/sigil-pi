"""Explicit development archive-export assembly; never adopts existing state."""

import hashlib
import json
import argparse
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scripts.build_workspace_deployment import build as build_base
from scripts.compose_archive_export import compose_archive_export, compose_archive_export_api
from scripts.compose_terminal_history import compose_terminal_history


def add_projection(root, config, stdlib):
    """Build-time only: bind fresh deployment source and exact function inventory."""
    root = Path(root).resolve()
    if config.get("version") != 11 or Path(config["state_root"]) != root / "records" or (root / "records").exists():
        raise ValueError("archive export assembly requires fresh v11 deployment state")
    api = compose_archive_export_api(stdlib)
    projection = compose_archive_export(stdlib)
    history = compose_terminal_history(stdlib)
    for name, built, component in (("api_discovery", api, config["worker"]),
                                  ("history", history, config["functions"]["history"]),
                                  ("archive_export", projection, dict(config["functions"]["history"]))):
        source = root / (name + ".sigil")
        source.write_text(built.text)
        component.update(source=str(source), source_sha256=built.compiler_input_sha256)
        if name == "archive_export":
            config["functions"][name] = component


def build(root, workspace, runtime, evaluator, stdlib, token, profile, *, endpoint=None):
    if profile.get("conversation_lifecycle") != "archive-v1" or profile.get("public_archive_export") != "v1":
        raise ValueError("explicit archive-v1 and public_archive_export v1 are required")
    # Compose before writing any deployment output; the base builder then checks
    # fresh/empty state and establishes the unchanged tenant/archive grants.
    compose_archive_export_api(stdlib)
    compose_archive_export(stdlib)
    compose_terminal_history(stdlib)
    config, path = build_base(root, workspace, runtime, evaluator, stdlib, token, profile, endpoint=endpoint)
    root = Path(root).resolve()
    add_projection(root, config, stdlib)
    path.write_text(json.dumps(config, indent=2) + "\n")
    inputs = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(root.rglob("*")) if p.is_file() and p.name != "build-inputs.json"}
    (root / "build-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
    return config, path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--evaluator", required=True, type=Path)
    parser.add_argument("--stdlib-root", required=True, type=Path)
    parser.add_argument("--profile", type=Path, default=ROOT / "config/public-archives-development.json")
    parser.add_argument("--token-env", default="SIGIL_PI_TOKEN")
    args = parser.parse_args()
    profile = json.loads(args.profile.read_text())
    if profile["endpoint"] != "http://127.0.0.1:11434/v1/messages":
        parser.error("this development profile requires the local model endpoint")
    _, path = build(args.output, args.workspace, args.runtime, args.evaluator,
                    args.stdlib_root, os.environ[args.token_env], profile)
    print(json.dumps({"service": str(path), "profile": profile["schema"]}))


if __name__ == "__main__":
    main()
