//! Native-only coupling of actual claim/delivery production to authenticated
//! publication. SIGIL selects event semantics/redaction; no guest signing API.
use crate::audited_transaction::{Config, combined_grants, environment_key, manifest};
use crate::evaluation_audit::{self, Failure, Pending, Projector, Subject, Target};
use crate::execution_time::ExecutionGuard;
use crate::{Function, Result, fields, frame, identity};
use sha2::{Digest, Sha256};
use sigil_durable_store::store::authenticated_log::AuthenticatedLog;
use sigil_durable_store::store::{Access, Batch, Check, Receipt, Scope, Store};
use sigil_worker_bridge::Bridge;
use std::collections::BTreeMap;
use std::time::{Duration, Instant};
use zeroize::Zeroizing;

#[cfg(test)]
#[path = "shared_effect_audit_cache_tests.rs"]
mod cache_tests;

#[cfg(test)]
#[path = "shared_effect_audit_publication_tests.rs"]
mod publication_tests;

pub(crate) struct Admitted {
    config: Config,
    evaluation: Option<Projector>,
    recorder_subject: Option<Subject>,
    key: Zeroizing<Vec<u8>>,
    formatter: Function,
    scope: BTreeMap<String, Access>,
    grants: String,
    producer: String,
    projector: String,
    effect: String,
    context: String,
}

pub(crate) struct EffectAudit {
    formatter: Function,
    evaluation: Option<Projector>,
    recorder_subject: Option<Subject>,
    log: AuthenticatedLog,
    scope: Scope,
    heads: String,
    records: String,
    dispatch_journal: Option<String>,
    chain: String,
    grants: String,
    producer: String,
    projector: String,
    effect: String,
    context: String,
}

// Not deserializable or public. These references come only from the actual
// recorder invocation, held native binding and actual prepared/observed facts.
pub(crate) struct Recording<'a> {
    pub intent: &'a Check,
    pub claim_namespace: &'a str,
    pub delivery_namespace: &'a str,
    pub claim_revision: u64,
    pub claim_generation: &'a str,
    pub worker_facts: &'a str,
    pub prepared: Option<&'a str>,
    pub input_sha256: &'a str,
    pub input_bytes: usize,
    pub output: &'a str,
    pub batch: &'a str,
    pub phase: &'a str,
    pub before: u64,
    pub after: u64,
    pub elapsed_ms: u128,
    pub timeout_ms: u64,
}

pub(crate) fn digest(value: &str) -> String {
    format!("{:x}", Sha256::digest(value.as_bytes()))
}

impl Admitted {
    pub(crate) fn new(
        config: Config,
        producer: &crate::claimed::RecorderConfig,
        worker: &Bridge,
        domain: &BTreeMap<String, Access>,
        credential_facts: &str,
    ) -> Result<Self> {
        Self::new_with_cache(config, producer, worker, domain, credential_facts, None)
    }
    pub(crate) fn new_with_cache(
        config: Config,
        producer: &crate::claimed::RecorderConfig,
        worker: &Bridge,
        domain: &BTreeMap<String, Access>,
        credential_facts: &str,
        mut cache: Option<&mut crate::PureCache>,
    ) -> Result<Self> {
        let scope = combined_grants(domain, &config)?;
        let grants = serde_json::to_string(domain).map_err(|_| "config")?;
        let evaluation = config
            .evaluation
            .clone()
            .map(|worker| {
                Projector::admit_with_cache(worker, &config.chain, &grants, cache.as_deref_mut())
            })
            .transpose()?;
        let recorder_subject = evaluation
            .as_ref()
            .map(|_| Subject::new(producer, &producer.worker, domain))
            .transpose()?;
        let producer = manifest(&producer.worker)?;
        let projector = manifest(&config.worker)?;
        let facts = worker.facts().map_err(|_| "config")?;
        let fuel = facts.max_fuel.to_string();
        let timeout = facts.max_timeout_ms.to_string();
        let net = serde_json::to_string(facts.net).map_err(|_| "config")?;
        let fs = serde_json::to_string(facts.fs).map_err(|_| "config")?;
        let secrets = serde_json::to_string(&facts.secret_names).map_err(|_| "config")?;
        let writes = serde_json::to_string(facts.fs_write).map_err(|_| "config")?;
        let mut fact_fields = vec![
            facts.source_sha256,
            facts.runtime_sha256,
            &fuel,
            &timeout,
            &net,
            &fs,
            &secrets,
        ];
        let marker = if facts.executor != "sigil" {
            fact_fields.push(&writes);
            fact_fields.push(facts.executor);
            "EM3\n"
        } else if facts.fs_write.is_empty() {
            "EM1\n"
        } else {
            fact_fields.push(&writes);
            "EM2\n"
        };
        let effect = frame(marker, &fact_fields)?;
        let mut formatter = Function::cached_for_owner(config.worker.clone(), cache)?;
        let key = environment_key(&config.key_env)?;
        let deadline = Instant::now() + Duration::from_millis(formatter.timeout_ms);
        let boot = frame(
            "WB1\n",
            &[
                &config.chain,
                &producer,
                &projector,
                &grants,
                &effect,
                credential_facts,
                &digest(credential_facts),
            ],
        )?;
        let decision = formatter.invoke(boot, deadline)?;
        let decision = fields(&decision, "WB2\n", 2)?;
        if decision[0] != "effect_audit_admitted"
            || decision[1].is_empty()
            || decision[1].len() > 1024
        {
            return Err("config");
        }
        Ok(Self {
            config,
            evaluation,
            recorder_subject,
            key,
            formatter,
            scope,
            grants,
            producer,
            projector,
            effect,
            context: decision[1].into(),
        })
    }

    pub(crate) fn open(self, store: &Store) -> Result<EffectAudit> {
        let log = AuthenticatedLog::new(
            store,
            &self.config.heads,
            &self.config.records,
            self.config.limits,
            &self.key,
        )
        .map_err(|_| "config")?;
        Ok(EffectAudit {
            formatter: self.formatter,
            evaluation: self.evaluation,
            recorder_subject: self.recorder_subject,
            log,
            scope: store.scope(self.scope).map_err(|_| "config")?,
            heads: self.config.heads,
            records: self.config.records,
            dispatch_journal: None,
            chain: self.config.chain,
            grants: self.grants,
            producer: self.producer,
            projector: self.projector,
            effect: self.effect,
            context: self.context,
        })
    }
}

impl EffectAudit {
    pub(crate) fn has_dispatch_journal(&self) -> bool {
        self.dispatch_journal.is_some()
    }
    pub(crate) fn check_journal_completion(
        &self,
        credit: sigil_durable_store::store::reservation::Credits,
        result_limit: usize,
    ) -> Result<()> {
        // Conservative bound on encoded result, terminal journal, all row
        // coordinates, existing head and signed event. No free pool space is
        // substituted for this originally held completion obligation.
        let bytes = (result_limit as u64)
            .checked_mul(6)
            .and_then(|n| n.checked_add(self.log.encoded_entry_ceiling() + 8192))
            .ok_or("funding_budget")?;
        if self.dispatch_journal.is_none() || credit.records < 3 || credit.live_bytes < bytes {
            return Err("funding_budget");
        }
        Ok(())
    }

    pub(crate) fn enable_dispatch_journal(&mut self, store: &Store, namespace: &str) -> Result<()> {
        let mut grants: BTreeMap<String, Access> =
            serde_json::from_str(&self.grants).map_err(|_| "config")?;
        if self.dispatch_journal.is_some()
            || !store.has_execution_fence()
            || grants.contains_key(namespace)
            || namespace == self.heads
            || namespace == self.records
        {
            return Err("config");
        }
        grants.insert(self.heads.clone(), Access::ReadWrite);
        grants.insert(self.records.clone(), Access::ReadWrite);
        grants.insert(namespace.into(), Access::CreateOnly);
        let scope = store.scope(grants).map_err(|_| "config")?;
        self.scope = scope;
        self.dispatch_journal = Some(namespace.into());
        Ok(())
    }

    #[cfg(test)]
    pub(crate) fn fixture(
        store: &mut Store,
        formatter: sigil_worker_bridge::Config,
        mut grants: BTreeMap<String, Access>,
        records: u64,
        fill: bool,
    ) -> Self {
        // Controlled native protocol fixture only, not compiler/event evidence.
        // Match actual Admitted::new: a cached formatter is boot-invoked before
        // an Attempt starts. A cold Fresh formatter here introduces per-event
        // process launch/reaping into a boundary production does not use.
        let mut formatter = Function::cached(formatter).unwrap();
        assert_eq!(
            formatter
                .invoke(
                    "native-audit-fixture-boot".into(),
                    Instant::now() + Duration::from_secs(5),
                )
                .unwrap(),
            "native fixture admitted",
        );
        let encoded = serde_json::to_string(&grants).unwrap();
        grants.insert("audit.heads".into(), Access::ReadWrite);
        grants.insert("audit.entries".into(), Access::ReadWrite);
        let scope = store.scope(grants).unwrap();
        let log = AuthenticatedLog::new(
            store,
            "audit.heads",
            "audit.entries",
            sigil_durable_store::store::authenticated_log::ChainLimits {
                payload_bytes: 1024,
                records,
                bytes: 1_000_000,
            },
            b"native-effect-audit-test-key-0123456789",
        )
        .unwrap();
        let chain = "a".repeat(64);
        if fill {
            log.append(
                store,
                &scope,
                &chain,
                0,
                "capacity fixture",
                &Batch {
                    checks: vec![],
                    writes: vec![],
                },
            )
            .unwrap();
        }
        Self {
            formatter,
            evaluation: None,
            recorder_subject: None,
            log,
            scope,
            heads: "audit.heads".into(),
            records: "audit.entries".into(),
            dispatch_journal: None,
            chain,
            grants: encoded,
            producer: "native fixture".into(),
            projector: "native fixture".into(),
            effect: "native fixture".into(),
            context: "native fixture".into(),
        }
    }

    pub(crate) fn inspect_owner(&self) -> Result<()> {
        if let Some(evaluation) = &self.evaluation {
            evaluation.inspect_owner()?;
        }
        self.formatter.inspect_owner()
    }

    pub(crate) fn record_evaluation_failure(
        &mut self,
        store: &mut Store,
        failure: Failure,
    ) -> Result<()> {
        evaluation_audit::publish(
            self.evaluation.as_mut(),
            Target {
                log: &self.log,
                scope: &self.scope,
                chain: &self.chain,
                heads: &self.heads,
            },
            store,
            failure,
        )
    }

    pub(crate) fn observes_recorder_evaluations(&self) -> bool {
        self.evaluation.is_some()
    }

    pub(crate) fn record_recorder_failure(
        &mut self,
        store: &mut Store,
        pending: Pending,
        code: &'static str,
    ) -> Result<()> {
        if self.evaluation.is_none() {
            return Ok(());
        }
        let subject = self.recorder_subject.as_ref().ok_or("audit_recording")?;
        let failure = pending.refuse(subject, code);
        self.record_evaluation_failure(store, failure)
    }

    pub(crate) fn inspect_existing(&self, store: &mut Store) -> Result<()> {
        self.log
            .inspect_existing(
                store,
                &self.scope,
                &self.chain,
                None,
                Instant::now() + Duration::from_secs(1),
            )
            .map(|_| ())
            .map_err(|_| "audit_verification")
    }

    pub(crate) fn propose(&mut self, r: Recording<'_>, deadline: Instant) -> Result<String> {
        let retired = r.worker_facts.starts_with("WF3\n");
        let fenced = retired || r.worker_facts.starts_with("WF2\n");
        let wf = if retired {
            fields(r.worker_facts, "WF3\n", 10)?
        } else if fenced {
            fields(r.worker_facts, "WF2\n", 10)?
        } else {
            fields(r.worker_facts, "WF1\n", 9)?
        };
        if (retired && wf[0] != "retired") || (fenced && !retired && wf[0] != "abandoned") {
            return Err("binding");
        }
        // Only a complete retained output is hashed. Oversized/non-string/missing
        // output remains explicitly unavailable, never the hash of an empty body.
        let output_digest = if wf[6] == "string" {
            digest(wf[8])
        } else {
            String::new()
        };
        let mut observed = wf[..8].to_vec();
        observed.push(&output_digest);
        if fenced {
            observed.push(wf[9]);
        }
        let observed = frame(
            if retired {
                "WO3\n"
            } else if fenced {
                "WO2\n"
            } else {
                "WO1\n"
            },
            &observed,
        )?;
        // Abandoned recovery does not establish the old worker's artifact,
        // selected input, grants or execution budgets from the current profile.
        let (effect, prepared) = if wf[0] == "abandoned" || retired {
            ("", "")
        } else {
            (self.effect.as_str(), r.prepared.ok_or("binding")?)
        };
        let input = frame(
            if retired {
                "WA3\n"
            } else if fenced {
                "WA2\n"
            } else {
                "WA1\n"
            },
            &[
                &identity()?,
                &self.chain,
                &self.producer,
                &self.projector,
                effect,
                &self.grants,
                &r.intent.namespace,
                r.claim_namespace,
                r.delivery_namespace,
                &r.intent.key,
                &r.intent.revision.to_string(),
                &r.claim_revision.to_string(),
                r.claim_generation,
                wf[1],
                &observed,
                prepared,
                r.input_sha256,
                &r.input_bytes.to_string(),
                &digest(r.output),
                &r.output.len().to_string(),
                &digest(r.batch),
                &r.batch.len().to_string(),
                r.phase,
                &r.before.to_string(),
                &r.after.to_string(),
                &r.elapsed_ms.to_string(),
                &r.timeout_ms.to_string(),
                &self.context,
            ],
        )?;
        let output = self.formatter.invoke(input, deadline)?;
        let parts = fields(&output, "AR1\n", 2)?;
        if parts[0] != "publish" || parts[1].is_empty() {
            return Err("binding");
        }
        Ok(parts[1].into())
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn commit_funded(
        &self,
        store: &mut Store,
        batch: &Batch,
        payload: &str,
        deadline: Instant,
        guard: Option<(&ExecutionGuard, &mut u64)>,
        held: &sigil_durable_store::store::reservation::Held,
        debit: sigil_durable_store::store::reservation::Credits,
        next_binding: Option<[u8; 32]>,
        witness: Option<&[u8]>,
        remaining_publications: u64,
        dispatch: Option<&crate::claimed::dispatch_journal::Prepared>,
    ) -> Result<sigil_durable_store::store::authenticated_log::ReservedPublication> {
        // Keep the terminal result and, for an opted-in assignment, the third
        // retirement publication funded before any claim/effect. Counts derive
        // from the native-held credit; this is not guest-created allowance.
        if !(1..=3).contains(&remaining_publications) {
            return Err("funding_audit");
        }
        let count = remaining_publications;
        self.log
            .check_held_allowance(
                held,
                &self.chain,
                count,
                count * self.log.encoded_entry_ceiling(),
            )
            .map_err(|_| "funding_audit")?;
        let head = store
            .get(&self.scope, &self.heads, &self.chain)
            .map_err(|_| "storage")?;
        let expecting_dispatch = self.dispatch_journal.is_some()
            && next_binding.is_some()
            && witness.is_some_and(|bytes| !bytes.is_empty());
        if dispatch.is_some() != expecting_dispatch {
            return Err("dispatch_journal");
        }
        let mut coupled = dispatch
            .map(|fact| {
                let sequence = self
                    .log
                    .next_sequence(store, &self.scope, &self.chain, head.revision)
                    .map_err(|_| "dispatch_journal")?;
                fact.couple(
                    self.dispatch_journal.as_deref().ok_or("dispatch_journal")?,
                    &self.chain,
                    sequence,
                    payload,
                    batch,
                )
            })
            .transpose()?;
        if coupled.is_none() && self.dispatch_journal.is_some() && batch.writes.len() == 2 {
            let intent = batch.checks.first().ok_or("terminal_journal")?;
            let snapshot = store
                .get(&self.scope, &intent.namespace, &intent.key)
                .map_err(|_| "intent")?;
            if snapshot.revision != intent.revision {
                return Err("intent");
            }
            let binding = crate::claimed::completion::hash(&[
                b"sigil-completion-intent/v1",
                intent.namespace.as_bytes(),
                intent.key.as_bytes(),
                &intent.revision.to_be_bytes(),
                snapshot.value.as_deref().ok_or("intent")?.as_bytes(),
                batch.writes[0].namespace.as_bytes(),
                batch.writes[1].namespace.as_bytes(),
            ]);
            let binding = binding
                .iter()
                .map(|b| format!("{b:02x}"))
                .collect::<String>();
            let sequence = self
                .log
                .next_sequence(store, &self.scope, &self.chain, head.revision)
                .map_err(|_| "terminal_journal")?;
            coupled = Some(crate::claimed::terminal_journal::couple(
                self.dispatch_journal.as_deref().ok_or("terminal_journal")?,
                &self.chain,
                sequence,
                &binding,
                payload,
                batch,
            )?);
        }
        let (batch, payload) = coupled
            .as_ref()
            .map_or((batch, payload), |(batch, payload)| {
                (batch, payload.as_str())
            });
        if coupled.is_some() {
            // Independently require enough originally held pool credit for the
            // complete claim publication. Unreserved free space cannot pay for
            // a missing journal debit. Include coordinates and row overhead;
            // the audit head ceiling is deliberately conservative on updates.
            let mut required_bytes = self.log.encoded_entry_ceiling() + 4096;
            for write in &batch.writes {
                required_bytes = required_bytes
                    .checked_add((write.namespace.len() + write.key.len() + 96) as u64)
                    .and_then(|n| n.checked_add(write.value.as_ref().map_or(0, |v| v.len()) as u64))
                    .ok_or("funding_budget")?;
            }
            required_bytes = required_bytes
                .checked_add(
                    (self.heads.len()
                        + self.chain.len()
                        + self.records.len()
                        + self.chain.len()
                        + 17
                        + 192) as u64,
                )
                .ok_or("funding_budget")?;
            let required_records = batch.writes.iter().filter(|w| w.revision == 0).count() as u64
                + 1
                + u64::from(head.revision == 0);
            if debit.records < required_records || debit.live_bytes < required_bytes {
                return Err("funding_budget");
            }
        }
        if let Some((guard, clock)) = guard {
            guard.admit(clock, deadline)?;
        } else if Instant::now() >= deadline {
            return Err("deadline");
        }
        let publication = if let Some(binding) = next_binding {
            if let Some(witness) = witness {
                self.log.append_assigning_witness(
                    store,
                    &self.scope,
                    &self.chain,
                    head.revision,
                    payload,
                    batch,
                    held,
                    debit,
                    binding,
                    witness,
                )
            } else {
                self.log.append_assigning(
                    store,
                    &self.scope,
                    &self.chain,
                    head.revision,
                    payload,
                    batch,
                    held,
                    debit,
                    binding,
                )
            }
        } else {
            self.log.append_spending(
                store,
                &self.scope,
                &self.chain,
                head.revision,
                payload,
                batch,
                held,
                debit,
            )
        };
        publication.map_err(|e| match e {
            sigil_durable_store::store::Error::CommitUncertain => "commit_uncertain",
            _ => "storage",
        })
    }

    pub(crate) fn commit(
        &self,
        store: &mut Store,
        batch: &Batch,
        payload: &str,
        deadline: Instant,
        guard: Option<(&ExecutionGuard, &mut u64)>,
    ) -> Result<Receipt> {
        let head = store
            .get(&self.scope, &self.heads, &self.chain)
            .map_err(|_| "storage")?;
        if let Some((guard, clock)) = guard {
            guard.admit(clock, deadline)?;
        } else if Instant::now() >= deadline {
            return Err("deadline");
        }
        self.log
            .append(
                store,
                &self.scope,
                &self.chain,
                head.revision,
                payload,
                batch,
            )
            .map(|p| p.receipt)
            .map_err(|_| "storage")
    }
}
