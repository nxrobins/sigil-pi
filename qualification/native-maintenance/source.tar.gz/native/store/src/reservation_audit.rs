//! Independent authenticated-chain allowances, coupled to pool credits.
//! These are encoded-record ceilings, not signing keys, effect authority,
//! execution ownership, recovery policy or a physical disk guarantee.
use super::super::authenticated_log::ChainLimits;
use super::*;

pub const CHAINS: usize = 8;
pub const ENCODED_BYTES: usize = 16_384;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Credit {
    pub(crate) heads: String,
    pub(crate) records_namespace: String,
    pub(crate) chain: String,
    pub(crate) limits: ChainLimits,
    pub(crate) records: u64,
    pub(crate) bytes: u64,
}
impl Credit {
    pub(crate) fn same_chain(&self, other: &Self) -> bool {
        self.heads == other.heads
            && self.records_namespace == other.records_namespace
            && self.chain == other.chain
            && self.limits == other.limits
    }
    fn aliases(&self, other: &Self) -> bool {
        self.chain == other.chain
            && (self.heads == other.heads || self.records_namespace == other.records_namespace)
    }
    fn matches(&self, debit: &Debit) -> bool {
        self.heads == debit.heads
            && self.records_namespace == debit.records_namespace
            && self.chain == debit.chain
    }
    fn valid(&self) -> bool {
        valid_name(&self.heads, 128)
            && valid_name(&self.records_namespace, 128)
            && self.heads != self.records_namespace
            && self.chain.len() == 64
            && self
                .chain
                .bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
            && self.records <= self.limits.records
            && self.bytes <= self.limits.bytes
    }
}

/// An authenticated head observation minted by AuthenticatedLog. This is only a
/// proposal: it holds no capacity until publication returns a confirmed receipt.
/// Neither Clone nor serializable; callers cannot supply a forged head count.
pub struct Allowance {
    pub(crate) boot: [u8; 32],
    pub(crate) revision: u64,
    pub(crate) count: u64,
    pub(crate) bytes: u64,
    pub(crate) credit: Credit,
}

/// Trusted native debit request, not a capability. It must match an allowance
/// actually contained in the held credit capability. Choosing to relinquish
/// unused allowance is application policy and must respect in-flight ownership.
pub struct Debit {
    pub heads: String,
    pub records_namespace: String,
    pub chain: String,
    pub records: u64,
    pub bytes: u64,
}

pub(crate) struct Guard {
    pub(crate) credit: Credit,
    pub(crate) count: u64,
    pub(crate) bytes: u64,
}
impl Guard {
    pub(crate) fn check(&self, connection: &Connection, profile: u8) -> Result<()> {
        let (records, bytes) = totals(connection, profile, &self.credit)?;
        if self.count.checked_add(records).ok_or(Error::Limit)? > self.credit.limits.records
            || self.bytes.checked_add(bytes).ok_or(Error::Limit)? > self.credit.limits.bytes
        {
            return Err(Error::Limit);
        }
        Ok(())
    }
}

pub(super) fn empty(credits: &[Credit]) -> bool {
    credits.iter().all(|c| c.records == 0 && c.bytes == 0)
}
pub(super) fn encode(credits: &[Credit]) -> Result<Vec<u8>> {
    if credits.len() > CHAINS {
        return Err(Error::Limit);
    }
    let raw = serde_json::to_vec(credits).map_err(|_| Error::Invalid)?;
    if raw.len() > ENCODED_BYTES {
        return Err(Error::Limit);
    }
    Ok(raw)
}
pub(super) fn decode(raw: &[u8]) -> Result<Vec<Credit>> {
    if raw.len() > ENCODED_BYTES {
        return Err(Error::Corrupt);
    }
    let credits: Vec<Credit> = serde_json::from_slice(raw).map_err(|_| Error::Corrupt)?;
    if credits.len() > CHAINS
        || encode(&credits).map_err(|_| Error::Corrupt)? != raw
        || credits.iter().any(|c| !c.valid())
    {
        return Err(Error::Corrupt);
    }
    for pair in credits.windows(2) {
        let key = |c: &Credit| {
            (
                c.heads.clone(),
                c.records_namespace.clone(),
                c.chain.clone(),
            )
        };
        if key(&pair[0]) >= key(&pair[1]) {
            return Err(Error::Corrupt);
        }
    }
    Ok(credits)
}

pub(super) fn validate(
    credits: &[Credit],
    limits: &Limits,
    allocation: &capacity::Allocation,
    owner: &str,
) -> Result<()> {
    let pool = allocation
        .pools
        .iter()
        .find(|p| p.namespaces.iter().any(|n| n == owner))
        .ok_or(Error::Corrupt)?;
    for c in credits {
        if !c.valid()
            || !pool.namespaces.contains(&c.heads)
            || !pool.namespaces.contains(&c.records_namespace)
        {
            return Err(Error::Corrupt);
        }
        c.limits.validate(limits).map_err(|_| Error::Corrupt)?;
    }
    Ok(())
}

fn each_entry(
    connection: &Connection,
    profile: u8,
    mut visit: impl FnMut(Entry) -> Result<()>,
) -> Result<()> {
    if profile < 4 {
        return Ok(());
    }
    let mut query=connection.prepare("SELECT namespace,key,length(CAST(namespace AS BLOB)),length(CAST(key AS BLOB)) FROM reservations ORDER BY namespace,key LIMIT ?1").map_err(|_|Error::Corrupt)?;
    let mut rows = query
        .query([ENTRIES as i64 + 1])
        .map_err(|_| Error::Corrupt)?;
    let mut count = 0;
    while let Some(row) = rows.next().map_err(|_| Error::Corrupt)? {
        if count == ENTRIES {
            return Err(Error::Limit);
        }
        count += 1;
        let n: i64 = row.get(2).map_err(|_| Error::Corrupt)?;
        let k: i64 = row.get(3).map_err(|_| Error::Corrupt)?;
        if !(1..=128).contains(&n) || !(1..=256).contains(&k) {
            return Err(Error::Corrupt);
        }
        let namespace: String = row.get(0).map_err(|_| Error::Corrupt)?;
        let key: String = row.get(1).map_err(|_| Error::Corrupt)?;
        if !valid_name(&namespace, 128) || !valid_name(&key, 256) {
            return Err(Error::Corrupt);
        }
        visit(read(connection, &namespace, &key, profile)?.ok_or(Error::Corrupt)?)?;
    }
    Ok(())
}
fn totals(connection: &Connection, profile: u8, wanted: &Credit) -> Result<(u64, u64)> {
    let mut result = (0u64, 0u64);
    each_entry(connection, profile, |entry| {
        for c in entry.audits {
            if c.aliases(wanted) {
                // Retained zero-credit coordinates also preserve identity/limits.
                if !c.same_chain(wanted) {
                    return Err(Error::Conflict);
                }
                result.0 = result.0.checked_add(c.records).ok_or(Error::Corrupt)?;
                result.1 = result.1.checked_add(c.bytes).ok_or(Error::Corrupt)?;
            }
        }
        Ok(())
    })?;
    Ok(result)
}

pub(super) fn create(
    connection: &Connection,
    profile: u8,
    allowances: &[Allowance],
) -> Result<Vec<Credit>> {
    if allowances.is_empty() {
        return Ok(vec![]);
    }
    if profile < 4 || allowances.len() > CHAINS {
        return Err(Error::Invalid);
    }
    let mut result: Vec<Credit> = Vec::new();
    for allowance in allowances {
        let c = &allowance.credit;
        if !c.valid()
            || (c.records == 0 && c.bytes == 0)
            || result.iter().any(|other| other.aliases(c))
        {
            return Err(Error::Invalid);
        }
        // Exact CAS against the authenticated observation, inside the same
        // transaction which creates credits and publishes related data.
        if Store::read_record(connection, &c.heads, &c.chain, 4096)?.revision != allowance.revision
        {
            return Err(Error::Conflict);
        }
        let (records, bytes) = totals(connection, profile, c)?;
        if allowance
            .count
            .checked_add(records)
            .and_then(|n| n.checked_add(c.records))
            .ok_or(Error::Limit)?
            > c.limits.records
            || allowance
                .bytes
                .checked_add(bytes)
                .and_then(|n| n.checked_add(c.bytes))
                .ok_or(Error::Limit)?
                > c.limits.bytes
        {
            return Err(Error::Limit);
        }
        result.push(c.clone());
    }
    result.sort_by(|a, b| {
        (&a.heads, &a.records_namespace, &a.chain).cmp(&(&b.heads, &b.records_namespace, &b.chain))
    });
    encode(&result)?;
    Ok(result)
}

pub(super) fn spend(credits: &[Credit], debits: &[Debit]) -> Result<Vec<Credit>> {
    if debits.len() > CHAINS {
        return Err(Error::Limit);
    }
    let mut result = credits.to_vec();
    let mut seen = BTreeSet::new();
    for debit in debits {
        if !seen.insert((&debit.heads, &debit.records_namespace, &debit.chain))
            || (debit.records == 0 && debit.bytes == 0)
        {
            return Err(Error::Invalid);
        }
        let credit = result
            .iter_mut()
            .find(|c| c.matches(debit))
            .ok_or(Error::Denied)?;
        credit.records = credit
            .records
            .checked_sub(debit.records)
            .ok_or(Error::Limit)?;
        credit.bytes = credit.bytes.checked_sub(debit.bytes).ok_or(Error::Limit)?;
    }
    Ok(result)
}

pub(super) fn authorize(
    store: &Store,
    scope: &Scope,
    owner: &str,
    batch: &Batch,
    allowances: &[Allowance],
    guard: Option<&Guard>,
) -> Result<()> {
    if !allowances.is_empty() && store.reserving < 4 {
        return Err(Error::Invalid);
    }
    if allowances.len() > CHAINS {
        return Err(Error::Limit);
    }
    let allocation = store.allocation.as_ref().ok_or(Error::Invalid)?;
    for allowance in allowances {
        if allowance.boot != store.boot {
            return Err(Error::Denied);
        }
        let c = &allowance.credit;
        validate(std::slice::from_ref(c), &store.limits, allocation, owner)
            .map_err(|_| Error::Denied)?;
        store.authorize(scope, &c.heads, &c.chain, true, allowance.revision, false)?;
        store.authorize(
            scope,
            &c.records_namespace,
            &format!("{}.0000000000000000", c.chain),
            true,
            0,
            false,
        )?;
        // Only the actual authenticated append path may mutate the head/entries
        // whose pre-append observation backs a newly created allowance.
        if batch
            .writes
            .iter()
            .any(|w| w.namespace == c.heads || w.namespace == c.records_namespace)
            && guard.is_none_or(|g| !g.credit.same_chain(c))
        {
            return Err(Error::Denied);
        }
    }
    Ok(())
}

#[cfg(test)]
#[path = "reservation_audit_tests.rs"]
mod tests;
