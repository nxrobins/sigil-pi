# Separate export obligations

The developing native `claimed::export_capacity` interface reserves export
obligations before an effect's recorded claim. It is an opt-in native embedding
interface, not an HTTP route or a completed export-only successor.

A fixed grantless SIGIL `Policy` receives actual read-scoped source facts, the
fixed sink identity and limit, and the authenticated-entry ceiling. It selects
preparation and acknowledgment amounts. The native mechanism independently
checks the bounded encoding costs and actual immutable pool membership. The
provided development budget policy only supports budget admission; it refuses
projection requests. Application-specific export policy remains to be added.

Admission also checks the actual immutable store limits for the future combined
transactions: at least ten batch items, enough value space for bounded prepared
bytes and authenticated entries, and enough combined batch bytes. The private
export audit requires at least 1024 payload bytes for all fixed event envelopes.
Reserved pool credit alone cannot override these independent structural limits.

The atomic admission writes an immutable signed source/destination/policy binding
and creates a distinct reservation in a private export namespace, including two
future audit entries. It never spends or releases the execution reservation.
Native reservation operations need a private read/write scope; no guest receives
that scope. An inadequate policy, missing caller read scope, already claimed
source, alias, different pool or unavailable capacity refuses before dispatch.

Only the live native permit can use the dedicated `run_recorded` path. That path
rechecks the actual owner epoch, source, unchanged admission and held export
reservation before calling the existing recorded execution machinery. Returned
execution credit leaves the export obligation held. Other native non-export
interfaces retain their existing contracts and do not acquire export guarantees.

The developing follow-on [export successor](export-successor.md) implements the
fresh bootstrap, authenticated recovery, exact prepared bytes, real fixed-sink
receipt and local acknowledgment, with a separately pinned control-plane
projection. Full frozen verification/review, source-lane exclusion and the
unchanged-consumer integration remain required. An unused admission also needs an explicit,
policy-authorized retirement path. The reservation catalog remains bounded.
These open requirements prevent this component from establishing M6 or MVP
readiness.
