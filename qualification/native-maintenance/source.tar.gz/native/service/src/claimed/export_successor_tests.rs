//! Native mechanisms with controlled policy/effect subprocesses. The compiled
//! SIGIL policy and process-kill integration are separate evidence gates.
use super::*;
use crate::claimed::completion_tests::{fund_parent_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, process_guard};
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use sigil_durable_store::store::capacity::{Allocation, Pool};
use sigil_durable_store::store::{Limits, OpenMode};
use std::os::unix::fs::PermissionsExt;
use std::path::Path;

#[path = "export_maintenance_tests.rs"]
mod maintenance;

fn ledger(store: &Store) -> Ledger {
    Ledger::new(
        store,
        "exports",
        "exports.heads",
        "exports.entries",
        &"b".repeat(64),
        ChainLimits {
            payload_bytes: 1024,
            records: 10,
            bytes: 1_000_000,
        },
        b"native-export-test-key-never-a-pilot-0123456789",
    )
    .unwrap()
}
fn terminal(store: &mut Store, intent: &str) -> TerminalCompletion {
    let scope = owner(store);
    let log = AuthenticatedLog::new(
        store,
        "audit.heads",
        "audit.entries",
        ChainLimits {
            payload_bytes: 1024,
            records: 3,
            bytes: 1_000_000,
        },
        b"native-effect-audit-test-key-0123456789",
    )
    .unwrap();
    TerminalCompletion::observe(
        store,
        &scope,
        &log,
        &"a".repeat(64),
        "api",
        intent,
        Instant::now() + Duration::from_secs(5),
    )
    .unwrap()
}
fn reopen(root: &Path) -> Store {
    reopen_profile(root, false)
}
fn reopen_profile(root: &Path, anchored: bool) -> Store {
    let open = |path: &Path, mode, limits, allocation, admission, slots| {
        if anchored {
            Store::open_anchored_reserved_bound(
                path,
                &root.join("authority").canonicalize().unwrap(),
                mode,
                limits,
                allocation,
                admission,
                slots,
            )
        } else {
            Store::open_fenced_reserved_bound(path, mode, limits, allocation, admission, slots)
        }
    };
    open(
        &root.join("store"),
        OpenMode::Existing,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                    "exports",
                    "exports.heads",
                    "exports.entries",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records: 64,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
    .unwrap()
}
fn policy(root: &Path) -> Policy {
    let response = |output: String| {
        serde_json::json!({"jsonrpc":"2.0","id":2,"result":{"content":[{
            "type":"text","text":serde_json::json!({"status":"ok","data":{"output_text":output}}).to_string()}]}})
            .to_string().replace("\"id\":2", "\"id\":'\"$n\"'")
    };
    let budget = response(frame("EB1\n", &["512", "3", "40000", "3", "25000"]).unwrap());
    let project = response(frame("EP1\n", &["publish", "68656c6c6f"]).unwrap());
    let runtime = root.join("export-runtime");
    let body = format!(
        "#!/bin/sh\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nn=2\nwhile read -r line; do\ncase \"$line\" in\n*budget*) printf '%s\\n' '{budget}' ;;\n*) printf '%s\\n' \"$line\" >> '{}'; printf '%s\\n' '{project}' ;;\nesac\nn=$((n + 1))\ndone\n",
        root.join("projections").display()
    );
    std::fs::write(&runtime, &body).unwrap();
    std::fs::set_permissions(&runtime, std::fs::Permissions::from_mode(0o700)).unwrap();
    let source = root.join("export-source");
    std::fs::write(&source, "controlled projection, not SIGIL").unwrap();
    Policy::new(crate::WorkerConfig {
        version: 1,
        runtime,
        runtime_sha256: digest(body.as_bytes()),
        source,
        source_sha256: digest(b"controlled projection, not SIGIL"),
        max_fuel: 1000,
        max_timeout_ms: 5000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    })
    .unwrap()
}

fn executed() -> (Fixture, FixedSink, Policy, String) {
    executed_with_policy(None, 512)
}

fn executed_with_policy(
    config: Option<crate::WorkerConfig>,
    sink_bytes: usize,
) -> (Fixture, FixedSink, Policy, String) {
    let (f, sink, policy, intent, _) = executed_with_source(config, sink_bytes, false);
    (f, sink, policy, intent)
}

fn executed_with_source(
    config: Option<crate::WorkerConfig>,
    sink_bytes: usize,
    guarded: bool,
) -> (Fixture, FixedSink, Policy, String, Option<FixedSource>) {
    executed_with_profile(config, sink_bytes, guarded, false)
}
fn executed_with_profile(
    config: Option<crate::WorkerConfig>,
    sink_bytes: usize,
    guarded: bool,
    anchored: bool,
) -> (Fixture, FixedSink, Policy, String, Option<FixedSource>) {
    let f = if anchored {
        Fixture::anchored(64)
    } else {
        Fixture::export_fenced(64)
    };
    let (mut f, mut recorder, mut credit, _) = fund_parent_fixture(f);
    credit.budget.claim = Credits {
        records: 4,
        live_bytes: 20_000,
    };
    credit.budget.result = Credits {
        records: 3,
        live_bytes: 25_000,
    };
    credit = credit.with_result_limit(1024).unwrap();
    recorder.enable_dispatch_journal(&f.store, "api").unwrap();
    let root = f.directory.path().join("sink");
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let sink = FixedSink::admit(&root.canonicalize().unwrap(), "delivery", sink_bytes).unwrap();
    let mut policy = config
        .map(|c| Policy::new(c).unwrap())
        .unwrap_or_else(|| policy(f.directory.path()));
    let scope = owner(&f.store);
    let ledger = ledger(&f.store);
    let source = if guarded {
        let path = f.directory.path().join("external");
        std::fs::create_dir(&path).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700)).unwrap();
        std::fs::write(path.join("intent"), b"external original").unwrap();
        std::fs::set_permissions(path.join("intent"), std::fs::Permissions::from_mode(0o600))
            .unwrap();
        Some(FixedSource::admit(&path.canonicalize().unwrap(), "intent", 1024).unwrap())
    } else {
        None
    };
    let permit = if let Some(source) = &source {
        ledger.reserve_guarded(&mut f.store, &scope, &credit, &sink, &mut policy, source)
    } else {
        ledger.reserve(&mut f.store, &scope, &credit, &sink, &mut policy)
    }
    .unwrap();
    let intent = permit.intent_binding().to_owned();
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(credit).unwrap();
    let result = if let Some(source) = &source {
        permit.run_recorded_guarded(&mut attempt, &mut recorder, &AtomicBool::new(false), source)
    } else {
        permit.run_recorded(&mut attempt, &mut recorder, &AtomicBool::new(false))
    }
    .unwrap();
    assert_eq!(result.phase.as_deref(), Some("2"));
    assert!(result.recording_error.is_none());
    assert!(attempt.take_returned_credit().is_some());
    drop(attempt);
    (f, sink, policy, intent, source)
}

#[test]
#[ignore = "requires explicitly pinned compiled policy and export-only executable"]
fn actual_compiled_successor_bootstrap_and_maximum_encodings() {
    let _serial = process_guard();
    let path = std::env::var("SIGIL_EXPORT_SUCCESSOR_FIXTURE").expect("explicit compiled fixture");
    let fixture: serde_json::Value = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let config = serde_json::from_value(fixture["policy"].clone()).unwrap();
    let maximum = fixture["payload_bytes"].as_u64().unwrap() as usize;
    let guarded = fixture["guarded"].as_bool().unwrap_or(false);
    let anchored = fixture["anchored"].as_bool().unwrap_or(false);
    let (f, sink, policy, intent, source) =
        executed_with_profile(Some(config), maximum, guarded, anchored);
    let root = f.directory.path().canonicalize().unwrap();
    let mut bootstrap = serde_json::json!({
        "version":if guarded {2}else{1},"state_root":root.join("store"),"limits":Limits::default(),
        "allocation":{"version":1,"pools":[{"id":"tenant","namespaces":[
            "intent","claim","delivery","funds","audit.heads","audit.entries","api",
            "exports","exports.heads","exports.entries"],"records":64,"live_bytes":4_000_000}]},
        "reservation_slots":{"tenant":8},"storage_admission_sha256":"03".repeat(32),
        "expected_domain":f.store.execution_identity().unwrap().0,
        "intent_binding":intent,"policy":fixture["policy"],
        "source_reads":["intent","claim","delivery","api","audit.heads","audit.entries"],
        "dispatch_journal":"api",
        "terminal_audit":{"heads":"audit.heads","records":"audit.entries","chain":"a".repeat(64),
            "limits":{"payload_bytes":1024,"records":3,"bytes":1_000_000},"key_env":"TEST_TERMINAL_KEY"},
        "export_namespace":"exports",
        "export_audit":{"heads":"exports.heads","records":"exports.entries","chain":"b".repeat(64),
            "limits":{"payload_bytes":1024,"records":10,"bytes":1_000_000},"key_env":"TEST_EXPORT_KEY"},
        "sink_root":root.join("sink"),"sink_key":"delivery","sink_bytes":maximum,"timeout_ms":30000
    });
    if guarded {
        bootstrap["source_guard"] =
            serde_json::json!({"root":root.join("external"),"key":"intent","bytes":1024});
    }
    if anchored {
        bootstrap["version"] = serde_json::json!(if guarded { 4 } else { 3 });
        bootstrap["restore_authority"] = serde_json::json!(root.join("authority"));
    }
    let path = root.join("successor.json");
    std::fs::write(&path, serde_json::to_vec(&bootstrap).unwrap()).unwrap();
    let run = |file: &Path| {
        std::process::Command::new(fixture["binary"].as_str().unwrap())
            .arg(file)
            .env_clear()
            .env("LANG", "C")
            .env(
                "TEST_TERMINAL_KEY",
                "native-effect-audit-test-key-0123456789",
            )
            .env(
                "TEST_EXPORT_KEY",
                "native-export-test-key-never-a-pilot-0123456789",
            )
            .output()
            .unwrap()
    };
    // The live original store/worker must still exclude the actual CLI.
    let busy = run(&path);
    assert!(!busy.status.success());
    assert!(!root.join("sink/delivery").exists());
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    drop(worker);
    drop(policy);
    drop(sink);
    drop(source);
    let result = run(&path);
    assert!(
        result.status.success(),
        "{} {}",
        String::from_utf8_lossy(&result.stdout),
        String::from_utf8_lossy(&result.stderr)
    );
    let output: serde_json::Value = serde_json::from_slice(&result.stdout).unwrap();
    assert_eq!(
        output["contract"],
        format!("sigil-export-successor/v{}", bootstrap["version"])
    );
    assert_eq!(output["consumer_acknowledged"], false);
    assert_eq!(output["replayed"], false);
    assert_eq!(output["payload_bytes"], maximum);
    assert_eq!(
        std::fs::read(root.join("sink/delivery")).unwrap(),
        vec![b'a'; maximum]
    );
    let mut store = reopen_profile(directory.path(), anchored);
    let ledger = ledger(&store);
    let raw = ledger
        .read_record(&store, &format!("admit:{intent}"), 12288)
        .unwrap()
        .unwrap();
    let admission: Admission = serde_json::from_str(&raw).unwrap();
    assert_eq!(admission.reservation_generation.is_some(), anchored);
    assert_eq!(admission.execution_generation.is_some(), anchored);
    let prepared = ledger
        .prepared(
            &mut store,
            &admission,
            &raw,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap()
        .unwrap();
    assert_eq!(prepared.2.len(), maximum);
    assert!(
        prepared.1.len() as u64 + ledger.log.encoded_entry_ceiling() < admission.preparation_bytes
    );
    let ack = ledger
        .read_record(&store, &format!("ack:{intent}"), 8192)
        .unwrap()
        .unwrap();
    assert!(
        ack.len() as u64 + ledger.log.encoded_entry_ceiling() < admission.acknowledgement_bytes
    );
    let held = store
        .reservation_snapshot(&ledger.scope, "exports", &format!("funds:{intent}"))
        .unwrap();
    assert_eq!(held.generation, admission.reservation_generation);
    assert_eq!(
        held.credits,
        Credits {
            records: 0,
            live_bytes: 0
        }
    );
    drop(store);
    drop(ledger);
    // Only an explicit destructive test injection removes this acknowledged file.
    std::fs::remove_file(root.join("sink/delivery")).unwrap();
    if guarded {
        std::fs::remove_file(root.join("external/intent")).unwrap();
    }
    let replay = run(&path);
    assert!(replay.status.success());
    let replay: serde_json::Value = serde_json::from_slice(&replay.stdout).unwrap();
    assert_eq!(replay["replayed"], true);
    assert_eq!(replay["payload_sha256"], output["payload_sha256"]);
    assert!(!root.join("sink/delivery").exists());
    if anchored {
        for variant in ["missing", "null", "relative", "old_profile"] {
            let mut invalid = bootstrap.clone();
            match variant {
                "missing" => {
                    invalid.as_object_mut().unwrap().remove("restore_authority");
                }
                "null" => invalid["restore_authority"] = serde_json::Value::Null,
                "relative" => invalid["restore_authority"] = serde_json::json!("authority"),
                _ => invalid["version"] = serde_json::json!(if guarded { 2 } else { 1 }),
            }
            let denied = root.join(format!("invalid-{variant}.json"));
            std::fs::write(&denied, serde_json::to_vec(&invalid).unwrap()).unwrap();
            let result = run(&denied);
            assert!(!result.status.success());
            let result: serde_json::Value = serde_json::from_slice(&result.stdout).unwrap();
            assert_eq!(result["code"], "config");
        }
    }
    // A request cannot add a worker to this strict one-shot bootstrap.
    let mut wrong = bootstrap;
    wrong["effect"] = serde_json::json!({"net":["127.0.0.1"]});
    std::fs::write(&path, serde_json::to_vec(&wrong).unwrap()).unwrap();
    assert!(!run(&path).status.success());
}

#[test]
fn anchored_export_requires_both_retained_generations_and_exact_successor_capacity() {
    let _serial = process_guard();
    let (f, mut sink, mut policy, intent, _) = executed_with_profile(None, 512, false, true);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    drop(worker);
    let mut store = reopen_profile(directory.path(), true);
    let ledger = ledger(&store);
    let scope = owner(&store);
    let (a, raw) = ledger
        .admission(
            &mut store,
            &intent,
            &sink,
            &policy,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap();
    assert_eq!(a.format, "sigil-native-export-admission/v3");
    let held = ledger.held(&store, &a, &raw, false).unwrap();
    assert_eq!(held.generation(), a.reservation_generation.as_ref());
    let terminal = terminal(&mut store, &intent);
    terminal.export_facts(&store, &scope, &a).unwrap();
    for field in ["reservation_generation", "execution_generation"] {
        let mut changed: Admission = serde_json::from_str(&raw).unwrap();
        if field == "reservation_generation" {
            changed.reservation_generation.as_mut().unwrap().generation += 1;
            assert!(ledger.held(&store, &changed, &raw, false).is_err());
        } else {
            changed.execution_generation.as_mut().unwrap().generation += 1;
            assert!(terminal.export_facts(&store, &scope, &changed).is_err());
        }
    }
    assert!(!directory.path().join("sink/delivery").exists());
    let ack = ledger
        .export_terminal(
            &mut store,
            &scope,
            &intent,
            &terminal,
            &mut sink,
            &mut policy,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap();
    assert!(!ack.replayed);
    let closed = store
        .reservation_snapshot(&ledger.scope, "exports", &format!("funds:{intent}"))
        .unwrap();
    assert_eq!(
        closed.credits,
        Credits {
            records: 0,
            live_bytes: 0
        }
    );
    assert_eq!(closed.generation, a.reservation_generation);
    assert!(
        ledger
            .replay_ack(
                &mut store,
                &intent,
                &sink,
                &policy,
                Instant::now() + Duration::from_secs(5)
            )
            .unwrap()
            .unwrap()
            .replayed
    );
    // Reuse the same coordinate, revision and binding after actual fresh-owner
    // retirement. Historical export capacity must not adopt the new occupant.
    let key = format!("funds:{intent}");
    let retirement = sigil_durable_store::store::reservation::slots::Retirement {
        namespace: "exports".into(),
        key: key.clone(),
        revision: closed.revision,
        binding: closed.binding,
        generation: closed.generation.clone().unwrap(),
    };
    store
        .commit_retiring_reservation(
            &ledger.scope,
            &Batch {
                checks: vec![Check {
                    namespace: "exports".into(),
                    key: format!("ack:{intent}"),
                    revision: 1,
                }],
                writes: vec![Mutation {
                    namespace: "exports".into(),
                    key: format!("retired:{intent}"),
                    revision: 0,
                    value: Some("retained historical export".into()),
                }],
            },
            &retirement,
        )
        .unwrap();
    let binding = super::completion::hash(&[b"sigil-export-reservation/v1", raw.as_bytes()]);
    let new = store
        .commit_reserving(
            &ledger.scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "exports".into(),
                    key: format!("reallocated:{intent}"),
                    revision: 0,
                    value: Some("distinct new allocation".into()),
                }],
            },
            &sigil_durable_store::store::reservation::Request {
                namespace: "exports".into(),
                key,
                binding,
                credits: Credits {
                    records: a.preparation_records + a.acknowledgement_records,
                    live_bytes: a.preparation_bytes + a.acknowledgement_bytes,
                },
            },
        )
        .unwrap()
        .held
        .unwrap();
    assert_ne!(new.generation(), a.reservation_generation.as_ref());
    assert!(ledger.held(&store, &a, &raw, false).is_err());
    assert!(
        ledger
            .replay_ack(
                &mut store,
                &intent,
                &sink,
                &policy,
                Instant::now() + Duration::from_secs(5)
            )
            .unwrap()
            .unwrap()
            .replayed
    );
}

#[test]
fn only_fresh_export_successor_prepares_then_publishes_and_acknowledges() {
    let _serial = process_guard();
    let (mut f, mut sink, mut policy, intent) = executed();
    let term = terminal(&mut f.store, &intent);
    let scope = owner(&f.store);
    assert!(
        ledger(&f.store)
            .export_terminal(
                &mut f.store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5)
            )
            .is_err()
    );
    assert!(!f.directory.path().join("sink/delivery").exists());
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    drop(worker);
    let mut store = reopen(directory.path());
    let scope = owner(&store);
    let source =
        ["intent", "claim", "delivery"].map(|n| store.get(&scope, n, "operation:1").unwrap());
    let execution = store
        .reservation_snapshot(&scope, "funds", "operation:1")
        .unwrap();
    let term = terminal(&mut store, &intent);
    let ledger = ledger(&store);
    let ack = ledger
        .export_terminal(
            &mut store,
            &scope,
            &intent,
            &term,
            &mut sink,
            &mut policy,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap();
    assert!(!ack.replayed);
    assert_eq!(ack.payload_sha256, digest(b"hello"));
    assert_eq!(
        std::fs::read(directory.path().join("sink/delivery")).unwrap(),
        b"hello"
    );
    for (i, n) in ["intent", "claim", "delivery"].iter().enumerate() {
        assert_eq!(store.get(&scope, n, "operation:1").unwrap(), source[i]);
    }
    let after = store
        .reservation_snapshot(&scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(after.revision, execution.revision);
    assert_eq!(after.credits, execution.credits);
    let returned = store
        .reservation_snapshot(&ledger.scope, "exports", &format!("funds:{intent}"))
        .unwrap();
    assert_eq!(
        returned.credits,
        Credits {
            records: 0,
            live_bytes: 0
        }
    );
    let replay = ledger
        .replay_ack(
            &mut store,
            &intent,
            &sink,
            &policy,
            Instant::now() + Duration::from_secs(5),
        )
        .unwrap()
        .unwrap();
    assert!(replay.replayed);
    assert_eq!(replay.payload_sha256, ack.payload_sha256);
}

#[test]
fn interrupted_export_reuses_prepared_bytes_and_replays_ack_without_recreating_missing_file() {
    let _serial = process_guard();
    for stop in ["prepared", "published", "acknowledged"] {
        let (f, mut sink, mut policy, intent) = executed();
        let Fixture {
            directory,
            store,
            worker,
            ..
        } = f;
        drop(store);
        drop(worker);
        let mut store = reopen(directory.path());
        let scope = owner(&store);
        let term = terminal(&mut store, &intent);
        let l = ledger(&store);
        assert_eq!(
            l.export_inner(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
                |at| if at == stop { Err("cut") } else { Ok(()) }
            )
            .err(),
            Some("cut")
        );
        let key = format!("prepare:{intent}");
        let prepared = l.read_record(&store, &key, 10_000).unwrap().unwrap();
        let calls = std::fs::read(directory.path().join("projections")).unwrap();
        if stop == "acknowledged" {
            // Fault injection only: a local receipt does not grant deletion or
            // prove consumer acknowledgment. Replay must not recreate bytes.
            std::fs::remove_file(directory.path().join("sink/delivery")).unwrap();
        }
        drop(l);
        drop(store);
        let mut store = reopen(directory.path());
        let scope = owner(&store);
        let term = terminal(&mut store, &intent);
        let l = ledger(&store);
        let ack = l
            .export_terminal(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
            )
            .unwrap();
        assert_eq!(ack.replayed, stop == "acknowledged");
        assert_eq!(
            l.read_record(&store, &key, 10_000).unwrap().unwrap(),
            prepared
        );
        assert_eq!(
            std::fs::read(directory.path().join("projections")).unwrap(),
            calls
        );
        assert_eq!(
            directory.path().join("sink/delivery").exists(),
            stop != "acknowledged"
        );
    }
}

#[test]
fn changed_source_or_sink_cannot_turn_preparation_into_publication() {
    let _serial = process_guard();
    for changed in ["source", "sink", "policy", "scope"] {
        let (f, mut sink, mut policy, intent) = executed();
        let Fixture {
            directory,
            store,
            worker,
            ..
        } = f;
        drop(store);
        drop(worker);
        let mut store = reopen(directory.path());
        let scope = owner(&store);
        let term = terminal(&mut store, &intent);
        let l = ledger(&store);
        assert_eq!(
            l.export_inner(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
                |at| if at == "prepared" { Err("cut") } else { Ok(()) }
            )
            .err(),
            Some("cut")
        );
        assert!(
            l.read_record(&store, &format!("prepare:{intent}"), 10_000)
                .unwrap()
                .is_some()
        );
        let before = store
            .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
            .unwrap();
        let limited = store
            .scope(BTreeMap::from([("intent".into(), Access::Read)]))
            .unwrap();
        match changed {
            "source" => {
                store
                    .commit(
                        &scope,
                        &Batch {
                            checks: vec![],
                            writes: vec![Mutation {
                                namespace: "intent".into(),
                                key: "operation:1".into(),
                                revision: 1,
                                value: Some("changed".into()),
                            }],
                        },
                    )
                    .unwrap();
            }
            "sink" => {
                sink = FixedSink::admit(
                    &directory.path().join("sink").canonicalize().unwrap(),
                    "different",
                    512,
                )
                .unwrap();
            }
            "policy" => {
                std::fs::write(&policy.config.source, "changed policy").unwrap();
            }
            _ => {}
        }
        assert!(
            l.export_terminal(
                &mut store,
                if changed == "scope" { &limited } else { &scope },
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5)
            )
            .is_err(),
            "{changed}"
        );
        assert!(
            !directory.path().join("sink/delivery").exists(),
            "{changed}"
        );
        assert!(
            !directory.path().join("sink/different").exists(),
            "{changed}"
        );
        let after = store
            .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
            .unwrap();
        assert_eq!(before.revision, after.revision);
        assert_eq!(before.credits, after.credits);
    }
}

#[test]
#[ignore = "child of explicit hard-death boundary test"]
fn export_crash_child() {
    let output = std::env::var("SIGIL_EXPORT_CRASH_OUTPUT").expect("child output");
    let cut = std::env::var("SIGIL_EXPORT_CRASH_CUT").expect("child boundary");
    let (f, mut sink, mut policy, intent) = executed();
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    let root = directory.keep().canonicalize().unwrap();
    std::fs::write(
        output,
        serde_json::to_vec(&serde_json::json!({
            "root":root,"intent":intent,"policy":policy.config
        }))
        .unwrap(),
    )
    .unwrap();
    drop(store);
    drop(worker);
    let mut store = reopen(&root);
    let scope = owner(&store);
    let term = terminal(&mut store, &intent);
    let ledger = ledger(&store);
    let _ = ledger.export_inner(
        &mut store,
        &scope,
        &intent,
        &term,
        &mut sink,
        &mut policy,
        Instant::now() + Duration::from_secs(10),
        |at| {
            if at == cut {
                // Test-only real process death: no destructors, receipt handling
                // or store close runs after this actual native boundary.
                unsafe {
                    libc::kill(libc::getpid(), libc::SIGKILL);
                }
                std::process::abort();
            }
            Ok(())
        },
    );
    panic!("hard-death boundary was not reached");
}

#[test]
fn actual_process_death_at_export_boundaries_has_only_durable_replay_outcomes() {
    use std::os::unix::process::ExitStatusExt;
    let _serial = process_guard();
    for cut in ["before_prepared", "prepared", "published", "acknowledged"] {
        let metadata = tempfile::NamedTempFile::new().unwrap();
        let result = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "claimed::export_successor::tests::export_crash_child",
                "--ignored",
                "--nocapture",
            ])
            .env("SIGIL_EXPORT_CRASH_OUTPUT", metadata.path())
            .env("SIGIL_EXPORT_CRASH_CUT", cut)
            .output()
            .unwrap();
        assert_eq!(
            result.status.signal(),
            Some(libc::SIGKILL),
            "{cut}: {} {}",
            String::from_utf8_lossy(&result.stdout),
            String::from_utf8_lossy(&result.stderr)
        );
        let saved: serde_json::Value =
            serde_json::from_slice(&std::fs::read(metadata.path()).unwrap()).unwrap();
        let root = Path::new(saved["root"].as_str().unwrap());
        let intent = saved["intent"].as_str().unwrap();
        let mut store = reopen(root);
        let scope = owner(&store);
        let term = terminal(&mut store, intent);
        let l = ledger(&store);
        let key = format!("prepare:{intent}");
        let before = l.read_record(&store, &key, 10_000).unwrap();
        assert_eq!(before.is_some(), cut != "before_prepared");
        assert_eq!(
            root.join("sink/delivery").exists(),
            matches!(cut, "published" | "acknowledged")
        );
        let calls = std::fs::read(root.join("projections")).unwrap();
        let mut policy =
            Policy::new(serde_json::from_value(saved["policy"].clone()).unwrap()).unwrap();
        let mut sink = FixedSink::admit(&root.join("sink"), "delivery", 512).unwrap();
        let ack = l
            .export_terminal(
                &mut store,
                &scope,
                intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
            )
            .unwrap();
        assert_eq!(ack.replayed, cut == "acknowledged");
        assert_eq!(std::fs::read(root.join("sink/delivery")).unwrap(), b"hello");
        if let Some(before) = before {
            assert_eq!(
                l.read_record(&store, &key, 10_000).unwrap().unwrap(),
                before
            );
            assert_eq!(std::fs::read(root.join("projections")).unwrap(), calls);
        }
        let scope = owner(&store);
        assert!(
            store
                .reservation_snapshot(&scope, "funds", "operation:1")
                .unwrap()
                .assignment
                .is_empty()
        );
        assert_eq!(
            store
                .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
                .unwrap()
                .credits,
            Credits {
                records: 0,
                live_bytes: 0
            }
        );
        println!("retained hard-death {cut} fixture: {}", root.display());
    }
}

#[test]
fn checksummed_export_tampering_and_occupied_destination_cannot_create_acknowledgment() {
    use sha2::{Digest, Sha256};
    let _serial = process_guard();
    for case in ["prepared", "ack", "occupied"] {
        let (f, mut sink, mut policy, intent) = executed();
        let Fixture {
            directory,
            store,
            worker,
            ..
        } = f;
        drop(store);
        drop(worker);
        let mut store = reopen(directory.path());
        let scope = owner(&store);
        let term = terminal(&mut store, &intent);
        let l = ledger(&store);
        if case == "ack" {
            l.export_terminal(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
            )
            .unwrap();
            std::fs::remove_file(directory.path().join("sink/delivery")).unwrap();
        } else {
            assert_eq!(
                l.export_inner(
                    &mut store,
                    &scope,
                    &intent,
                    &term,
                    &mut sink,
                    &mut policy,
                    Instant::now() + Duration::from_secs(5),
                    |at| if at == "prepared" { Err("cut") } else { Ok(()) }
                )
                .err(),
                Some("cut")
            );
        }
        let before = store
            .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
            .unwrap();
        if case == "occupied" {
            let path = directory.path().join("sink/delivery");
            std::fs::write(&path, b"occupied").unwrap();
            std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).unwrap();
        } else {
            let key = format!(
                "{}:{intent}",
                if case == "prepared" { "prepare" } else { "ack" }
            );
            let raw = l.read_record(&store, &key, 10_000).unwrap().unwrap();
            let forged = if case == "prepared" {
                let mut p: PreparedExport = serde_json::from_str(&raw).unwrap();
                p.payload_hex = "6f74686572".into();
                p.payload_sha256 = digest(b"other");
                serde_json::to_string(&p).unwrap()
            } else {
                let mut ack: Ack = serde_json::from_str(&raw).unwrap();
                ack.publication.existing = !ack.publication.existing;
                serde_json::to_string(&ack).unwrap()
            };
            let mut h = Sha256::new();
            h.update(b"sigil-store/record/v1\0");
            for s in ["exports", &key] {
                h.update((s.len() as u64).to_be_bytes());
                h.update(s.as_bytes());
            }
            h.update(1u64.to_be_bytes());
            h.update([1]);
            h.update(forged.as_bytes());
            let db =
                rusqlite::Connection::open(directory.path().join("store/records.sqlite")).unwrap();
            assert_eq!(
                db.execute(
                    "UPDATE records SET value=?1,digest=?2 WHERE namespace='exports' AND key=?3",
                    rusqlite::params![forged.as_bytes(), h.finalize().to_vec(), key]
                )
                .unwrap(),
                1
            );
        }
        let error = l
            .export_terminal(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
            )
            .err();
        assert_eq!(
            error,
            Some(if case == "occupied" {
                "export_publication_unconfirmed"
            } else {
                "export_authentication"
            }),
            "{case}"
        );
        if case == "occupied" {
            assert_eq!(
                std::fs::read(directory.path().join("sink/delivery")).unwrap(),
                b"occupied"
            );
        } else {
            assert!(!directory.path().join("sink/delivery").exists());
        }
        let after = store
            .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
            .unwrap();
        assert_eq!(after.revision, before.revision);
        assert_eq!(after.credits, before.credits);
    }
}

#[test]
fn guarded_export_requires_original_external_file_until_ack_and_never_infers_no_publication() {
    let _serial = process_guard();
    for case in [
        "success",
        "unbound_api",
        "changed",
        "replaced",
        "prepared",
        "published",
        "bounds",
    ] {
        let (f, mut sink, mut policy, intent, source) = executed_with_source(None, 512, true);
        let source = source.unwrap();
        let Fixture {
            directory,
            store,
            worker,
            ..
        } = f;
        drop(store);
        drop(worker);
        let mut store = reopen(directory.path());
        let scope = owner(&store);
        let term = terminal(&mut store, &intent);
        let l = ledger(&store);
        let path = directory.path().join("external/intent");
        if case == "changed" {
            std::fs::write(&path, b"other publication").unwrap();
        }
        if case == "replaced" {
            let replacement = directory.path().join("external/replacement");
            std::fs::write(&replacement, b"external original").unwrap();
            std::fs::set_permissions(&replacement, std::fs::Permissions::from_mode(0o600)).unwrap();
            std::fs::rename(replacement, &path).unwrap();
        }
        if case == "bounds" {
            let mut config = policy.config.clone();
            config.max_fuel += 1;
            policy = Policy::new(config).unwrap();
        }
        let result = if case == "unbound_api" {
            l.export_terminal(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
            )
        } else {
            l.export_with_source(
                &mut store,
                &scope,
                &intent,
                &term,
                &mut sink,
                &mut policy,
                Instant::now() + Duration::from_secs(5),
                Some(&source),
                |at| {
                    if at == case {
                        std::fs::write(&path, b"advanced source").unwrap();
                    }
                    Ok(())
                },
            )
        };
        if case == "success" {
            assert!(!result.unwrap().replayed);
            // Historical acknowledgment does not require current source bytes,
            // and cannot recreate a target after consumer progress/removal.
            std::fs::remove_file(&path).unwrap();
            std::fs::remove_file(directory.path().join("sink/delivery")).unwrap();
            assert!(
                l.replay_ack(
                    &mut store,
                    &intent,
                    &sink,
                    &policy,
                    Instant::now() + Duration::from_secs(5)
                )
                .unwrap()
                .unwrap()
                .replayed
            );
            assert!(!directory.path().join("sink/delivery").exists());
        } else {
            assert_eq!(
                result.err(),
                Some(if case == "bounds" {
                    "export_admission"
                } else {
                    "export_external_source"
                }),
                "{case}"
            );
            assert_eq!(
                directory.path().join("sink/delivery").exists(),
                case == "published",
                "{case}"
            );
            assert!(
                l.read_record(&store, &format!("ack:{intent}"), 8192)
                    .unwrap()
                    .is_none()
            );
            let credits = store
                .reservation_snapshot(&l.scope, "exports", &format!("funds:{intent}"))
                .unwrap()
                .credits;
            assert!(credits.records >= 3 && credits.live_bytes >= 25000);
            if case == "published" {
                // Restoring bytes in place is still a changed file version.
                std::fs::write(&path, b"external original").unwrap();
                let restored = FixedSource::admit(
                    &directory.path().join("external").canonicalize().unwrap(),
                    "intent",
                    1024,
                )
                .unwrap();
                assert!(
                    l.export_terminal_guarded(
                        &mut store,
                        &scope,
                        &intent,
                        &term,
                        &mut sink,
                        &mut policy,
                        &restored,
                        Instant::now() + Duration::from_secs(5)
                    )
                    .is_err()
                );
                assert_eq!(
                    std::fs::read(directory.path().join("sink/delivery")).unwrap(),
                    b"hello"
                );
            }
        }
    }
}
