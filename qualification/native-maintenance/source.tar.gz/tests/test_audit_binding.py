"""Signed records must remain bound to the conversation being read or restored."""

import hashlib
import io
import json
import tarfile

import pytest

from agent import AuditLog, entry_hash, sign_entry, verify_audit_dir, verify_chain
from product_service import ProductDataManager, ProductScheduleStore, SessionOperationLocks
from state_tool import StateToolError, create_backup, restore_backup
from test_product_service import DATA_TOKEN, _data_agent, _headers, _seed_session, _service
from test_state_tool import AUDIT_KEY, _state


def record(log, session):
    log.append_or_raise(session, "tool", "source", "input", "output", None, None, 1)


@pytest.mark.parametrize("key", [None, b"binding-test-signing-key"])
def test_transplanted_chain_is_refused_by_reader_directory_verifier_and_writer(tmp_path, key):
    log = AuditLog(tmp_path / "audit", key=key)
    record(log, "a")
    record(log, "b")
    assert verify_audit_dir(log.dir, key=key)["ok"]
    moved = log._path("a").read_bytes()
    assert verify_chain(log.read("a"), key=key)[0]
    log._path("b").write_bytes(moved)
    with pytest.raises(ValueError, match="session"):
        log.read("b")
    report = verify_audit_dir(log.dir, key=key)
    assert not report["ok"] and report["problems"][0][0] == log._path("b").name
    with pytest.raises(ValueError, match="session"):
        record(log, "b")
    assert log._path("b").read_bytes() == moved


def test_standalone_verifier_binds_an_explicit_expected_session(tmp_path):
    log = AuditLog(tmp_path / "audit", key=AUDIT_KEY)
    record(log, "a")
    records = log.read("a")
    assert verify_chain(records, key=AUDIT_KEY, expected_session_sha256=log._path("a").stem)[0]
    assert not verify_chain(records, key=AUDIT_KEY, expected_session_sha256=log._path("b").stem)[0]
    assert not verify_chain([], key=AUDIT_KEY, expected_session_sha256="invalid")[0]


def test_individually_signed_records_cannot_change_session_within_a_chain(tmp_path):
    log = AuditLog(tmp_path / "audit", key=AUDIT_KEY)
    record(log, "a")
    record(log, "a")
    records = log.read("a")
    # A writer-fixture inconsistency: both signatures and the link are valid.
    # This is not a claim that a storage attacker can generate a new signature.
    records[1]["session_sha256"] = log._path("b").stem
    records[1]["prev_hash"] = entry_hash(records[0])
    records[1]["sig"] = sign_entry({k: v for k, v in records[1].items() if k != "sig"}, AUDIT_KEY)
    assert not verify_chain(records, key=AUDIT_KEY)[0]


@pytest.mark.parametrize("session", [None, "short", "A" * 64, 7])
def test_standalone_verifier_rejects_malformed_session_identity(tmp_path, session):
    log = AuditLog(tmp_path / "audit")
    record(log, "a")
    records = log.read("a")
    records[0]["session_sha256"] = session
    assert not verify_chain(records)[0]
    assert not verify_chain([None])[0]


@pytest.mark.parametrize("signature", [7, "é" * 64])
def test_invalid_signature_encoding_reports_failure_without_crashing_verification(tmp_path, signature):
    log = AuditLog(tmp_path / "audit", key=AUDIT_KEY)
    record(log, "a")
    item = log.read("a")[0]
    item["sig"] = signature
    log._path("a").write_text(json.dumps(item) + "\n")
    assert not verify_audit_dir(log.dir, key=AUDIT_KEY)["ok"]
    with pytest.raises(ValueError, match="signature"):
        log.read("a")


@pytest.mark.parametrize("rewrite_identity", [False, True])
def test_export_refuses_another_tenants_valid_signed_audit(tmp_path, rewrite_identity):
    agent = _data_agent(tmp_path)
    a = _seed_session(agent, "tenant-a", "project", "a-private")
    b = _seed_session(agent, "tenant-b", "project", "b-private")
    schedules = ProductScheduleStore(tmp_path / "schedules.json")
    manager = ProductDataManager(agent, schedules, SessionOperationLocks())
    service = _service(agent, schedule_store=schedules, data_manager=manager)
    path = "/v1/sessions/project/export"
    assert service.dispatch("GET", path, _headers(DATA_TOKEN))[0] == 200
    moved = agent.audit._path(b).read_bytes()
    if rewrite_identity:
        # Changing the signed identity to match the filename must not evade
        # verification at export while the background audit check is pending.
        item = json.loads(moved)
        item["session_sha256"] = agent.audit._path(a).stem
        moved = (json.dumps(item) + "\n").encode()
    agent.audit._path(a).write_bytes(moved)
    status, _, body = service.dispatch("GET", path, _headers(DATA_TOKEN))
    assert status == 500 and body["error"]["code"] == "internal_error"
    assert "audit" not in body and "b-private" not in json.dumps(body)


@pytest.mark.parametrize("operation", ["backup", "restore"])
def test_backup_and_restore_refuse_valid_chain_transplant_even_with_matching_checksums(tmp_path, operation):
    state = _state(tmp_path)
    source = AuditLog(tmp_path / "foreign-audit", key=AUDIT_KEY)
    record(source, "another-tenant-conversation")
    moved = source._path("another-tenant-conversation").read_bytes()
    assert verify_audit_dir(source.dir, key=AUDIT_KEY)["ok"]
    audit_path = next((state / "audit").glob("*.jsonl"))
    original = tmp_path / "original.tar.gz"
    if operation == "backup":
        audit_path.write_bytes(moved)
        with pytest.raises(StateToolError, match="audit verification failed"):
            create_backup(state, original, audit_key=AUDIT_KEY)
        assert not original.exists()
        return
    create_backup(state, original, audit_key=AUDIT_KEY)
    relative = audit_path.relative_to(state).as_posix()
    with tarfile.open(original, "r:gz") as archive:
        data = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
    data["data/" + relative] = moved
    manifest = json.loads(data["manifest.json"])
    for item in manifest["files"]:
        if item["path"] == relative:
            item.update(size=len(moved), sha256=hashlib.sha256(moved).hexdigest())
    data["manifest.json"] = json.dumps(manifest).encode()
    tampered = tmp_path / "transplanted.tar.gz"
    with tarfile.open(tampered, "w:gz") as archive:
        for name, body in data.items():
            member = tarfile.TarInfo(name)
            member.size = len(body)
            archive.addfile(member, io.BytesIO(body))
    target = tmp_path / "restored"
    with pytest.raises(StateToolError, match="audit verification failed"):
        restore_backup(tampered, target, audit_key=AUDIT_KEY)
    assert not target.exists() and not list(tmp_path.glob(".restored.restore-*"))
