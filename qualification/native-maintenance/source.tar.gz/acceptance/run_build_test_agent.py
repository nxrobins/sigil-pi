"""Four real-model build/test repair samples; independent per-task oracles."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tests"), str(ROOT)]
from api_support import TOKEN_A
from test_workspace_agent import WorkspaceApi
from acceptance.build_test_fixtures import FILES, TASKS, populate
from acceptance.run_local import local_get
from acceptance.run_repository_agent import capture, save, wait
from acceptance.repository_assertions import files
from scripts.workspace_deployment import fields
from acceptance.capacity_evidence import inspect_capacity, assert_returned


def production_identity(profile_path=None, host=None):
    paths = set()
    for directory, pattern in (
        ("app", "*.sigil"),
        ("tools", "*.sigil"),
        ("scripts", "*.py"),
        ("web", "*"),
    ):
        paths.update(p for p in (ROOT / directory).rglob(pattern) if p.is_file())
    for crate in ("worker", "service", "evaluator", "store"):
        paths.update((ROOT / f"native/{crate}/src").rglob("*.rs"))
        paths.update(
            ROOT / f"native/{crate}/{name}"
            for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")
        )
    paths.update(
        ROOT / p
        for p in (
            "native/command-image/init.c",
            "native/command-image/Dockerfile",
            "config/build-test-development.json",
            "acceptance/run_build_test_agent.py",
            "acceptance/build_test_fixtures.py",
            "acceptance/capacity_evidence.py",
            "acceptance/browser_repository.mjs",
            "tests/test_workspace_agent.py",
            "native/service/target/release/sigil-application-host",
            "native/evaluator/target/release/sigil-fixed-evaluator",
        )
    )
    if profile_path:
        paths.add(profile_path)
    result = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(paths)
    }
    if host:
        result["executed_host:" + str(host)] = hashlib.sha256(
            host.read_bytes()
        ).hexdigest()
    return result


def snapshot_digest(workspace):
    """Independent reconstruction of the snapshot identity, from retained files."""
    h = hashlib.sha256()

    def visit(directory, prefix=""):
        for p in sorted(directory.iterdir()):
            if p.name.startswith("."):
                continue
            name = (prefix + p.name).encode()
            h.update(len(name).to_bytes(8, "big"))
            h.update(name)
            if p.is_dir():
                h.update(b"d")
                visit(p, prefix + p.name + "/")
            else:
                value = p.read_bytes()
                h.update(b"f")
                h.update(len(value).to_bytes(8, "big"))
                h.update(value)

    visit(workspace)
    return h.hexdigest()


def verify(deployment, workspace, task, operation, before, before_digest):
    after = files(workspace)
    changed = sorted(
        p for p in before.keys() | after.keys() if before.get(p) != after.get(p)
    )
    assert changed == [task["target"]], ("changed paths", changed)
    assert after == FILES, "source repair or test integrity mismatch"
    with sqlite3.connect(
        f"file:{deployment / 'records/records.sqlite'}?mode=ro", uri=True
    ) as db:
        intents = [
            (k, fields(bytes(v).decode(), "SI1\n", 5))
            for k, v in db.execute(
                "select key,value from records where namespace='workspace.intent'"
            )
            if k.startswith(operation + ":")
        ]
        deliveries = {
            k: fields(bytes(v).decode(), "DR1\n", 7)
            for k, v in db.execute(
                "select key,value from records where namespace='executor0.delivery'"
            )
        }
    observations = []
    for key, intent in sorted(intents, key=lambda x: int(x[1][1])):
        if intent[2] != "tool":
            continue
        assert deliveries[key][5] == "returned", (key, deliveries[key])
        status, output = fields(deliveries[key][6], "RF1\n", 2)
        item = {
            "sequence": int(intent[1]),
            "tool": intent[3],
            "input": json.loads(intent[4]),
            "status": status,
            "output": output,
        }
        if intent[3] in ("build_project", "test_project"):
            assert status == "ok"
            code, stdout, stderr, snapshot, image = fields(output, "CR1\n", 5)
            item["command"] = {
                "exit_code": int(code),
                "stdout": stdout,
                "stderr": stderr,
                "snapshot_sha256": snapshot,
                "image": image,
            }
        observations.append(item)
    edits = [
        x for x in observations if x["tool"] == "edit_file" and x["status"] == "ok"
    ]
    assert edits and all(x["input"]["path"] == task["target"] for x in edits)
    failures = [
        x
        for x in observations
        if x["tool"] == task["failed_tool"]
        and x["sequence"] < edits[0]["sequence"]
        and x["command"]["exit_code"] != 0
    ]
    assert failures, "initial real failure was not reproduced"
    assert failures[0]["command"]["snapshot_sha256"] == before_digest
    after_digest = snapshot_digest(workspace)
    for name in ("build_project", "test_project"):
        checks = [
            x
            for x in observations
            if x["tool"] == name and x["sequence"] > edits[-1]["sequence"]
        ]
        assert checks and checks[-1]["command"]["exit_code"] == 0, (
            "no successful post-edit check",
            name,
        )
        command = checks[-1]["command"]
        assert command["snapshot_sha256"] == after_digest
        assert (
            command["image"]
            == json.loads((deployment / "profile.json").read_text())["commands"][
                "image"
            ]
        )
        if name == "test_project":
            assert "PASS: 3 C temperature" in command["stdout"]
            assert "Ran 3 tests" in command["stderr"] and "\nOK\n" in command["stderr"]
    assert not (workspace / "build").exists()
    return {
        "passed": True,
        "changed_paths": changed,
        "before_snapshot": before_digest,
        "after_snapshot": after_digest,
        "observations": observations,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--interface", choices=["api", "browser"], required=True)
    parser.add_argument("--case", choices=["B01", "B02"])
    parser.add_argument(
        "--profile", type=Path, default=ROOT / "config/build-test-development.json"
    )
    parser.add_argument(
        "--host",
        type=Path,
        default=ROOT / "native/service/target/release/sigil-application-host",
    )
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    args.profile, args.host = args.profile.resolve(), args.host.resolve()
    frozen = production_identity(args.profile, args.host)
    save(root / "production-inputs.json", frozen)
    profile = json.loads(args.profile.read_text())
    funded = "completion_capacity" in profile
    # Synthetic acceptance credential, only supplied to the native audit owner.
    audit_key = b"capacity-test-key-never-for-a-pilot-0123456789"
    if funded:
        os.environ[profile["completion_capacity"]["audit_key_env"]] = audit_key.decode()
    installed = next(
        m for m in local_get("/api/tags")["models"] if m["name"] == profile["model"]
    )
    assert installed["digest"] == profile["model_digest"]
    summary = {
        "milestone": "completion-capacity/v1" if funded else "real-builds-and-tests/v1",
        "interface": args.interface,
        "profile": profile,
        "model": installed,
        "tasks": [],
        "passed": False,
    }
    save(root / "summary.json", summary)
    commands = profile["commands"]
    image = json.loads(
        subprocess.check_output(
            [
                commands["docker"],
                "--host",
                "unix://" + commands["socket"],
                "image",
                "inspect",
                commands["image"],
            ]
        )
    )
    assert len(image) == 1 and image[0]["Id"] == commands["image"]
    save(root / "image.json", image[0])
    os.environ["SIGIL_PI_LOCAL_PROVIDER_TOKEN"] = "local-only-placeholder"
    for task in TASKS:
        if args.case and args.case != task["id"]:
            continue
        area = root / task["id"]
        area.mkdir()
        workspace = area / "workspace"
        populate(workspace, task)
        before = files(workspace)
        before_digest = snapshot_digest(workspace)
        save(area / "before.json", before)
        report = {
            "task": task,
            "profile": profile,
            "model": installed,
            "interface": args.interface,
            "passed": False,
        }
        save(area / "report.json", report)
        with WorkspaceApi(
            area / "deployment",
            workspace,
            profile["endpoint"],
            profile=profile,
            binary=args.host,
        ) as api:
            print(json.dumps({"case": task["id"], "service": api.ready}), flush=True)
            start = time.monotonic()
            try:
                if args.interface == "api":
                    code, accepted = api.request(
                        body={
                            "session": task["session"],
                            "message": task["prompt"],
                            "submission_key": task["id"],
                        }
                    )
                    assert code == 202, accepted
                    operation = accepted["operation"]
                    report["result"] = wait(api, operation)
                    assert report["result"]["status"] == "done", report["result"]
                else:
                    browser_output = area / "browser"
                    browser_output.mkdir()
                    proc = subprocess.run(
                        ["node", str(ROOT / "acceptance/browser_repository.mjs")],
                        input=json.dumps(
                            {
                                "url": "http://" + api.ready["address"],
                                "token": TOKEN_A,
                                "tasks": [task],
                                "output": str(browser_output),
                            }
                        ),
                        text=True,
                        capture_output=True,
                        timeout=400,
                    )
                    (browser_output / "browser.log").write_text(
                        proc.stdout + "\n" + proc.stderr
                    )
                    assert proc.returncode == 0, proc.stderr
                    report["browser"] = json.loads(
                        (browser_output / "browser-report.json").read_text()
                    )
                    operation = report["browser"]["turns"][0]["operation"]
                    report["result"] = api.request(
                        "GET", "/v1/operations/" + operation
                    )[1]
                report["elapsed_s"] = time.monotonic() - start
                report["verification"] = verify(
                    api.root, workspace, task, operation, before, before_digest
                )
                if funded:
                    capacity = inspect_capacity(api.root, audit_key)
                    save(area / "capacity.json", capacity)
                    assert_returned(capacity)
                    report["capacity_verified"] = True
                report["passed"] = True
            finally:
                report["production_inputs_unchanged"] = (
                    production_identity(args.profile, args.host) == frozen
                )
                if not report["production_inputs_unchanged"]:
                    report["passed"] = False
                report["after"] = files(workspace)
                capture(area, api, report)
                print(
                    json.dumps(
                        {
                            "task": task["id"],
                            "passed": report["passed"],
                            "elapsed_s": report.get("elapsed_s"),
                            "result": report.get("result"),
                        }
                    ),
                    flush=True,
                )
            assert report["production_inputs_unchanged"], (
                "production inputs changed during acceptance"
            )
        summary["tasks"].append(
            {
                "task": task["id"],
                "passed": report["passed"],
                "report": str(area / "report.json"),
            }
        )
        save(root / "summary.json", summary)
    summary["passed"] = all(t["passed"] for t in summary["tasks"])
    save(root / "summary.json", summary)


if __name__ == "__main__":
    main()
