use super::*;
use crate::store::authenticated_log::AuthenticatedLog;
use std::os::unix::fs::PermissionsExt;

fn allocation() -> capacity::Allocation {
    capacity::Allocation {
        version: 1,
        pools: vec![
            capacity::Pool {
                id: "alpha".into(),
                namespaces: vec![
                    "a".into(),
                    "ah".into(),
                    "ar".into(),
                    "xh".into(),
                    "xr".into(),
                ],
                records: 500,
                live_bytes: 1_000_000,
            },
            capacity::Pool {
                id: "beta".into(),
                namespaces: vec!["b".into(), "bh".into(), "br".into()],
                records: 500,
                live_bytes: 1_000_000,
            },
        ],
    }
}
fn slots(a: u16, b: u16) -> BTreeMap<String, u16> {
    BTreeMap::from([("alpha".into(), a), ("beta".into(), b)])
}
fn open(root: &Path, mode: OpenMode, catalog: BTreeMap<String, u16>) -> Store {
    Store::open_audit_reserved_bound(
        root,
        mode,
        Limits::default(),
        allocation(),
        [3; 32],
        catalog,
    )
    .unwrap()
}
fn fresh() -> (tempfile::TempDir, Store, Scope) {
    let root = tempfile::tempdir().unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let store = open(root.path(), OpenMode::CreateNew, slots(8, 8));
    let scope = store
        .scope(
            allocation()
                .pools
                .into_iter()
                .flat_map(|p| p.namespaces)
                .map(|n| (n, Access::ReadWrite))
                .collect(),
        )
        .unwrap();
    (root, store, scope)
}
fn log(store: &Store, records: u64, bytes: u64) -> AuthenticatedLog {
    AuthenticatedLog::new(
        store,
        "ah",
        "ar",
        ChainLimits {
            payload_bytes: 1024,
            records,
            bytes,
        },
        &[0x64; 32],
    )
    .unwrap()
}
fn batch(ns: &str, key: &str, revision: u64, value: &str) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: ns.into(),
            key: key.into(),
            revision,
            value: Some(value.into()),
        }],
    }
}
fn request(ns: &str, key: &str) -> Request {
    Request {
        namespace: ns.into(),
        key: key.into(),
        binding: [8; 32],
        credits: Credits {
            records: 10,
            live_bytes: 50_000,
        },
    }
}
fn snapshot(
    store: &Store,
) -> (
    i64,
    Vec<Vec<rusqlite::types::Value>>,
    Vec<Vec<rusqlite::types::Value>>,
) {
    let get = |sql: &str, n: usize| {
        store
            .connection
            .prepare(sql)
            .unwrap()
            .query_map([], |r| {
                (0..n)
                    .map(|i| r.get(i))
                    .collect::<rusqlite::Result<Vec<_>>>()
            })
            .unwrap()
            .collect::<rusqlite::Result<Vec<_>>>()
            .unwrap()
    };
    (
        store
            .connection
            .query_row("SELECT revision FROM meta", [], |r| r.get(0))
            .unwrap(),
        get(
            "SELECT namespace,key,revision,value,digest FROM records ORDER BY namespace,key",
            5,
        ),
        get(
            "SELECT namespace,key,revision,binding,records,bytes,audits,digest FROM reservations ORDER BY namespace,key",
            8,
        ),
    )
}
fn held_entry(store: &Store, key: &str) -> Entry {
    read(&store.connection, "a", key, 4).unwrap().unwrap()
}

#[test]
fn independent_chain_reservation_protects_two_results_and_explicit_release_is_atomic() {
    let (_root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let allowance = log
        .prepare_allowance(&store, &scope, &chain, 0, 2, 20_000)
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "accepted"),
            &request("a", "hold"),
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        log.append(
            &mut store,
            &scope,
            &chain,
            0,
            "unrelated",
            &batch("a", "steal", 0, "x")
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let publication = log
        .append_spending(
            &mut store,
            &scope,
            &chain,
            0,
            "observed",
            &batch("a", "done", 0, "first"),
            &held,
            Credits {
                records: 3,
                live_bytes: 10_000,
            },
        )
        .unwrap();
    let checkpoint = publication.publication.checkpoint;
    let held = publication.held.unwrap();
    assert_eq!(
        held_entry(&store, "hold").audits[0].bytes,
        20_000 - checkpoint.bytes
    );
    assert_eq!(held_entry(&store, "hold").audits[0].records, 1);
    let before = snapshot(&store);
    assert!(matches!(
        log.append(
            &mut store,
            &scope,
            &chain,
            1,
            "unrelated",
            &batch("a", "steal", 0, "x")
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let publication = log
        .append_spending(
            &mut store,
            &scope,
            &chain,
            1,
            "settled",
            &batch("a", "done", 1, "second"),
            &held,
            Credits {
                records: 1,
                live_bytes: 10_000,
            },
        )
        .unwrap();
    let held = publication.held.unwrap();
    let left = held_entry(&store, "hold").audits[0].clone();
    assert_eq!(left.records, 0);
    assert!(left.bytes > 0);
    let released = store
        .commit_spending_audited(
            &scope,
            &batch("a", "done", 2, "terminal"),
            &held,
            held.credits(),
            &[Debit {
                heads: left.heads,
                records_namespace: left.records_namespace,
                chain: left.chain,
                records: 0,
                bytes: left.bytes,
            }],
        )
        .unwrap();
    assert!(released.held.is_none());
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 4, [8; 32]),
        Err(Error::Conflict)
    ));
    assert_eq!(
        log.verify(
            &mut store,
            &scope,
            &chain,
            None,
            std::time::Instant::now() + Duration::from_secs(2)
        )
        .unwrap()
        .count,
        2
    );
}

#[test]
fn encoded_byte_allowance_counts_escaping_and_one_byte_short_rolls_back_everything() {
    for under in [true, false] {
        let (_root, mut store, scope) = fresh();
        let log = log(&store, 4, 8000);
        let payload = "\0".repeat(1024);
        let control = log
            .append(
                &mut store,
                &scope,
                &"b".repeat(64),
                0,
                &payload,
                &batch("a", "control", 0, "x"),
            )
            .unwrap();
        let encoded = control.checkpoint.bytes;
        assert!(encoded > payload.len() as u64 * 6);
        let chain = "a".repeat(64);
        let allowance = log
            .prepare_allowance(&store, &scope, &chain, 0, 1, encoded - u64::from(under))
            .unwrap();
        let held = store
            .commit_reserving_audited(
                &scope,
                &batch("a", "intent", 0, "x"),
                &request("a", "hold"),
                &[allowance],
            )
            .unwrap()
            .held
            .unwrap();
        let before = snapshot(&store);
        let result = log.append_spending(
            &mut store,
            &scope,
            &chain,
            0,
            &payload,
            &batch("a", "done", 0, "x"),
            &held,
            Credits {
                records: 3,
                live_bytes: 20_000,
            },
        );
        if under {
            assert!(matches!(result, Err(Error::Limit)));
            assert_eq!(snapshot(&store), before);
        } else {
            let p = result.unwrap();
            assert_eq!(p.publication.checkpoint.bytes, encoded);
            assert!(empty(&held_entry(&store, "hold").audits));
        }
    }
}

#[test]
fn multiple_holds_share_chain_ceiling_and_stale_authenticated_observation_cannot_reserve() {
    let (_root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    for n in 0..2 {
        let a = log
            .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
            .unwrap();
        store
            .commit_reserving_audited(
                &scope,
                &batch("a", &format!("intent{n}"), 0, "x"),
                &request("a", &format!("hold{n}")),
                &[a],
            )
            .unwrap();
    }
    let a = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "third", 0, "x"),
            &request("a", "third"),
            &[a]
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let other = "b".repeat(64);
    let stale = log
        .prepare_allowance(&store, &scope, &other, 0, 1, 1000)
        .unwrap();
    log.append(
        &mut store,
        &scope,
        &other,
        0,
        "advance",
        &batch("a", "advance", 0, "x"),
    )
    .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "stale", 0, "x"),
            &request("a", "stale"),
            &[stale]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn actual_signed_append_and_future_allowance_creation_share_the_capacity_decision() {
    let (_root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let over = log
        .prepare_allowance(&store, &scope, &chain, 0, 2, 2000)
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        log.append_reserving(
            &mut store,
            &scope,
            &chain,
            0,
            "accepted",
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[over]
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let fit = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 2000)
        .unwrap();
    let p = log
        .append_reserving(
            &mut store,
            &scope,
            &chain,
            0,
            "accepted",
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[fit],
        )
        .unwrap();
    assert_eq!(p.publication.checkpoint.count, 1);
    assert_eq!(held_entry(&store, "hold").audits[0].records, 1);
    let held = p.held.unwrap();
    assert!(
        log.append_spending(
            &mut store,
            &scope,
            &chain,
            1,
            "done",
            &batch("a", "done", 0, "x"),
            &held,
            Credits {
                records: 2,
                live_bytes: 5000
            }
        )
        .is_ok()
    );
}

#[test]
fn allowance_proposals_do_not_expand_scope_pool_or_boot_authority() {
    let (_root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let only_domain = store
        .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap();
    assert!(matches!(
        log.prepare_allowance(&store, &only_domain, &chain, 0, 1, 1000),
        Err(Error::Denied)
    ));
    let a = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_reserving_audited(
            &only_domain,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a]
        ),
        Err(Error::Denied)
    ));
    let other = AuthenticatedLog::new(
        &store,
        "bh",
        "br",
        ChainLimits {
            payload_bytes: 1024,
            records: 2,
            bytes: 65_536,
        },
        &[0x64; 32],
    )
    .unwrap();
    let a = other
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a]
        ),
        Err(Error::Denied)
    ));
    let (_r2, second, s2) = fresh();
    let l2 = log_for_second(&second);
    let a = l2
        .prepare_allowance(&second, &s2, &chain, 0, 1, 1000)
        .unwrap();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a]
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
}
fn log_for_second(store: &Store) -> AuthenticatedLog {
    log(store, 2, 65_536)
}

#[test]
fn closed_alpha_slots_cannot_consume_beta_admission_and_catalog_is_immutable() {
    let root = tempfile::tempdir().unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let mut store = open(root.path(), OpenMode::CreateNew, slots(2, 2));
    let scope = store
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("b".into(), Access::ReadWrite),
        ]))
        .unwrap();
    for n in 0..2 {
        let held = store
            .commit_reserving(
                &scope,
                &batch("a", "state", n * 2, "x"),
                &request("a", &format!("hold{n}")),
            )
            .unwrap()
            .held
            .unwrap();
        assert!(
            store
                .commit_spending(
                    &scope,
                    &batch("a", "state", n * 2 + 1, "x"),
                    &held,
                    held.credits()
                )
                .unwrap()
                .held
                .is_none()
        );
    }
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_reserving(&scope, &batch("a", "third", 0, "x"), &request("a", "third")),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    store
        .commit_reserving(&scope, &batch("b", "intent", 0, "x"), &request("b", "hold"))
        .unwrap();
    drop(store);
    assert!(matches!(
        Store::open_audit_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots(3, 1)
        ),
        Err(Error::Invalid)
    ));
    let store = open(root.path(), OpenMode::Existing, slots(2, 2));
    let scope = store
        .scope(BTreeMap::from([("b".into(), Access::ReadWrite)]))
        .unwrap();
    assert!(
        store
            .resume_reservation(&scope, "b", "hold", 1, [8; 32])
            .is_ok()
    );
}

#[test]
fn audit_reservation_commit_error_requires_reopen_without_inventing_credit_refill() {
    let (root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let a = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a],
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    store.connection.commit_hook(Some(|| true)).unwrap();
    assert!(matches!(
        log.append_spending(
            &mut store,
            &scope,
            &chain,
            0,
            "done",
            &batch("a", "done", 0, "x"),
            &held,
            Credits {
                records: 3,
                live_bytes: 5000
            }
        ),
        Err(Error::CommitUncertain)
    ));
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 1, [8; 32]),
        Err(Error::ReopenRequired)
    ));
    drop(store);
    let store = open(root.path(), OpenMode::Existing, slots(8, 8));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn invalid_slot_catalogs_fail_before_initializing_state_and_old_profiles_cannot_adopt() {
    for catalog in [
        slots(0, 2),
        slots(1000, 1000),
        slots(501, 2),
        BTreeMap::from([("alpha".into(), 2)]),
        BTreeMap::from([("alpha".into(), 2), ("unknown".into(), 2)]),
    ] {
        let root = tempfile::tempdir().unwrap();
        fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
        assert!(
            Store::open_audit_reserved_bound(
                root.path(),
                OpenMode::CreateNew,
                Limits::default(),
                allocation(),
                [3; 32],
                catalog
            )
            .is_err()
        );
        assert!(!root.path().join("records.sqlite").exists());
    }
    let (root, store, _) = fresh();
    drop(store);
    assert!(matches!(
        Store::open_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32]
        ),
        Err(Error::Corrupt)
    ));
    assert!(matches!(
        Store::open_audit_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [4; 32],
            slots(8, 8)
        ),
        Err(Error::Invalid)
    ));
    let old = tempfile::tempdir().unwrap();
    fs::set_permissions(old.path(), fs::Permissions::from_mode(0o700)).unwrap();
    drop(
        Store::open_reserved_bound(
            old.path(),
            OpenMode::CreateNew,
            Limits::default(),
            allocation(),
            [3; 32],
        )
        .unwrap(),
    );
    assert!(matches!(
        Store::open_audit_reserved_bound(
            old.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots(8, 8)
        ),
        Err(Error::Corrupt)
    ));
}

#[test]
fn changed_limits_aliases_duplicate_and_excess_allowances_do_not_mint_promises() {
    let (_root, mut store, scope) = fresh();
    let first = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let a = first
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a],
        )
        .unwrap();
    let before = snapshot(&store);
    let different = log(&store, 3, 65_536);
    let a = different
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "other", 0, "x"),
            &request("a", "other"),
            &[a]
        ),
        Err(Error::Conflict)
    ));
    let aliased = AuthenticatedLog::new(
        &store,
        "xh",
        "ar",
        ChainLimits {
            payload_bytes: 1024,
            records: 2,
            bytes: 65_536,
        },
        &[0x64; 32],
    )
    .unwrap();
    let a = aliased
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "other", 0, "x"),
            &request("a", "other"),
            &[a]
        ),
        Err(Error::Conflict)
    ));
    let other = "b".repeat(64);
    let duplicates = (0..2)
        .map(|_| {
            first
                .prepare_allowance(&store, &scope, &other, 0, 1, 1000)
                .unwrap()
        })
        .collect::<Vec<_>>();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "other", 0, "x"),
            &request("a", "other"),
            &duplicates
        ),
        Err(Error::Invalid)
    ));
    let excess = (0..9)
        .map(|n| {
            first
                .prepare_allowance(&store, &scope, &format!("{n:064x}"), 0, 1, 1000)
                .unwrap()
        })
        .collect::<Vec<_>>();
    assert!(matches!(
        store.commit_reserving_audited(
            &scope,
            &batch("a", "other", 0, "x"),
            &request("a", "other"),
            &excess
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn eight_chain_metadata_is_canonical_and_corrupt_audit_blob_is_bounded_and_read_only() {
    let (root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let allowances = (0..8)
        .map(|n| {
            log.prepare_allowance(&store, &scope, &format!("{n:064x}"), 0, 1, 1000)
                .unwrap()
        })
        .collect::<Vec<_>>();
    store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &allowances,
        )
        .unwrap();
    let row = held_entry(&store, "hold");
    assert_eq!(row.audits.len(), 8);
    let encoded: Vec<u8> = store
        .connection
        .query_row("SELECT audits FROM reservations", [], |r| r.get(0))
        .unwrap();
    assert_eq!(encoded, encode(&row.audits).unwrap());
    assert!(encoded.len() < ENCODED_BYTES);
    store
        .inspect_namespaces(
            &scope,
            &["a".into()],
            std::time::Instant::now() + Duration::from_secs(2),
        )
        .unwrap();
    store
        .connection
        .execute(
            "UPDATE reservations SET audits=zeroblob(?1)",
            [ENCODED_BYTES as i64 + 1],
        )
        .unwrap();
    let before = snapshot(&store);
    assert!(
        store
            .inspect_namespaces(
                &scope,
                &["a".into()],
                std::time::Instant::now() + Duration::from_secs(2)
            )
            .is_err()
    );
    assert_eq!(snapshot(&store), before);
    drop(store);
    assert!(
        Store::open_audit_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots(8, 8)
        )
        .is_err()
    );
}

#[test]
fn stale_scope_and_debit_generation_after_restart_cannot_spend_current_allowance() {
    let (root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let a = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "x"),
            &request("a", "hold"),
            &[a],
        )
        .unwrap()
        .held
        .unwrap();
    drop(store);
    let mut store = open(root.path(), OpenMode::Existing, slots(8, 8));
    let current = store
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("ah".into(), Access::ReadWrite),
            ("ar".into(), Access::ReadWrite),
        ]))
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 1, [8; 32]),
        Err(Error::Denied)
    ));
    assert!(matches!(
        store.commit_spending(&current, &batch("a", "done", 0, "x"), &held, held.credits()),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    let h1 = store
        .resume_reservation(&current, "a", "hold", 1, [8; 32])
        .unwrap();
    let h2 = store
        .resume_reservation(&current, "a", "hold", 1, [8; 32])
        .unwrap();
    let log = log_for_second(&store);
    log.append_spending(
        &mut store,
        &current,
        &chain,
        0,
        "done",
        &batch("a", "done", 0, "x"),
        &h1,
        Credits {
            records: 3,
            live_bytes: 5000,
        },
    )
    .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_spending_audited(
            &current,
            &batch("a", "second", 0, "x"),
            &h2,
            h2.credits(),
            &[Debit {
                heads: "ah".into(),
                records_namespace: "ar".into(),
                chain,
                records: 1,
                bytes: 1000
            }]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
}

struct Child(std::process::Child);
impl Drop for Child {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn kill_at(root: &Path, kind: &str, phase: &str) {
    use std::io::{BufRead, BufReader};
    use std::process::{Command, Stdio};
    let mut child = Child(
        Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::reservation::audit::tests::audit_phase_worker_child",
                "--nocapture",
            ])
            .env("SIGIL_AUDIT_RESERVATION_ROOT", root)
            .env("SIGIL_AUDIT_RESERVATION_KIND", kind)
            .env("SIGIL_AUDIT_RESERVATION_PHASE", phase)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap(),
    );
    let output = child.0.stdout.take().unwrap();
    let (tx, rx) = std::sync::mpsc::channel();
    let reader = std::thread::spawn(move || {
        for line in BufReader::new(output)
            .lines()
            .map_while(std::result::Result::ok)
        {
            if line.contains("AUDIT_RESERVATION_BOUNDARY") {
                let _ = tx.send(());
                break;
            }
        }
    });
    rx.recv_timeout(Duration::from_secs(15))
        .expect("actual audit-reservation transaction boundary not reached");
    child.0.kill().unwrap();
    assert!(!child.0.wait().unwrap().success());
    reader.join().unwrap();
}
#[test]
fn audit_phase_worker_child() {
    use std::io::Write;
    let Ok(root) = std::env::var("SIGIL_AUDIT_RESERVATION_ROOT") else {
        return;
    };
    let kind = std::env::var("SIGIL_AUDIT_RESERVATION_KIND").unwrap();
    let phase = std::env::var("SIGIL_AUDIT_RESERVATION_PHASE").unwrap();
    let mut store = open(Path::new(&root), OpenMode::Existing, slots(8, 8));
    let scope = store
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("ah".into(), Access::ReadWrite),
            ("ar".into(), Access::ReadWrite),
        ]))
        .unwrap();
    let log = log(&store, 1, 65_536);
    let chain = "a".repeat(64);
    let park = || {
        println!("AUDIT_RESERVATION_BOUNDARY");
        std::io::stdout().flush().unwrap();
        loop {
            std::thread::park();
        }
    };
    if kind == "assign" {
        let held = store
            .resume_reservation(&scope, "a", "hold", 1, [8; 32])
            .unwrap();
        let related = batch("a", "assigned-claim", 0, "actual claim boundary");
        let debit = Credits {
            records: 3,
            live_bytes: 5000,
        };
        if phase == "before" {
            log.append_credit_update(
                &mut store,
                &scope,
                &chain,
                0,
                "prepared",
                &related,
                &held,
                debit,
                Some([9; 32]),
                park,
            )
            .unwrap();
        } else {
            log.append_assigning(
                &mut store, &scope, &chain, 0, "prepared", &related, &held, debit, [9; 32],
            )
            .unwrap();
            park();
        }
    } else if kind == "create" {
        let a = log
            .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
            .unwrap();
        if phase == "before" {
            store
                .commit_reserving_audited_inner(
                    &scope,
                    &batch("a", "intent", 0, "x"),
                    &request("a", "hold"),
                    &[a],
                    None,
                    park,
                )
                .unwrap();
        } else {
            store
                .commit_reserving_audited(
                    &scope,
                    &batch("a", "intent", 0, "x"),
                    &request("a", "hold"),
                    &[a],
                )
                .unwrap();
            park();
        }
    } else {
        let held = store
            .resume_reservation(&scope, "a", "hold", 1, [8; 32])
            .unwrap();
        if phase == "before" {
            log.append_spending_inner(
                &mut store,
                &scope,
                &chain,
                0,
                "done",
                &batch("a", "done", 0, "x"),
                &held,
                Credits {
                    records: 3,
                    live_bytes: 5000,
                },
                park,
            )
            .unwrap();
        } else {
            log.append_spending(
                &mut store,
                &scope,
                &chain,
                0,
                "done",
                &batch("a", "done", 0, "x"),
                &held,
                Credits {
                    records: 3,
                    live_bytes: 5000,
                },
            )
            .unwrap();
            park();
        }
    }
}
#[test]
fn hard_death_preserves_audit_pool_data_atomicity_before_and_after_creation_and_spend() {
    for kind in ["create", "spend"] {
        for phase in ["before", "after"] {
            let (root, mut store, scope) = fresh();
            let log = log(&store, 1, 65_536);
            let chain = "a".repeat(64);
            if kind == "spend" {
                let a = log
                    .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
                    .unwrap();
                store
                    .commit_reserving_audited(
                        &scope,
                        &batch("a", "intent", 0, "x"),
                        &request("a", "hold"),
                        &[a],
                    )
                    .unwrap();
            }
            let before = snapshot(&store);
            drop(store);
            kill_at(root.path(), kind, phase);
            let mut store = open(root.path(), OpenMode::Existing, slots(8, 8));
            let scope = store
                .scope(BTreeMap::from([
                    ("a".into(), Access::ReadWrite),
                    ("ah".into(), Access::ReadWrite),
                    ("ar".into(), Access::ReadWrite),
                ]))
                .unwrap();
            if phase == "before" {
                assert_eq!(snapshot(&store), before);
            } else if kind == "create" {
                assert_eq!(held_entry(&store, "hold").audits[0].records, 1);
                assert_eq!(store.get(&scope, "a", "intent").unwrap().revision, 1);
                let log = AuthenticatedLog::new(
                    &store,
                    "ah",
                    "ar",
                    ChainLimits {
                        payload_bytes: 1024,
                        records: 1,
                        bytes: 65_536,
                    },
                    &[0x64; 32],
                )
                .unwrap();
                assert!(matches!(
                    log.append(
                        &mut store,
                        &scope,
                        &chain,
                        0,
                        "steal",
                        &batch("a", "steal", 0, "x")
                    ),
                    Err(Error::Limit)
                ));
            } else {
                assert_eq!(held_entry(&store, "hold").audits[0].records, 0);
                assert_eq!(held_entry(&store, "hold").revision, 2);
                assert_eq!(store.get(&scope, "a", "done").unwrap().revision, 1);
                assert!(matches!(
                    store.resume_reservation(&scope, "a", "hold", 1, [8; 32]),
                    Err(Error::Conflict)
                ));
                let log = AuthenticatedLog::new(
                    &store,
                    "ah",
                    "ar",
                    ChainLimits {
                        payload_bytes: 1024,
                        records: 1,
                        bytes: 65_536,
                    },
                    &[0x64; 32],
                )
                .unwrap();
                assert_eq!(
                    log.verify(
                        &mut store,
                        &scope,
                        &chain,
                        None,
                        std::time::Instant::now() + Duration::from_secs(2)
                    )
                    .unwrap()
                    .count,
                    1
                );
            }
        }
    }
}

#[test]
fn audit_metadata_bytes_are_charged_at_exact_pool_boundary_including_empty_array() {
    for chain_count in [0usize, 1, 8] {
        // Derive the actual encoded metadata size from the public proposal path.
        // The data row costs 96 + len(a) + len(intent) + UTF-8 len(é) = 105.
        // The ledger coordinate costs 144 + len(a) + len(hold) = 149.
        let (_reference_root, reference, reference_scope) = fresh();
        let reference_log = log(&reference, 2, 65_536);
        let credits = (0..chain_count)
            .map(|n| {
                reference_log
                    .prepare_allowance(
                        &reference,
                        &reference_scope,
                        &format!("{n:064x}"),
                        0,
                        1,
                        1000,
                    )
                    .unwrap()
                    .credit
            })
            .collect::<Vec<_>>();
        let metadata_bytes = serde_json::to_vec(&credits).unwrap().len() as u64;
        if chain_count == 0 {
            assert_eq!(metadata_bytes, 2);
        }
        let exact = 105 + 149 + 50_000 + metadata_bytes;
        for shortage in [0u64, 1] {
            let root = tempfile::tempdir().unwrap();
            fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
            let mut catalog = allocation();
            catalog.pools[0].live_bytes = exact - shortage;
            let mut store = Store::open_audit_reserved_bound(
                root.path(),
                OpenMode::CreateNew,
                Limits::default(),
                catalog.clone(),
                [3; 32],
                slots(8, 8),
            )
            .unwrap();
            let scope = store
                .scope(
                    catalog
                        .pools
                        .into_iter()
                        .flat_map(|p| p.namespaces)
                        .map(|n| (n, Access::ReadWrite))
                        .collect(),
                )
                .unwrap();
            let log = log(&store, 2, 65_536);
            let allowances = (0..chain_count)
                .map(|n| {
                    log.prepare_allowance(&store, &scope, &format!("{n:064x}"), 0, 1, 1000)
                        .unwrap()
                })
                .collect::<Vec<_>>();
            let before = snapshot(&store);
            let result = store.commit_reserving_audited(
                &scope,
                &batch("a", "intent", 0, "é"),
                &request("a", "hold"),
                &allowances,
            );
            if shortage == 1 {
                assert!(matches!(result, Err(Error::Limit)));
                assert_eq!(snapshot(&store), before);
                continue;
            }
            let held = result.unwrap().held.unwrap();
            let before = snapshot(&store);
            assert_eq!(
                store.commit(&scope, &batch("a", "intent", 1, "éx")),
                Err(Error::Limit)
            );
            assert_eq!(snapshot(&store), before);
            // One actual UTF-8 byte may grow only when one held byte is spent.
            let spent = store
                .commit_spending(
                    &scope,
                    &batch("a", "intent", 1, "éx"),
                    &held,
                    Credits {
                        records: 0,
                        live_bytes: 1,
                    },
                )
                .unwrap()
                .held
                .unwrap();
            assert_eq!(spent.credits().live_bytes, 49_999);
            assert_eq!(held_entry(&store, "hold").audits, credits);
            // Alpha's exact boundary has no effect on beta's reserved pool.
            store
                .commit(&scope, &batch("b", "independent", 0, "ok"))
                .unwrap();
        }
    }
}

#[test]
fn only_one_current_generation_can_atomically_assign_credit_with_distinct_claims() {
    let (_root, mut store, scope) = fresh();
    let original = store
        .commit_reserving(
            &scope,
            &batch("a", "intent", 0, "accepted"),
            &request("a", "hold"),
        )
        .unwrap()
        .held
        .unwrap();
    let rival = store
        .resume_reservation(&scope, "a", "hold", 1, [8; 32])
        .unwrap();
    let zero = Credits {
        records: 0,
        live_bytes: 0,
    };
    let first = store
        .commit_assigning(
            &scope,
            &batch("a", "claim-1", 0, "first"),
            &original,
            zero,
            &[],
            [9; 32],
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(first.revision(), 2);
    assert_eq!(first.credits(), original.credits());
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("a", "claim-2", 0, "second"),
            &rival,
            zero,
            &[],
            [10; 32]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 2, [8; 32]),
        Err(Error::Conflict)
    ));
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 1, [9; 32]),
        Err(Error::Conflict)
    ));
    assert!(
        store
            .resume_reservation(&scope, "a", "hold", 2, [9; 32])
            .is_ok()
    );
    // Returning the binding cannot revive a formerly held generation (ABA).
    let returned = store
        .commit_assigning(
            &scope,
            &batch("a", "terminal", 0, "observed"),
            &first,
            zero,
            &[],
            [8; 32],
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(returned.revision(), 3);
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("a", "claim-3", 0, "stale"),
            &original,
            zero,
            &[],
            [11; 32]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(
        store
            .resume_reservation(&scope, "a", "hold", 3, [8; 32])
            .is_ok()
    );
}

#[test]
fn signed_assignment_debits_only_actual_audit_and_invalidates_prior_binding() {
    let (_root, mut store, scope) = fresh();
    let log = log(&store, 2, 65_536);
    let chain = "a".repeat(64);
    let allowance = log
        .prepare_allowance(&store, &scope, &chain, 0, 2, 20_000)
        .unwrap();
    let old = store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "accepted"),
            &request("a", "hold"),
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let assigned = log
        .append_assigning(
            &mut store,
            &scope,
            &chain,
            0,
            "prepared",
            &batch("a", "claim", 0, "claimed"),
            &old,
            Credits {
                records: 3,
                live_bytes: 5000,
            },
            [9; 32],
        )
        .unwrap();
    assert_eq!(assigned.publication.checkpoint.count, 1);
    let actual_bytes = assigned.publication.checkpoint.bytes;
    let held = assigned.held.unwrap();
    assert_eq!(held_entry(&store, "hold").audits[0].records, 1);
    assert_eq!(
        held_entry(&store, "hold").audits[0].bytes,
        20_000 - actual_bytes
    );
    let before = snapshot(&store);
    assert!(matches!(
        log.append_assigning(
            &mut store,
            &scope,
            &chain,
            1,
            "forged second claim",
            &batch("a", "other", 0, "x"),
            &old,
            Credits {
                records: 1,
                live_bytes: 5000
            },
            [10; 32]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        log.append(
            &mut store,
            &scope,
            &chain,
            1,
            "steal",
            &batch("a", "other", 0, "x")
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let terminal = log
        .append_assigning(
            &mut store,
            &scope,
            &chain,
            1,
            "observed",
            &batch("a", "result", 0, "observed"),
            &held,
            Credits {
                records: 1,
                live_bytes: 5000,
            },
            [8; 32],
        )
        .unwrap();
    assert_eq!(terminal.publication.checkpoint.count, 2);
    assert_eq!(terminal.held.unwrap().revision(), 3);
    assert_eq!(held_entry(&store, "hold").audits[0].records, 0);
    assert_eq!(
        held_entry(&store, "hold").audits[0].bytes,
        20_000 - terminal.publication.checkpoint.bytes
    );
}

#[test]
fn assignment_refusals_preserve_binding_scope_credits_and_data() {
    let (_root, mut store, scope) = fresh();
    let held = store
        .commit_reserving(
            &scope,
            &batch("a", "intent", 0, "accepted"),
            &request("a", "hold"),
        )
        .unwrap()
        .held
        .unwrap();
    let zero = Credits {
        records: 0,
        live_bytes: 0,
    };
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("a", "claim", 0, "x"),
            &held,
            zero,
            &[],
            [8; 32]
        ),
        Err(Error::Invalid)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("b", "claim", 0, "x"),
            &held,
            zero,
            &[],
            [9; 32]
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    let read_only = store
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    assert!(matches!(
        store.commit_assigning(
            &read_only,
            &batch("a", "claim", 0, "x"),
            &held,
            zero,
            &[],
            [9; 32]
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("a", "intent", 0, "stale"),
            &held,
            zero,
            &[],
            [9; 32]
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("a", "claim", 0, "x"),
            &held,
            Credits {
                records: 11,
                live_bytes: 0
            },
            &[],
            [9; 32]
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let (_other_root, mut other, other_scope) = fresh();
    let other_before = snapshot(&other);
    assert!(matches!(
        other.commit_assigning(
            &other_scope,
            &batch("a", "claim", 0, "x"),
            &held,
            zero,
            &[],
            [9; 32]
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&other), other_before);
    assert!(
        store
            .resume_reservation(&scope, "a", "hold", 1, [8; 32])
            .is_ok()
    );
}

#[test]
fn uncertain_signed_assignment_poisoning_cannot_be_treated_as_new_authority() {
    let (root, mut store, scope) = fresh();
    let log = log(&store, 1, 65_536);
    let chain = "a".repeat(64);
    let allowance = log
        .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &scope,
            &batch("a", "intent", 0, "accepted"),
            &request("a", "hold"),
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    store.connection.commit_hook(Some(|| true)).unwrap();
    assert!(matches!(
        log.append_assigning(
            &mut store,
            &scope,
            &chain,
            0,
            "prepared",
            &batch("a", "claim", 0, "x"),
            &held,
            Credits {
                records: 3,
                live_bytes: 5000
            },
            [9; 32]
        ),
        Err(Error::CommitUncertain)
    ));
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 1, [8; 32]),
        Err(Error::ReopenRequired)
    ));
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 2, [9; 32]),
        Err(Error::ReopenRequired)
    ));
    drop(store);
    let store = open(root.path(), OpenMode::Existing, slots(8, 8));
    assert_eq!(snapshot(&store), before);
    let scope = store
        .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap();
    assert!(
        store
            .resume_reservation(&scope, "a", "hold", 1, [8; 32])
            .is_ok()
    );
    assert!(matches!(
        store.resume_reservation(&scope, "a", "hold", 2, [9; 32]),
        Err(Error::Conflict)
    ));
}

#[test]
fn hard_death_around_signed_assignment_keeps_claim_credit_and_binding_atomic() {
    for phase in ["before", "after"] {
        let (root, mut store, scope) = fresh();
        let log = log(&store, 1, 65_536);
        let chain = "a".repeat(64);
        let allowance = log
            .prepare_allowance(&store, &scope, &chain, 0, 1, 1000)
            .unwrap();
        store
            .commit_reserving_audited(
                &scope,
                &batch("a", "intent", 0, "accepted"),
                &request("a", "hold"),
                &[allowance],
            )
            .unwrap();
        let before = snapshot(&store);
        drop(store);
        kill_at(root.path(), "assign", phase);
        let store = open(root.path(), OpenMode::Existing, slots(8, 8));
        let scope = store
            .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
            .unwrap();
        if phase == "before" {
            assert_eq!(snapshot(&store), before);
            assert!(
                store
                    .resume_reservation(&scope, "a", "hold", 1, [8; 32])
                    .is_ok()
            );
            assert!(matches!(
                store.resume_reservation(&scope, "a", "hold", 2, [9; 32]),
                Err(Error::Conflict)
            ));
        } else {
            let assigned = store
                .resume_reservation(&scope, "a", "hold", 2, [9; 32])
                .unwrap();
            assert_eq!(assigned.credits().records, 7);
            assert_eq!(assigned.credits().live_bytes, 45_000);
            assert!(matches!(
                store.resume_reservation(&scope, "a", "hold", 1, [8; 32]),
                Err(Error::Conflict)
            ));
            assert_eq!(
                store.get(&scope, "a", "assigned-claim").unwrap().revision,
                1
            );
            assert_eq!(held_entry(&store, "hold").audits[0].records, 0);
            assert_eq!(
                store
                    .connection
                    .query_row(
                        "SELECT count(*) FROM records WHERE namespace='ar'",
                        [],
                        |r| r.get::<_, i64>(0)
                    )
                    .unwrap(),
                1
            );
        }
    }
}
