//! Native terminal-publication facts. No result is invented or interpreted.
use crate::{Result, fields};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sigil_durable_store::store::{Batch, Mutation};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Fact {
    pub format: String,
    pub observed_at_unix_ms: u64,
    pub intent_binding: String,
    pub terminal_batch_sha256: String,
    pub audit_chain: String,
    pub audit_sequence: u64,
}
fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

pub(crate) fn couple(
    namespace: &str,
    chain: &str,
    sequence: u64,
    intent_binding: &str,
    payload: &str,
    batch: &Batch,
) -> Result<(Batch, String)> {
    if batch.writes.len() != 2 || batch.checks.len() != 1 {
        return Err("terminal_journal");
    }
    let claim = &batch.writes[0];
    let result = &batch.writes[1];
    let sd = fields(claim.value.as_deref().ok_or("claim")?, "SD1\n", 5)?;
    let dr = fields(result.value.as_deref().ok_or("delivery")?, "DR1\n", 7)?;
    if claim.revision != 1
        || result.revision != 0
        || dr[..5] != sd
        || !matches!(sd[4], "2" | "3" | "4" | "5" | "6")
    {
        return Err("terminal_journal");
    }
    let now = u64::try_from(
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|_| "clock")?
            .as_millis(),
    )
    .map_err(|_| "clock")?;
    if now == 0 {
        return Err("clock");
    }
    let key = format!("{intent_binding}.terminal");
    let fact = serde_json::to_string(&Fact {
        format: "sigil-native-terminal-publication/v1".into(),
        observed_at_unix_ms: now,
        intent_binding: intent_binding.into(),
        terminal_batch_sha256: digest(&serde_json::to_vec(batch).map_err(|_| "terminal_journal")?),
        audit_chain: chain.into(),
        audit_sequence: sequence,
    })
    .map_err(|_| "terminal_journal")?;
    let mut related = batch.clone();
    related.writes.push(Mutation {
        namespace: namespace.into(),
        key: key.clone(),
        revision: 0,
        value: Some(fact.clone()),
    });
    let envelope = serde_json::to_string(&serde_json::json!({
        "format":"sigil-native-terminal-audit/v1", "policy_payload":payload,
        "journal_namespace":namespace, "journal_key":key,
        "journal_sha256":digest(fact.as_bytes()),
        "related_batch_sha256":digest(&serde_json::to_vec(&related).map_err(|_| "terminal_journal")?),
    })).map_err(|_| "terminal_journal")?;
    Ok((related, envelope))
}
