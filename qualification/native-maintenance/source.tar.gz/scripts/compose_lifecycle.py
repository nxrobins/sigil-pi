"""Explicit archive-v1 application; native storage remains a generic mechanism."""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_capacity import compose_capacity
from scripts.sigil_omit import _functions, _tokens

ROOT = Path(__file__).resolve().parent.parent


def compose_lifecycle(name, stdlib):
    base = compose_capacity(name, stdlib)
    body, inputs = base.text, dict(base.input_hashes)

    def read(relative):
        raw = (ROOT / relative).read_bytes()
        inputs[relative] = hashlib.sha256(raw).hexdigest()
        return raw.decode()

    if "configured" in _functions(_tokens(body)):
        start, end, public = _functions(_tokens(body))["configured"]
        if public:
            raise ValueError("configured must remain internal")
        body = body[:start] + read("app/pi/archive_authority.sigil") + body[end:]
    if name == "admission":
        old = "store_commit(checks,w6)"
        guard = "if w6 < 0{return w6;}"
        if body.count(old) != 1 or body.count(guard) != 1:
            raise ValueError("archive composition requires one funded admission commit")
        body = body.replace(old, "store_commit(checks,w7)").replace(
            guard, guard + "let w7: i64 @Internal = archive_admission(w6,c,prior_snapshot,previous);if w7 < 0{return w7;}")
        body += "\n" + read("app/pi/history_archive.sigil")
    body = compact(body)
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("archive admission exceeds source/entry ceilings")
    inputs["scripts/compose_lifecycle.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body, inputs, base.stdlib_hash)
