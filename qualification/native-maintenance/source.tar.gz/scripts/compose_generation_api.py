"""Explicit AH9 API: bind the allocation before publishing admission records."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource
from scripts.compose_archive_export import compose_archive_export_api
from scripts.compose_bootstrap_admission import compact
from scripts.sigil_omit import omit_unreferenced_functions

ROOT = Path(__file__).resolve().parent.parent


def compose_generation_api(stdlib):
    base = compose_archive_export_api(stdlib)
    body, inputs = base.text, dict(base.input_hashes)
    # Fixed unused helpers from the prior API assembly; no runtime optimizer.
    body = omit_unreferenced_functions(body, {
        "capacity_reserve": "6c73f51e8b926883261ee957f8202d710cfb6dfa2e78314d44cde9c29b7dbf1b",
        "capacity_audit": "b06a6bd63972d6e726f8e5e4df8f63ea1f5159cfa70ffc4303c50ab4dd1c4a99",
        "capacity_effect": "0bc7213002cabf7f2e3e82158efe71ec83aa1e605ee19a916ed972c6a4eb3832",
        "capacity_transaction": "070618fcc99f0d5be7ad5896cb9b71d9aaf90335f397411c3475ef671a3ce051",
    }).text

    def replace(old, new):
        nonlocal body
        if body.count(old) != 1:
            raise ValueError("generation API composition site changed: " + old)
        body = body.replace(old, new)

    body = body.replace('"AH8\\n"', '"AH9\\n"').replace('"HC8\\n"', '"HC9\\n"')
    replace('arr_len(get(x,10))!= 5', 'arr_len(get(x,10))!= 6')
    for index, name in ((4, "storage"), (3, "listing"), (2, "history")):
        replace(f'item(get(x,10),{index}),"{name}"', f'item(get(x,10),{index+1}),"{name}"')
    replace('!is_text(item(get(x,10),1),"archive_export")',
            '!is_text(item(get(x,10),1),"archive_export")|| !is_text(item(get(x,10),2),"generation_admission")')
    replace(r'[\"call\",\"commit\",\"metadata\",\"read\",\"reply\",\"reserve\",\"spend\"]',
            r'[\"call\",\"commit\",\"metadata\",\"read\",\"reply\",\"reservation\",\"reservation_plan\",\"reserve\",\"spend\"]')
    replace('if !submitting || !is_text(get(x,8),"admission"){return -400;}',
            'if !submitting || (!is_text(get(x,8),"admission")&& !is_text(get(x,8),"generation_admission")){return -400;}')
    site = 'let action: i64 @Internal = read_record(command("reserve",get(planned,1),get(planned,3),get(x,5)),"HC9\\n",5);'
    replace(site, compact('''
        if is_text(get(x, 8), "admission") {
            let proposal: i64 @Internal = read_record(command("reservation_plan", get(c, 13), get(x, 5), get(x, 7)), "HC9\\n", 5);
            put(proposal, 4, get(planned, 2));
            return write_record(proposal, "HC9\\n", 5);
        }
    ''') + site)
    replace('if is_text(get(x,6),"call"){if !submitting', compact('''
        if is_text(get(x, 6), "reservation_plan") {
            if !submitting { return -400; }
            let held: i64 @Internal = read_record(get(x, 8), "AD2\\n", 4);
            if held < 0 || !is_text(get(held, 0), "ok") { return -400; }
            let args: i64 @Internal = alloc(16);
            put(args, 0, get(x, 7)); put(args, 1, get(x, 8));
            let action: i64 @Internal = read_record(command("call", text("generation_admission"), write_record(args, "GP1\\n", 2), text("generation_admission")), "HC9\\n", 5);
            put(action, 4, get(held, 2));
            return write_record(action, "HC9\\n", 5);
        }
    ''') + 'if is_text(get(x,6),"call"){if !submitting')
    replace("fn cancel_api(", "fn cancel_base(")
    cancel = (ROOT / "app/pi/generation_cancel_api.sigil").read_bytes()
    body = compact(body + cancel.decode())
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("generation API exceeds source/entry limits")
    inputs["scripts/compose_generation_api.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    inputs["app/pi/generation_cancel_api.sigil"] = hashlib.sha256(cancel).hexdigest()
    inputs["scripts/sigil_omit.py"] = hashlib.sha256((ROOT / "scripts/sigil_omit.py").read_bytes()).hexdigest()
    return ApplicationSource(body, inputs, base.stdlib_hash)
