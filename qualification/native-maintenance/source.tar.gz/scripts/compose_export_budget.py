"""Build-only pure export-budget component; no runtime orchestration."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource, strip_line_comments
from sigil_compose import compose_with_stdlib

ROOT = Path(__file__).resolve().parent.parent


def compose_export_budget(stdlib, *, root=ROOT):
    inputs = {}

    def read(name):
        raw = (root / name).read_bytes()
        inputs[name] = hashlib.sha256(raw).hexdigest()
        return raw.decode()

    body = read("app/shared/export_budget.sigil")
    helpers = read("app/shared/record_helpers.sigil")
    assert body.count("// RECORD_HELPERS") == 1
    assert helpers.count("// UTF8_VALIDATOR") == 1
    helpers = helpers.replace("// UTF8_VALIDATOR", read("app/shared/utf8.sigil"))
    body = body.replace("// RECORD_HELPERS", helpers)
    composed = compose_with_stdlib(body, ["json"], stdlib)
    inputs["scripts/compose_export_budget.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(strip_line_comments(composed.text), inputs, composed.stdlib_hash)
