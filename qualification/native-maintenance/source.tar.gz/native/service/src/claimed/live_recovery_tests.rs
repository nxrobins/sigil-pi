//! Actual admitted SIGIL HTTP effect + owner SIGKILL + compiled recovery.
//! The local provider is a receipt-gated test server, not a model benchmark.
use super::*;
use std::os::unix::process::ExitStatusExt;
use std::process::Command;

#[derive(serde::Deserialize)]
struct LivePrograms {
    completion: WorkerConfig,
    audit: WorkerConfig,
    effect: WorkerConfig,
    credential: String,
    control: std::path::PathBuf,
    input: String,
}
fn programs() -> LivePrograms {
    let path = std::env::var("SIGIL_LIVE_RECOVERY_FIXTURE").unwrap();
    serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap()
}
fn policies(live: &LivePrograms) -> Programs {
    Programs {
        anchored: false,
        completion: live.completion.clone(),
        audit: live.audit.clone(),
        credential: live.credential.clone(),
        report: live.control.join("actual-recovery.json"),
        retirement: true,
        failure: false,
        refusal: false,
    }
}
fn new_store(root: &Path) -> Store {
    std::fs::create_dir(root).unwrap();
    std::fs::set_permissions(root, std::fs::Permissions::from_mode(0o700)).unwrap();
    Store::open_fenced_reserved_bound(
        root,
        OpenMode::CreateNew,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records: 13,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
    .unwrap()
}
fn key() -> Vec<u8> {
    std::env::var("SIGIL_COMPILED_RECOVERY_AUDIT_KEY")
        .unwrap()
        .into_bytes()
}
fn write_json(path: &Path, value: &Value) {
    let temp = path.with_extension("pending");
    std::fs::write(&temp, serde_json::to_vec_pretty(value).unwrap()).unwrap();
    std::fs::rename(temp, path).unwrap();
}

#[test]
fn live_effect_owner_process_child() {
    if std::env::var_os("SIGIL_LIVE_RECOVERY_OWNER").is_none() {
        return;
    }
    let live = programs();
    let configured = policies(&live);
    let mut store = new_store(&live.control.join("store"));
    let owner = owner(&store);
    let operation = format!("{}:1", "b".repeat(64));
    store
        .commit(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: operation.clone(),
                    revision: 0,
                    value: Some("actual SIGIL HTTP effect".into()),
                }],
            },
        )
        .unwrap();
    let scope = store.scope(grant_map()).unwrap();
    let binding = crate::claimed::Binding {
        intent_namespace: "intent".into(),
        claim_namespace: "claim".into(),
        key: operation.clone(),
    };
    let mut worker =
        Bridge::new_fenced(live.effect.clone(), store.execution_lease().unwrap()).unwrap();
    let mut recorder = attach(&configured, &worker, &store, false);
    let identity = CompletionIdentity::observe(&store, &scope, &binding, "delivery").unwrap();
    let origin = identity.reservation_binding();
    let log = AuthenticatedLog::new(&store, "audit.heads", "audit.entries", limits(true), &key())
        .unwrap();
    let allowance = log
        .prepare_allowance(
            &store,
            &owner,
            &"a".repeat(64),
            0,
            3,
            3 * log.encoded_entry_ceiling(),
        )
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &owner,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 0,
                    value: Some("original three obligations".into()),
                }],
            },
            &Request {
                namespace: "funds".into(),
                key: operation.clone(),
                binding: origin,
                credits: Credits {
                    records: 10,
                    live_bytes: 700_000,
                },
            },
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let funding = identity
        .fund_with_retirement(
            &store,
            held,
            CompletionBudget {
                claim: Credits {
                    records: 3,
                    live_bytes: 200_000,
                },
                result: Credits {
                    records: 2,
                    live_bytes: 200_000,
                },
            },
            Credits {
                records: 1,
                live_bytes: 200_000,
            },
        )
        .unwrap();
    let (domain, epoch) = store
        .execution_identity()
        .map(|(d, e)| (d.to_owned(), e.to_owned()))
        .unwrap();
    let mut clock = 0;
    let mut attempt = Attempt::begin(
        &mut store,
        &scope,
        &mut worker,
        &mut clock,
        binding,
        crate::claimed::Execution {
            input: live.input.clone(),
            fuel: live.effect.max_fuel,
            timeout_ms: 30_000,
            time_guard: frame("TG1\n", &["0", "9007199254740991"]).unwrap(),
        },
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    attempt.claim_recorded(&mut recorder).unwrap();
    let ticket = attempt.prepared().ticket.clone();
    let generation = attempt.prepared().generation.clone();
    write_json(
        &live.control.join("prepared.json"),
        &serde_json::json!({
            "owner_pid":std::process::id(),"domain":domain,"epoch":epoch,"origin":hex(origin),
            "generation":generation,"effect_source":live.effect.source_sha256,"effect_runtime":live.effect.runtime_sha256,
            "input_sha256":attempt.prepared().input_sha256,
        }),
    );
    let _ = attempt.execute(&ticket, &AtomicBool::new(false));
    panic!("owner should be killed while actual HTTP response is held");
}

struct Cleanup {
    child: std::process::Child,
    release: std::path::PathBuf,
}
impl Drop for Cleanup {
    fn drop(&mut self) {
        let _ = std::fs::write(&self.release, b"release");
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

#[test]
#[ignore = "explicit local-server test; validates the Darwin runtime survivor profile"]
fn actual_runtime_owner_death_preserves_fence_and_compiled_recovery() {
    let _serial = process_guard();
    let live = programs();
    let configured = policies(&live);
    let fixture = std::env::var("SIGIL_LIVE_RECOVERY_FIXTURE").unwrap();
    let log_file = std::fs::File::create(live.control.join("owner.log")).unwrap();
    let mut cleanup = Cleanup {
        child: Command::new(std::env::current_exe().unwrap()).args([
            "--exact","claimed::recorded::recovery::tests::compiled::live::live_effect_owner_process_child","--nocapture",
        ]).env("SIGIL_LIVE_RECOVERY_FIXTURE",fixture).env("SIGIL_LIVE_RECOVERY_OWNER","1")
        .stdout(log_file.try_clone().unwrap()).stderr(log_file).spawn().unwrap(),
        release:live.control.join("release"),
    };
    let until = Instant::now() + Duration::from_secs(45);
    while !live.control.join("received.json").exists() {
        assert!(
            cleanup.child.try_wait().unwrap().is_none(),
            "{}",
            std::fs::read_to_string(live.control.join("owner.log")).unwrap()
        );
        assert!(
            Instant::now() < until,
            "actual SIGIL HTTP request was not observed"
        );
        std::thread::sleep(Duration::from_millis(10));
    }
    let prepared: Value =
        serde_json::from_slice(&std::fs::read(live.control.join("prepared.json")).unwrap())
            .unwrap();
    let receipt: Value =
        serde_json::from_slice(&std::fs::read(live.control.join("received.json")).unwrap())
            .unwrap();
    assert_eq!(receipt["requests"], 1);
    assert_eq!(receipt["authorized"], true);
    cleanup.child.kill().unwrap();
    let killed = cleanup.child.wait().unwrap();
    assert_eq!(killed.signal(), Some(9));
    // The actual forge runtime is still inside the received HTTP call, holding
    // the inherited lease. The native owner is gone; reopening must remain Busy.
    let mut busy_checks = 0;
    for _ in 0..10 {
        assert!(matches!(
            open(&live.control.join("store")),
            Err(sigil_durable_store::store::Error::Busy)
        ));
        busy_checks += 1;
        std::thread::sleep(Duration::from_millis(50));
    }
    std::fs::write(&cleanup.release, b"release").unwrap();
    let until = Instant::now() + Duration::from_secs(20);
    let mut store = loop {
        match open(&live.control.join("store")) {
            Ok(store) => break store,
            Err(sigil_durable_store::store::Error::Busy) => {
                assert!(
                    Instant::now() < until,
                    "actual runtime did not release lease after HTTP completion"
                );
                std::thread::sleep(Duration::from_millis(10));
            }
            Err(error) => panic!("reopen failed: {error:?}"),
        }
    };
    let owner = owner(&store);
    let (domain, epoch) = store
        .execution_identity()
        .map(|(d, e)| (d.to_owned(), e.to_owned()))
        .unwrap();
    assert_eq!(domain, prepared["domain"].as_str().unwrap());
    assert_ne!(epoch, prepared["epoch"].as_str().unwrap());
    let operation = format!("{}:1", "b".repeat(64));
    let assigned = store
        .reservation_snapshot(&owner, "funds", &operation)
        .unwrap();
    assert_eq!(assigned.revision, 2);
    assert_eq!(
        assigned.credits,
        Credits {
            records: 7,
            live_bytes: 500_000
        }
    );
    assert_eq!(store.get(&owner, "claim", &operation).unwrap().revision, 1);
    assert_eq!(
        store.get(&owner, "delivery", &operation).unwrap().revision,
        0
    );
    assert_eq!(
        store
            .get(&owner, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        1
    );
    let worker = Bridge::new_fenced(live.effect.clone(), store.execution_lease().unwrap()).unwrap();
    let mut recorder = attach(&configured, &worker, &store, false);
    let mut recovery = recorder
        .recover_funded_pending(&mut store, &owner, "funds", &operation)
        .unwrap();
    assert_eq!(recovery.recovered.phase, "4");
    assert_eq!(
        recovery.recovered.claim_generation,
        prepared["generation"].as_str().unwrap()
    );
    let returned = recovery.take_returned_credit().unwrap();
    assert!(recovery.take_returned_credit().is_none());
    store
        .check_reservation_binding(&returned, assigned.origin)
        .unwrap();
    assert_eq!(
        returned.credits(),
        Credits {
            records: 5,
            live_bytes: 300_000
        }
    );
    assert_eq!(hex(assigned.origin), prepared["origin"]);
    let log = AuthenticatedLog::new(&store, "audit.heads", "audit.entries", limits(true), &key())
        .unwrap();
    assert_eq!(
        log.verify(
            &mut store,
            &owner,
            &"a".repeat(64),
            None,
            Instant::now() + Duration::from_secs(1)
        )
        .unwrap()
        .count,
        2
    );
    let entries: Vec<String> = (0..2)
        .map(|sequence| {
            store
                .get(
                    &owner,
                    "audit.entries",
                    &format!("{}.{sequence:016x}", "a".repeat(64)),
                )
                .unwrap()
                .value
                .unwrap()
        })
        .collect();
    let expected = serde_json::json!({"schema":"sigil/local-exclusion/v1","domain":domain,"prior_epoch":prepared["epoch"],
        "current_epoch":epoch,"reservation_namespace":"funds","reservation_key":operation,"reservation_revision":2,
        "assignment_binding":hex(assigned.binding),"origin_binding":hex(assigned.origin),"result_records":2,"result_live_bytes":200000});
    let signed: Value = serde_json::from_str(&entries[1]).unwrap();
    let event: Value = serde_json::from_str(signed["body"]["payload"].as_str().unwrap()).unwrap();
    assert_eq!(event["local_exclusion"], expected);
    assert_eq!(event["phase"], 4);
    assert_eq!(event["request_may_have_run"], 1);
    assert_eq!(event["worker_reaped"], 0);
    assert!(event["effect"].is_null());
    assert!(
        recorder
            .recover_funded_pending(&mut store, &owner, "funds", &operation)
            .is_err()
    );
    assert!(
        recorder
            .retire_funded_terminal(&mut store, &owner, "funds", &operation)
            .is_err()
    );
    let final_receipt: Value =
        serde_json::from_slice(&std::fs::read(live.control.join("received.json")).unwrap())
            .unwrap();
    assert_eq!(final_receipt["requests"], 1);
    write_json(
        &live.control.join("actual-recovery.json"),
        &serde_json::json!({
            "entries":entries,"expected_exclusion":expected,"prepared":prepared,"owner_signal":9,
            "busy_checks_after_owner_reaped":busy_checks,"observed_requests_before":receipt["requests"],
            "observed_requests_after":final_receipt["requests"],"returned_records":5,"returned_bytes":300000,
            "qualification":false,"scope":"Actual Darwin SIGIL HTTP effect and owner kill; not product API/model/Linux qualification",
        }),
    );
}
