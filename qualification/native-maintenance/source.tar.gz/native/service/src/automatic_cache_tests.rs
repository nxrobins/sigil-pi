use super::*;

#[test]
fn cache_profiles_are_explicit_distinct_and_mutually_exclusive() {
    let mut config = Config {
        coordinator_cache: None,
        pure_cache: None,
        participants: vec![],
    };
    assert_eq!(config.cache_modes(), Ok((false, false)));
    config.coordinator_cache = Some("owner-local-exact-worker/v1".into());
    assert_eq!(config.cache_modes(), Ok((true, false)));
    config.pure_cache = Some("owner-local-exact-worker/v1".into());
    assert_eq!(config.cache_modes(), Err("config"));
    config.coordinator_cache = None;
    assert_eq!(config.cache_modes(), Ok((true, true)));
    config.pure_cache = Some("unknown".into());
    assert_eq!(config.cache_modes(), Err("config"));
    config.pure_cache = None;
    config.coordinator_cache = Some("unknown".into());
    assert_eq!(config.cache_modes(), Err("config"));
}
