"""Explicit funded-journal profile overlay; budgets remain SIGIL decisions."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource


def with_dispatch_journal(base):
    body = base.text
    if "fn capacity_reserve(" in body:
        replacements = [
            ("actions * 8 + 16", "actions * 10 + 16"),
            (r'\"claim\":{\"records\":3,', r'\"claim\":{\"records\":4,'),
            (r'\"result\":{\"records\":2,', r'\"result\":{\"records\":3,'),
        ]
        for old, new in replacements:
            if body.count(old) != 1:
                raise ValueError(f"journal profile expected one budget site: {old}")
            body = body.replace(old, new)
    inputs = dict(base.input_hashes)
    inputs["scripts/compose_dispatch_journal.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if len(body.encode()) > 65536:
        raise ValueError("journal profile exceeds source limit")
    return ApplicationSource(body, inputs, base.stdlib_hash)
