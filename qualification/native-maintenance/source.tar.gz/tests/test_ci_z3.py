"""Execute CI solver selection; fake versions test selection, not solver proofs.

The Linux workflow separately exercises the real archive library with env_clear.
These checks do not need or alter a system loader configuration.
"""
import os
from pathlib import Path
import subprocess
import sys

import pytest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/ci_z3.py"


@pytest.fixture
def solver(tmp_path):
    root = tmp_path / "verified archive"
    (root / "bin").mkdir(parents=True)
    binary = root / "bin/z3"
    binary.write_text("#!/bin/sh\nprintf 'Z3 version 4.12.2 - 64 bit\\n'\n")
    binary.chmod(0o755)
    path_file, env_file = tmp_path / "github-path", tmp_path / "github-env"
    path_file.write_text("earlier-path\n")
    env_file.write_text("EARLIER=value\n")
    env = {key: value for key, value in os.environ.items() if key != "SIGIL_Z3_IDENTITY"}
    env.update(GITHUB_PATH=str(path_file), GITHUB_ENV=str(env_file))
    return root, env, path_file, env_file


def run(solver, *extra):
    root, env, _, _ = solver
    return subprocess.run([sys.executable, str(SCRIPT), "select", "--root", str(root),
                           "--version", "4.12.2", *extra],
                          env=env, capture_output=True, text=True, timeout=10)


def unchanged(solver):
    assert solver[2].read_text() == "earlier-path\n"
    assert solver[3].read_text() == "EARLIER=value\n"


def test_select_observes_pinned_solver_despite_shadow_and_exports_identity(solver, tmp_path):
    shadow = tmp_path / "shadow"
    shadow.mkdir()
    binary = shadow / "z3"
    binary.write_text("#!/bin/sh\nprintf 'Z3 version 0.0.0 - 64 bit\\n'\n")
    binary.chmod(0o755)
    solver[1]["PATH"] = str(shadow)
    result = run(solver)
    assert result.returncode == 0, result.stderr
    assert result.stdout == "Z3 version 4.12.2 - 64 bit\n"
    assert solver[2].read_text() == f"earlier-path\n{solver[0] / 'bin'}\n"
    assert solver[3].read_text() == "EARLIER=value\nSIGIL_Z3_IDENTITY=Z3 version 4.12.2 - 64 bit\n"


@pytest.mark.parametrize("override", ["", "forged", "Z3 version 4.12.2 - 64 bit"])
def test_select_rejects_even_plausible_preasserted_identity(solver, override):
    solver[1]["SIGIL_Z3_IDENTITY"] = override
    result = run(solver)
    assert result.returncode == 1 and "pre-set" in result.stderr
    unchanged(solver)


@pytest.mark.parametrize("output", ["", "4.12.2", "Z3 version 4.13.0 - 64 bit",
                                    "Z3 version 4.12.2 - 32 bit",
                                    "Z3 version 4.12.2 - 64 bit\\nINJECTED=value"])
def test_select_rejects_wrong_or_multiline_identity(solver, output):
    (solver[0] / "bin/z3").write_text(f"#!/bin/sh\nprintf '{output}\\n'\n")
    result = run(solver)
    assert result.returncode == 1 and "unexpected Z3 identity" in result.stderr
    unchanged(solver)


@pytest.mark.parametrize("fault", ["missing", "nonexecutable", "symlink", "failed"])
def test_select_cannot_fall_back_from_broken_pinned_solver(solver, fault, tmp_path):
    binary = solver[0] / "bin/z3"
    if fault == "missing":
        binary.unlink()
    elif fault == "nonexecutable":
        binary.chmod(0o644)
    elif fault == "symlink":
        target = tmp_path / "other-z3"
        binary.rename(target)
        binary.symlink_to(target)
    else:
        binary.write_text("#!/bin/sh\nexit 7\n")
    assert run(solver).returncode == 1
    unchanged(solver)


@pytest.mark.parametrize("version", ["4.12.2\nINJECTED=value", "", "4.12"])
def test_select_rejects_invalid_requested_version(solver, version):
    result = run(solver, "--version", version)
    assert result.returncode == 1 and "invalid solver version" in result.stderr
    unchanged(solver)


def test_select_rejects_multiline_archive_path(solver):
    old_root, env, path_file, env_file = solver
    root = old_root.with_name("archive\nINJECTED=value")
    old_root.rename(root)
    changed = root, env, path_file, env_file
    result = run(changed)
    assert result.returncode == 1 and "control character" in result.stderr
    unchanged(changed)


def test_install_refuses_non_linux_or_non_root_without_touching_archive(solver):
    if sys.platform == "linux" and os.geteuid() == 0:
        pytest.skip("root installation is exercised only in an isolated Linux image")
    result = subprocess.run([sys.executable, str(SCRIPT), "install", "--root", str(solver[0]),
                             "--version", "4.12.2"], capture_output=True, text=True, timeout=10)
    assert result.returncode == 1 and "requires root" in result.stderr
    assert sorted(path.name for path in (solver[0] / "bin").iterdir()) == ["z3"]
    unchanged(solver)
