# Bounded model context

The explicit `context_window: v1` development profile adds context reduction to
`archive-v1` and public archive retrieval. It requires a fresh deployment.
The builder is `scripts/build_context_window_deployment.py`.

On a follow-up, SIGIL atomically archives the exact settled prior state and
operation result before replacing the current state. It retains at most 64
recent messages and 32 KiB of prior context (or half the configured history cap
if smaller), cutting only at a user-text boundary. It never cuts a message or
separates a model tool request from its result. The new user message and visible
context notice are additional; the existing 128 KiB whole-request history limit
still applies. A single oversized prior exchange can be omitted in full.

Interrupted operations first receive paired explicitly unknown tool results
and their actual terminal notice. A reduced request includes a visible notice
linking to `/v1/sessions/{session}/archives`, warning that older effects can be
uncertain and must not be repeated automatically. Every previous snapshot and
terminal result remains available through that authenticated API. Archive
snapshots may overlap; they are not new transcript messages to concatenate.

Recent retained context supports follow-up questions. This first slice does
not give the model a new archive-retrieval tool or invent a summary of omitted
content. The public API provides bounded retrieval. Context reduction does not
grant authority: checked edits still require an observed build/test baseline in
the new turn. It does not delete archives, reclaim reservation identities, or
qualify the full MVP.

The initial real-model trial consumed all 1,536 output tokens in auxiliary
thinking without an answer, returning after 59.47 seconds; the service correctly
settled as uncertain. The same retained request with explicit thinking disabled
returned the correct label in 0.29 seconds on a warm cache. This diagnostic is
not cold-start performance qualification. The profile now requires
`model_thinking: disabled`; SIGIL emits the option on every model request. This
uses [Ollama's explicit Messages API control](https://github.com/ollama/ollama/blob/main/docs/api/anthropic-compatibility.mdx).
The 32 KiB allowance, 60-second worker ceiling and uncertainty rules remain.

The subsequent full-service Flint trial completed within the deadline but
returned the first retained label instead of the latest one. Exact repeats,
short-history and fresh-prefix controls retained that semantic failure;
clearer last-message wording passing does not replace the original failed case.
An installed Qwen 14B model passed the unchanged question in one direct
diagnostic. `config/context-window-qwen14b-development.json` is a separate
candidate for service qualification; neither model is qualified for the full
MVP task benchmark by these diagnostics.

Follow-up normalization also pairs truncated model tool proposals as explicitly
not executed. This is distinct from interrupted dispatched calls with unknown
results, and does not change the archived state or authorize a retry.
