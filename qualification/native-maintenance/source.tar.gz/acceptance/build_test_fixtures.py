"""Independent, small real build and behavioral-test repositories."""

FILES = {
    "README.md": "Build with build_project; run all behavioral tests with test_project. Both use path '.'. C source: src/scale.c; Python source: src/pricing.py. Tests and Makefile must remain unchanged. Build artifacts live only in temporary command snapshots.\n",
    "Makefile": ".PHONY: build test\nbuild:\n\tmkdir -p build\n\tgcc -std=c11 -Wall -Wextra -Werror src/scale.c tests/test_scale.c -o build/test_scale\ntest: build\n\t./build/test_scale\n\tPYTHONPATH=src python3 -m unittest discover -s tests -p 'test_*.py' -v\n",
    "src/scale.c": "/* Convert Celsius to Fahrenheit using integer arithmetic. */\nint fahrenheit(int celsius) {\n    return celsius * 9 / 5 + 32;\n}\n",
    "tests/test_scale.c": '#include <stdio.h>\nint fahrenheit(int);\nint main(void) {\n    if (fahrenheit(0) != 32 || fahrenheit(100) != 212 || fahrenheit(-40) != -40) {\n        fputs("FAIL: temperature conversion expectations\n", stderr);\n        return 1;\n    }\n    puts("PASS: 3 C temperature conversion assertions");\n    return 0;\n}\n'.replace(
        'expectations\n"', 'expectations\\n"'
    ),
    "src/pricing.py": '"""Return the total for nonnegative integer-cent line items."""\ndef total_cents(items):\n    return sum(items)\n',
    "tests/test_pricing.py": "import unittest\nfrom pricing import total_cents\n\nclass PricingTests(unittest.TestCase):\n    def test_multiple_items(self): self.assertEqual(total_cents([125, 75, 300]), 500)\n    def test_empty(self): self.assertEqual(total_cents([]), 0)\n    def test_single_item(self): self.assertEqual(total_cents([99]), 99)\n\nif __name__ == '__main__': unittest.main()\n",
}
TASKS = [
    {
        "id": "B01",
        "session": "c-build-repair",
        "target": "src/scale.c",
        "failed_tool": "build_project",
        "prompt": "This repository's C build is failing. Discover the project instructions and relevant source, reproduce the failure with the approved build, make the smallest source fix, then run the real build and all tests. Preserve the Makefile, tests, and unrelated files. Report the actual build and test outcomes.",
    },
    {
        "id": "B02",
        "session": "python-test-repair",
        "target": "src/pricing.py",
        "failed_tool": "test_project",
        "prompt": "The pricing behavior in this repository is wrong. Discover the instructions, reproduce the failure with the real test suite, fix only the responsible source, and run the approved build and all tests after the fix. Do not change tests, the Makefile, or unrelated files. Report what failed and what passed.",
    },
]


def populate(workspace, task):
    workspace.mkdir(parents=True)
    for path, original in FILES.items():
        text = original
        if task["id"] == "B01" and path == task["target"]:
            text = text.replace("+ 32;", "+ 32")
        if task["id"] == "B02" and path == task["target"]:
            text = text.replace("sum(items)", "sum(items) + 1")
        target = workspace / path
        target.parent.mkdir(exist_ok=True)
        target.write_text(text)
