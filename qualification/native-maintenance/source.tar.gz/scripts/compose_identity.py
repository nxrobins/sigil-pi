"""Reuse the authenticated CF2 identity grammar in pure derived projections."""

import hashlib
from pathlib import Path


def identity_helper(repo, name):
    raw = (Path(repo) / "app/pi/api.sigil").read_bytes()
    source = raw.decode()
    begin, end = "fn identity_text(", "fn namespace("
    if source.count(begin) != 1 or source.count(end) != 1 or source.index(begin) >= source.index(end):
        raise ValueError("CF2 identity helper changed")
    if not name.isidentifier() or not name.isascii():
        raise ValueError("invalid build-time helper name")
    fragment = source[source.index(begin):source.index(end)].replace(begin, "fn " + name + "(")
    return fragment, {
        "app/pi/api.sigil": hashlib.sha256(raw).hexdigest(),
        "scripts/compose_identity.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
