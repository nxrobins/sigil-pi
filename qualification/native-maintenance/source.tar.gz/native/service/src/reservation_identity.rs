//! Explicit reservation facts across the SIGIL/native boundary. These values
//! never expand the caller's scope or establish execution cleanup.
use crate::{Result, digest_bytes};
use serde::{Deserialize, Serialize};
use sigil_durable_store::store::{
    Scope, Store,
    reservation::{Generation, Held},
};

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Identity {
    pub version: u32,
    pub pool: String,
    pub slot: u16,
    /// Decimal strings preserve the complete signed-64 range through JSON.
    pub generation: String,
    pub revision: String,
    pub binding: String,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ProposedGeneration {
    pub pool: String,
    pub slot: u16,
    pub generation: String,
}
impl ProposedGeneration {
    pub(crate) fn native(&self) -> Result<Generation> {
        Ok(Generation {
            pool: self.pool.clone(),
            slot: self.slot,
            generation: number(&self.generation)?,
        })
    }
}

pub(crate) fn plan_wire(
    store: &Store,
    scope: &Scope,
    namespace: &str,
    key: &str,
) -> Result<String> {
    let g = store
        .next_reservation_generation(scope, namespace, key)
        .map_err(|_| "funding")?;
    crate::frame(
        "GA1\n",
        &[
            namespace,
            key,
            &g.pool,
            &g.slot.to_string(),
            &g.generation.to_string(),
        ],
    )
}

fn number(raw: &str) -> Result<u64> {
    let value = raw.parse::<u64>().map_err(|_| "funding_identity")?;
    if value == 0 || value > i64::MAX as u64 || value.to_string() != raw {
        return Err("funding_identity");
    }
    Ok(value)
}

impl Identity {
    pub(crate) fn retirement(
        &self,
        namespace: &str,
        key: &str,
    ) -> Result<sigil_durable_store::store::reservation::slots::Retirement> {
        if self.version != 1 {
            return Err("funding_identity");
        }
        Ok(sigil_durable_store::store::reservation::slots::Retirement {
            namespace: namespace.into(),
            key: key.into(),
            revision: number(&self.revision)?,
            binding: digest_bytes(&self.binding).map_err(|_| "funding_identity")?,
            generation: Generation {
                pool: self.pool.clone(),
                slot: self.slot,
                generation: number(&self.generation)?,
            },
        })
    }
    /// Read scoped facts only. A subsequent grant still checks this complete
    /// identity against the actual current, independently anchored Store.
    pub fn observe(store: &Store, scope: &Scope, namespace: &str, key: &str) -> Result<Self> {
        let snapshot = store
            .reservation_snapshot(scope, namespace, key)
            .map_err(|_| "funding")?;
        Self::from_snapshot(&snapshot)
    }

    fn from_snapshot(
        snapshot: &sigil_durable_store::store::reservation::witness::Snapshot,
    ) -> Result<Self> {
        let generation = snapshot.generation.as_ref().ok_or("funding_profile")?;
        Ok(Self {
            version: 1,
            pool: generation.pool.clone(),
            slot: generation.slot,
            generation: generation.generation.to_string(),
            revision: snapshot.revision.to_string(),
            binding: snapshot
                .binding
                .iter()
                .map(|v| format!("{v:02x}"))
                .collect(),
        })
    }

    pub fn resume(&self, store: &Store, scope: &Scope, namespace: &str, key: &str) -> Result<Held> {
        if self.version != 1 {
            return Err("funding_identity");
        }
        let generation = Generation {
            pool: self.pool.clone(),
            slot: self.slot,
            generation: number(&self.generation)?,
        };
        store
            .resume_reservation_generation(
                scope,
                namespace,
                key,
                number(&self.revision)?,
                digest_bytes(&self.binding).map_err(|_| "funding_identity")?,
                &generation,
            )
            .map_err(|_| "funding")
    }
}

/// One independently verified read snapshot. These are scoped observations,
/// not a serialized grant, an application adoption decision or cleanup proof.
/// SIGIL must bind the initial generation durably before dispatch and compare
/// it on later observations; looking up a coordinate is not that comparison.
pub(crate) fn observe_wire(
    store: &Store,
    scope: &Scope,
    namespace: &str,
    key: &str,
) -> Result<String> {
    let snapshot = store
        .reservation_snapshot(scope, namespace, key)
        .map_err(|_| "funding")?;
    let identity = Identity::from_snapshot(&snapshot)?;
    crate::frame(
        "GI1\n",
        &[
            namespace,
            key,
            &serde_json::to_string(&identity).map_err(|_| "funding_identity")?,
            &snapshot
                .origin
                .iter()
                .map(|v| format!("{v:02x}"))
                .collect::<String>(),
            if snapshot.assignment.is_empty() {
                "idle"
            } else {
                "assigned"
            },
            &snapshot.credits.records.to_string(),
            &snapshot.credits.live_bytes.to_string(),
        ],
    )
}

pub(crate) fn held(
    store: &Store,
    scope: &Scope,
    namespace: &str,
    key: &str,
    identity: Option<&Identity>,
    require_idle: bool,
) -> Result<Held> {
    let facts = store
        .reservation_snapshot(scope, namespace, key)
        .map_err(|_| "funding")?;
    if require_idle && !facts.assignment.is_empty() {
        return Err("funding_assigned");
    }
    match (facts.generation, identity) {
        (Some(_), Some(identity)) => identity.resume(store, scope, namespace, key),
        (None, None) => store
            .resume_reservation(scope, namespace, key, facts.revision, facts.binding)
            .map_err(|_| "funding"),
        _ => Err("funding_identity"),
    }
}

#[cfg(test)]
#[path = "reservation_identity_tests.rs"]
mod tests;
