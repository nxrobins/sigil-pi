# Native deployment materialization — development only

Status: **integrated in the working tree after 57 build/native/browser checks passed
in isolation; full integrated source gate pending; not a qualified release or pilot** (2026-09-10).

The existing `scripts/build_release.py` still packages the reference Python
service. It is not a release path for the migrated SIGIL application. This new
`scripts/stage_native_deployment.py` addresses a separate prerequisite: copying
an explicitly configured native v9 or v10 application and its browser assets into a
private, self-contained artifact directory. It does not replace the old release
builder or qualify any M0–M8 gate.

## What it does

The builder requires an owner-supplied native configuration, host executable and
expected digest, browser manifest, new artifact destination and new state path.
It enumerates the actual entry, helper, coordinator, effect, dispatch policy,
recorder, transaction and both audit-publisher/evaluation worker slots. Every
selected source/runtime and browser file is copied as the exact supplied digest,
with duplicate artifact bytes stored once. Native source/runtime/static limits
and unsafe-file-mode rejection are retained; final-component symlinks and FIFOs
are refused. Strict JSON parsing rejects duplicate members and non-finite values.

Only worker source/runtime paths, public asset paths and the explicitly supplied
state path change. Credential facts, grants, secret environment references,
model/tool bindings, policy inputs, deadlines and allowances are retained. The
builder reads no secret environment values, starts no service, opens no state
store and makes no network request. Python is build/install tooling only; the
printed launch commands directly execute the native host.

The resulting directory is mode 0700; configuration/source/browser files are
0600 and executables 0700. `DEPLOYMENT.json`, written last, records all other file
digests, sizes/modes, worker-role identities and exact `init`/`open` command arrays.
It is an inventory, **not** verification provenance, a signature, a successful
native admission receipt or proof that the application is ready. The supplied
configuration contains private deployment/identity information and must not be
published as a public release asset.

## Explicit operator workflow

Run the module with `--config`, `--host`, `--host-sha256`, `--assets`, `--output`
and `--state-root`, all explicit absolute paths except the digest. The output
and state directories must be disjoint and nonexistent. Their parents must
already exist. The builder never overwrites or migrates an existing deployment
or state directory; a failed build may leave a private incomplete output without
a completion manifest. Do not launch that output.

Verify the artifact inventory against independently trusted build/provenance
evidence before executing either recorded command. Set only the intended
operator-managed secret references required by the supplied configuration.
`init` creates new state through the existing SIGIL/native bootstrap checks;
`open` reuses the **same unchanged deployment/configuration** and existing state.
The example command arrays use the existing loopback listener's ephemeral port
argument `0`; they are not public exposure or a pilot topology approval.

The current AV2/v9 SIGIL bootstrap admits one configured credential per
tenant/principal pair. It refuses aliases and rotation peers even when their
validity windows do not overlap. This prevents competing credential-specific
execution lanes; it does not provide credential rotation or authorize resuming
an existing operation under changed configuration. The older Python service's
rotation instructions do not apply to this development deployment.

The configuration is deliberately path-bound. Relocation changes the native
bundle identity; this builder is not a portable archive installer, in-place
upgrade or state migration. It neither rewrites recorded operations nor claims
that a differently located deployment can resume old state. Workspace files
remain outside the artifact directory under the original explicit grants; they
are not copied into public browser assets.

## Verification and remaining work

The initial build-time run failed after 12 passing cases (`de5d2a`) because this
filesystem cleared the requested set-ID permission bit. Read-only inspection
showed actual mode 0700 (`8f5d83`), not the requested unsafe mode. The unchanged
mode predicate was factored into a directly tested helper: real-file unsafe
mode checks remain, and explicit bit-level cases cover set-ID rejection without
claiming that the filesystem created such a file. All **44 build-time cases
passed in 0.22 seconds** (`6312d5`); lint passed. Inert executable fixtures in
those tests are never run and do not establish native admission.

Five additional actual-runtime cases are prepared, bringing collection to 49
(`c1347b`). They keep the original native/evaluator/browser prerequisites and
browser assertions. The two normal/lost-acknowledgement stories run copied host,
sources, runtimes and browser files from an empty working directory, with the
generated input directory moved away and checkout-selection environment hints
removed. They exercise browser and direct API use, two tenants, actual file/model
effects, signed effect records and restart without extra provider work. Three
negative cases require modified entry, runtime or browser bytes to fail native
admission before state creation. Execution and visual inspection are pending.

This is a local scripted-provider check on the current host, not a fresh Linux
installation or real-provider acceptance. System/dynamic-library dependencies
are not bundled or independently qualified by copying an executable. A release
still needs the actual SIGIL product configuration workflow, complete route and
audit/retention behavior, Linux packaging/dependency inventory, trusted provenance
and SBOM, protected full CI, versioned upgrade/restore/rollback evidence and all
other gates in `docs/mvp-goal.md`. Model, quota, retention and operational choices
remain owner decisions. No pilot is deployed by this tooling.

## Destination-validation follow-up

The first combined 49-case run is still live in the separate original copy
`/private/tmp/sigil-pi-native-deployment.gWsvZBcL`, session **68317**, with frozen
aggregate `16f171f0ce59b5e628bb8394960f7fc46df8b9e6ef424f2c346cf7ee21aeb157`.
It includes 44 original build checks plus five actual browser/native checks.
Do not treat that source as the corrected builder below, even if it passes.

An independent two-case regression outside the frozen copy reproduced missing
destination checks (`21c780`): symlinked parent aliases could name the same actual
artifact/state directory, and a nonexistent state parent was accepted even though
native initialization requires it. No existing user deployment was changed; both
reproductions used inert files in new private test directories.

The corrected copy at `/private/tmp/sigil-pi-deployment-path-fix.cmWOTblu` compares
resolved existing parent directories, rejects non-directory/missing parents and
rechecks state-path absence immediately after exclusive artifact-directory
creation. The latter catches filesystem case/name equivalence not visible from
lexical path comparison. Distinct symlinked parents remain usable and explicit
operator path strings are retained. These checks are build-time validation, not
an upgrade/migration or a guarantee against a compromised same-user filesystem.

All **49 expanded build-time cases passed in 0.17 seconds** (`7de6c0`), including
the five added destination cases; lint passed. This is not the combined 49-case
browser run. After the original run terminates, preserve its exact result/source,
integrate the corrected files under hash preconditions, then verify the expanded
combined set described below. No passing
runtime result is transferred to changed builder bytes. Main's independent full
source gate remains frozen and this work is not yet integrated there.

The documented command-line entry point was then exercised directly, including
an output path containing spaces and rejection when required settings are
missing. The positive checks copy inert executable bytes without launching them;
they produce the same manifest as the build function and create no state or
Python runtime files. All **52 build-time cases passed in 0.31 seconds**
(`7bd97d`), with lint passing. The next combined set contains those 52 cases and
the five unchanged actual-runtime/browser cases: **57 total**, not a retroactive
pass for either the original 49-case execution or the corrected deployment.

## Original combined run stopped; corrected run preparation

Session **68317** terminated with **1 failed, 44 passed in 646.47 seconds**
(10:46), terminal `f622da`. Original native, fixed-evaluator and browser-runtime
prerequisites completed. The first real scenario then failed in its build-time
comparison before launching the copied host: it zipped original and sorted JSON
dictionary iteration order, comparing `function/history` to
`function/emergency_policy`. No copied-service startup, browser story, model
request or restart passed in this run; the other four actual cases did not run.
The source aggregate matched before/after (`530a13` / `f56caa`):
`16f171f0ce59b5e628bb8394960f7fc46df8b9e6ef424f2c346cf7ee21aeb157`.

After that terminal result, the destination fixes, expanded build tests and
their documentation were copied here using the recorded old/new hashes
(`4fd864` / `4c72f0`). The actual scenario now compares workers by their explicit
role names, requires no duplicate or missing role, and retains every byte and
non-path policy/grant/limit comparison. This corrects the test's map-order
assumption; it does not alter the native configuration or service behavior.
All 57 cases must run on the corrected snapshot with the original prerequisites.
This latest checkpoint supersedes the earlier statement that 68317 is live.

## Corrected copied-deployment verification passed

The corrected **57-case** run, session **98198**, passed **57 tests in 469.82
seconds** (7:49), exit zero, terminal `4e448a`. It launched at **2026-09-10
01:20:40 UTC** (`f0470a`). This includes all 52 build-time cases and all five
actual-runtime scenarios, with no skipped or xfailed cases and no native,
fixed-evaluator, browser, assertion or deadline bypass. The source and
documentation aggregate matched before/after (`623458` / `323000`):
`a6d16625e630b219a2964df85c533dacb29f69aff1280350654125b27b004bb6`.

Reproduce from this directory using only local scripted-provider sockets:

```sh
env -u CARGO_TARGET_DIR -u PI_FORGE_BIN -u PI_TOOLCHAIN_DIR -u PI_STDLIB_DIR -u ANTHROPIC_API_KEY -u OPENAI_API_KEY -u SIGIL_ALLOW_UNVERIFIED_CERT PYTHONDONTWRITEBYTECODE=1 SIGIL_ROOT=/private/tmp/sigil-pi-pinned-8277a1d9.9NXtMw PI_REQUIRE_TOOLCHAIN=1 CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=2 PI_PLAYWRIGHT_DIR=/private/tmp/sigil-pi-browser-clean-install.LDlIoWgu/node_modules/playwright /Users/nigel/Projects/sigil-pi/.venv/bin/python -m pytest -xq -o addopts= -p no:cacheprovider tests/test_stage_native_deployment.py tests/test_native_deployment_browser.py
```

Actual optimized artifact SHA-256 values (`323000`):

| Artifact | SHA-256 |
|---|---|
| Application host | `240215fd75234b30a956b18ef4b6e2cf276a0248a562f168f2bb6d746d9076fd` |
| Transaction executable | `a65f88478b794702bf5d404d0617696c4c662ee013637088fe9b607d536818e9` |
| Claimed worker | `f9ebbe84993804fb06054f43730ec1e63cfcb8b85ffd84dd5a28b4856f491986` |
| Fixed evaluator | `afdfa1269ff1f871967e05b60a39fa539864e102b1bc311161f5336af12ef7cb` |

The story is copied native/SIGIL/browser artifacts -> authenticated chat and
direct API -> scoped model/file effects and durable state -> rendered retained
conversation -> actual restart without additional provider work. No Python API
or Python agent is launched. The local model replies remain scripted, not M4
live-model usefulness evidence.

The actual artifacts are under
`/private/var/folders/rn/jlv2wkkx77dg6j9f57sf36jc0000gn/T/pytest-of-nigel/pytest-414`.
Read-only post-run verification checked every recorded artifact digest, byte
length and mode: each normal/lost-ack bundle has **26 files and 34 unique worker
roles**, with both v2 audit publishers for both tenants (`794caf`). The admitted
entry digest is `dda44ebb392d02f22060bf507fb363aab879382a2789948e9c6f4b54c616f5fa`.
The original generated input path remains absent and each service's launch
working directory remains empty. The two private manifests have SHA-256:

- Basic: `e0079c595618a5e036da033efcae78c61ccb13193769e365835bedc4f53dc320`.
- Lost acknowledgement: `954a1d6cfacd87f7a222bd69ce5e7217ca0e46045b25644067dc75d0dd3ea59c`.

Independent read-only SQLite inspection found basic tenant A/B claim and delivery
counts **5/5 and 1/1**, with **10 and 2** effect events. The lost-acknowledgement
case has **3 claims, 3 deliveries and 6 effect events** for tenant A and none for
tenant B (`794caf`). The tests independently verify event signatures/linkage,
unchanged state/events at restart and no new provider request from reopening.
The three copied source/runtime/asset tamper cases fail actual native admission
before creating state or performing provider work.

The browser-verification skills prompted visual inspection as well as assertions.
Their CLI is unavailable, so the existing pinned Playwright driver supplied real
screenshots, console/foreign-request checks and keyboard/control assertions.
Inspected initial connection, completed model/tool response, mobile retained
history and lost-acknowledgement screenshots. The mobile capture shows retained
history while its operation-status check is still pending; it is not a screenshot
of a settled status. Separate test assertions establish completed turns and
restart behavior. The loss screenshot explicitly warns that work may have been
accepted and offers only an explicit same-submission retry.

This closes the targeted copied-deployment test boundary, not M7. Main integration,
the complete unchanged source gate, actual product configuration, fresh Linux
x86_64 installation, dependency/provenance/SBOM evidence, versioned upgrades and
the full remaining M0–M8 criteria are still required. No public deployment,
provider spend, runtime-pin change or sibling-repository change occurred.

## Working-tree integration

All four deployment builder/test/documentation files were integrated after the
run terminated, under exact source hashes and absent-destination preconditions.
The post-result documentation snapshot had aggregate
`6a3761c648fd2cc7d8f0cdadb7bc83644b90ee6826d1164f00bbb9d0e3eccf27`
(`52aee8`), distinct from the tested snapshot above. All four copied files matched
before this integration-status documentation update (`794e30`). No application,
native, original browser-driver, compiler-pin or regression-gate source changed.
Main now collects 3,778 tests; whole-tree F/E9 lint passes. The complete original
`ci.sh` must pass against the integrated bytes before claiming a source-gate pass.

## Explicit v10 storage admission (2026-10-28)

The builder also accepts the explicit v10 profile described in
[native-service.md](native-service.md#explicit-v10-durable-storage-admission).
Its storage policy must name an existing inventoried function; no extra worker
slot or execution authority is introduced. The opaque parameters, namespace
allocation, numeric limits and every other non-path field are copied unchanged.
The builder checks inventory shape only. The actual native/SIGIL bootstrap must
admit the tenant mapping before any state opens. v9 cannot carry this new field;
v10 cannot omit it or use null. Schema-1 state is never converted by the builder.
The bound v10 service also persists its complete admission identity. Copying or
changing paths, policy parameters or artifacts changes the bundle and cannot be
used to relabel or reopen an existing bound deployment. Unbound experimental
schema-2 stores require an explicit migration; this tool cannot adopt them.

All 61 build-time cases pass, including the original v9 checks, exact v10 policy
preservation and eight malformed/mismatched storage-profile cases. The copied
v10 browser stories and original v9 deployment/service regressions are running
in the isolated integration stage; no runtime pass is inferred from build tests.
Results and sources are being retained under
`dist/mvp-evidence/2026-10-28/storage-admission/`. Clean Linux installation,
candidate provenance, operational settings and the full M7 gate remain open.


## Funded workspace development profile (v11, schema 6)

`config/completion-capacity-development.json` opts the existing workspace builder
into one SIGIL application shared by chat and API, with whole-turn logical
capacity reserved before HTTP 202. The new entry contract is AH8/HC8; automatic
transactions use TX2. This profile includes the existing approved C/Python build
and test tools. Python composes deployment files at build time; no Python process
owns the production turn or API decisions.

Build the native host with the pinned Rust toolchain, then pass
`--profile config/completion-capacity-development.json` to
`scripts/build_workspace_deployment.py` with the workspace, output, pinned runtime
and stdlib paths used by the workspace recipe. Supply `SIGIL_PI_TOKEN`,
`SIGIL_PI_LOCAL_PROVIDER_TOKEN` (a local placeholder), and a fresh private
`SIGIL_PI_AUDIT_KEY` of at least 32 bytes to the native process. Keep the audit key
stable across reopening that deployment. Do not use the test fixture audit key.
The host starts with `init service.json 0 --public-assets public-assets.json`;
subsequent starts use `open` with the original configuration and state. Source,
runtime, evaluator, allocation and authority bindings remain admitted identities.

This requires a **new empty deployment**. It does not upgrade existing schema-2
state or silently change older v3–v10 profiles. The generic v9/v10 staging tool
has not been extended to package v11; this is the explicit workspace development
builder, not the immutable Linux release gate.

SIGIL restricts a turn to at most 20 model responses, four tools per response,
128 KiB retained history, and 64 KiB tool results. Native execution independently
bounds serialized observations to 64 KiB; an oversized possibly-delivered result
becomes uncertain instead of an invented successful observation. Tool batching
is sequential and cannot enlarge the admitted envelope. Long conversations stop
at their history limit; compaction remains an MVP requirement.

For `S` model steps, reserve `A = 5*S` possible actions. The compiled policy holds
`8*A + 16` records and `2 MiB*A + 8 MiB` of data allowance. Each action debits at
most 3 records/512 KiB for claim, 2/512 KiB for result, and 3/1 MiB for
interpretation. These allowances include signed entry/head writes and bounded
state/next-intent growth. The additional allowance covers cancellation, terminal
settlement and one uncertain retirement. Initial admission writes are charged
separately in the same atomic reservation commit. A larger batch or result is
refused or terminates truthfully before it can grow the funded envelope.

The native authenticated log bounds payloads to 8192 bytes and encodes at most
`6*8192 + 1024 = 50176` bytes per entry. SIGIL reserves `3*A + 1` effect entries
and `A + 3` transaction entries, each at that byte ceiling. Native admission
checks the requested byte allowance against the actual admitted log ceiling.
At S=20 the data hold is 816 records/208 MiB; effect and transaction audit holds
are respectively 301/103 entries and 15,102,976 bytes/5,168,128 bytes. Exact
calculations and configured limits are retained with milestone evidence.
The conservative effect-audit hold permits one maximum-size active turn per
tenant at the default 16 MiB chain limit. After its unused allowance is returned,
another turn can be admitted while sufficient room remains. A larger advertised
concurrency envelope requires separate quota and load qualification.

Each tenant has its own namespace pool (10,000 records, 512 MiB), two signed
chains (10,000 entries/16 MiB each), and 128 reservation slots. Closed reservation
rows remain causal records and **still occupy slots**. Reaching any admission
limit returns HTTP 429 `completion_capacity_exhausted` before a model or tool is
called. The browser explains this result. No automatic deletion or slot recycling
is implemented; retention and operational capacity planning remain separate gates.

Each effect witnesses the actual intent and original operation reservation.
Cancellation can debit the same ledger while work is in flight. A completion
refreshes only the same assignment with monotonically reduced allowance; it
cannot adopt a returned or different assignment. Signed result publication and
credit debit/return are atomic. Terminal settlement returns all unused data and
both audit allowances, at most once.

A store execution lease excludes reopening while a surviving SIGIL effect
process can still act. Once exclusion is actually established, recovery records
uncertainty with prior/current owner identity and does not replay the effect.
For Docker-backed commands, a host lease does not prove the external engine has
stopped a container. Those commands run on private offline snapshots under an
independent deadline; recovery preserves an unknown outcome and does not invent
reaping or rollback. A new command cannot take an occupied execution slot.

These are logical quota guarantees, not physical disk preallocation or protection
against media failure. Full-disk behavior, backup/restore, supported Linux
packaging, long-duration load, independent review and operator signoff remain
unqualified. Keys stay in the native owner; the SIGIL application selects policy
and receives scoped mechanisms and observed facts.


## Conversation archive development profile

`config/conversation-lifecycle-development.json` opts the funded builder into
`archive-v1`. Pass it with `--profile` to the same workspace builder. Use a new
empty output and state directory; reopen only the unchanged generated deployment.
This is still native v11/schema 6, with explicitly different SIGIL artifacts and
a seventh, tenant-scoped API storage grant. Tool workers and the automatic
coordinator receive no archive access.

Before a follow-up replaces settled state, SIGIL atomically preserves the exact
prior state and settled operation result in the tenant's archive. A rejected
admission creates no partial archive, and repeated submissions use existing
deduplication. The current turn remains in current state until another admission.
Failed, cancelled and uncertain outcomes remain exactly as observed. These
internal snapshots include overlapping context and authority facts; they must
never be returned as raw public exports.

The [lifecycle contract](mvp-lifecycle-contract.md) specifies the record, identity
and future retention requirements. This first slice does not reduce model
context, expire archives, recycle execution identities or expose a public archive
API. The current history route still reports retained context. Qualification
and review evidence is tracked in the MVP dependency graph; the profile does not
claim full MVP readiness.
