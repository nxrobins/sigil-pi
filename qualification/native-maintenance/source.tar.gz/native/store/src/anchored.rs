//! Explicit fresh schema-7 store with independent, inode-bound restore authority.
//! This profile is still a candidate; existing profiles are not adopted.
use super::*;
use sigil_worker_bridge::execution_fence::{ExecutionFence, OpenMode as FenceMode};

#[cfg(test)]
thread_local! {
    pub(super) static ROOT_CALLS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

pub const FORMAT: &str = "sigil-anchored-reservation/v1";

pub(super) fn fault(value: restore_anchor::Failure) -> Error {
    use restore_anchor::Failure as F;
    match value {
        F::Busy => Error::Busy,
        F::Io => Error::Storage,
        F::Exhausted => Error::Limit,
        F::ReopenRequired => Error::ReopenRequired,
        F::Corrupt | F::Ambiguous => Error::Corrupt,
        _ => Error::Denied,
    }
}

pub(super) fn snapshot(connection: &Connection, profile: u8) -> Result<[u8; 32]> {
    let tx = connection
        .unchecked_transaction()
        .map_err(|_| Error::Storage)?;
    root(&tx, profile)
}

/// Hash every logical value, including tombstones, metadata, reservations and
/// authenticated logs (opaque records). The caller owns a consistent transaction.
/// Physical free pages and SQLite's change counter are not logical state.
pub(super) fn root(connection: &Connection, profile: u8) -> Result<[u8; 32]> {
    #[cfg(test)]
    ROOT_CALLS.with(|count| count.set(count.get() + 1));
    if profile != 7 {
        return Err(Error::Invalid);
    }
    let mut h = Sha256::new();
    h.update(b"sigil-canonical-store-state/v1\0");
    for pragma in ["application_id", "user_version"] {
        let value: i64 = connection
            .pragma_query_value(None, pragma, |r| r.get(0))
            .map_err(|_| Error::Corrupt)?;
        h.update(value.to_be_bytes());
    }
    let definitions = {
        let mut stmt = connection
            .prepare(
                "SELECT name,sql FROM sqlite_schema WHERE name NOT GLOB 'sqlite_*' ORDER BY name",
            )
            .map_err(|_| Error::Corrupt)?;
        stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)))
            .map_err(|_| Error::Corrupt)?
            .collect::<std::result::Result<Vec<_>, _>>()
            .map_err(|_| Error::Corrupt)?
    };
    if definitions != Store::definitions(profile) {
        return Err(Error::Corrupt);
    }
    for (name, sql) in definitions {
        for value in [name.as_bytes(), sql.as_bytes()] {
            h.update((value.len() as u64).to_be_bytes());
            h.update(value);
        }
    }
    for query in [
        "SELECT * FROM meta ORDER BY id",
        "SELECT * FROM records ORDER BY namespace,key",
        "SELECT * FROM reservation_slots ORDER BY pool,slot",
        "SELECT * FROM reservations ORDER BY namespace,key",
    ] {
        h.update((query.len() as u64).to_be_bytes());
        h.update(query);
        let mut stmt = connection.prepare(query).map_err(|_| Error::Corrupt)?;
        let columns = stmt.column_count();
        h.update((columns as u64).to_be_bytes());
        let mut rows = stmt.query([]).map_err(|_| Error::Corrupt)?;
        while let Some(row) = rows.next().map_err(|_| Error::Corrupt)? {
            h.update([1]);
            for index in 0..columns {
                use rusqlite::types::ValueRef as V;
                match row.get_ref(index).map_err(|_| Error::Corrupt)? {
                    V::Null => h.update([0]),
                    V::Integer(n) => {
                        h.update([1]);
                        h.update(n.to_be_bytes());
                    }
                    V::Text(s) => {
                        h.update([2]);
                        h.update((s.len() as u64).to_be_bytes());
                        h.update(s);
                    }
                    V::Blob(b) => {
                        h.update([3]);
                        h.update((b.len() as u64).to_be_bytes());
                        h.update(b);
                    }
                    V::Real(_) => return Err(Error::Corrupt),
                }
            }
        }
        h.update([0]);
    }
    Ok(h.finalize().into())
}

impl Store {
    #[allow(clippy::too_many_arguments)]
    pub fn open_anchored_reserved_bound(
        root: &Path,
        authority: &Path,
        mode: OpenMode,
        limits: Limits,
        mut allocation: capacity::Allocation,
        admission: [u8; 32],
        slots: BTreeMap<String, u16>,
    ) -> Result<Self> {
        limits.validate()?;
        allocation.validate(&limits)?;
        reservation::catalog::validate(&allocation, &slots)?;
        let data_path = root.canonicalize().map_err(|_| Error::Denied)?;
        let authority_path = authority.canonicalize().map_err(|_| Error::Denied)?;
        if !authority.is_absolute()
            || authority_path != authority
            || authority.starts_with(&data_path)
            || data_path.starts_with(authority)
        {
            return Err(Error::Denied);
        }
        let execution = ExecutionFence::open(
            root,
            match mode {
                OpenMode::CreateNew => FenceMode::CreateNew,
                OpenMode::Existing => FenceMode::Existing,
            },
        )
        .map_err(|e| {
            if e == sigil_worker_bridge::Fault::Busy {
                Error::Busy
            } else {
                Error::Denied
            }
        })?;
        let mut h = Sha256::new();
        h.update(b"sigil-anchored-storage-admission/v1\0");
        h.update(admission);
        let domain = execution.identity().map_err(|_| Error::Denied)?;
        h.update((domain.len() as u64).to_be_bytes());
        h.update(domain);
        let context: [u8; 32] = h.finalize().into();
        Self::open_inner(
            root,
            mode,
            limits,
            Some(allocation),
            Some(context),
            7,
            Some(slots),
            Some(execution),
            Some((authority, context)),
        )
    }
}

#[cfg(test)]
#[path = "anchored_tests.rs"]
mod tests;
