//! Explicit schema-6 storage ownership coupled to the actual local execution
//! fence. Reopening cannot bypass a surviving holder by acquiring only SQLite's
//! separate owner lock. This is not yet a per-assignment cleanup/recovery policy.
use super::*;
use sigil_worker_bridge::execution_fence::{ExecutionFence, ExecutionLease, OpenMode as FenceMode};

pub const FORMAT: &str = "sigil-fenced-audited-reservation-witness/v1";
fn fault(e: sigil_worker_bridge::Fault) -> Error {
    if e == sigil_worker_bridge::Fault::Busy {
        Error::Busy
    } else {
        Error::Denied
    }
}
impl Store {
    pub fn has_execution_fence(&self) -> bool {
        self.execution.is_some()
    }

    pub fn open_fenced_reserved_bound(
        root: &Path,
        mode: OpenMode,
        limits: Limits,
        mut allocation: capacity::Allocation,
        admission: [u8; 32],
        reservation_slots: BTreeMap<String, u16>,
    ) -> Result<Self> {
        // All caller configuration is checked before creating a fence or DB.
        limits.validate()?;
        allocation.validate(&limits)?;
        reservation::catalog::validate(&allocation, &reservation_slots)?;
        let execution = ExecutionFence::open(
            root,
            match mode {
                OpenMode::CreateNew => FenceMode::CreateNew,
                OpenMode::Existing => FenceMode::Existing,
            },
        )
        .map_err(fault)?;
        let domain = execution.identity().map_err(fault)?;
        let mut binding = Sha256::new();
        for part in [
            b"sigil-fenced-storage-admission/v1".as_slice(),
            admission.as_slice(),
            domain.as_bytes(),
        ] {
            binding.update((part.len() as u64).to_be_bytes());
            binding.update(part);
        }
        Self::open_inner(
            root,
            mode,
            limits,
            Some(allocation),
            Some(binding.finalize().into()),
            6,
            Some(reservation_slots),
            Some(execution),
            None,
        )
    }
    /// Bootstrap-only lease issuance from this actual admitted store. This API
    /// adds no guest scope and cannot be supplied a replacement lock or PID.
    pub fn execution_lease(&self) -> Result<ExecutionLease> {
        self.verify_files()?;
        self.execution_issued.set(true);
        self.execution
            .as_ref()
            .ok_or(Error::Invalid)?
            .lease()
            .map_err(fault)
    }
    /// Public identity facts are not spending or cleanup authority.
    pub fn execution_identity(&self) -> Result<(&str, &str)> {
        self.verify_files()?;
        let execution = self.execution.as_ref().ok_or(Error::Invalid)?;
        Ok((
            execution.identity().map_err(fault)?,
            execution.epoch().map_err(fault)?,
        ))
    }
}

#[cfg(test)]
#[path = "fenced_tests.rs"]
mod tests;
