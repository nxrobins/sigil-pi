//! Reservation/assignment mechanics. Controlled protocol workers are not SIGIL
//! policy qualification; no supplied observation here is a public result API.
use super::*;
use crate::claimed::completion_tests::{fund_fixture, fund_retirement_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, process_guard};
use serde_json::Value;
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use sigil_worker_bridge::{Fault, Observation};

#[test]
fn retirement_without_original_third_audit_allowance_refuses_before_claim_or_effect() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, _) = fund_retirement_fixture(Fixture::fenced(13), 2, "4");
    let owner = owner(&f.store);
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    assert!(matches!(
        attempt.claim_recorded(&mut recorder),
        Err("funding_audit")
    ));
    drop(attempt);
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap()
            .revision,
        1
    );
    assert!(!f.directory.path().join("started").exists());
}

#[test]
fn retirement_credit_is_originally_bound_and_survives_uncertain_result_publication() {
    let _serial = process_guard();
    let (mut f, mut recorder, funding, origin) =
        fund_retirement_fixture(Fixture::fenced(13), 3, "4");
    let owner = owner(&f.store);
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    attempt.claim_recorded(&mut recorder).unwrap();
    let generation = attempt.prepared().generation.clone();
    let observed = Observation {
        generation,
        request_may_have_run: true,
        worker_reaped: false,
        fault: Some(Fault::CleanupUnconfirmed),
        result: None,
    };
    let (phase, _) = attempt
        .persist_observation(&mut recorder, Some(&observed), None)
        .unwrap();
    assert_eq!(phase, "4");
    assert!(attempt.take_returned_credit().is_none());
    drop(attempt);
    let assigned = f
        .store
        .reservation_snapshot(&owner, "funds", "operation:1")
        .unwrap();
    assert_eq!(assigned.revision, 3);
    assert_ne!(assigned.binding, origin);
    assert_eq!(
        assigned.credits,
        Credits {
            records: 5,
            live_bytes: 40000
        }
    );
    let witness: Value = serde_json::from_slice(&assigned.assignment).unwrap();
    assert_eq!(witness["format"], "sigil-completion-assignment/v3");
    assert_eq!(
        witness["retirement"],
        serde_json::json!({"records":1,"live_bytes":5000})
    );
    let held = f
        .store
        .resume_reservation(&owner, "funds", "operation:1", 3, assigned.binding)
        .unwrap();
    let log = AuthenticatedLog::new(
        &f.store,
        "audit.heads",
        "audit.entries",
        ChainLimits {
            payload_bytes: 1024,
            records: 3,
            bytes: 1_000_000,
        },
        b"native-effect-audit-test-key-0123456789",
    )
    .unwrap();
    log.check_held_allowance(&held, &"a".repeat(64), 1, log.encoded_entry_ceiling())
        .unwrap();
    assert!(
        log.check_held_allowance(&held, &"a".repeat(64), 2, 2 * log.encoded_entry_ceiling())
            .is_err()
    );
    assert_eq!(
        f.store
            .get(&owner, "delivery", "operation:1")
            .unwrap()
            .revision,
        1
    );
    assert!(!f.directory.path().join("started").exists());
}

#[test]
fn retirement_budget_cannot_exceed_original_credit_or_opt_into_legacy_profile() {
    let _serial = process_guard();
    for (profile, credit) in [
        (
            6,
            Credits {
                records: 0,
                live_bytes: 1,
            },
        ),
        (
            6,
            Credits {
                records: 6,
                live_bytes: 1,
            },
        ),
        (
            6,
            Credits {
                records: 1,
                live_bytes: 40001,
            },
        ),
        (
            6,
            Credits {
                records: u64::MAX,
                live_bytes: 1,
            },
        ),
        (
            5,
            Credits {
                records: 1,
                live_bytes: 1,
            },
        ),
    ] {
        let fixture = if profile == 6 {
            Fixture::fenced(13)
        } else {
            Fixture::witnessed(13)
        };
        let (f, _recorder, mut funding, _) = fund_fixture(fixture, 2, "4");
        let result = funding.identity.fund_with_retirement(
            &f.store,
            funding.held.take().unwrap(),
            funding.budget,
            credit,
        );
        assert!(result.is_err());
        assert_eq!(
            f.store
                .reservation_snapshot(&owner(&f.store), "funds", "operation:1")
                .unwrap()
                .revision,
            1
        );
        assert!(!f.directory.path().join("started").exists());
    }
}

#[test]
fn retirement_assignment_cannot_bypass_third_allowance_with_unsigned_recorder() {
    let _serial = process_guard();
    let (mut f, signed, funding, _) = fund_retirement_fixture(Fixture::fenced(13), 3, "4");
    drop(signed);
    let mut recorder = crate::claimed::audit_tests::admitted_recorder(f.directory.path(), "4");
    let owner = owner(&f.store);
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    assert!(matches!(
        attempt.claim_recorded(&mut recorder),
        Err("funding_audit")
    ));
    drop(attempt);
    assert_eq!(
        f.store
            .get(&owner, "claim", "operation:1")
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        f.store
            .reservation_snapshot(&owner, "funds", "operation:1")
            .unwrap()
            .revision,
        1
    );
    assert!(!f.directory.path().join("started").exists());
}
