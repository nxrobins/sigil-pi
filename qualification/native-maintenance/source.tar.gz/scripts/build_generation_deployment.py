"""Fresh development profile with durable allocation identities; not qualified."""
import hashlib
import json
from pathlib import Path
from scripts.build_context_window_deployment import build as build_base
from scripts.compose_generation_api import compose_generation_api
from scripts.compose_generation_admission import compose_generation_admission
from scripts.compose_generation_coordinator import compose_generation_coordinator
from scripts.compose_generation_transaction import compose_generation_transaction, SHAPES
from scripts.compose_dispatch_journal import with_dispatch_journal
from scripts.workspace_deployment import fields


def build(root, workspace, runtime, evaluator, stdlib, token, profile, *, restore_authority, endpoint=None, base_config=None):
    root=Path(root).resolve()
    authority=Path(restore_authority)
    if not authority.is_absolute() or authority.exists() or authority.is_relative_to(root) or root.is_relative_to(authority):
        raise ValueError("fresh independent authority outside deployment tree required")
    programs={"api_discovery":compose_generation_api(stdlib),
        "generation_admission":compose_generation_admission(stdlib),
        "coordinator":compose_generation_coordinator(stdlib),
        **{name:compose_generation_transaction(name,stdlib) for name in SHAPES}}
    if profile.get("dispatch_journal") is not None:
        programs={name:with_dispatch_journal(source) for name,source in programs.items()}
    if base_config is None:
        config,path=build_base(root,workspace,runtime,evaluator,stdlib,token,profile,endpoint=endpoint)
    else:
        config,path=base_config,root/"service.json"
    if config["version"]!=11 or Path(config["state_root"])!=root/"records" or (root/"records").exists():
        raise ValueError("generation assembly requires a fresh funded context deployment")
    config["version"]=12
    config["storage"]["restore_authority"]=str(authority)
    def bind(worker,name):
        source=root/(name+".sigil");source.write_text(programs[name].text)
        worker.update(source=str(source),source_sha256=programs[name].compiler_input_sha256)
    bind(config["worker"],"api_discovery")
    config["functions"]["generation_admission"]=dict(config["functions"]["admission"])
    bind(config["functions"]["generation_admission"],"generation_admission")
    for p in config["automatic"]["participants"]:
        bind(p["worker"],"coordinator")
        row=next(row for row in config["credentials"] if row["sha256"]==p["credential_sha256"])
        ns=fields(row["facts"],"CF2\n",15)[13]
        for alias,name,index in [("interpret","turn_completion",1),("settle","settlement",0),("preclaim","preclaim_cancellable",0)]:
            tx=p["transactions"][alias];old,count,new=SHAPES[name]
            if tx["marker"]!=old+"\n" or len(tx["inputs"])!=count:
                raise ValueError("generation transaction requires the exact prior input template")
            bind(tx["worker"],name)
            tx["marker"]=new+"\n"
            tx["inputs"] += [{"kind":"reservation","namespace":ns,"key":{"kind":"value","index":index}},
                {"kind":"read","namespace":ns,"key":{"kind":"prefixed_value","prefix":"generation:","index":index}}]
    path.write_text(json.dumps(config,indent=2)+"\n")
    inputs={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob("*")) if p.is_file() and p.name!="build-inputs.json"}
    (root/"build-inputs.json").write_text(json.dumps(inputs,indent=2)+"\n")
    return config,path
