//! Fixed pure transaction producer over actual scoped snapshots. No application
//! phase, account, tenant, operation or recovery decision is interpreted here.
use crate::action::{admit_time, commit_batch};
use crate::evaluation_audit::{Failure, Lookup, Pending, Subject};
use crate::policy::Input;
use crate::{Function, Result, fields, frame, now};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sigil_durable_store::store::{Access, Batch, ReadKey, Receipt, Record, Scope, Store};
use sigil_worker_bridge::Config as WorkerConfig;
use std::collections::{BTreeMap, BTreeSet};
use std::time::{Duration, Instant};

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub worker: WorkerConfig,
    pub marker: String,
    pub values: usize,
    pub inputs: Vec<Input>,
    pub grants: BTreeMap<String, Access>,
}
pub struct Transaction {
    function: Function,
    subject: Subject,
    pending_evaluation: Option<Pending>,
    marker: String,
    count: usize,
    inputs: Vec<Input>,
    scope: Scope,
}
/// Keep the actual admitted pure worker and bound templates across bootstrap;
/// do not re-read a different program when application storage is opened later.
pub(crate) struct Admitted {
    function: Function,
    subject: Subject,
    marker: String,
    count: usize,
    inputs: Vec<Input>,
    grants: BTreeMap<String, Access>,
}
impl Admitted {
    pub(crate) fn open(self, store: &Store) -> Result<Transaction> {
        Ok(Transaction {
            function: self.function,
            subject: self.subject,
            pending_evaluation: None,
            marker: self.marker,
            count: self.count,
            inputs: self.inputs,
            scope: store.scope(self.grants).map_err(|_| "config")?,
        })
    }
}
/// Host-created observations of a completed pure producer. Not deserializable
/// and never accepted as an invocation argument or an external-effect result.
pub(crate) struct Prepared {
    pub funding: Option<crate::capacity::Spend>,
    pub context: [String; 2],
    pub batch: Option<Batch>,
    pub deadline: Instant,
    pub facts: Vec<String>,
}
fn digest(raw: &str) -> String {
    format!("{:x}", Sha256::digest(raw.as_bytes()))
}
#[derive(Serialize)]
pub struct Applied {
    /// Opaque SIGIL-owned data, never an execution or storage capability.
    pub context: [String; 2],
    /// Present only for this invocation's actual acknowledged commit.
    pub receipt: Option<Receipt>,
}
type Reads = BTreeMap<(String, String), u64>;

/// Reuse the Store's bounded, fully verified read snapshot during maintenance.
/// This caches observations for one preparation only, never across a commit.
/// Larger sets retain the existing read path and its original input ceiling.
fn maintenance_records(
    store: &mut Store,
    scope: &Scope,
    inputs: &[Input],
    values: &[String],
) -> Result<BTreeMap<(String, String), Record>> {
    let mut keys = BTreeSet::new();
    for input in inputs {
        if let Input::Read { namespace, key } = input {
            keys.insert((namespace.clone(), key.resolve(values)?));
        }
    }
    if keys.is_empty() || keys.len() > sigil_durable_store::store::READ_SET_ITEMS {
        return Ok(BTreeMap::new());
    }
    let requests: Vec<_> = keys
        .iter()
        .map(|(namespace, key)| ReadKey {
            namespace: namespace.clone(),
            key: key.clone(),
        })
        .collect();
    match store.get_many(scope, &requests) {
        Ok(records) => Ok(keys.into_iter().zip(records).collect()),
        // get_many's aggregate value limit is smaller than the transaction
        // envelope. Preserve previously admitted larger inputs without raising
        // either limit or accepting a partial read-set result.
        Err(sigil_durable_store::store::Error::Limit) => Ok(BTreeMap::new()),
        Err(_) => Err("storage"),
    }
}

impl Transaction {
    pub(crate) fn take_failure(&mut self, code: &'static str) -> Option<Failure> {
        self.pending_evaluation
            .take()
            .map(|pending| pending.refuse(&self.subject, code))
    }

    pub(crate) fn inspect_owner(&self) -> Result<()> {
        self.function.inspect_owner()
    }

    /// Admit bound templates before application storage is initialized.
    pub(crate) fn validate_config(config: &Config) -> Result<()> {
        if config
            .inputs
            .iter()
            .filter(|input| matches!(input, Input::Reservation { .. }))
            .count()
            > 1
            || config.marker.len() != 4
            || !config.marker.as_bytes()[..3]
                .iter()
                .all(u8::is_ascii_alphanumeric)
            || !config.marker.ends_with('\n')
            || config.values > 16
            || config.inputs.is_empty()
            || config.inputs.len() > 32
        {
            return Err("config");
        }
        Store::validate_grants(&config.grants).map_err(|_| "config")?;
        for input in &config.inputs {
            match input {
                Input::WorkerFacts | Input::CredentialFacts | Input::Bundle => {
                    return Err("config");
                }
                Input::Value { index } if *index >= config.values => return Err("config"),
                Input::Literal { value } if value.len() > 16384 => return Err("config"),
                Input::Read { namespace, key } | Input::Reservation { namespace, key }
                    if !matches!(
                        config.grants.get(namespace),
                        Some(Access::Read | Access::ReadWrite)
                    ) || !key.valid(config.values) =>
                {
                    return Err("config");
                }
                _ => {}
            }
        }
        Ok(())
    }

    pub fn new(config: Config, store: &Store) -> Result<Self> {
        Self::admit(config)?.open(store)
    }

    pub(crate) fn admit(config: Config) -> Result<Admitted> {
        Self::admit_with(config, Function::new)
    }
    pub(crate) fn admit_cached(config: Config) -> Result<Admitted> {
        Self::admit_with(config, Function::cached)
    }
    fn admit_with(
        config: Config,
        construct: fn(WorkerConfig) -> Result<Function>,
    ) -> Result<Admitted> {
        Self::validate_config(&config)?;
        let subject = Subject::new(&config, &config.worker, &config.grants)?;
        Ok(Admitted {
            subject,
            function: construct(config.worker)?,
            marker: config.marker,
            count: config.values,
            inputs: config.inputs,
            grants: config.grants,
        })
    }

    /// Hold the Store exclusively across reads, pure evaluation and exact commit.
    /// Callers supply bounded lookup values, never snapshots, proposals or receipts.
    pub fn apply(
        &mut self,
        store: &mut Store,
        last_clock: &mut u64,
        values: &[String],
    ) -> Result<Applied> {
        let plan = self.prepare(store, last_clock, values)?;
        if plan.funding.is_some() {
            return Err("funding_profile");
        }
        let receipt = match plan.batch {
            Some(batch) => {
                admit_time(None, last_clock, plan.deadline, now)?;
                Some(store.commit(&self.scope, &batch).map_err(|_| "storage")?)
            }
            None => None,
        };
        Ok(Applied {
            context: plan.context,
            receipt,
        })
    }

    /// Distinct maintenance mechanism for an independently acquired owner that
    /// has never issued execution leases. SIGIL selects the retained causal
    /// records; Store enforces actual exclusion, zero credits and exact identity.
    /// No live execution is cancelled, no allowance is released and no latest
    /// allocation is adopted here. Ordinary transaction entry points are unchanged.
    pub fn retire_generation(
        &mut self,
        store: &mut Store,
        last_clock: &mut u64,
        values: &[String],
    ) -> Result<Applied> {
        if !store.has_reservation_generations()
            || self
                .inputs
                .iter()
                .filter(|v| matches!(v, Input::Reservation { .. }))
                .count()
                != 1
        {
            return Err("funding_profile");
        }
        let plan = self.prepare_inner(store, last_clock, values, true)?;
        let receipt = match (plan.batch, plan.funding) {
            (None, None) => None,
            (Some(batch), Some(funding))
                if funding.release && funding.records == 0 && funding.live_bytes == 0 =>
            {
                let retirement = funding
                    .identity
                    .as_ref()
                    .ok_or("funding_identity")?
                    .retirement(&funding.namespace, &funding.key)?;
                admit_time(None, last_clock, plan.deadline, now)?;
                Some(
                    store
                        .commit_retiring_reservation(&self.scope, &batch, &retirement)
                        .map_err(|e| {
                            if e == sigil_durable_store::store::Error::CommitUncertain {
                                "commit_uncertain"
                            } else {
                                "retirement_refused"
                            }
                        })?,
                )
            }
            _ => return Err("funding_profile"),
        };
        Ok(Applied {
            context: plan.context,
            receipt,
        })
    }

    pub(crate) fn prepare(
        &mut self,
        store: &mut Store,
        last_clock: &mut u64,
        values: &[String],
    ) -> Result<Prepared> {
        self.prepare_inner(store, last_clock, values, false)
    }

    fn prepare_inner(
        &mut self,
        store: &mut Store,
        last_clock: &mut u64,
        values: &[String],
        maintenance: bool,
    ) -> Result<Prepared> {
        self.pending_evaluation = None;
        if values.len() != self.count || values.iter().any(|v| v.len() > 512) {
            return Err("protocol");
        }
        let started = Instant::now();
        let deadline = started + Duration::from_millis(self.function.timeout_ms);
        admit_time(None, last_clock, deadline, now)?;
        let at = last_clock.to_string();
        let records = if maintenance {
            maintenance_records(store, &self.scope, &self.inputs, values)?
        } else {
            BTreeMap::new()
        };
        let mut parts = Vec::new();
        let mut reads = BTreeMap::new();
        let mut reservation = None;
        let mut bytes = 4usize;
        for input in &self.inputs {
            let value = match input {
                Input::Literal { value } => value.clone(),
                Input::Value { index } => values[*index].clone(),
                Input::Clock => at.clone(),
                Input::Read { namespace, key } => {
                    let key = key.resolve(values)?;
                    let seen = match records.get(&(namespace.clone(), key.clone())) {
                        Some(record) => record.clone(),
                        None => store
                            .get(&self.scope, namespace, &key)
                            .map_err(|_| "storage")?,
                    };
                    reads.insert((namespace.clone(), key.clone()), seen.revision);
                    frame(
                        "SR1\n",
                        &[
                            "ok",
                            &seen.revision.to_string(),
                            seen.value.as_deref().unwrap_or(""),
                        ],
                    )?
                }
                Input::Reservation { namespace, key } => {
                    let key = key.resolve(values)?;
                    let actual = crate::reservation_identity::observe_wire(
                        store,
                        &self.scope,
                        namespace,
                        &key,
                    )?;
                    let parts = fields(&actual, "GI1\n", 7)?;
                    let identity: crate::reservation_identity::Identity =
                        serde_json::from_str(parts[2]).map_err(|_| "protocol")?;
                    reservation = Some((namespace.clone(), key, identity));
                    actual
                }
                Input::WorkerFacts | Input::CredentialFacts | Input::Bundle => {
                    return Err("config");
                }
            };
            bytes = bytes.checked_add(8 + value.len()).ok_or("limit")?;
            if bytes > 4 * 1024 * 1024 {
                return Err("limit");
            }
            parts.push(value);
        }
        let input = frame(
            &self.marker,
            &parts.iter().map(String::as_str).collect::<Vec<_>>(),
        )?;
        let input_digest = digest(&input);
        let input_bytes = input.len();
        let lookup = Lookup::new(values)?;
        let evaluated = self.function.observe(input, deadline);
        self.pending_evaluation = Some(Pending::new(evaluated.facts, lookup, deadline));
        let (output, selected_timeout) = evaluated.result?;
        let parts = if output.starts_with("TX2\n") {
            fields(&output, "TX2\n", 4)?
        } else {
            fields(&output, "TX1\n", 3)?
        };
        let funding: Option<crate::capacity::Spend> = if parts.len() == 4 && !parts[3].is_empty() {
            Some(
                serde_json::from_value(
                    sigil_worker_bridge::strict::parse(parts[3].as_bytes())
                        .map_err(|_| "protocol")?,
                )
                .map_err(|_| "protocol")?,
            )
        } else {
            None
        };
        if parts[0].len() > 65536 || parts[1].len() > 65536 {
            return Err("limit");
        }
        let context = [parts[0].to_owned(), parts[1].to_owned()];
        admit_time(None, last_clock, deadline, now)?;
        let batch = if parts[2].is_empty() {
            None
        } else {
            let batch = commit_batch(parts[2])?;
            validate(&batch, &reads)?;
            // A reservation fact is useful only for spending that exact observed
            // allocation. SIGIL still compares the retained application identity.
            // The Store checks the returned identity again in the actual commit.
            if let Some((namespace, key, identity)) = &reservation {
                let spend = funding.as_ref().ok_or("funding_identity")?;
                if &spend.namespace != namespace
                    || &spend.key != key
                    || spend.identity.as_ref() != Some(identity)
                {
                    return Err("funding_identity");
                }
            }
            Some(batch)
        };
        let facts = vec![
            at,
            last_clock.to_string(),
            started.elapsed().as_millis().to_string(),
            self.function.fuel.to_string(),
            selected_timeout.to_string(),
            input_digest,
            input_bytes.to_string(),
            digest(&output),
            output.len().to_string(),
            digest(parts[2]),
            parts[2].len().to_string(),
            batch.as_ref().map_or(0, |b| b.checks.len()).to_string(),
            batch.as_ref().map_or(0, |b| b.writes.len()).to_string(),
        ];
        self.pending_evaluation = None;
        Ok(Prepared {
            funding,
            context,
            batch,
            deadline,
            facts,
        })
    }
}

/// Every mutation/precondition names an actual read and its exact revision, and
/// every actual read remains a precondition. No unobserved or unchecked coordinate.
fn validate(batch: &Batch, reads: &Reads) -> Result<()> {
    if batch.writes.is_empty() {
        return Err("binding");
    }
    let mut covered = BTreeSet::new();
    for (namespace, key, revision) in batch
        .checks
        .iter()
        .map(|c| (&c.namespace, &c.key, c.revision))
        .chain(
            batch
                .writes
                .iter()
                .map(|w| (&w.namespace, &w.key, w.revision)),
        )
    {
        let coordinate = (namespace.clone(), key.clone());
        if reads.get(&coordinate) != Some(&revision) || !covered.insert(coordinate) {
            return Err("binding");
        }
    }
    if covered.len() != reads.len() {
        return Err("binding");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use sigil_durable_store::store::{Check, Mutation};

    fn input(key: &str) -> Input {
        Input::Read {
            namespace: "state".into(),
            key: crate::policy::Key::Literal { value: key.into() },
        }
    }

    #[test]
    fn maintenance_read_set_preserves_missing_tombstone_and_duplicate_inputs() {
        use sigil_durable_store::store::{Limits, OpenMode};
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        std::fs::set_permissions(dir.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
        let mut store = Store::open(dir.path(), OpenMode::CreateNew, Limits::default()).unwrap();
        let scope = store
            .scope(BTreeMap::from([("state".into(), Access::ReadWrite)]))
            .unwrap();
        store
            .commit(
                &scope,
                &Batch {
                    checks: vec![],
                    writes: vec![
                        Mutation {
                            namespace: "state".into(),
                            key: "empty".into(),
                            revision: 0,
                            value: Some(String::new()),
                        },
                        Mutation {
                            namespace: "state".into(),
                            key: "deleted".into(),
                            revision: 0,
                            value: None,
                        },
                    ],
                },
            )
            .unwrap();
        let records = maintenance_records(
            &mut store,
            &scope,
            &[
                input("empty"),
                input("deleted"),
                input("missing"),
                input("empty"),
            ],
            &[],
        )
        .unwrap();
        assert_eq!(records.len(), 3);
        for key in ["empty", "deleted", "missing"] {
            assert_eq!(
                records[&("state".into(), key.into())],
                store.get(&scope, "state", key).unwrap()
            );
        }
        assert_eq!(records[&("state".into(), "deleted".into())].revision, 1);
        assert_eq!(records[&("state".into(), "missing".into())].revision, 0);
        let denied = store
            .scope(BTreeMap::from([("other".into(), Access::Read)]))
            .unwrap();
        assert_eq!(
            maintenance_records(&mut store, &denied, &[input("empty")], &[]),
            Err("storage")
        );
    }

    #[test]
    fn maintenance_read_set_keeps_original_large_input_path() {
        use sigil_durable_store::store::{Limits, OpenMode};
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        std::fs::set_permissions(dir.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
        let mut store = Store::open(dir.path(), OpenMode::CreateNew, Limits::default()).unwrap();
        let scope = store
            .scope(BTreeMap::from([("state".into(), Access::ReadWrite)]))
            .unwrap();
        let value = "x".repeat(1_100_000);
        for key in ["a", "b"] {
            store
                .commit(
                    &scope,
                    &Batch {
                        checks: vec![],
                        writes: vec![Mutation {
                            namespace: "state".into(),
                            key: key.into(),
                            revision: 0,
                            value: Some(value.clone()),
                        }],
                    },
                )
                .unwrap();
        }
        assert!(
            maintenance_records(&mut store, &scope, &[input("a"), input("b")], &[])
                .unwrap()
                .is_empty()
        );
        assert_eq!(store.get(&scope, "state", "a").unwrap().value, Some(value));
        assert!(
            maintenance_records(
                &mut store,
                &scope,
                &[input("a"), input("b"), input("c"), input("d")],
                &[]
            )
            .unwrap()
            .is_empty()
        );
    }

    #[test]
    fn maintenance_read_set_refuses_tampering_outside_selected_records() {
        use sigil_durable_store::store::{
            Limits, OpenMode,
            capacity::{Allocation, Pool},
        };
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        for name in ["data", "authority"] {
            let path = dir.path().join(name);
            std::fs::create_dir(&path).unwrap();
            std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o700)).unwrap();
        }
        let data = dir.path().join("data").canonicalize().unwrap();
        let mut store = Store::open_anchored_reserved_bound(
            &data,
            &dir.path().join("authority").canonicalize().unwrap(),
            OpenMode::CreateNew,
            Limits::default(),
            Allocation {
                version: 1,
                pools: vec![Pool {
                    id: "pool".into(),
                    namespaces: vec!["state".into()],
                    records: 100,
                    live_bytes: 1_000_000,
                }],
            },
            [3; 32],
            BTreeMap::from([("pool".into(), 1)]),
        )
        .unwrap();
        let scope = store
            .scope(BTreeMap::from([("state".into(), Access::Read)]))
            .unwrap();
        assert_eq!(
            maintenance_records(&mut store, &scope, &[input("missing")], &[])
                .unwrap()
                .len(),
            1
        );
        let attacker = rusqlite::Connection::open(data.join("records.sqlite")).unwrap();
        attacker
            .execute("UPDATE meta SET revision=revision+1 WHERE id=1", [])
            .unwrap();
        assert_eq!(
            maintenance_records(&mut store, &scope, &[input("missing")], &[]),
            Err("storage")
        );
    }

    fn batch() -> Batch {
        Batch {
            checks: vec![Check {
                namespace: "state".into(),
                key: "conversation".into(),
                revision: 7,
            }],
            writes: vec![Mutation {
                namespace: "output".into(),
                key: "record".into(),
                revision: 0,
                value: Some("opaque".into()),
            }],
        }
    }
    fn reads() -> Reads {
        BTreeMap::from([
            (("state".into(), "conversation".into()), 7),
            (("output".into(), "record".into()), 0),
        ])
    }
    #[test]
    fn exact_observed_coordinates_and_revisions_are_required() {
        assert_eq!(validate(&batch(), &reads()), Ok(()));
        for change in 0..6 {
            let mut b = batch();
            match change {
                0 => b.checks.clear(),
                1 => b.writes.clear(),
                2 => b.writes[0].namespace = "unread".into(),
                3 => b.writes[0].revision = 1,
                4 => b.checks[0].revision = 8,
                _ => b.checks.push(b.checks[0].clone()),
            }
            assert_eq!(validate(&b, &reads()), Err("binding"));
        }
    }
    #[test]
    fn extra_reads_and_duplicate_check_write_coordinates_are_refused() {
        let mut observed = reads();
        observed.insert(("uncovered".into(), "key".into()), 3);
        assert_eq!(validate(&batch(), &observed), Err("binding"));
        let mut b = batch();
        b.writes[0].namespace = "state".into();
        b.writes[0].key = "conversation".into();
        b.writes[0].revision = 7;
        assert_eq!(validate(&b, &reads()), Err("binding"));
    }
}

#[cfg(test)]
#[path = "generation_retirement_tests.rs"]
mod generation_retirement_tests;
