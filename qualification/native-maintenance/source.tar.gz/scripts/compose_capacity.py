"""Explicit funded workspace profile; all admission/budget decisions are SIGIL."""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_storage_admission import compose_storage_admission
from scripts.compose_workspace import compose_workspace

ROOT = Path(__file__).resolve().parent.parent


def compose_capacity(name, stdlib):
    base = (
        compose_storage_admission(ROOT, stdlib)
        if name == "storage"
        else compose_workspace(name, stdlib)
    )
    body = base.text
    inputs = dict(base.input_hashes)

    def replace(old, new, count=1):
        nonlocal body
        if body.count(old) != count:
            raise ValueError(f"funded composition expected {count} sites: {old}")
        body = body.replace(old, new)

    # Every module that validates a PC1 enforces this profile's bounded envelope.
    old = "if tokens < 1 || steps < 1 || history < 1024 || result < 1 { return -400; }"
    if old in body:
        replace(
            old,
            "if tokens < 1 || steps < 1 || steps > 20 || history < 1024 || history > 131072 || result < 1 || result > 65536 { return -400; }",
        )
    old = "pending = append(pending, normalized);"
    if old in body:
        replace(
            old,
            old
            + '\nif array_count(pending) > 4 { return stop(s, "failed", "tool_batch_limit"); }',
        )

    helper_names = {
        "admission",
        "api_discovery",
        "coordinator",
        "turn_completion",
        "settlement",
        "preclaim_cancellable",
    }
    if name in helper_names:
        path = ROOT / "app/pi/completion_capacity.sigil"
        raw = path.read_bytes()
        body += "\n" + raw.decode()
        inputs["app/pi/completion_capacity.sigil"] = hashlib.sha256(raw).hexdigest()

    if name == "admission":
        replace(
            'let t: i64 @Internal = alloc(24);\nput(t, 0, text(kind)); put(t, 1, batch); put(t, 2, guard);\nreturn write_record(t, "AD1\\n", 3);',
            'let t: i64 @Internal = alloc(32);\nput(t, 0, text(kind)); put(t, 1, batch); put(t, 2, guard); put(t, 3, text(""));\nreturn write_record(t, "AD2\\n", 4);',
        )
        replace(
            'return answer("ok", store_commit(checks, w6), write_record(guard, "TG1\\n", 2));',
            'let funded: i64 @Internal = read_record(answer("ok", store_commit(checks, w6), write_record(guard, "TG1\\n", 2)), "AD2\\n", 4);\n'
            'if funded < 0 { return funded; }\nput(funded, 3, capacity_reserve(c, cfg, get(x, 2)));\nreturn write_record(funded, "AD2\\n", 4);',
        )
    elif name == "api_discovery":
        body = body.replace('"AH4\\n"', '"AH8\\n"').replace('"HC4\\n"', '"HC8\\n"')
        replace("arr_len(get(x, 10)) != 3", "arr_len(get(x, 10)) != 4")
        replace(
            '!is_text(item(get(x, 10), 2), "listing")',
            '!is_text(item(get(x, 10), 2), "listing") || !is_text(item(get(x, 10), 3), "storage")',
        )
        replace(
            r"[\"call\",\"commit\",\"metadata\",\"read\",\"reply\"]",
            r"[\"call\",\"commit\",\"metadata\",\"read\",\"reply\",\"reserve\",\"spend\"]",
        )
        replace(
            'read_record(get(x, 7), "AD1\\n", 3)', 'read_record(get(x, 7), "AD2\\n", 4)'
        )
        replace(
            'command("commit", get(planned, 1), text(""), get(x, 5))',
            'command("reserve", get(planned, 1), get(planned, 3), get(x, 5))',
        )
        replace(
            'return command("commit", batch, text(""), text("cancel_commit"));',
            'return command("spend", batch, capacity_spend(get(c, 13), operation, 1, 4096, false), text("cancel_commit"));',
        )
        replace(
            'if !is_text(get(receipt, 0), "ok") { return failure(503, "storage_unavailable"); }',
            'if is_text(get(receipt, 0), "capacity") { return failure(429, "completion_capacity_exhausted"); }\n'
            'if !is_text(get(receipt, 0), "ok") { return failure(503, "storage_unavailable"); }',
            2,
        )
    elif name == "coordinator":
        replace(
            'command("start", get(k, 6), values4(get(k, 2), get(k, 3), get(k, 4), cancel_key(get(k, 2))), text(""),',
            'command("start", get(k, 6), values4(get(k, 2), get(k, 3), get(k, 4), cancel_key(get(k, 2))), capacity_effect(get(c, 13), get(k, 2)),',
        )
        replace(
            'command("recover", get(k, 6), values2(get(c, 11), get(k, 4)), text(""),',
            'command("recover", get(k, 6), values2(get(c, 11), get(k, 4)), values2(get(c, 13), get(k, 2)),',
        )
        original = 'return command("transaction", get(b, 2), values4(get(k, 3), get(k, 2), get(k, 4), get(k, 5)), text(""), next_step(k, "state_read"), 0);'
        replace(
            original,
            'return command("retire", get(k, 6), values2(get(c, 13), get(k, 2)), text(""), next_step(k, "retired"), 0);',
        )
        replace(
            "let step: i64 @Internal = get(k, 0);",
            'let step: i64 @Internal = get(k, 0);\nif is_text(step, "retired") { '
            + original
            + " }",
        )
    elif name in {"turn_completion", "settlement", "preclaim_cancellable"}:
        replace(
            "pub fn tool_main(input_ptr: i64, input_len: i64)",
            "fn capacity_base(input_ptr: i64 @Internal, input_len: i64 @Internal)",
        )
        if name == "turn_completion":
            replace(
                'read_record(slice(input_ptr, input_len), "TF1\\n", 12)',
                'read_record(slice(input_ptr, input_len), "TF2\\n", 13)',
            )
            marker, count, extraction, release = (
                "TF2",
                13,
                "get(x, 12), get(x, 4)",
                "false",
            )
        else:
            marker, count = ("SF1", 9) if name == "settlement" else ("UF2", 17)
            extraction, release = "get(c, 13), get(x, 2)", "true"
        body += f'''
pub fn tool_main(input_ptr: i64, input_len: i64) -> i64 @Internal ! {{ Alloc }} {{
    let raw: i64 @Internal = capacity_base(input_ptr, input_len);
    if raw < 0 {{ return raw; }}
    let x: i64 @Internal = read_record(slice(input_ptr, input_len), "{marker}\\n", {count});
    if x < 0 {{ return x; }}
    '''
        if name != "turn_completion":
            body += 'let c: i64 @Internal = read_record(get(x, 0), "CF2\\n", 15);\nif c < 0 { return c; }\n'
        body += f"return capacity_transaction(raw, {extraction}, {release});\n}}\n"

    body = compact(body)
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError(
            f"funded {name} must preserve source/entry ceilings: {len(body.encode())}"
        )
    inputs["scripts/compose_capacity.py"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    return ApplicationSource(body, inputs, base.stdlib_hash)
