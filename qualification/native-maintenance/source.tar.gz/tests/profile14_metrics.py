"""Qualification-only observations; never reads authority or request bodies."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import time
from test_completion_capacity_service import prepared_service as original_service


@contextmanager
def recorded_service(root, *, mode='init', expected_profile=14):
    directory = Path(os.environ['PI_QUALIFICATION_METRICS_DIR'])
    directory.mkdir(parents=True, exist_ok=True)
    index = 0
    while True:
        path = directory / f'open-{index:03d}.json'
        try:
            with path.open('x') as stream:
                stream.write('{}\n')
            break
        except FileExistsError:
            index += 1
    report = dict(mode=mode, expected_profile=expected_profile, startup_ms=None,
                  requests=[], completed=False, product_qualified=False)
    began = time.monotonic()
    try:
        with original_service(root, mode=mode) as api:
            report['startup_ms'] = (time.monotonic() - began) * 1000
            report['pid'] = api.proc.pid
            report['protocol'] = api.ready['protocol']
            assert report['startup_ms'] < 35000
            assert report['protocol'] == f'sigil-application-host/v{expected_profile}'
            original = api.request
            api.qualification_window = 'functional'
            api.qualification_requests = report['requests']

            def request(*args, **kwargs):
                start = time.monotonic()
                route = args[1] if len(args) > 1 else kwargs.get('path', '')
                row = dict(window=api.qualification_window, status=None,
                    kind='cancel' if route.endswith('/cancel') else 'read' if route else 'submit')
                try:
                    result = original(*args, **kwargs)
                    row['status'] = result[0]
                    return result
                finally:
                    row['elapsed_ms'] = (time.monotonic() - start) * 1000
                    report['requests'].append(row)
                    assert row['elapsed_ms'] < 30000
            api.request = request
            yield api
            report['completed'] = True
    finally:
        report['elapsed_seconds'] = time.monotonic() - began
        path.write_text(json.dumps(report, indent=2) + '\n')
