"""Observed service costs; request latency is not queue latency or a load PASS."""
from contextlib import contextmanager
import json
import math
import time

from test_completion_capacity_service import prepared_service


@contextmanager
def sampled_service(root, report, *, mode="init"):
    began = time.monotonic()
    metrics = dict(mode=mode, startup_ms=None, requests=[], product_qualified=False)
    try:
        with prepared_service(root, mode=mode) as api:
            metrics["startup_ms"] = (time.monotonic() - began) * 1000
            original = api.request

            def request(*args, **kwargs):
                started = time.monotonic()
                observed = dict(method=args[0] if args else kwargs.get("method", "POST"), status=None)
                try:
                    result = original(*args, **kwargs)
                    observed["status"] = result[0]
                    return result
                finally:
                    observed["elapsed_ms"] = (time.monotonic() - started) * 1000
                    metrics["requests"].append(observed)

            api.request = request
            yield api
    finally:
        if "api" in locals() and hasattr(api, "maintenance_events"):
            api.maintenance_events.thread.join(timeout=2)
            metrics["observed_events"] = api.maintenance_events.observed
        metrics["elapsed_ms"] = (time.monotonic() - began) * 1000
        times = sorted(row["elapsed_ms"] for row in metrics["requests"])
        if times:
            metrics.update(first_request_ms=metrics["requests"][0]["elapsed_ms"],
                p50_request_ms=times[math.ceil(len(times)*0.50)-1],
                p95_request_ms=times[math.ceil(len(times)*0.95)-1], max_request_ms=times[-1])
        report.write_text(json.dumps(metrics, indent=2)+"\n")
