//! Read-only fixed source identity for a single external publication lane.
//! This detects replacement and changed bytes; it is not a cross-store lock or
//! a concurrent-writer/rollback guarantee. The embedding must exclude lane reuse.
use super::*;

pub struct FixedSource {
    fixed: FixedSink,
    device: u64,
    inode: u64,
    baseline: Metadata,
    identity: String,
}

/// Actual descriptor-read bytes, never deserialized caller claims.
pub struct SourceObservation {
    identity: String,
    payload_sha256: String,
    bytes: Vec<u8>,
}
impl SourceObservation {
    pub fn identity(&self) -> &str {
        &self.identity
    }
    pub fn payload_sha256(&self) -> &str {
        &self.payload_sha256
    }
    pub fn bytes(&self) -> &[u8] {
        &self.bytes
    }
}

fn unchanged(a: &Metadata, b: &Metadata) -> bool {
    same(a, b)
        && a.len() == b.len()
        && a.mtime() == b.mtime()
        && a.mtime_nsec() == b.mtime_nsec()
        && a.ctime() == b.ctime()
        && a.ctime_nsec() == b.ctime_nsec()
}
impl FixedSource {
    pub fn admit(root: &Path, key: &str, max_bytes: usize) -> Result<Self> {
        let fixed = FixedSink::admit(root, key, max_bytes)?;
        let file =
            open_at(&fixed.directory, &fixed.key, libc::O_RDONLY).map_err(|_| Error::Invalid)?;
        let meta = file.metadata().map_err(|_| Error::Invalid)?;
        if !private(&file, &meta, false) || meta.len() == 0 || meta.len() > max_bytes as u64 {
            return Err(Error::Invalid);
        }
        let identity = crate::digest(
            format!(
                "sigil-fixed-source/v1:{}:{}:{}:{}:{}:{}:{}:{}:{}",
                fixed.identity,
                meta.dev(),
                meta.ino(),
                max_bytes,
                meta.len(),
                meta.mtime(),
                meta.mtime_nsec(),
                meta.ctime(),
                meta.ctime_nsec()
            )
            .as_bytes(),
        );
        let result = Self {
            fixed,
            device: meta.dev(),
            inode: meta.ino(),
            baseline: meta,
            identity,
        };
        result.observe()?;
        Ok(result)
    }
    pub fn identity(&self) -> &str {
        &self.identity
    }
    pub fn observe(&self) -> Result<SourceObservation> {
        self.fixed.check()?;
        let mut file = open_at(&self.fixed.directory, &self.fixed.key, libc::O_RDONLY)
            .map_err(|_| Error::Unconfirmed)?;
        let before = file.metadata().map_err(|_| Error::Unconfirmed)?;
        if !private(&file, &before, false)
            || before.dev() != self.device
            || before.ino() != self.inode
            || !unchanged(&self.baseline, &before)
            || before.len() == 0
            || before.len() > self.fixed.max_bytes as u64
        {
            return Err(Error::Conflict);
        }
        let mut bytes = Vec::new();
        (&mut file)
            .take(self.fixed.max_bytes as u64 + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| Error::Unconfirmed)?;
        let after = file.metadata().map_err(|_| Error::Unconfirmed)?;
        let current = open_at(&self.fixed.directory, &self.fixed.key, libc::O_RDONLY)
            .map_err(|_| Error::Unconfirmed)?;
        let current_meta = current.metadata().map_err(|_| Error::Unconfirmed)?;
        if bytes.len() != before.len() as usize
            || !unchanged(&before, &after)
            || !unchanged(&after, &current_meta)
            || !private(&current, &current_meta, false)
        {
            return Err(Error::Conflict);
        }
        self.fixed.check()?;
        Ok(SourceObservation {
            identity: self.identity.clone(),
            payload_sha256: crate::digest(&bytes),
            bytes,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::{PermissionsExt, symlink};

    #[test]
    fn fixed_source_observes_actual_bytes_and_refuses_replacement_or_widened_access() {
        let root = tempfile::tempdir().unwrap();
        let root_path = root.path().canonicalize().unwrap();
        std::fs::set_permissions(&root_path, std::fs::Permissions::from_mode(0o700)).unwrap();
        let path = root_path.join("intent");
        std::fs::write(&path, b"original").unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
        let source = FixedSource::admit(&root_path, "intent", 64).unwrap();
        let first = source.observe().unwrap();
        assert_eq!(first.bytes(), b"original");
        assert_eq!(first.payload_sha256(), crate::digest(b"original"));
        assert_eq!(first.identity(), source.identity());
        std::fs::write(&path, b"modified").unwrap();
        assert!(source.observe().is_err());
        let changed = FixedSource::admit(&root_path, "intent", 64)
            .unwrap()
            .observe()
            .unwrap();
        assert_ne!(changed.payload_sha256(), first.payload_sha256());
        let replacement = root_path.join("replacement");
        std::fs::write(&replacement, b"original").unwrap();
        std::fs::set_permissions(&replacement, std::fs::Permissions::from_mode(0o600)).unwrap();
        std::fs::rename(&replacement, &path).unwrap();
        assert!(source.observe().is_err());
        let new = FixedSource::admit(&root_path, "intent", 64).unwrap();
        assert_ne!(new.identity(), source.identity());
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
        assert!(new.observe().is_err());
        std::fs::remove_file(&path).unwrap();
        symlink("replacement", &path).unwrap();
        assert!(FixedSource::admit(&root_path, "intent", 64).is_err());
        assert!(FixedSource::admit(&root_path, "../intent", 64).is_err());
    }
}
