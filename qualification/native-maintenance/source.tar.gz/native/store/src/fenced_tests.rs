use super::*;
use crate::store::reservation::{Credits, Request};
use sigil_worker_bridge::{Bridge, Config};
use std::os::unix::fs::PermissionsExt;
use std::sync::atomic::AtomicBool;
use std::time::{Duration, Instant};

fn root() -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    dir
}
fn allocation() -> capacity::Allocation {
    capacity::Allocation {
        version: 1,
        pools: vec![capacity::Pool {
            id: "p".into(),
            namespaces: vec!["a".into()],
            records: 1000,
            live_bytes: 1_000_000,
        }],
    }
}
fn slots() -> BTreeMap<String, u16> {
    BTreeMap::from([("p".into(), 8)])
}
fn open(root: &Path, mode: OpenMode) -> Result<Store> {
    Store::open_fenced_reserved_bound(
        root,
        mode,
        Limits::default(),
        allocation(),
        [3; 32],
        slots(),
    )
}
fn scope(store: &Store) -> Scope {
    store
        .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap()
}
fn batch(key: &str, value: &str) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: key.into(),
            revision: 0,
            value: Some(value.into()),
        }],
    }
}
fn assign(store: &mut Store) {
    let scope = scope(store);
    let held = store
        .commit_reserving(
            &scope,
            &batch("intent", "accepted"),
            &Request {
                namespace: "a".into(),
                key: "hold".into(),
                binding: [7; 32],
                credits: Credits {
                    records: 10,
                    live_bytes: 50_000,
                },
            },
        )
        .unwrap()
        .held
        .unwrap();
    store
        .commit_assigning_witness(
            &scope,
            &batch("claim", "possibly delivered"),
            &held,
            Credits {
                records: 0,
                live_bytes: 0,
            },
            &[],
            [8; 32],
            b"opaque assignment facts",
        )
        .unwrap();
}
fn config(root: &Path, script: &str) -> Config {
    let runtime = root.join("runtime");
    let body = format!("#!/bin/sh\n{script}\n");
    fs::write(&runtime, &body).unwrap();
    fs::set_permissions(&runtime, fs::Permissions::from_mode(0o700)).unwrap();
    let source = root.join("program");
    fs::write(&source, "native fenced-store fixture").unwrap();
    Config {
        version: 1,
        runtime,
        runtime_sha256: format!("{:x}", Sha256::digest(body.as_bytes())),
        source,
        source_sha256: format!("{:x}", Sha256::digest(b"native fenced-store fixture")),
        max_fuel: 1000,
        max_timeout_ms: 30_000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    }
}
#[test]
fn actual_store_lease_excludes_successor_and_keeps_assignment_across_epoch_change() {
    let root = root();
    let mut store = open(root.path(), OpenMode::CreateNew).unwrap();
    assign(&mut store);
    let (domain, epoch) = store.execution_identity().unwrap();
    let (domain, epoch) = (domain.to_owned(), epoch.to_owned());
    let bridge = Bridge::new_fenced(
        config(root.path(), "exit 0"),
        store.execution_lease().unwrap(),
    )
    .unwrap();
    assert_eq!(bridge.execution_domain().unwrap(), Some(domain.as_str()));
    assert_eq!(bridge.execution_epoch().unwrap(), Some(epoch.as_str()));
    drop(store);
    assert!(matches!(
        open(root.path(), OpenMode::Existing),
        Err(Error::Busy)
    ));
    // The old constructor cannot silently bypass the leased exclusion domain.
    assert!(
        Store::open_witnessed_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots()
        )
        .is_err()
    );
    drop(bridge);
    let store = open(root.path(), OpenMode::Existing).unwrap();
    assert_eq!(store.execution_identity().unwrap().0, domain);
    assert_ne!(store.execution_identity().unwrap().1, epoch);
    let facts = store
        .reservation_snapshot(&scope(&store), "a", "hold")
        .unwrap();
    assert_eq!(facts.revision, 2);
    assert_eq!(facts.binding, [8; 32]);
    assert_eq!(facts.origin, [7; 32]);
    assert_eq!(facts.credits.records, 10);
    assert_eq!(facts.credits.live_bytes, 50_000);
    assert_eq!(facts.assignment, b"opaque assignment facts");
    assert_eq!(
        store
            .get(&scope(&store), "a", "claim")
            .unwrap()
            .value
            .as_deref(),
        Some("possibly delivered")
    );
}
#[test]
fn old_profiles_refuse_fenced_store_and_fenced_open_never_adopts_an_old_store() {
    let root = root();
    drop(open(root.path(), OpenMode::CreateNew).unwrap());
    assert!(Store::open(root.path(), OpenMode::Existing, Limits::default()).is_err());
    assert!(
        Store::open_allocated(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation()
        )
        .is_err()
    );
    assert!(
        Store::open_allocated_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32]
        )
        .is_err()
    );
    assert!(
        Store::open_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32]
        )
        .is_err()
    );
    assert!(
        Store::open_audit_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots()
        )
        .is_err()
    );
    assert!(
        Store::open_witnessed_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots()
        )
        .is_err()
    );
    let old = tempfile::tempdir().unwrap();
    fs::set_permissions(old.path(), fs::Permissions::from_mode(0o700)).unwrap();
    drop(
        Store::open_witnessed_reserved_bound(
            old.path(),
            OpenMode::CreateNew,
            Limits::default(),
            allocation(),
            [3; 32],
            slots(),
        )
        .unwrap(),
    );
    assert!(open(old.path(), OpenMode::Existing).is_err());
    assert!(!old.path().join("execution.lock").exists());
    drop(
        Store::open_witnessed_reserved_bound(
            old.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots(),
        )
        .unwrap(),
    );
}
#[test]
fn identical_lock_bytes_on_a_new_inode_cannot_replace_persisted_admission() {
    let root = root();
    let mut store = open(root.path(), OpenMode::CreateNew).unwrap();
    assign(&mut store);
    let old = store.execution_identity().unwrap().0.to_owned();
    drop(store);
    let path = root.path().join("execution.lock");
    fs::rename(&path, root.path().join("old.lock")).unwrap();
    fs::copy(root.path().join("old.lock"), &path).unwrap();
    let replacement = ExecutionFence::open(root.path(), FenceMode::Existing).unwrap();
    assert_ne!(replacement.identity().unwrap(), old);
    drop(replacement);
    assert!(open(root.path(), OpenMode::Existing).is_err());
    fs::remove_file(&path).unwrap();
    fs::rename(root.path().join("old.lock"), &path).unwrap();
    let store = open(root.path(), OpenMode::Existing).unwrap();
    assert_eq!(store.execution_identity().unwrap().0, old);
    assert_eq!(
        store
            .reservation_snapshot(&scope(&store), "a", "hold")
            .unwrap()
            .revision,
        2
    );
}
#[test]
fn live_fence_replacement_denies_store_reads_commits_and_leases() {
    let root = root();
    let mut store = open(root.path(), OpenMode::CreateNew).unwrap();
    let scope = scope(&store);
    let path = root.path().join("execution.lock");
    fs::rename(&path, root.path().join("old.lock")).unwrap();
    fs::copy(root.path().join("old.lock"), &path).unwrap();
    assert!(matches!(
        store.get(&scope, "a", "missing"),
        Err(Error::Denied)
    ));
    assert!(matches!(
        store.commit(&scope, &batch("bad", "x")),
        Err(Error::Denied)
    ));
    assert!(matches!(store.execution_lease(), Err(Error::Denied)));
    assert!(matches!(store.execution_identity(), Err(Error::Denied)));
    drop(store);
    assert!(open(root.path(), OpenMode::Existing).is_err());
    fs::remove_file(&path).unwrap();
    fs::rename(root.path().join("old.lock"), path).unwrap();
    let store = open(root.path(), OpenMode::Existing).unwrap();
    let absent = store.get(&self::scope(&store), "a", "bad").unwrap();
    assert_eq!(absent.revision, 0);
    assert!(absent.value.is_none());
}
#[test]
fn invalid_configuration_and_missing_or_corrupt_fence_are_never_repaired() {
    let root = root();
    assert!(
        Store::open_fenced_reserved_bound(
            root.path(),
            OpenMode::CreateNew,
            Limits::default(),
            allocation(),
            [3; 32],
            BTreeMap::new()
        )
        .is_err()
    );
    assert_eq!(fs::read_dir(root.path()).unwrap().count(), 0);
    drop(open(root.path(), OpenMode::CreateNew).unwrap());
    let path = root.path().join("execution.lock");
    fs::rename(&path, root.path().join("old.lock")).unwrap();
    assert!(open(root.path(), OpenMode::Existing).is_err());
    assert!(!path.exists());
    fs::write(&path, "corrupt").unwrap();
    fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
    assert!(open(root.path(), OpenMode::Existing).is_err());
    assert_eq!(fs::read(&path).unwrap(), b"corrupt");
}
struct Cleanup {
    child: std::process::Child,
    release: PathBuf,
}
impl Drop for Cleanup {
    fn drop(&mut self) {
        let _ = fs::write(&self.release, b"");
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}
#[test]
fn fenced_store_owner_process_child() {
    use std::io::Write;
    let Ok(root) = std::env::var("SIGIL_FENCED_STORE_PROCESS_ROOT") else {
        return;
    };
    let root = PathBuf::from(root);
    let mut store = open(&root, OpenMode::CreateNew).unwrap();
    assign(&mut store);
    let identity = store.execution_identity().unwrap();
    fs::write(
        root.join("identity.json"),
        serde_json::to_vec(&identity).unwrap(),
    )
    .unwrap();
    let release = root.join("release");
    let descendant = root.join("descendant");
    let received = root.join("received");
    let helper = root.join("helper");
    fs::write(&helper, format!("#!/bin/sh\n: > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done\n", descendant.display(), release.display())).unwrap();
    fs::set_permissions(&helper, fs::Permissions::from_mode(0o700)).unwrap();
    let script = format!(
        "'{}' &\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nread -r line\n: > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done",
        helper.display(),
        received.display(),
        release.display()
    );
    let mut bridge =
        Bridge::new_fenced(config(&root, &script), store.execution_lease().unwrap()).unwrap();
    let prepared = bridge
        .prepare("actual invocation".into(), 100, 30_000)
        .unwrap();
    std::thread::spawn(move || {
        let until = Instant::now() + Duration::from_secs(15);
        while !received.exists() || !descendant.exists() {
            assert!(Instant::now() < until);
            std::thread::sleep(Duration::from_millis(5));
        }
        println!("ACTUAL_STORE_LEASED_EFFECT_RECEIVED");
        std::io::stdout().flush().unwrap();
    });
    let _ = bridge.execute(&prepared.ticket, &AtomicBool::new(false));
    panic!("test owner should have been killed while effect was held");
}
#[test]
fn actual_owner_death_blocks_storage_reopen_until_all_effect_holders_exit() {
    use std::io::{BufRead, BufReader};
    use std::process::{Command, Stdio};
    let root = root();
    let mut cleanup = Cleanup {
        child: Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::fenced::tests::fenced_store_owner_process_child",
                "--nocapture",
            ])
            .env("SIGIL_FENCED_STORE_PROCESS_ROOT", root.path())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap(),
        release: root.path().join("release"),
    };
    let output = cleanup.child.stdout.take().unwrap();
    let (tx, rx) = std::sync::mpsc::channel();
    let reader = std::thread::spawn(move || {
        for line in BufReader::new(output)
            .lines()
            .map_while(std::result::Result::ok)
        {
            if line.contains("ACTUAL_STORE_LEASED_EFFECT_RECEIVED") {
                let _ = tx.send(());
                break;
            }
        }
    });
    rx.recv_timeout(Duration::from_secs(20))
        .expect("actual leased effect did not receive invocation");
    cleanup.child.kill().unwrap();
    assert!(!cleanup.child.wait().unwrap().success());
    reader.join().unwrap();
    let old: (String, String) =
        serde_json::from_slice(&fs::read(root.path().join("identity.json")).unwrap()).unwrap();
    assert!(matches!(
        open(root.path(), OpenMode::Existing),
        Err(Error::Busy)
    ));
    assert!(
        Store::open_witnessed_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [3; 32],
            slots()
        )
        .is_err()
    );
    fs::write(&cleanup.release, b"").unwrap();
    let until = Instant::now() + Duration::from_secs(5);
    let store = loop {
        match open(root.path(), OpenMode::Existing) {
            Ok(store) => break store,
            Err(Error::Busy) if Instant::now() < until => {
                std::thread::sleep(Duration::from_millis(5))
            }
            _ => panic!("store failed to reopen after inherited holders exited"),
        }
    };
    let next = store.execution_identity().unwrap();
    assert_eq!(next.0, old.0);
    assert_ne!(next.1, old.1);
    let facts = store
        .reservation_snapshot(&scope(&store), "a", "hold")
        .unwrap();
    assert_eq!(facts.revision, 2);
    assert_eq!(facts.credits.records, 10);
    assert_eq!(facts.assignment, b"opaque assignment facts");
}
