"""Whole-turn capacity through the real native HTTP service and compiled SIGIL."""

import json
import os
import sqlite3
import threading
import time
import select
import subprocess
import hashlib
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from conftest import PI_ROOT, MCP_BIN, FIXED_EVALUATOR_BIN, SIGIL_ROOT
from api_support import TOKEN_A, TOKEN_B
from scripts.workspace_deployment import configuration, fields, record
from scripts.build_workspace_deployment import build
from automatic_support import wait_operation
from test_workspace_agent import WorkspaceApi, call
from turn_support import text_reply
from acceptance.capacity_evidence import inspect_capacity, assert_returned

AUDIT_KEY = b"capacity-test-key-never-for-a-pilot-0123456789"


def profile():
    p = json.loads(
        (PI_ROOT / "config/completion-capacity-development.json").read_text()
    )
    p.pop("commands")
    p["max_steps"] = 4
    return p


def binary():
    return Path(
        os.environ.get(
            "PI_CAPACITY_HOST",
            str(PI_ROOT / "native/service/target/release/sigil-application-host"),
        )
    )


def ledger(root):
    with sqlite3.connect(
        f"file:{root / 'records' / 'records.sqlite'}?mode=ro", uri=True
    ) as db:
        return db.execute(
            "SELECT key,records,bytes,witness FROM reservations ORDER BY key"
        ).fetchall()


def setup_env(monkeypatch):
    monkeypatch.setenv("SIGIL_PI_LOCAL_PROVIDER_TOKEN", "local-placeholder")
    monkeypatch.setenv("SIGIL_PI_AUDIT_KEY", AUDIT_KEY.decode())


@pytest.mark.parametrize(
    "exhausted", ["records", "bytes", "audit_records", "audit_bytes"]
)
def test_capacity_refusal_precedes_acceptance_and_any_effect(
    scripted_llm, tmp_path, monkeypatch, exhausted
):
    setup_env(monkeypatch)
    p = profile()
    caps = p["completion_capacity"]
    if exhausted == "records":
        caps.update(records_per_tenant=10, reservation_slots=1)
    elif exhausted == "bytes":
        caps["bytes_per_tenant"] = 16 * 1024 * 1024
    elif exhausted == "audit_records":
        caps["audit_records"] = 1
    else:
        caps["audit_bytes"] = 65536
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    root = tmp_path / "deployment"
    with WorkspaceApi(
        root, workspace, scripted_llm.url, profile=p, binary=binary()
    ) as api:
        status, reply = api.request(
            body={"session": "pressure", "message": "hello", "submission_key": "first"}
        )
        assert status == 429, reply
        assert reply["error"]["code"] == "completion_capacity_exhausted", reply
        assert scripted_llm.requests == []
        assert ledger(root) == []


def test_funded_multistep_result_is_signed_settled_and_reopens(
    scripted_llm, tmp_path, monkeypatch
):
    setup_env(monkeypatch)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "note.txt").write_text("retained-capacity-marker\n")
    scripted_llm.script = [
        call("read_file", {"path": "note.txt"}),
        json.loads(
            text_reply(
                "retained-capacity-marker",
                usage={"input_tokens": 10, "output_tokens": 10},
            )
        ),
    ]
    root = tmp_path / "deployment"
    with WorkspaceApi(
        root, workspace, scripted_llm.url, profile=profile(), binary=binary()
    ) as api:
        status, accepted = api.request(
            body={
                "session": "capacity",
                "message": "Read note.txt",
                "submission_key": "first",
            }
        )
        assert status == 202, accepted
        result = wait_operation(api, accepted["operation"])
        assert result["status"] == "done", result
        rows = ledger(root)
        assert len(rows) == 1 and rows[0][1:] == (0, 0, b""), rows
        audit = inspect_capacity(root, AUDIT_KEY)
        assert_returned(audit)
        effects = next(c["events"] for c in audit["chains"] if c["kind"] == "effect")
        assert [e["event"] for e in effects] == ["prepared", "observed"] * 3
        assert all(e["phase"] == 2 for e in effects[1::2])
        assert len(scripted_llm.requests) == 2
    with WorkspaceApi(
        root, workspace, scripted_llm.url, mode="open", binary=binary()
    ) as api:
        status, reopened = api.request("GET", accepted["status_url"], raw=b"")
        assert status == 200 and reopened == result
        assert len(scripted_llm.requests) == 2


@pytest.mark.parametrize(
    "scenario", ["oversized_result", "closed_slot", "full_batches"]
)
def test_bounded_completion_and_retained_capacity_edges(
    scripted_llm, tmp_path, monkeypatch, scenario
):
    setup_env(monkeypatch)
    p = profile()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "note.txt").write_text("observed file data\n")
    if scenario == "oversized_result":
        scripted_llm.script = [json.loads(text_reply("x" * 70000))]
    elif scenario == "closed_slot":
        p["completion_capacity"]["reservation_slots"] = 1
        scripted_llm.script = [json.loads(text_reply("complete"))]
    else:
        p["max_steps"] = 3
        tools = {
            "content": [
                call("read_file", {"path": "note.txt"}, str(i))["content"][0]
                for i in range(4)
            ],
            "usage": {"input_tokens": 10, "output_tokens": 10},
        }
        scripted_llm.script = [tools, tools, json.loads(text_reply("complete"))]
    root = tmp_path / "deployment"
    with WorkspaceApi(
        root, workspace, scripted_llm.url, profile=p, binary=binary()
    ) as api:
        status, accepted = api.request(
            body={
                "session": "edge",
                "message": "Read the file",
                "submission_key": "first",
            }
        )
        assert status == 202, accepted
        result = wait_operation(api, accepted["operation"])
        assert result["status"] == (
            "uncertain" if scenario == "oversized_result" else "done"
        ), result
        report = inspect_capacity(root, AUDIT_KEY)
        assert_returned(report)
        if scenario == "full_batches":
            effects = next(
                c["events"] for c in report["chains"] if c["kind"] == "effect"
            )
            assert len(effects) == 22 and len(scripted_llm.requests) == 3
        elif scenario == "closed_slot":
            before = ledger(root)
            status, refused = api.request(
                body={
                    "session": "other",
                    "message": "second task",
                    "submission_key": "second",
                }
            )
            assert (
                status == 429
                and refused["error"]["code"] == "completion_capacity_exhausted"
            )
            assert len(scripted_llm.requests) == 1 and ledger(root) == before


@contextmanager
def delayed_provider():
    arrived, release = threading.Event(), threading.Event()
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            requests.append(
                json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            )
            arrived.set()
            release.wait(45)
            payload = text_reply(
                "observed", usage={"input_tokens": 10, "output_tokens": 10}
            ).encode()
            try:
                self.send_response(200)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield (
            f"http://127.0.0.1:{server.server_port}/v1/messages",
            requests,
            arrived,
            release,
        )
    finally:
        release.set()
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_competing_request_cannot_take_an_accepted_turn_capacity(tmp_path, monkeypatch):
    setup_env(monkeypatch)
    p = profile()
    p["completion_capacity"]["bytes_per_tenant"] = 64 * 1024 * 1024
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    root = tmp_path / "deployment"
    with delayed_provider() as (url, requests, arrived, release):
        with WorkspaceApi(root, workspace, url, profile=p, binary=binary()) as api:
            body = {"session": "first", "message": "hello", "submission_key": "first"}
            status, first = api.request(body=body)
            assert status == 202 and arrived.wait(20), first
            before = ledger(root)
            status, replay = api.request(body=body)
            assert status == 202 and replay["operation"] == first["operation"]
            assert ledger(root) == before
            status, changed = api.request(body={**body, "message": "different payload"})
            assert status == 409 and changed["error"]["code"] == "submission_conflict"
            assert ledger(root) == before
            status, rejected = api.request(
                body={**body, "session": "second", "submission_key": "second"}
            )
            assert (
                status == 429
                and rejected["error"]["code"] == "completion_capacity_exhausted"
            )
            assert len(requests) == 1 and ledger(root) == before
            release.set()
            result = wait_operation(api, first["operation"])
            assert result["status"] == "done", result
            assert ledger(root)[0][1:] == (0, 0, b"")
            # After settlement, a newly requested turn may use returned credit.
            status, second = api.request(
                body={**body, "session": "second", "submission_key": "second"}
            )
            assert status == 202, second
            assert wait_operation(api, second["operation"])["status"] == "done"
            assert len(requests) == 2
            assert all(row[1:] == (0, 0, b"") for row in ledger(root))


@pytest.mark.parametrize("mode", ["cancel", "kill"])
def test_funded_interruption_does_not_replay_or_return_credit_twice(
    tmp_path, monkeypatch, mode
):
    setup_env(monkeypatch)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    root = tmp_path / "deployment"
    with delayed_provider() as (url, requests, arrived, release):
        with WorkspaceApi(
            root, workspace, url, profile=profile(), binary=binary()
        ) as api:
            status, first = api.request(
                body={
                    "session": "interrupted",
                    "message": "hello",
                    "submission_key": "first",
                }
            )
            assert status == 202 and arrived.wait(20), first
            assert ledger(root)[0][1] > 0
            if mode == "cancel":
                status, _ = api.request(
                    "POST", first["status_url"] + "/cancel", body={}
                )
                assert status == 202
                result = wait_operation(api, first["operation"])
                assert result["status"] == "uncertain", result
                assert ledger(root)[0][1:] == (0, 0, b"")
            else:
                api.proc.kill()
                api.proc.wait(timeout=5)
                # The actual surviving SIGIL effect process retains the lease.
                with pytest.raises(AssertionError, match='"code":"storage"'):
                    WorkspaceApi(root, workspace, url, mode="open", binary=binary())
                assert ledger(root)[0][1] > 0
            release.set()
        time.sleep(0.5)
        with WorkspaceApi(root, workspace, url, mode="open", binary=binary()) as api:
            recovered = wait_operation(api, first["operation"])
            assert recovered["status"] == "uncertain", recovered
            assert len(requests) == 1
            closed = ledger(root)
            assert closed[0][1:] == (0, 0, b"")
            audit = inspect_capacity(root, AUDIT_KEY)
            assert_returned(audit)
            effects = next(
                c["events"] for c in audit["chains"] if c["kind"] == "effect"
            )
            assert len(effects) == 2 and effects[-1]["phase"] == 4
            assert effects[-1]["request_may_have_run"] == 1
            if mode == "kill":
                assert (
                    effects[-1]["event"] == "abandoned"
                    and effects[-1]["worker_reaped"] == 0
                )
                exclusion = effects[-1]["local_exclusion"]
                assert exclusion["origin_binding"] == first["operation"]
                assert exclusion["reservation_key"] == first["operation"]
                assert exclusion["prior_epoch"] != exclusion["current_epoch"]
            status, _ = api.request("POST", first["status_url"] + "/cancel", body={})
            assert status == 200 and ledger(root) == closed
        with WorkspaceApi(root, workspace, url, mode="open", binary=binary()) as api:
            assert wait_operation(api, first["operation"]) == recovered
            assert len(requests) == 1 and ledger(root) == closed


@contextmanager
def prepared_service(root, mode="init"):
    api = WorkspaceApi.__new__(WorkspaceApi)
    api.root = root
    api.config = json.loads((root / "service.json").read_text())
    api.proc = subprocess.Popen(
        [str(binary()), mode, str(root / "service.json"), "0"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        ready, _, _ = select.select([api.proc.stdout], [], [], 40)
        assert ready
        line = api.proc.stdout.readline()
        assert line, api.proc.stderr.read()
        api.ready = json.loads(line)
        assert api.ready["status"] == "ready"
        api.port = int(api.ready["address"].split(":")[1])
        yield api
    finally:
        api.close()


def test_one_exhausted_tenant_does_not_consume_another_tenant_pool(
    scripted_llm, tmp_path, monkeypatch
):
    setup_env(monkeypatch)
    areas = [tmp_path / "tenant-a", tmp_path / "tenant-b"]
    for name, area in zip(["private-a", "private-b"], areas, strict=True):
        area.mkdir()
        (area / "note.txt").write_text(name)
    p = profile()
    seed = tmp_path / "seed"
    template, _ = build(
        seed,
        areas[0],
        MCP_BIN,
        FIXED_EVALUATOR_BIN,
        SIGIL_ROOT,
        TOKEN_A,
        p,
        endpoint=scripted_llm.url,
    )
    first = template["credentials"][0]
    values = fields(first["facts"], "CF2\n", 15)
    values[0], values[1], values[2] = "second-user", "second-workspace", "second-policy"
    for index in [7, 8, 10, 11, 12, 13]:
        values[index] = "second" + values[index][len("workspace") :]
    second = {
        "sha256": hashlib.sha256(TOKEN_B.encode()).hexdigest(),
        "facts": record("CF2\n", values),
        "grants": {values[i]: "read_write" for i in [7, 8, 10, 11, 12, 13]},
    }
    programs = {
        alias: Path(effect["worker"]["source"]).read_text()
        for alias, effect in template["automatic"]["participants"][0]["effects"].items()
    }
    root = tmp_path / "deployment"
    config = configuration(
        root,
        programs,
        scripted_llm.url,
        areas,
        [first, second],
        MCP_BIN,
        FIXED_EVALUATOR_BIN,
        SIGIL_ROOT,
        funded=p["completion_capacity"],
    )
    config["storage"]["allocation"]["pools"][0]["records"] = 10
    config["storage"]["reservation_slots"]["workspace-pool-0"] = 1
    (root / "service.json").write_text(json.dumps(config))
    scripted_llm.script = [
        call("read_file", {"path": "note.txt"}),
        json.loads(
            text_reply("private-b", usage={"input_tokens": 10, "output_tokens": 10})
        ),
    ]
    body = {
        "session": "same-session",
        "message": "Read note.txt",
        "submission_key": "same-key",
    }
    with prepared_service(root) as api:
        status, rejected = api.request(body=body)
        assert (
            status == 429
            and rejected["error"]["code"] == "completion_capacity_exhausted"
        )
        assert len(scripted_llm.requests) == 0
        status, accepted = api.request(body=body, token=TOKEN_B)
        assert status == 202, accepted
        result = wait_operation(api, accepted["operation"], token=TOKEN_B)
        assert result["status"] == "done", result
        assert "private-b" in json.dumps(
            scripted_llm.requests[-1]
        ) and "private-a" not in json.dumps(scripted_llm.requests)
        status, _ = api.request("GET", accepted["status_url"], raw=b"", token=TOKEN_A)
        assert status == 404
        audit = inspect_capacity(root, AUDIT_KEY)
        assert_returned(audit)
        assert len(audit["reservations"]) == 1
        assert audit["reservations"][0]["namespace"] == "second.reservation"
        assert all(c["namespace"].startswith("audit1.") for c in audit["chains"])
