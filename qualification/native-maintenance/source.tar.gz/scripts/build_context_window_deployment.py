"""Build a fresh context-window-v1 deployment with public archive retrieval."""

import hashlib
import json
import argparse
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scripts.build_archive_export_deployment import build as build_archives
from scripts.compose_context_window import compose_context_window

COMPONENTS = ("admission", "turn_completion", "dispatch_cancellable", "preclaim_cancellable")

def add_context_window(root, config, stdlib):
    root = Path(root).resolve()
    if config.get("version") != 11 or Path(config["state_root"]) != root / "records" or (root / "records").exists():
        raise ValueError("context-window assembly requires fresh v11 deployment state")
    if "archive_export" not in config["functions"]:
        raise ValueError("context reduction requires public archive retrieval")
    built = {name: compose_context_window(name, stdlib) for name in COMPONENTS}
    targets = [("admission", config["functions"]["admission"])]
    for participant in config["automatic"]["participants"]:
        targets.append(("turn_completion", participant["transactions"]["interpret"]["worker"]))
        targets.append(("preclaim_cancellable", participant["transactions"]["preclaim"]["worker"]))
        for effect in participant["effects"].values():
            targets.append(("dispatch_cancellable", effect["policy"]["worker"]))
    for name, worker in targets:
        source = root / (name + ".sigil")
        source.write_text(built[name].text)
        worker.update(source=str(source), source_sha256=built[name].compiler_input_sha256)


def build(root, workspace, runtime, evaluator, stdlib, token, profile, *, endpoint=None):
    if profile.get("context_window") != "v1" or profile.get("model_thinking") != "disabled":
        raise ValueError("explicit context_window v1 and model_thinking disabled are required")
    for name in COMPONENTS:
        compose_context_window(name, stdlib)
    config, path = build_archives(root, workspace, runtime, evaluator, stdlib, token, profile, endpoint=endpoint)
    root = Path(root).resolve()
    add_context_window(root, config, stdlib)
    path.write_text(json.dumps(config, indent=2) + "\n")
    inputs = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(root.rglob("*")) if p.is_file() and p.name != "build-inputs.json"}
    (root / "build-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
    return config, path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--evaluator", required=True, type=Path)
    parser.add_argument("--stdlib-root", required=True, type=Path)
    parser.add_argument("--profile", type=Path, default=ROOT / "config/context-window-development.json")
    parser.add_argument("--token-env", default="SIGIL_PI_TOKEN")
    args = parser.parse_args()
    profile = json.loads(args.profile.read_text())
    if profile["endpoint"] != "http://127.0.0.1:11434/v1/messages":
        parser.error("this development profile requires the local model endpoint")
    _, path = build(args.output, args.workspace, args.runtime, args.evaluator,
                    args.stdlib_root, os.environ[args.token_env], profile)
    print(json.dumps({"service": str(path), "profile": profile["schema"]}))


if __name__ == "__main__":
    main()
