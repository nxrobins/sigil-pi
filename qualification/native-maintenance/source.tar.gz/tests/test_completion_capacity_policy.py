"""Compiled application bounds behind the whole-turn reservation calculation."""

import json

import pytest

from api_support import credential
from conftest import SIGIL_ROOT, forge_ok
from scripts.compose_capacity import compose_capacity
from test_admission import incoming, profile
from turn_support import configuration, fields, record, event, run, tool_reply, refused


def bounded_config(**kwargs):
    cfg = fields(configuration(**kwargs), "PC1\n", 7)
    cfg[5] = "131072"
    cfg[6] = "65536"
    return record("PC1\n", cfg)


@pytest.mark.parametrize("steps", [1, 4, 20])
def test_admission_reserves_the_whole_permitted_action_envelope(mcp, steps):
    cfg = fields(bounded_config(), "PC1\n", 7)
    cfg[2] = str(steps)
    row = credential(profile=profile(config=record("PC1\n", cfg), outputs=1000000))
    outcome, batch, guard, budget = fields(
        forge_ok(
            mcp,
            compose_capacity("admission", SIGIL_ROOT).text,
            incoming(row=row),
            fuel=300000000,
        ),
        "AD2\n",
        4,
    )
    assert outcome == "ok"
    writes = json.loads(batch)["writes"]
    budget = json.loads(budget)
    operation = next(w["key"] for w in writes if w["namespace"] == "a.operations")
    assert budget["key"] == budget["binding"] == operation
    assert budget["namespace"] == "a.reservation"
    # Three publication boundaries per action; record creation includes heads.
    maximum_actions = steps * (1 + 4)
    assert budget["records"] >= maximum_actions * (3 + 2 + 3) + 1
    assert budget["live_bytes"] >= maximum_actions * (524288 + 524288 + 1048576) + 4096
    assert budget["audits"]["effect"]["records"] >= maximum_actions * 3
    assert budget["audits"]["transaction"]["records"] >= maximum_actions + 2
    assert all(
        a["bytes"] >= a["records"] * (8192 * 6 + 1024)
        for a in budget["audits"].values()
    )


@pytest.mark.parametrize("index,value", [(2, "21"), (5, "131073"), (6, "65537")])
def test_underbudgetable_profiles_are_refused_at_compiled_admission(mcp, index, value):
    cfg = fields(bounded_config(), "PC1\n", 7)
    cfg[index] = value
    row = credential(profile=profile(config=record("PC1\n", cfg)))
    refused(mcp, compose_capacity("admission", SIGIL_ROOT).text, incoming(row=row), 400)


def test_fifth_tool_is_not_dispatched_past_the_funded_envelope(mcp):
    source = compose_capacity("turn", SIGIL_ROOT).text
    first = run(mcp, source, event(config=bounded_config()))
    result = run(mcp, source, first.result(tool_reply(*(["read_file"] * 5))))
    assert result.action == "failed" and result.input == ""
    assert fields(result.state, "PT1\n", 17)[14] == "tool_batch_limit"


def test_four_tools_still_execute_within_the_same_model_step(mcp):
    source = compose_capacity("turn", SIGIL_ROOT).text
    first = run(mcp, source, event(config=bounded_config()))
    result = run(mcp, source, first.result(tool_reply(*(["read_file"] * 4))))
    assert result.action == "tool"
    for index in range(4):
        assert result.sequence == str(index + 2)
        result = run(mcp, source, result.result("observed file data"))
    assert result.action == "model"
