use super::{
    Failure,
    files::{Anchor, Mode},
};
use std::fs;
use std::os::unix::fs::{FileExt, PermissionsExt, symlink};

fn root() -> (tempfile::TempDir, std::path::PathBuf) {
    let d = tempfile::tempdir().unwrap();
    fs::set_permissions(d.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let p = d.path().canonicalize().unwrap();
    (d, p)
}

#[test]
fn durable_confirmation_reopens_but_old_or_partial_root_refuses() {
    let (_d, root) = root();
    let mut a = Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap();
    let ticket = a.prepare([1; 32], [2; 32]).unwrap();
    a.confirm(ticket, [2; 32]).unwrap();
    assert_eq!(a.issued(), 1);
    drop(a);
    assert!(matches!(
        Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]),
        Err(Failure::RootMismatch)
    ));
    assert!(matches!(
        Anchor::open(&root, Mode::Existing, [7; 32], [3; 32]),
        Err(Failure::RootMismatch)
    ));
    let a = Anchor::open(&root, Mode::Existing, [7; 32], [2; 32]).unwrap();
    assert_eq!(a.issued(), 1);
}

#[test]
fn pending_recovery_aborts_or_finalizes_without_resetting_issued_identity() {
    for actual in [[1; 32], [2; 32]] {
        let (_d, root) = root();
        let mut a = Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap();
        let _pending = a.prepare([1; 32], [2; 32]).unwrap();
        drop(a);
        let mut reopened = Anchor::open(&root, Mode::Existing, [7; 32], actual).unwrap();
        assert_eq!(reopened.issued(), 1);
        let ticket = reopened.prepare(actual, [3; 32]).unwrap();
        reopened.confirm(ticket, [3; 32]).unwrap();
        assert_eq!(reopened.issued(), 2);
    }
}

#[test]
fn actual_file_lock_excludes_a_second_owner() {
    let (_d, root) = root();
    let owner = Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap();
    assert!(matches!(
        Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]),
        Err(Failure::Busy)
    ));
    drop(owner);
    Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]).unwrap();
}

#[test]
fn a_single_damaged_confirmed_copy_is_repaired_and_lone_pending_quarantines() {
    let (_d, root) = root();
    drop(Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap());
    let file = fs::OpenOptions::new()
        .write(true)
        .open(root.join("anchor.0"))
        .unwrap();
    file.write_all_at(&[0xff], 10).unwrap();
    file.sync_all().unwrap();
    let mut a = Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]).unwrap();
    assert_eq!(a.issued(), 0);
    assert_eq!(
        fs::read(root.join("anchor.0")).unwrap(),
        fs::read(root.join("anchor.1")).unwrap()
    );
    let _ticket = a.prepare([1; 32], [2; 32]).unwrap();
    drop(a);
    let file = fs::OpenOptions::new()
        .write(true)
        .open(root.join("anchor.1"))
        .unwrap();
    file.write_all_at(&[0xff], 10).unwrap();
    file.sync_all().unwrap();
    assert!(matches!(
        Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]),
        Err(Failure::Ambiguous)
    ));
}

#[test]
fn missing_replaced_or_nonprivate_authority_is_never_adopted() {
    for change in ["missing", "replace", "symlink", "hardlink", "mode"] {
        let (_d, root) = root();
        drop(Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap());
        let target = root.join("anchor.0");
        match change {
            "missing" => fs::remove_file(&target).unwrap(),
            "replace" => {
                fs::rename(&target, root.join("old")).unwrap();
                fs::copy(root.join("old"), &target).unwrap();
            }
            "symlink" => {
                fs::remove_file(&target).unwrap();
                symlink(root.join("anchor.1"), &target).unwrap();
            }
            "hardlink" => fs::hard_link(&target, root.join("linked")).unwrap(),
            "mode" => fs::set_permissions(&target, fs::Permissions::from_mode(0o644)).unwrap(),
            _ => unreachable!(),
        }
        assert!(
            Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]).is_err(),
            "{change}"
        );
    }
}

#[test]
fn wrong_domain_or_post_admission_replacement_cannot_confirm() {
    let (_d, root) = root();
    let a = Anchor::open(&root, Mode::CreateNew, [7; 32], [1; 32]).unwrap();
    drop(a);
    assert!(matches!(
        Anchor::open(&root, Mode::Existing, [8; 32], [1; 32]),
        Err(Failure::Domain)
    ));
    let mut a = Anchor::open(&root, Mode::Existing, [7; 32], [1; 32]).unwrap();
    let ticket = a.prepare([1; 32], [2; 32]).unwrap();
    fs::rename(root.join("anchor.1"), root.join("old")).unwrap();
    fs::copy(root.join("old"), root.join("anchor.1")).unwrap();
    assert!(matches!(a.confirm(ticket, [2; 32]), Err(Failure::Denied)));
}

// These tests exercise actual SQLite commits and SIGKILL, independently of the
// future Store integration. The one-row root below is only this fixture's root.
fn database(path: &std::path::Path) -> rusqlite::Connection {
    let c = rusqlite::Connection::open(path.join("state.sqlite")).unwrap();
    c.execute_batch("PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL;")
        .unwrap();
    c
}

fn observed(path: &std::path::Path) -> [u8; 32] {
    let value: u8 = database(path)
        .query_row("SELECT value FROM state", [], |r| r.get(0))
        .unwrap();
    [value; 32]
}

fn fixture() -> tempfile::TempDir {
    let d = tempfile::tempdir().unwrap();
    let authority = d.path().join("authority");
    fs::create_dir(&authority).unwrap();
    fs::set_permissions(&authority, fs::Permissions::from_mode(0o700)).unwrap();
    database(d.path())
        .execute_batch("CREATE TABLE state(value INTEGER NOT NULL); INSERT INTO state VALUES(1);")
        .unwrap();
    drop(
        Anchor::open(
            &authority.canonicalize().unwrap(),
            Mode::CreateNew,
            [7; 32],
            observed(d.path()),
        )
        .unwrap(),
    );
    d
}

fn child(path: &std::path::Path, action: &str, stage: &str) -> std::process::Output {
    std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            "store::restore_anchor::file_tests::crash_child",
            "--nocapture",
        ])
        .env("SIGIL_TEST_ANCHOR_PATH", path)
        .env("SIGIL_TEST_ANCHOR_ACTION", action)
        .env("SIGIL_TEST_ANCHOR_CUT", stage)
        .output()
        .unwrap()
}

#[test]
fn crash_child() {
    let Ok(path) = std::env::var("SIGIL_TEST_ANCHOR_PATH") else {
        return;
    };
    let path = std::path::Path::new(&path);
    let mut a = Anchor::open(
        &path.join("authority").canonicalize().unwrap(),
        Mode::Existing,
        [7; 32],
        observed(path),
    )
    .unwrap();
    if std::env::var("SIGIL_TEST_ANCHOR_ACTION").unwrap() == "recover" {
        return;
    }
    let mut c = database(path);
    let tx = c.transaction().unwrap();
    tx.execute("UPDATE state SET value=2", []).unwrap();
    let ticket = a.prepare([1; 32], [2; 32]).unwrap();
    super::files::cut("before_database_commit");
    tx.commit().unwrap();
    super::files::cut("after_database_commit");
    a.confirm(ticket, observed(path)).unwrap();
    super::files::cut("after_confirmation");
    super::files::cut("before_receipt");
    let receipt = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path.join("receipt"))
        .unwrap();
    receipt.write_all_at(&[2; 32], 0).unwrap();
    receipt.sync_all().unwrap();
    fs::File::open(path).unwrap().sync_all().unwrap();
    super::files::cut("after_receipt");
}

#[test]
fn process_death_at_commit_boundaries_preserves_acknowledged_state() {
    use std::os::unix::process::ExitStatusExt;
    let mut stages = vec![
        "before_database_commit".to_string(),
        "after_database_commit".to_string(),
        "after_confirmation".to_string(),
        "before_receipt".to_string(),
        "after_receipt".to_string(),
    ];
    for record in ["prepared", "confirmed_first", "confirmed_mirror"] {
        for point in ["before", "after"] {
            stages.push(format!("{point}_{record}_write"));
        }
        stages.push(format!("after_{record}_sync"));
    }
    for stage in stages {
        let d = fixture();
        let result = child(d.path(), "commit", &stage);
        assert_eq!(
            result.status.signal(),
            Some(libc::SIGKILL),
            "{stage}: {}",
            String::from_utf8_lossy(&result.stderr)
        );
        let actual = observed(d.path());
        let authority = d.path().join("authority").canonicalize().unwrap();
        let recovered = Anchor::open(&authority, Mode::Existing, [7; 32], actual).unwrap();
        if d.path().join("receipt").exists() {
            assert_eq!(actual, [2; 32], "{stage}");
            assert_eq!(fs::read(d.path().join("receipt")).unwrap(), actual);
        }
        assert_eq!(
            recovered.issued(),
            if stage == "before_prepared_write" {
                0
            } else {
                1
            },
            "{stage}"
        );
        drop(recovered);
        assert_eq!(
            fs::read(authority.join("anchor.0")).unwrap(),
            fs::read(authority.join("anchor.1")).unwrap()
        );
        if actual == [2; 32] {
            database(d.path())
                .execute("UPDATE state SET value=1", [])
                .unwrap();
            assert!(
                matches!(
                    Anchor::open(&authority, Mode::Existing, [7; 32], observed(d.path())),
                    Err(Failure::RootMismatch)
                ),
                "{stage}"
            );
        }
    }
}

#[test]
fn recovery_itself_can_die_without_reinterpreting_a_persisted_resolution() {
    use std::os::unix::process::ExitStatusExt;
    for actual in [1u8, 2u8] {
        for record in ["recovery_resolution", "recovery_mirror"] {
            for point in ["before_write", "after_write", "after_sync"] {
                let stage = match point {
                    "before_write" => format!("before_{record}_write"),
                    "after_write" => format!("after_{record}_write"),
                    _ => format!("after_{record}_sync"),
                };
                let d = fixture();
                let authority = d.path().join("authority").canonicalize().unwrap();
                let mut a = Anchor::open(&authority, Mode::Existing, [7; 32], [1; 32]).unwrap();
                let _ticket = a.prepare([1; 32], [2; 32]).unwrap();
                drop(a);
                database(d.path())
                    .execute("UPDATE state SET value=?", [actual])
                    .unwrap();
                let result = child(d.path(), "recover", &stage);
                assert_eq!(
                    result.status.signal(),
                    Some(libc::SIGKILL),
                    "{actual}/{stage}: {}",
                    String::from_utf8_lossy(&result.stderr)
                );
                // Once resolution bytes are visible, presenting the opposite
                // state cannot reinterpret that persisted abort/finalize.
                if stage != "before_recovery_resolution_write" {
                    assert!(
                        matches!(
                            Anchor::open(&authority, Mode::Existing, [7; 32], [3 - actual; 32]),
                            Err(Failure::RootMismatch)
                        ),
                        "{actual}/{stage}"
                    );
                }
                // Kill the repair as well whenever a partial mirror remains.
                let repaired = child(d.path(), "recover", "before_recovery_repair_write");
                assert!(
                    repaired.status.success() || repaired.status.signal() == Some(libc::SIGKILL)
                );
                let a = Anchor::open(&authority, Mode::Existing, [7; 32], [actual; 32]).unwrap();
                assert_eq!(a.issued(), 1);
                drop(a);
                assert!(matches!(
                    Anchor::open(&authority, Mode::Existing, [7; 32], [3 - actual; 32]),
                    Err(Failure::RootMismatch)
                ));
            }
        }
    }
}
