"""Bounded SIGIL archive discovery; native reads supply every observation."""

import json
import pytest

from conftest import SIGIL_ROOT, forge_ok
from scripts.compose_archive_export import compose_archive_export
from test_history_projection import state
from turn_support import FUEL, fields, record, refused


@pytest.fixture(scope="module")
def program():
    return compose_archive_export(SIGIL_ROOT).text


def request(observation, *, stage="state", held="", after="", limit="2", expected="0", session="conversation", tenant="tenant-a"):
    return record("XI1\n", [tenant, session, after, limit, expected, stage, observation, held])


def snapshot(revision="9", value=None, status="ok"):
    return record("SR1\n", [status, revision, state(**{"0": "c" * 64}) if value is None else value])


def evaluate(mcp, program, payload):
    kind, body, held = fields(forge_ok(mcp, program, payload, fuel=FUEL), "XI2\n", 3)
    return kind, json.loads(body), held


def metadata(keys, next_key=""):
    return record("KM1\n", ["ok", json.dumps([
        {"key": key, "revision": "1", "present": True, "value_bytes": 100} for key in keys]), next_key])


def test_bounded_lexical_index_identifies_current_context_without_duplicate_messages(mcp, program):
    kind, query, held = evaluate(mcp, program, request(snapshot()))
    assert kind == "query" and query == {"after": "conversation:", "limit": 2}
    keys = ["conversation:" + letter * 64 for letter in "ab"]
    kind, page, _ = evaluate(mcp, program, request(metadata(keys, keys[-1]), stage="page", held=held))
    assert kind == "ok" and page["state_revision"] == "9"
    assert page["archives"] == [{"operation": letter * 64, "archive_revision": "1"} for letter in "ab"]
    assert page["next_after"] == "b" * 64 and page["context_snapshots_may_overlap"] is True
    assert page["current"]["operation"] == "c" * 64
    assert page["current"]["messages_url"] == "/v1/sessions/conversation/messages?revision=9"
    assert "messages" not in page and "SYSTEM-private-canary" not in json.dumps(page)
    kind, _, next_held = evaluate(mcp, program, request(snapshot(), after="b" * 64, expected="9"))
    assert kind == "query"
    kind, end, _ = evaluate(mcp, program, request(metadata(["other-session:" + "d" * 64]),
        stage="page", held=next_held, after="b" * 64, expected="9"))
    assert kind == "ok" and end["archives"] == [] and end["next_after"] is None
    assert "other-session" not in json.dumps(end)


def test_collection_cursor_requires_exact_current_state_revision(mcp, program):
    assert evaluate(mcp, program, request(snapshot(), expected="8"))[:2] == ("stale", {})
    refused(mcp, program, request(snapshot(), after="a" * 64), 400)
    assert evaluate(mcp, program, request(snapshot(revision="0", value="")))[:2] == ("missing", {})
    assert evaluate(mcp, program, request(snapshot(revision="0", value="", status="error")))[:2] == ("unavailable", {})
    refused(mcp, program, request(snapshot(), session="different"), 409)


@pytest.mark.parametrize("tenant", ["Équipe 一 / example.org", "a" * 128])
def test_index_accepts_cf2_tenant_names(mcp, program, tenant):
    assert evaluate(mcp, program, request(snapshot(), tenant=tenant))[0] == "query"


@pytest.mark.parametrize("tenant", ["", " leading", "trailing ", "a\nb", "a\x7fb", "a" * 129])
def test_index_rejects_invalid_cf2_tenant_names(mcp, program, tenant):
    refused(mcp, program, request(snapshot(), tenant=tenant), 400)


@pytest.mark.parametrize("kind", ["duplicate", "backwards", "wrong_cursor", "over_limit", "current_is_archived", "malformed_identity"])
def test_metadata_cannot_skip_duplicate_or_relabel_an_operation(mcp, program, kind):
    _, _, held = evaluate(mcp, program, request(snapshot()))
    keys = ["conversation:" + letter * 64 for letter in "ab"]
    next_key = keys[-1]
    if kind == "duplicate": keys[1] = keys[0]
    if kind == "backwards": keys.reverse()
    if kind == "wrong_cursor": next_key = keys[0]
    if kind == "over_limit": keys.append("conversation:" + "d" * 64)
    if kind == "current_is_archived": keys[1] = "conversation:" + "c" * 64
    if kind == "malformed_identity": keys[1] = "conversation:invalid"
    refused(mcp, program, request(metadata(keys, next_key), stage="page", held=held),
            409 if kind in {"current_is_archived", "malformed_identity"} else 400)
