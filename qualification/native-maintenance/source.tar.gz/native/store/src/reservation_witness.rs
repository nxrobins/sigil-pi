//! Explicit schema-5 immutable origin and bounded assignment witness. These are
//! retained facts, not execution authority, proof of cleanup or retry policy.
use super::*;

pub const BYTES: usize = 8192;
pub const FORMAT: &str = "sigil-audited-reservation-witness/v1";
#[derive(Clone, PartialEq, Eq)]
pub(super) struct Retained {
    pub(super) origin: [u8; 32],
    pub(super) assignment: Vec<u8>,
}

pub struct Snapshot {
    pub revision: u64,
    pub generation: Option<Generation>,
    pub binding: [u8; 32],
    pub origin: [u8; 32],
    pub credits: Credits,
    pub assignment: Vec<u8>,
}

impl Retained {
    pub(super) fn valid(&self, binding: [u8; 32]) -> bool {
        self.assignment.len() <= BYTES && (binding == self.origin) == self.assignment.is_empty()
    }
}
pub(super) fn created(profile: u8, binding: [u8; 32]) -> Option<Retained> {
    (profile >= 5).then(|| Retained {
        origin: binding,
        assignment: vec![],
    })
}
pub(super) fn update(
    profile: u8,
    old: Option<&Retained>,
    binding: [u8; 32],
    next_binding: Option<[u8; 32]>,
    assignment: Option<&[u8]>,
) -> Result<Option<Retained>> {
    if profile < 5 {
        return if old.is_none() && assignment.is_none() {
            Ok(None)
        } else {
            Err(Error::Invalid)
        };
    }
    let old = old.ok_or(Error::Corrupt)?;
    if !old.valid(binding) {
        return Err(Error::Corrupt);
    }
    let Some(next_binding) = next_binding else {
        return if assignment.is_none() {
            Ok(Some(old.clone()))
        } else {
            Err(Error::Invalid)
        };
    };
    let assignment = assignment.ok_or(Error::Invalid)?;
    if assignment.len() > BYTES {
        return Err(Error::Limit);
    }
    let next = Retained {
        origin: old.origin,
        assignment: assignment.to_vec(),
    };
    if !next.valid(next_binding) {
        return Err(Error::Invalid);
    }
    Ok(Some(next))
}

impl Store {
    pub fn has_reservation_witnesses(&self) -> bool {
        self.reserving >= 5
    }

    /// Bounded scoped facts only. Reading does not issue a Held grant or establish
    /// that the old worker stopped. Any later resume still needs exact current
    /// revision/binding and independently authorized native recovery policy.
    pub fn reservation_snapshot(
        &self,
        scope: &Scope,
        namespace: &str,
        key: &str,
    ) -> Result<Snapshot> {
        if self.reserving < 5 {
            return Err(Error::Invalid);
        }
        self.authorize(scope, namespace, key, false, 0, false)?;
        self.verify_files()?;
        let _snapshot = self.anchored_read()?;
        self.reservation_snapshot_in(&self.connection, namespace, key)
    }

    // Caller owns the authorized, verified read transaction for all observations.
    pub(in crate::store) fn reservation_snapshot_in(
        &self,
        connection: &Connection,
        namespace: &str,
        key: &str,
    ) -> Result<Snapshot> {
        let entry = read(connection, namespace, key, self.reserving)?.ok_or(Error::Missing)?;
        let retained = entry.witness.ok_or(Error::Corrupt)?;
        Ok(Snapshot {
            revision: entry.revision,
            generation: entry.generation,
            binding: entry.binding,
            origin: retained.origin,
            credits: entry.credits,
            assignment: retained.assignment,
        })
    }

    #[allow(clippy::too_many_arguments)]
    pub fn commit_assigning_witness(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        debits: &[Debit],
        next_binding: [u8; 32],
        assignment: &[u8],
    ) -> Result<Publication> {
        self.commit_credit_update_witness(
            scope,
            batch,
            held,
            debit,
            debits,
            Some(next_binding),
            Some(assignment),
            None,
            || {},
        )
    }
}

#[cfg(test)]
#[path = "reservation_witness_tests.rs"]
mod tests;
