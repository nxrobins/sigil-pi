//! Fixed-destination create-only publication for trusted native embeddings.
//! This primitive grants no execution/recovery authority and does not decide
//! application transitions. The caller must durably prepare the exact payload
//! and fund the obligation before calling it. A receipt proves local durable
//! publication/readback, never remote interpretation or an application ack.
use serde::Serialize;
use std::ffi::CString;
use std::fs::{File, Metadata};
use std::io::{Read, Seek, SeekFrom, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::MetadataExt;
use std::path::{Component, Path, PathBuf};

#[path = "publication_source.rs"]
mod source;
pub use source::{FixedSource, SourceObservation};

const MAX_BYTES: usize = 1_048_576;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Error {
    Invalid,
    Busy,
    Conflict,
    Unconfirmed,
    WrongProcess,
}
type Result<T> = std::result::Result<T, Error>;

/// Bootstrap-owned destination capability. No deserialization or caller path
/// is accepted by publish. Reopening a path is not export admission by itself.
pub struct FixedSink {
    root: PathBuf,
    directory: File,
    key: CString,
    temporary: CString,
    identity: String,
    process: u32,
    max_bytes: usize,
}

/// Only an actual successful native publication creates this non-deserializable
/// receipt. Persisting/acknowledging it is a separate admitted store transaction.
#[derive(Debug, Serialize)]
pub struct DurablePublication {
    destination: String,
    payload_sha256: String,
    payload_bytes: usize,
    existing: bool,
}
impl DurablePublication {
    pub fn destination(&self) -> &str {
        &self.destination
    }
    pub fn payload_sha256(&self) -> &str {
        &self.payload_sha256
    }
    pub fn payload_bytes(&self) -> usize {
        self.payload_bytes
    }
    pub fn already_present(&self) -> bool {
        self.existing
    }
}

fn same(a: &Metadata, b: &Metadata) -> bool {
    a.dev() == b.dev() && a.ino() == b.ino()
}
fn private(file: &File, meta: &Metadata, directory: bool) -> bool {
    // SAFETY: geteuid takes no memory or caller-controlled arguments.
    meta.uid() == unsafe { libc::geteuid() }
        && meta.mode() & 0o077 == 0
        && no_extended_acl(file)
        && if directory {
            meta.is_dir()
        } else {
            meta.is_file()
        }
}

// macOS ACL allows are independent of Unix mode bits, and inheritable entries
// can reach a newly created 0600 file. Inspect the actual descriptor, never a
// second pathname. This deliberately rejects even restrictive extended ACLs.
#[cfg(target_os = "macos")]
fn no_extended_acl(file: &File) -> bool {
    use libc::{c_int, c_void};
    unsafe extern "C" {
        fn acl_get_fd_np(fd: c_int, kind: c_int) -> *mut c_void;
        fn acl_valid(acl: *mut c_void) -> c_int;
        fn acl_get_entry(acl: *mut c_void, entry_id: c_int, entry: *mut *mut c_void) -> c_int;
        fn acl_free(acl: *mut c_void) -> c_int;
    }
    // SAFETY: the fd is live; ACL_TYPE_EXTENDED=0x100 and ACL_FIRST_ENTRY=0
    // follow the macOS SDK sys/acl.h ABI. The returned allocation is released
    // exactly once; the entry pointer is borrowed and never dereferenced.
    unsafe {
        let acl = acl_get_fd_np(file.as_raw_fd(), 0x100);
        if acl.is_null() {
            // macOS reports an absent extended ACL as ENOENT even though this
            // is an open descriptor. Other failures cannot establish privacy.
            return std::io::Error::last_os_error().raw_os_error() == Some(libc::ENOENT);
        }
        let mut entry = std::ptr::null_mut();
        let empty = acl_valid(acl) == 0
            && acl_get_entry(acl, 0, &mut entry) == -1
            && std::io::Error::last_os_error().raw_os_error() == Some(libc::EINVAL);
        let released = acl_free(acl) == 0;
        empty && released
    }
}

#[cfg(target_os = "linux")]
fn no_extended_acl(file: &File) -> bool {
    [c"system.posix_acl_access", c"system.posix_acl_default"]
        .into_iter()
        .all(|name| {
            // SAFETY: a live fd, static NUL-terminated name, and a null/zero
            // buffer request only the xattr size; no caller memory is written.
            let size = unsafe {
                libc::fgetxattr(file.as_raw_fd(), name.as_ptr(), std::ptr::null_mut(), 0)
            };
            size < 0
                && matches!(
                    std::io::Error::last_os_error().raw_os_error(),
                    Some(libc::ENODATA | libc::ENOTSUP)
                )
        })
}

#[cfg(not(any(target_os = "macos", target_os = "linux")))]
fn no_extended_acl(_: &File) -> bool {
    false
}
fn open_at(directory: &File, key: &CString, flags: i32) -> std::io::Result<File> {
    // SAFETY: live directory descriptor and NUL-terminated name. The returned
    // descriptor is new and is transferred exactly once to its owning File.
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            key.as_ptr(),
            flags | libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK,
            0o600,
        )
    };
    if fd < 0 {
        return Err(std::io::Error::last_os_error());
    }
    Ok(unsafe { File::from_raw_fd(fd) })
}
fn open_directory(path: &Path) -> Result<File> {
    if !path.is_absolute() {
        return Err(Error::Invalid);
    }
    let mut directory = File::open("/").map_err(|_| Error::Invalid)?;
    for component in path.components() {
        match component {
            Component::RootDir => {}
            Component::Normal(name) => {
                use std::os::unix::ffi::OsStrExt;
                let key = CString::new(name.as_bytes()).map_err(|_| Error::Invalid)?;
                directory = open_at(&directory, &key, libc::O_RDONLY | libc::O_DIRECTORY)
                    .map_err(|_| Error::Invalid)?;
            }
            _ => return Err(Error::Invalid),
        }
    }
    if !private(
        &directory,
        &directory.metadata().map_err(|_| Error::Invalid)?,
        true,
    ) {
        return Err(Error::Invalid);
    }
    Ok(directory)
}

impl FixedSink {
    pub fn admit(root: &Path, key: &str, max_bytes: usize) -> Result<Self> {
        if key.is_empty()
            || key.len() > 128
            || key.starts_with('.')
            || !key
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.'))
            || !(1..=MAX_BYTES).contains(&max_bytes)
        {
            return Err(Error::Invalid);
        }
        let directory = open_directory(root)?;
        let meta = directory.metadata().map_err(|_| Error::Invalid)?;
        let identity = crate::digest(
            format!("sigil-fixed-sink/v1:{}:{}:{}", meta.dev(), meta.ino(), key).as_bytes(),
        );
        let temporary =
            CString::new(format!(".sigil-publish-{}", crate::digest(key.as_bytes()))).unwrap();
        Ok(Self {
            root: root.into(),
            directory,
            key: CString::new(key).unwrap(),
            temporary,
            identity,
            process: std::process::id(),
            max_bytes,
        })
    }

    pub fn identity(&self) -> &str {
        &self.identity
    }

    /// Immutable admitted ceiling, not a receipt or a promise of availability.
    pub fn payload_limit(&self) -> usize {
        self.max_bytes
    }

    fn check(&self) -> Result<()> {
        if self.process != std::process::id() {
            return Err(Error::WrongProcess);
        }
        let current = open_directory(&self.root)?;
        if !same(
            &current.metadata().map_err(|_| Error::Invalid)?,
            &self.directory.metadata().map_err(|_| Error::Invalid)?,
        ) {
            return Err(Error::Invalid);
        }
        Ok(())
    }

    fn target(&self) -> Result<Option<File>> {
        match open_at(&self.directory, &self.key, libc::O_RDONLY) {
            Ok(file) => Ok(Some(file)),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(_) => Err(Error::Invalid),
        }
    }

    fn exact(&self, file: &mut File, payload: &[u8]) -> Result<()> {
        let meta = file.metadata().map_err(|_| Error::Unconfirmed)?;
        if !private(file, &meta, false)
            || meta.len() != payload.len() as u64
            || meta.len() > self.max_bytes as u64
            || meta.nlink() == 0
            || meta.nlink() > 2
        {
            return Err(Error::Conflict);
        }
        file.seek(SeekFrom::Start(0))
            .map_err(|_| Error::Unconfirmed)?;
        let mut bytes = Vec::new();
        file.take(self.max_bytes as u64 + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| Error::Unconfirmed)?;
        if bytes != payload {
            return Err(Error::Conflict);
        }
        Ok(())
    }

    fn unlink_temporary(&self) -> Result<()> {
        // SAFETY: live root descriptor and fixed NUL-terminated child name.
        if unsafe { libc::unlinkat(self.directory.as_raw_fd(), self.temporary.as_ptr(), 0) } != 0 {
            return Err(Error::Unconfirmed);
        }
        Ok(())
    }

    /// The exact prior payload must already be durable. Repeating the same
    /// publication re-syncs and checks the actual destination; conflicts never
    /// overwrite it. Errors do not imply that publication did not happen.
    pub fn publish(&mut self, payload: &[u8]) -> Result<DurablePublication> {
        self.publish_inner(payload, |_| Ok(()))
    }

    fn publish_inner(
        &mut self,
        payload: &[u8],
        mut cut: impl FnMut(u8) -> Result<()>,
    ) -> Result<DurablePublication> {
        self.check()?;
        if payload.is_empty() || payload.len() > self.max_bytes {
            return Err(Error::Invalid);
        }
        let mut existing = true;
        // One fixed temporary coordinate bounds crash/retry debris per admitted
        // destination. Its OS lock also excludes another publisher process.
        let mut temporary = match open_at(
            &self.directory,
            &self.temporary,
            libc::O_RDWR | libc::O_CREAT | libc::O_EXCL,
        ) {
            Ok(file) => file,
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
                open_at(&self.directory, &self.temporary, libc::O_RDWR)
                    .map_err(|_| Error::Invalid)?
            }
            Err(_) => return Err(Error::Invalid),
        };
        temporary.try_lock().map_err(|_| Error::Busy)?;
        let tm = temporary.metadata().map_err(|_| Error::Invalid)?;
        if !private(&temporary, &tm, false)
            || tm.nlink() < 1
            || tm.nlink() > 2
            || tm.len() > self.max_bytes as u64
        {
            return Err(Error::Invalid);
        }
        let named = open_at(&self.directory, &self.temporary, libc::O_RDONLY)
            .map_err(|_| Error::Invalid)?;
        if !same(&tm, &named.metadata().map_err(|_| Error::Invalid)?) {
            return Err(Error::Invalid);
        }
        if let Some(mut target) = self.target()? {
            self.exact(&mut target, payload)?;
            let target_meta = target.metadata().map_err(|_| Error::Unconfirmed)?;
            if target_meta.nlink() != 1 && !same(&tm, &target_meta) {
                return Err(Error::Conflict);
            }
            if tm.nlink() != 1 && !same(&tm, &target_meta) {
                return Err(Error::Conflict);
            }
            target.sync_all().map_err(|_| Error::Unconfirmed)?;
            self.unlink_temporary()?;
        } else {
            if tm.nlink() != 1 {
                return Err(Error::Conflict);
            }
            // A previous owner may have died during a partial temporary write.
            // Its released lock and this exact fixed destination allow repair
            // from the caller's unchanged, already-durable prepared bytes.
            temporary.set_len(0).map_err(|_| Error::Unconfirmed)?;
            temporary
                .seek(SeekFrom::Start(0))
                .map_err(|_| Error::Unconfirmed)?;
            temporary
                .write_all(payload)
                .map_err(|_| Error::Unconfirmed)?;
            cut(1)?;
            temporary.sync_all().map_err(|_| Error::Unconfirmed)?;
            cut(2)?;
            self.check()?;
            // linkat is create-only: neither rename nor an existence check is
            // used as an overwrite authorization.
            let linked = unsafe {
                libc::linkat(
                    self.directory.as_raw_fd(),
                    self.temporary.as_ptr(),
                    self.directory.as_raw_fd(),
                    self.key.as_ptr(),
                    0,
                )
            };
            if linked != 0 {
                let error = std::io::Error::last_os_error();
                if error.kind() != std::io::ErrorKind::AlreadyExists {
                    return Err(Error::Unconfirmed);
                }
                let mut target = self.target()?.ok_or(Error::Unconfirmed)?;
                self.exact(&mut target, payload)?;
                if target.metadata().map_err(|_| Error::Unconfirmed)?.nlink() != 1 {
                    return Err(Error::Conflict);
                }
                target.sync_all().map_err(|_| Error::Unconfirmed)?;
            } else {
                existing = false;
            }
            cut(3)?;
            self.unlink_temporary()?;
        }
        cut(4)?;
        self.directory.sync_all().map_err(|_| Error::Unconfirmed)?;
        cut(5)?;
        self.check()?;
        let mut target = self.target()?.ok_or(Error::Unconfirmed)?;
        self.exact(&mut target, payload)?;
        if target.metadata().map_err(|_| Error::Unconfirmed)?.nlink() != 1 {
            return Err(Error::Conflict);
        }
        target.sync_all().map_err(|_| Error::Unconfirmed)?;
        self.directory.sync_all().map_err(|_| Error::Unconfirmed)?;
        let named = self.target()?.ok_or(Error::Unconfirmed)?;
        if !same(
            &target.metadata().map_err(|_| Error::Unconfirmed)?,
            &named.metadata().map_err(|_| Error::Unconfirmed)?,
        ) {
            return Err(Error::Unconfirmed);
        }
        cut(6)?;
        Ok(DurablePublication {
            destination: self.identity.clone(),
            payload_sha256: crate::digest(payload),
            payload_bytes: payload.len(),
            existing,
        })
    }
}

#[cfg(test)]
#[path = "publication_tests.rs"]
mod tests;
