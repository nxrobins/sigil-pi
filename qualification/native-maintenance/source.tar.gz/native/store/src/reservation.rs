//! Schema-3 pool credits and explicit schema-4 authenticated-chain allowances,
//! distinct from data coordinates and their revisions. This is not physical disk
//! allocation, execution admission, a retry policy or permission to retire an attempt.
//! The embedding host must bind held credits to the actual in-flight ticket.
use super::*;
#[path = "reservation_audit.rs"]
pub(super) mod audit;
#[path = "reservation_catalog.rs"]
pub(super) mod catalog;
pub use audit::{Allowance, Debit};
#[path = "reservation_slots.rs"]
pub mod slots;
pub use slots::Generation;
#[path = "reservation_witness.rs"]
pub mod witness;

pub const ENTRIES: usize = 1024;
pub const ROW_BYTES: u64 = 144;
pub(super) const SQL: &str = "CREATE TABLE reservations (namespace TEXT NOT NULL, key TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0), binding BLOB NOT NULL, records INTEGER NOT NULL CHECK(records>=0), bytes INTEGER NOT NULL CHECK(bytes>=0), digest BLOB NOT NULL, PRIMARY KEY(namespace,key)) WITHOUT ROWID";

pub(super) const AUDITED_SQL: &str = "CREATE TABLE reservations (namespace TEXT NOT NULL, key TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0), binding BLOB NOT NULL, records INTEGER NOT NULL CHECK(records>=0), bytes INTEGER NOT NULL CHECK(bytes>=0), audits BLOB NOT NULL, digest BLOB NOT NULL, PRIMARY KEY(namespace,key)) WITHOUT ROWID";
pub(super) const WITNESSED_SQL: &str = "CREATE TABLE reservations (namespace TEXT NOT NULL, key TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0), binding BLOB NOT NULL, records INTEGER NOT NULL CHECK(records>=0), bytes INTEGER NOT NULL CHECK(bytes>=0), audits BLOB NOT NULL, origin BLOB NOT NULL, witness BLOB NOT NULL, digest BLOB NOT NULL, PRIMARY KEY(namespace,key)) WITHOUT ROWID";
pub(super) const GENERATIONAL_SQL: &str = "CREATE TABLE reservations (namespace TEXT NOT NULL, key TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0), binding BLOB NOT NULL, records INTEGER NOT NULL CHECK(records>=0), bytes INTEGER NOT NULL CHECK(bytes>=0), audits BLOB NOT NULL, origin BLOB NOT NULL, witness BLOB NOT NULL, digest BLOB NOT NULL, pool TEXT NOT NULL, slot INTEGER NOT NULL CHECK(slot>=0), generation INTEGER NOT NULL CHECK(generation>0), PRIMARY KEY(namespace,key)) WITHOUT ROWID";
pub(super) fn schema_sql(profile: u8) -> &'static str {
    match profile {
        7 => GENERATIONAL_SQL,
        5 | 6 => WITNESSED_SQL,
        4 => AUDITED_SQL,
        _ => SQL,
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Credits {
    pub records: u64,
    pub live_bytes: u64,
}
impl Credits {
    fn empty(self) -> bool {
        self.records == 0 && self.live_bytes == 0
    }
    fn subtract(self, debit: Self) -> Result<Self> {
        Ok(Self {
            records: self
                .records
                .checked_sub(debit.records)
                .ok_or(Error::Limit)?,
            live_bytes: self
                .live_bytes
                .checked_sub(debit.live_bytes)
                .ok_or(Error::Limit)?,
        })
    }
}

/// Trusted embedding input, never a serialized handle or a data-write grant.
pub struct Request {
    pub namespace: String,
    pub key: String,
    pub binding: [u8; 32],
    pub credits: Credits,
}

/// Deliberately not Clone, Debug or serializable. This permits a credit debit;
/// it never expands the ordinary Scope needed for the coupled data mutation.
pub struct Held {
    boot: [u8; 32],
    namespace: String,
    key: String,
    revision: u64,
    binding: [u8; 32],
    credits: Credits,
    pub(super) audits: Vec<audit::Credit>,
    witness: Option<witness::Retained>,
    generation: Option<Generation>,
}
impl Held {
    pub fn generation(&self) -> Option<&Generation> {
        self.generation.as_ref()
    }
    /// Trusted embedding inspection for final retirement. This does not grant
    /// signing authority or establish that an assigned execution has stopped.
    pub fn remaining_audit_debits(&self) -> Vec<Debit> {
        self.audits
            .iter()
            .map(|a| Debit {
                heads: a.heads.clone(),
                records_namespace: a.records_namespace.clone(),
                chain: a.chain.clone(),
                records: a.records,
                bytes: a.bytes,
            })
            .collect()
    }

    pub fn unassigned(&self) -> bool {
        self.witness
            .as_ref()
            .is_some_and(|w| w.assignment.is_empty())
    }

    pub fn origin(&self) -> Option<[u8; 32]> {
        self.witness.as_ref().map(|w| w.origin)
    }
    /// A snapshot, not a promise that a later generation or write will succeed.
    pub fn credits(&self) -> Credits {
        self.credits
    }
    pub fn revision(&self) -> u64 {
        self.revision
    }
    /// Non-secret lookup coordinates, not a storage scope or recovery grant.
    pub fn coordinate(&self) -> (&str, &str) {
        (&self.namespace, &self.key)
    }
}

pub struct Publication {
    pub receipt: Receipt,
    /// None means all credits were consumed. A charged ledger tombstone remains.
    pub held: Option<Held>,
}

struct Entry {
    revision: u64,
    binding: [u8; 32],
    credits: Credits,
    audits: Vec<audit::Credit>,
    witness: Option<witness::Retained>,
    generation: Option<Generation>,
}

fn digest(namespace: &str, key: &str, entry: &Entry, profile: u8) -> Result<Vec<u8>> {
    let mut value = Sha256::new();
    value.update(if profile == 7 {
        &b"sigil-storage-reservation/v4\0"[..]
    } else if profile >= 5 {
        &b"sigil-storage-reservation/v3\0"[..]
    } else if profile == 4 {
        &b"sigil-storage-reservation/v2\0"[..]
    } else {
        &b"sigil-storage-reservation/v1\0"[..]
    });
    for part in [namespace.as_bytes(), key.as_bytes()] {
        value.update((part.len() as u64).to_be_bytes());
        value.update(part);
    }
    value.update(entry.revision.to_be_bytes());
    value.update(entry.binding);
    value.update(entry.credits.records.to_be_bytes());
    value.update(entry.credits.live_bytes.to_be_bytes());
    if profile >= 4 {
        let encoded = audit::encode(&entry.audits)?;
        value.update((encoded.len() as u64).to_be_bytes());
        value.update(encoded);
    }
    if profile >= 5 {
        let retained = entry.witness.as_ref().ok_or(Error::Corrupt)?;
        if !retained.valid(entry.binding) {
            return Err(Error::Corrupt);
        }
        value.update(retained.origin);
        value.update((retained.assignment.len() as u64).to_be_bytes());
        value.update(&retained.assignment);
    }
    if profile == 7 {
        let g = entry.generation.as_ref().ok_or(Error::Corrupt)?;
        if !valid_name(&g.pool, 128) || g.generation == 0 || g.generation > i64::MAX as u64 {
            return Err(Error::Corrupt);
        }
        value.update((g.pool.len() as u64).to_be_bytes());
        value.update(g.pool.as_bytes());
        value.update(g.slot.to_be_bytes());
        value.update(g.generation.to_be_bytes());
    } else if entry.generation.is_some() {
        return Err(Error::Corrupt);
    }
    Ok(value.finalize().to_vec())
}

fn read(connection: &Connection, namespace: &str, key: &str, profile: u8) -> Result<Option<Entry>> {
    let sql = if profile >= 5 {
        "SELECT revision,binding,records,bytes,digest,length(binding),length(digest),audits,length(audits),origin,length(origin),witness,length(witness) FROM reservations WHERE namespace=?1 AND key=?2"
    } else if profile == 4 {
        "SELECT revision,binding,records,bytes,digest,length(binding),length(digest),audits,length(audits),X'',0,X'',0 FROM reservations WHERE namespace=?1 AND key=?2"
    } else {
        "SELECT revision,binding,records,bytes,digest,length(binding),length(digest),CAST('[]' AS BLOB),2,X'',0,X'',0 FROM reservations WHERE namespace=?1 AND key=?2"
    };
    let row = connection
        .query_row(sql, params![namespace, key], |r| {
            if r.get::<_, i64>(5)? != 32
                || r.get::<_, i64>(6)? != 32
                || !(2..=audit::ENCODED_BYTES as i64).contains(&r.get::<_, i64>(8)?)
                || r.get::<_, i64>(10)? != if profile >= 5 { 32 } else { 0 }
                || !(0..=if profile >= 5 {
                    witness::BYTES as i64
                } else {
                    0
                })
                    .contains(&r.get::<_, i64>(12)?)
            {
                return Err(rusqlite::Error::InvalidQuery);
            }
            Ok((
                r.get::<_, i64>(0)?,
                r.get::<_, Vec<u8>>(1)?,
                r.get::<_, i64>(2)?,
                r.get::<_, i64>(3)?,
                r.get::<_, Vec<u8>>(4)?,
                r.get::<_, Vec<u8>>(7)?,
                r.get::<_, Vec<u8>>(9)?,
                r.get::<_, Vec<u8>>(11)?,
            ))
        })
        .optional()
        .map_err(|_| Error::Corrupt)?;
    let Some((revision, binding, records, bytes, stored_digest, audits, origin, assignment)) = row
    else {
        return Ok(None);
    };
    if revision <= 0 || records < 0 || bytes < 0 {
        return Err(Error::Corrupt);
    }
    let generation = if profile == 7 {
        Some(connection.query_row("SELECT pool,slot,generation,length(CAST(pool AS BLOB)) FROM reservations WHERE namespace=?1 AND key=?2",params![namespace,key],|r| {
            if !(1..=128).contains(&r.get::<_,i64>(3)?) {return Err(rusqlite::Error::InvalidQuery);}
            Ok(Generation {pool:r.get(0)?,slot:r.get(1)?,generation:r.get::<_,i64>(2)?.try_into().map_err(|_|rusqlite::Error::InvalidQuery)?})
        }).map_err(|_|Error::Corrupt)?)
    } else {
        None
    };
    let entry = Entry {
        generation,
        revision: revision as u64,
        binding: binding.try_into().map_err(|_| Error::Corrupt)?,
        credits: Credits {
            records: records as u64,
            live_bytes: bytes as u64,
        },
        audits: audit::decode(&audits)?,
        witness: if profile >= 5 {
            Some(witness::Retained {
                origin: origin.try_into().map_err(|_| Error::Corrupt)?,
                assignment,
            })
        } else {
            None
        },
    };
    if stored_digest != digest(namespace, key, &entry, profile)? {
        return Err(Error::Corrupt);
    }
    Ok(Some(entry))
}

pub(super) enum Change<'a> {
    Create(&'a Request, &'a [Allowance], Option<&'a Generation>),
    Retire(&'a slots::Retirement),
    Spend(
        &'a Held,
        Credits,
        &'a [Debit],
        Option<[u8; 32]>,
        Option<&'a [u8]>,
    ),
}
pub(super) fn apply(
    connection: &Connection,
    change: Change<'_>,
    profile: u8,
    allocation: Option<&capacity::Allocation>,
) -> Result<()> {
    let (namespace, key, entry) = match change {
        Change::Retire(request) => {
            if profile != 7 {
                return Err(Error::Invalid);
            }
            let old = read(connection, &request.namespace, &request.key, profile)?
                .ok_or(Error::Conflict)?;
            if old.revision != request.revision
                || old.binding != request.binding
                || old.generation.as_ref() != Some(&request.generation)
                || !old.credits.empty()
                || !audit::empty(&old.audits)
                || !old
                    .witness
                    .as_ref()
                    .is_some_and(|w| w.assignment.is_empty())
            {
                return Err(Error::Conflict);
            }
            slots::release(connection, &request.generation)?;
            if connection
                .execute(
                    "DELETE FROM reservations WHERE namespace=?1 AND key=?2",
                    params![request.namespace, request.key],
                )
                .map_err(|_| Error::Storage)?
                != 1
            {
                return Err(Error::Conflict);
            }
            return Ok(());
        }
        Change::Create(request, allowances, expected) => {
            // Even a closed ledger coordinate cannot silently become a new
            // reservation. Retention/migration must preserve its causal fence.
            if read(connection, &request.namespace, &request.key, profile)?.is_some() {
                return Err(Error::Conflict);
            }
            if expected.is_some() && profile != 7 {
                return Err(Error::Invalid);
            }
            (
                &request.namespace,
                &request.key,
                Entry {
                    generation: if profile == 7 {
                        let pool = allocation
                            .ok_or(Error::Invalid)?
                            .pools
                            .iter()
                            .find(|p| p.namespaces.contains(&request.namespace))
                            .ok_or(Error::Denied)?;
                        let actual = slots::allocate(connection, &pool.id)?;
                        if expected.is_some_and(|expected| expected != &actual) {
                            return Err(Error::Conflict);
                        }
                        Some(actual)
                    } else {
                        None
                    },
                    revision: 1,
                    binding: request.binding,
                    credits: request.credits,
                    audits: audit::create(connection, profile, allowances)?,
                    witness: witness::created(profile, request.binding),
                },
            )
        }
        Change::Spend(held, debit, audit_debits, next_binding, next_witness) => {
            let old =
                read(connection, &held.namespace, &held.key, profile)?.ok_or(Error::Conflict)?;
            if old.revision != held.revision
                || old.binding != held.binding
                || old.credits != held.credits
                || old.audits != held.audits
                || old.witness != held.witness
                || old.generation != held.generation
            {
                return Err(Error::Conflict);
            }
            if old.revision == i64::MAX as u64 {
                return Err(Error::Limit);
            }
            (
                &held.namespace,
                &held.key,
                Entry {
                    generation: old.generation.clone(),
                    revision: old.revision + 1,
                    binding: next_binding.unwrap_or(old.binding),
                    credits: old.credits.subtract(debit)?,
                    audits: audit::spend(&old.audits, audit_debits)?,
                    witness: witness::update(
                        profile,
                        old.witness.as_ref(),
                        old.binding,
                        next_binding,
                        next_witness,
                    )?,
                },
            )
        }
    };
    if profile == 7 {
        let retained = entry.witness.as_ref().ok_or(Error::Corrupt)?;
        let generation = entry.generation.as_ref().ok_or(Error::Corrupt)?;
        connection.execute("INSERT INTO reservations(namespace,key,revision,binding,records,bytes,audits,origin,witness,digest,pool,slot,generation) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13) ON CONFLICT(namespace,key) DO UPDATE SET revision=excluded.revision,binding=excluded.binding,records=excluded.records,bytes=excluded.bytes,audits=excluded.audits,origin=excluded.origin,witness=excluded.witness,digest=excluded.digest",params![namespace,key,entry.revision as i64,&entry.binding[..],entry.credits.records as i64,entry.credits.live_bytes as i64,audit::encode(&entry.audits)?,&retained.origin[..],&retained.assignment,digest(namespace,key,&entry,profile)?,generation.pool,generation.slot,generation.generation as i64]).map_err(|_|Error::Storage)?;
    } else if profile >= 5 {
        let retained = entry.witness.as_ref().ok_or(Error::Corrupt)?;
        connection.execute(
            "INSERT INTO reservations(namespace,key,revision,binding,records,bytes,audits,origin,witness,digest) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10) ON CONFLICT(namespace,key) DO UPDATE SET revision=excluded.revision,binding=excluded.binding,records=excluded.records,bytes=excluded.bytes,audits=excluded.audits,origin=excluded.origin,witness=excluded.witness,digest=excluded.digest",
            params![namespace,key,entry.revision as i64,&entry.binding[..],entry.credits.records as i64,
                entry.credits.live_bytes as i64,audit::encode(&entry.audits)?,&retained.origin[..],&retained.assignment,
                digest(namespace,key,&entry,profile)?]
        ).map_err(|_| Error::Storage)?;
    } else if profile == 4 {
        connection.execute(
            "INSERT INTO reservations(namespace,key,revision,binding,records,bytes,audits,digest) VALUES (?1,?2,?3,?4,?5,?6,?7,?8) ON CONFLICT(namespace,key) DO UPDATE SET revision=excluded.revision,binding=excluded.binding,records=excluded.records,bytes=excluded.bytes,audits=excluded.audits,digest=excluded.digest",
            params![namespace,key,entry.revision as i64,&entry.binding[..],entry.credits.records as i64,
                entry.credits.live_bytes as i64,audit::encode(&entry.audits)?,digest(namespace,key,&entry,profile)?]
        ).map_err(|_| Error::Storage)?;
    } else {
        connection.execute(
            "INSERT INTO reservations(namespace,key,revision,binding,records,bytes,digest) VALUES (?1,?2,?3,?4,?5,?6,?7) ON CONFLICT(namespace,key) DO UPDATE SET revision=excluded.revision,binding=excluded.binding,records=excluded.records,bytes=excluded.bytes,digest=excluded.digest",
            params![namespace,key,entry.revision as i64,&entry.binding[..],entry.credits.records as i64,
                entry.credits.live_bytes as i64,digest(namespace,key,&entry,profile)?]
        ).map_err(|_| Error::Storage)?;
    }
    Ok(())
}

/// Includes the separate ledger and outstanding credits in the SAME proposed
/// transaction as actual data. Definite rejection rolls back both. A coherent
/// older database is not detectable here; the existing rollback limits remain.
pub(super) fn check(
    connection: &Connection,
    limits: &Limits,
    allocation: &capacity::Allocation,
    profile: u8,
    slots: Option<&BTreeMap<String, u16>>,
) -> Result<()> {
    if profile == 7 {
        slots::validate(connection, slots.ok_or(Error::Corrupt)?)?;
    }
    let mut ledger_counts: BTreeMap<String, usize> = BTreeMap::new();
    let mut totals: BTreeMap<String, (u64, u64)> = BTreeMap::new();
    let mut query=connection.prepare("SELECT namespace,count(*),sum(coalesce(length(value),0)+length(namespace)+length(key)+96) FROM records GROUP BY namespace").map_err(|_| Error::Corrupt)?;
    let mut rows = query.query([]).map_err(|_| Error::Corrupt)?;
    while let Some(row) = rows.next().map_err(|_| Error::Corrupt)? {
        let count: i64 = row.get(1).map_err(|_| Error::Corrupt)?;
        let bytes: i64 = row.get(2).map_err(|_| Error::Corrupt)?;
        if count < 0 || bytes < 0 {
            return Err(Error::Corrupt);
        }
        totals.insert(
            row.get(0).map_err(|_| Error::Corrupt)?,
            (count as u64, bytes as u64),
        );
    }
    let mut query = connection
        .prepare("SELECT namespace,key,length(CAST(namespace AS BLOB)),length(CAST(key AS BLOB)) FROM reservations ORDER BY namespace,key LIMIT ?1")
        .map_err(|_| Error::Corrupt)?;
    let mut rows = query
        .query([ENTRIES as i64 + 1])
        .map_err(|_| Error::Corrupt)?;
    let mut count = 0;
    while let Some(row) = rows.next().map_err(|_| Error::Corrupt)? {
        count += 1;
        if count > ENTRIES {
            return Err(Error::Limit);
        }
        // Inspect byte lengths before allocating strings from retained metadata.
        let namespace_bytes: i64 = row.get(2).map_err(|_| Error::Corrupt)?;
        let key_bytes: i64 = row.get(3).map_err(|_| Error::Corrupt)?;
        if !(1..=128).contains(&namespace_bytes) || !(1..=256).contains(&key_bytes) {
            return Err(Error::Corrupt);
        }
        let namespace: String = row.get(0).map_err(|_| Error::Corrupt)?;
        let key: String = row.get(1).map_err(|_| Error::Corrupt)?;
        if !valid_name(&namespace, 128) || !valid_name(&key, 256) || !allocation.covers(&namespace)
        {
            return Err(Error::Corrupt);
        }
        let entry = read(connection, &namespace, &key, profile)?.ok_or(Error::Corrupt)?;
        if profile == 7 {
            let g = entry.generation.as_ref().ok_or(Error::Corrupt)?;
            if !allocation
                .pools
                .iter()
                .any(|p| p.id == g.pool && p.namespaces.contains(&namespace))
            {
                return Err(Error::Corrupt);
            }
        }
        *ledger_counts.entry(namespace.clone()).or_default() += 1;
        audit::validate(&entry.audits, limits, allocation, &namespace)?;
        let metadata_bytes = if profile >= 4 {
            audit::encode(&entry.audits)?.len() as u64
        } else {
            0
        };
        let metadata_bytes = metadata_bytes
            + entry
                .generation
                .as_ref()
                .map_or(0, |g| g.pool.len() as u64 + 10)
            + entry
                .witness
                .as_ref()
                .map_or(0, |w| 32 + w.assignment.len() as u64);
        let total = totals.entry(namespace.clone()).or_default();
        total.0 = total
            .0
            .checked_add(1)
            .and_then(|n| n.checked_add(entry.credits.records))
            .ok_or(Error::Corrupt)?;
        total.1 = total
            .1
            .checked_add(ROW_BYTES + namespace.len() as u64 + key.len() as u64 + metadata_bytes)
            .and_then(|n| n.checked_add(entry.credits.live_bytes))
            .ok_or(Error::Corrupt)?;
    }
    let mut global = (0u64, 0u64);
    for pool in &allocation.pools {
        let mut total = if profile == 7 {
            let n = u64::from(
                *slots
                    .ok_or(Error::Corrupt)?
                    .get(&pool.id)
                    .ok_or(Error::Corrupt)?,
            );
            (n, n * (slots::ROW_BYTES + pool.id.len() as u64))
        } else {
            (0u64, 0u64)
        };
        let mut ledger_count = 0usize;
        for namespace in &pool.namespaces {
            ledger_count += ledger_counts.remove(namespace).unwrap_or_default();
            let add = totals.remove(namespace).unwrap_or_default();
            total.0 = total.0.checked_add(add.0).ok_or(Error::Corrupt)?;
            total.1 = total.1.checked_add(add.1).ok_or(Error::Corrupt)?;
        }
        if let Some(slots) = slots {
            if ledger_count > usize::from(*slots.get(&pool.id).ok_or(Error::Corrupt)?) {
                return Err(Error::Limit);
            }
        } else if profile >= 4 {
            return Err(Error::Corrupt);
        }
        if total.0 > pool.records || total.1 > pool.live_bytes {
            return Err(Error::Limit);
        }
        global.0 = global.0.checked_add(total.0).ok_or(Error::Corrupt)?;
        global.1 = global.1.checked_add(total.1).ok_or(Error::Corrupt)?;
    }
    if !totals.is_empty() {
        return Err(Error::Corrupt);
    }
    if global.0 > limits.records || global.1 > limits.live_bytes {
        return Err(Error::Limit);
    }
    Ok(())
}

impl Store {
    fn reservation_owner(&self, scope: &Scope, namespace: &str, key: &str) -> Result<()> {
        if self.reserving == 0 {
            return Err(Error::Invalid);
        }
        self.authorize(scope, namespace, key, true, 0, false)?;
        if scope.grants.get(namespace) != Some(&Access::ReadWrite) {
            return Err(Error::Denied);
        }
        self.verify_process()
    }

    fn reservation_batch(&self, scope: &Scope, batch: &Batch, owner: &str) -> Result<()> {
        self.check_batch(scope, batch)?;
        let pool = self
            .allocation
            .as_ref()
            .ok_or(Error::Invalid)?
            .pools
            .iter()
            .find(|pool| pool.namespaces.iter().any(|name| name == owner))
            .ok_or(Error::Denied)?;
        if batch
            .writes
            .iter()
            .any(|write| !pool.namespaces.contains(&write.namespace))
        {
            return Err(Error::Denied);
        }
        Ok(())
    }

    /// Reserve and publish intent/state atomically. This does not admit dispatch.
    pub fn commit_reserving(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
    ) -> Result<Publication> {
        self.commit_reserving_inner(scope, batch, request, || {})
    }

    fn commit_reserving_inner(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.commit_reserving_audited_inner(scope, batch, request, &[], None, before_commit)
    }

    /// Publish data and reserve logical pool and authenticated-chain allowances
    /// atomically. Allowance proposals must come from actual authenticated heads.
    pub fn commit_reserving_audited(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
        allowances: &[Allowance],
    ) -> Result<Publication> {
        self.commit_reserving_audited_inner(scope, batch, request, allowances, None, || {})
    }

    /// The application can publish its chosen allocation identity in `batch`
    /// atomically with this exact catalog allocation. Stale proposals refuse.
    pub fn commit_reserving_generation_audited(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
        allowances: &[Allowance],
        expected: &Generation,
    ) -> Result<Publication> {
        if self.reserving != 7 {
            return Err(Error::Invalid);
        }
        self.commit_reserving_bound_inner(
            scope,
            batch,
            request,
            allowances,
            None,
            Some(expected),
            || {},
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn commit_reserving_audited_inner(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
        allowances: &[Allowance],
        guard: Option<&audit::Guard>,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.commit_reserving_bound_inner(
            scope,
            batch,
            request,
            allowances,
            guard,
            None,
            before_commit,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn commit_reserving_bound_inner(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        request: &Request,
        allowances: &[Allowance],
        guard: Option<&audit::Guard>,
        expected: Option<&Generation>,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.reservation_owner(scope, &request.namespace, &request.key)?;
        self.reservation_batch(scope, batch, &request.namespace)?;
        if request.credits.empty()
            || request.credits.records > self.limits.records
            || request.credits.live_bytes > self.limits.live_bytes
        {
            return Err(Error::Limit);
        }
        audit::authorize(self, scope, &request.namespace, batch, allowances, guard)?;
        let mut audits: Vec<_> = allowances.iter().map(|a| a.credit.clone()).collect();
        audits.sort_by(|a, b| {
            (&a.heads, &a.records_namespace, &a.chain).cmp(&(
                &b.heads,
                &b.records_namespace,
                &b.chain,
            ))
        });
        let receipt = self.commit_storage_reserved(
            batch,
            Some(Change::Create(request, allowances, expected)),
            guard,
            before_commit,
        )?;
        let generation = if self.reserving == 7 {
            let observed = (|| {
                let _snapshot = self.anchored_read()?;
                read(
                    &self.connection,
                    &request.namespace,
                    &request.key,
                    self.reserving,
                )?
                .ok_or(Error::Corrupt)?
                .generation
                .ok_or(Error::Corrupt)
            })();
            match observed {
                Ok(generation) => Some(generation),
                Err(_) => {
                    self.poisoned = true;
                    return Err(Error::CommitUncertain);
                }
            }
        } else {
            None
        };
        Ok(Publication {
            receipt,
            held: Some(Held {
                boot: self.boot,
                namespace: request.namespace.clone(),
                key: request.key.clone(),
                generation,
                revision: 1,
                binding: request.binding,
                credits: request.credits,
                audits,
                witness: witness::created(self.reserving, request.binding),
            }),
        })
    }

    /// Validate an already-held native capability at its exact current binding.
    /// This neither mints a grant nor proves execution/recovery authority.
    pub fn check_reservation_binding(&self, held: &Held, expected_binding: [u8; 32]) -> Result<()> {
        self.verify_process()?;
        if held.boot != self.boot || held.binding != expected_binding {
            return Err(Error::Denied);
        }
        self.verify_storage_files()?;
        let _snapshot = self.anchored_read()?;
        let entry = read(&self.connection, &held.namespace, &held.key, self.reserving)?
            .ok_or(Error::Conflict)?;
        if entry.revision != held.revision
            || entry.binding != held.binding
            || entry.credits != held.credits
            || entry.audits != held.audits
            || entry.witness != held.witness
            || entry.generation != held.generation
            || (entry.credits.empty() && audit::empty(&entry.audits))
        {
            return Err(Error::Conflict);
        }
        Ok(())
    }

    /// Reacquire credit authority after independent application/host recovery.
    /// This proves exact current ownership/binding, not whether a request ran.
    pub fn resume_reservation(
        &self,
        scope: &Scope,
        namespace: &str,
        key: &str,
        revision: u64,
        binding: [u8; 32],
    ) -> Result<Held> {
        if self.reserving == 7 {
            return Err(Error::Denied);
        }
        self.resume_reservation_generation_inner(scope, namespace, key, revision, binding, None)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn resume_reservation_generation(
        &self,
        scope: &Scope,
        namespace: &str,
        key: &str,
        revision: u64,
        binding: [u8; 32],
        generation: &Generation,
    ) -> Result<Held> {
        if self.reserving != 7 {
            return Err(Error::Invalid);
        }
        self.resume_reservation_generation_inner(
            scope,
            namespace,
            key,
            revision,
            binding,
            Some(generation),
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn resume_reservation_generation_inner(
        &self,
        scope: &Scope,
        namespace: &str,
        key: &str,
        revision: u64,
        binding: [u8; 32],
        generation: Option<&Generation>,
    ) -> Result<Held> {
        self.reservation_owner(scope, namespace, key)?;
        self.verify_storage_files()?;
        let _snapshot = self.anchored_read()?;
        let entry =
            read(&self.connection, namespace, key, self.reserving)?.ok_or(Error::Missing)?;
        if entry.generation.as_ref() != generation
            || entry.revision != revision
            || entry.binding != binding
            || (entry.credits.empty() && audit::empty(&entry.audits))
        {
            return Err(Error::Conflict);
        }
        Ok(Held {
            boot: self.boot,
            namespace: namespace.into(),
            key: key.into(),
            revision: entry.revision,
            binding: entry.binding,
            credits: entry.credits,
            audits: entry.audits,
            witness: entry.witness,
            generation: entry.generation,
        })
    }

    /// Refresh an existing trusted holder after another serialized, authorized
    /// debit. Assignment, binding and origin must be identical; credits can only
    /// decrease. This cannot adopt another execution or a returned reservation.
    pub fn refresh_reservation(&self, held: &Held) -> Result<Held> {
        self.verify_files()?;
        if held.boot != self.boot || held.unassigned() {
            return Err(Error::Denied);
        }
        let _snapshot = self.anchored_read()?;
        let entry = read(&self.connection, &held.namespace, &held.key, self.reserving)?
            .ok_or(Error::Missing)?;
        if entry.revision < held.revision
            || entry.binding != held.binding
            || entry.witness != held.witness
            || entry.generation != held.generation
            || entry.credits.records > held.credits.records
            || entry.credits.live_bytes > held.credits.live_bytes
            || entry.audits.len() != held.audits.len()
            || entry
                .audits
                .iter()
                .zip(&held.audits)
                .any(|(a, b)| !a.same_chain(b) || a.records > b.records || a.bytes > b.bytes)
        {
            return Err(Error::Conflict);
        }
        Ok(Held {
            boot: self.boot,
            namespace: held.namespace.clone(),
            key: held.key.clone(),
            revision: entry.revision,
            binding: entry.binding,
            credits: entry.credits,
            audits: entry.audits,
            witness: entry.witness,
            generation: entry.generation,
        })
    }

    /// The trusted holder selects a debit; ordinary scoped writes remain checked.
    /// A definite rejection preserves credits. CommitUncertain does NOT: the owner
    /// is poisoned and must reopen/reconcile data and ledger before further work.
    pub fn commit_spending(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
    ) -> Result<Publication> {
        self.commit_spending_inner(scope, batch, held, debit, || {})
    }

    pub(super) fn commit_spending_inner(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.commit_spending_guarded(scope, batch, held, debit, &[], None, before_commit)
    }

    /// Debit or explicitly relinquish held chain allowances with related data.
    /// The holder must enforce its application retirement/in-flight policy; this
    /// primitive never decides that an external effect has stopped or is safe to retry.
    pub fn commit_spending_audited(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        audits: &[Debit],
    ) -> Result<Publication> {
        self.commit_spending_guarded(scope, batch, held, debit, audits, None, || {})
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn commit_spending_guarded(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        debits: &[Debit],
        guard: Option<&audit::Guard>,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.commit_credit_update(
            scope,
            batch,
            held,
            debit,
            debits,
            None,
            guard,
            before_commit,
        )
    }

    /// Atomically move an existing credit generation to a new opaque binding
    /// while publishing scoped data and selected debits. The old generation can
    /// no longer spend or assign it after confirmation. This alone does not prove
    /// any worker identity or establish that an old effect has stopped: only the
    /// trusted embedding can bind its actual claim/ticket and authorize recovery.
    #[allow(clippy::too_many_arguments)]
    pub fn commit_assigning(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        debits: &[Debit],
        next_binding: [u8; 32],
    ) -> Result<Publication> {
        self.commit_credit_update(
            scope,
            batch,
            held,
            debit,
            debits,
            Some(next_binding),
            None,
            || {},
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn commit_credit_update(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        debits: &[Debit],
        next_binding: Option<[u8; 32]>,
        guard: Option<&audit::Guard>,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        self.commit_credit_update_witness(
            scope,
            batch,
            held,
            debit,
            debits,
            next_binding,
            None,
            guard,
            before_commit,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn commit_credit_update_witness(
        &mut self,
        scope: &Scope,
        batch: &Batch,
        held: &Held,
        debit: Credits,
        debits: &[Debit],
        next_binding: Option<[u8; 32]>,
        next_witness: Option<&[u8]>,
        guard: Option<&audit::Guard>,
        before_commit: impl FnOnce(),
    ) -> Result<Publication> {
        if self.reserving == 0 {
            return Err(Error::Invalid);
        }
        self.reservation_batch(scope, batch, &held.namespace)?;
        if held.boot != self.boot {
            return Err(Error::Denied);
        }
        if (debit.empty() && debits.is_empty() && next_binding.is_none())
            || next_binding == Some(held.binding)
            || (held.credits.empty() && audit::empty(&held.audits))
        {
            return Err(Error::Invalid);
        }
        let witness = witness::update(
            self.reserving,
            held.witness.as_ref(),
            held.binding,
            next_binding,
            next_witness,
        )?;
        let remaining = held.credits.subtract(debit)?;
        let audits = audit::spend(&held.audits, debits)?;
        let receipt = self.commit_storage_reserved(
            batch,
            Some(Change::Spend(
                held,
                debit,
                debits,
                next_binding,
                next_witness,
            )),
            guard,
            before_commit,
        )?;
        let held = (!remaining.empty() || !audit::empty(&audits)).then(|| Held {
            boot: self.boot,
            namespace: held.namespace.clone(),
            key: held.key.clone(),
            revision: held.revision + 1,
            binding: next_binding.unwrap_or(held.binding),
            credits: remaining,
            audits,
            witness,
            generation: held.generation.clone(),
        });
        Ok(Publication { receipt, held })
    }
}

#[cfg(test)]
#[path = "reservation_tests.rs"]
mod tests;
