//! Private pre-execution export obligations. Application policy supplies the
//! allowances; native code binds actual source, destination and held capacity.
//! This module alone does not implement export or authorize a successor.
use super::*;
use serde::{Deserialize, Serialize};
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use sigil_durable_store::store::reservation::{Credits, Generation, Held, Request};
use sigil_durable_store::store::{Access, Batch, Mutation};
use sigil_worker_bridge::publication::{FixedSink, FixedSource, SourceObservation};
use std::collections::BTreeMap;

const MAX_PAYLOAD: usize = 65_536;

pub(super) struct Source {
    pub intent: Check,
    pub snapshot: Record,
    pub claim_namespace: String,
    pub delivery_namespace: String,
    pub intent_binding: [u8; 32],
    pub execution_funding_namespace: String,
    pub execution_generation: Option<Generation>,
}

/// Explicit policy-selected amounts. Native checks independently cover bounded
/// preparation/receipt encoding plus both authenticated publications.
struct Budget {
    payload_bytes: usize,
    preparation: Credits,
    acknowledgement: Credits,
}

/// One fixed grantless SIGIL policy. Its identity is retained before execution
/// and must also match the future successor's projection policy.
pub struct Policy {
    pub(super) config: crate::WorkerConfig,
    pub(super) function: crate::Function,
}
impl Policy {
    pub fn new(config: crate::WorkerConfig) -> Result<Self> {
        if config.version != 1 {
            return Err("export_policy");
        }
        let function = crate::Function::cached(config.clone())?;
        Ok(Self { config, function })
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Guard {
    pub identity: String,
    pub payload_sha256: String,
    pub payload_bytes: usize,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct PolicyBounds {
    pub fuel: u64,
    pub timeout_ms: u64,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Admission {
    pub format: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reservation_generation: Option<Generation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub execution_generation: Option<Generation>,
    pub domain: String,
    pub epoch: String,
    pub intent_namespace: String,
    pub intent_key: String,
    pub intent_revision: u64,
    pub intent_sha256: String,
    pub claim_namespace: String,
    pub delivery_namespace: String,
    pub intent_binding: String,
    pub execution_funding_namespace: String,
    pub destination: String,
    pub policy_source: String,
    pub policy_runtime: String,
    pub payload_bytes: usize,
    pub preparation_records: u64,
    pub preparation_bytes: u64,
    pub acknowledgement_records: u64,
    pub acknowledgement_bytes: u64,
    pub audit_chain: String,
    pub audit_sequence: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source_guard: Option<Guard>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub policy_bounds: Option<PolicyBounds>,
}

/// Private native wrapper. Its RW reservation scope is never given to a guest;
/// writes remain fixed-prefix create-only records in the methods below.
pub struct Ledger {
    pub(super) namespace: String,
    pub(super) heads: String,
    pub(super) records: String,
    pub(super) chain: String,
    pub(super) scope: Scope,
    pub(super) log: AuthenticatedLog,
}

/// Not deserializable or cloneable. This is a live preclaim check, not a receipt
/// and not permission to publish bytes, recover work or spend execution credits.
pub struct Permit {
    admission: Admission,
    raw: String,
    namespace: String,
    held: Held,
    binding: [u8; 32],
}

fn digest(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    format!("{:x}", Sha256::digest(bytes))
}
fn hex(bytes: [u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

pub(super) fn source_frame(observed: &SourceObservation) -> Result<String> {
    let encoded: String = observed
        .bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect();
    frame(
        "SG1\n",
        &[observed.identity(), observed.payload_sha256(), &encoded],
    )
}

pub(super) fn checked_source(
    admission: &Admission,
    source: Option<&FixedSource>,
) -> Result<Option<String>> {
    match (&admission.source_guard, source) {
        (None, None) => Ok(None),
        (Some(expected), Some(source)) => {
            let observed = source.observe().map_err(|_| "export_external_source")?;
            if observed.identity() != expected.identity
                || observed.payload_sha256() != expected.payload_sha256
                || observed.bytes().len() != expected.payload_bytes
            {
                return Err("export_external_source");
            }
            source_frame(&observed).map(Some)
        }
        _ => Err("export_external_source"),
    }
}

impl Ledger {
    pub fn new(
        store: &Store,
        namespace: &str,
        heads: &str,
        records: &str,
        chain: &str,
        limits: ChainLimits,
        signing_key: &[u8],
    ) -> Result<Self> {
        store.execution_identity().map_err(|_| "execution_fence")?;
        crate::digest_bytes(chain)?;
        // Fixed native event envelopes have a bounded shape, including the
        // longer future preparation key. Admission must cover every stage.
        if limits.payload_bytes < 1024 {
            return Err("export_audit");
        }
        if namespace == heads || namespace == records || heads == records {
            return Err("export_namespace");
        }
        store
            .same_pool(&[namespace, heads, records])
            .map_err(|_| "export_pool")?;
        let scope = store
            .scope(
                [namespace, heads, records]
                    .into_iter()
                    .map(|n| (n.to_owned(), Access::ReadWrite))
                    .collect(),
            )
            .map_err(|_| "export_scope")?;
        let log = AuthenticatedLog::new(store, heads, records, limits, signing_key)
            .map_err(|_| "export_audit")?;
        Ok(Self {
            namespace: namespace.into(),
            heads: heads.into(),
            records: records.into(),
            chain: chain.into(),
            scope,
            log,
        })
    }

    /// Reserve independently of the already-held execution credit, while the
    /// actual source still has no claim or delivery. Refusal performs no sink
    /// publication or effect I/O.
    pub fn reserve(
        &self,
        store: &mut Store,
        caller: &Scope,
        completion: &CompletionCredit,
        sink: &FixedSink,
        policy: &mut Policy,
    ) -> Result<Permit> {
        self.reserve_inner(store, caller, completion, sink, policy, None)
    }

    pub fn reserve_guarded(
        &self,
        store: &mut Store,
        caller: &Scope,
        completion: &CompletionCredit,
        sink: &FixedSink,
        policy: &mut Policy,
        source: &FixedSource,
    ) -> Result<Permit> {
        self.reserve_inner(store, caller, completion, sink, policy, Some(source))
    }

    fn reserve_inner(
        &self,
        store: &mut Store,
        caller: &Scope,
        completion: &CompletionCredit,
        sink: &FixedSink,
        policy: &mut Policy,
        source_guard: Option<&FixedSource>,
    ) -> Result<Permit> {
        let source = completion.export_source(store)?;
        if store
            .get(caller, &source.intent.namespace, &source.intent.key)
            .map_err(|_| "export_source")?
            != source.snapshot
        {
            return Err("export_source");
        }
        for namespace in [&source.claim_namespace, &source.delivery_namespace] {
            let observed = store
                .get(caller, namespace, &source.intent.key)
                .map_err(|_| "export_source")?;
            if observed.revision != 0 || observed.value.is_some() {
                return Err("export_claimed");
            }
        }
        let native = frame(
            "EX1\n",
            &[
                &source.intent.namespace,
                &source.intent.key,
                &source.intent.revision.to_string(),
                source.snapshot.value.as_deref().ok_or("export_source")?,
                &hex(source.intent_binding),
                sink.identity(),
                &sink.payload_limit().to_string(),
                &self.log.encoded_entry_ceiling().to_string(),
            ],
        )?;
        let observed = source_guard
            .map(FixedSource::observe)
            .transpose()
            .map_err(|_| "export_external_source")?;
        let native = if let Some(observed) = &observed {
            frame("GX1\n", &[&native, &source_frame(observed)?])?
        } else {
            native
        };
        let input = frame("XP1\n", &["budget", &native])?;
        let output = policy
            .function
            .invoke(input, Instant::now() + Duration::from_secs(30))?;
        if output.len() > 512 {
            return Err("export_budget");
        }
        let values = fields(&output, "EB1\n", 5)?;
        let numbers = values
            .iter()
            .map(|value| {
                let n: u64 = value.parse().map_err(|_| "export_budget")?;
                if n.to_string() != *value {
                    return Err("export_budget");
                }
                Ok(n)
            })
            .collect::<Result<Vec<_>>>()?;
        let budget = Budget {
            payload_bytes: usize::try_from(numbers[0]).map_err(|_| "export_budget")?,
            preparation: Credits {
                records: numbers[1],
                live_bytes: numbers[2],
            },
            acknowledgement: Credits {
                records: numbers[3],
                live_bytes: numbers[4],
            },
        };
        if let (Some(source), Some(previous)) = (source_guard, &observed) {
            let current = source.observe().map_err(|_| "export_external_source")?;
            if current.identity() != previous.identity()
                || current.payload_sha256() != previous.payload_sha256()
                || current.bytes() != previous.bytes()
            {
                return Err("export_external_source");
            }
        }
        self.reserve_amounts_inner(
            store,
            caller,
            completion,
            sink,
            &policy.config,
            budget,
            observed.as_ref(),
        )
    }

    #[cfg(test)]
    fn reserve_amounts(
        &self,
        store: &mut Store,
        caller: &Scope,
        completion: &CompletionCredit,
        sink: &FixedSink,
        policy: &crate::WorkerConfig,
        budget: Budget,
    ) -> Result<Permit> {
        self.reserve_amounts_inner(store, caller, completion, sink, policy, budget, None)
    }

    #[allow(clippy::too_many_arguments)]
    fn reserve_amounts_inner(
        &self,
        store: &mut Store,
        caller: &Scope,
        completion: &CompletionCredit,
        sink: &FixedSink,
        policy: &crate::WorkerConfig,
        budget: Budget,
        source_observation: Option<&SourceObservation>,
    ) -> Result<Permit> {
        crate::Function::manifest(policy)?;
        if policy.version != 1
            || !(1..=MAX_PAYLOAD).contains(&budget.payload_bytes)
            || budget.payload_bytes > sink.payload_limit()
        {
            return Err("export_budget");
        }
        crate::digest_bytes(&policy.source_sha256)?;
        crate::digest_bytes(&policy.runtime_sha256)?;
        let _admitted_policy = crate::Function::cached(policy.clone())?;
        // Six is the worst JSON escape expansion. The prepared value uses a
        // bounded hex payload; this deliberately conservative bound covers it.
        let preparation_floor =
            6 * budget.payload_bytes as u64 + self.log.encoded_entry_ceiling() + 8192;
        let acknowledgement_floor = self.log.encoded_entry_ceiling() + 8192;
        self.check_future_limits(store, budget.payload_bytes)?;
        if budget.preparation.records < 3
            || budget.acknowledgement.records < 3
            || budget.preparation.live_bytes < preparation_floor
            || budget.acknowledgement.live_bytes < acknowledgement_floor
        {
            return Err("export_budget");
        }
        let source = completion.export_source(store)?;
        let sources = [
            &source.intent.namespace,
            &source.claim_namespace,
            &source.delivery_namespace,
            &source.execution_funding_namespace,
        ];
        if sources.iter().any(|n| {
            [
                self.namespace.as_str(),
                self.heads.as_str(),
                self.records.as_str(),
            ]
            .contains(&n.as_str())
        }) {
            return Err("export_namespace");
        }
        store
            .same_pool(&[
                &self.namespace,
                &self.heads,
                &self.records,
                &source.intent.namespace,
                &source.claim_namespace,
                &source.delivery_namespace,
                &source.execution_funding_namespace,
            ])
            .map_err(|_| "export_pool")?;
        if store
            .get(caller, &source.intent.namespace, &source.intent.key)
            .map_err(|_| "export_source")?
            != source.snapshot
        {
            return Err("export_source");
        }
        for namespace in [&source.claim_namespace, &source.delivery_namespace] {
            let record = store
                .get(caller, namespace, &source.intent.key)
                .map_err(|_| "export_source")?;
            if record.revision != 0 || record.value.is_some() {
                return Err("export_claimed");
            }
        }
        let (domain, epoch) = store.execution_identity().map_err(|_| "execution_fence")?;
        let head = store
            .get(&self.scope, &self.heads, &self.chain)
            .map_err(|_| "export_audit")?;
        let sequence = self
            .log
            .next_sequence(store, &self.scope, &self.chain, head.revision)
            .map_err(|_| "export_audit")?;
        if store.has_reservation_generations() != source.execution_generation.is_some() {
            return Err("export_generation");
        }
        let reservation_key = format!("funds:{}", hex(source.intent_binding));
        let generation = if store.has_reservation_generations() {
            Some(
                store
                    .next_reservation_generation(&self.scope, &self.namespace, &reservation_key)
                    .map_err(|_| "export_generation")?,
            )
        } else {
            None
        };
        let admission = Admission {
            format: admission_format(source_observation.is_some(), generation.is_some()).into(),
            reservation_generation: generation.clone(),
            execution_generation: source.execution_generation,
            domain: domain.into(),
            epoch: epoch.into(),
            intent_namespace: source.intent.namespace.clone(),
            intent_key: source.intent.key.clone(),
            intent_revision: source.intent.revision,
            intent_sha256: digest(
                source
                    .snapshot
                    .value
                    .as_deref()
                    .ok_or("export_source")?
                    .as_bytes(),
            ),
            claim_namespace: source.claim_namespace.clone(),
            delivery_namespace: source.delivery_namespace.clone(),
            intent_binding: hex(source.intent_binding),
            execution_funding_namespace: source.execution_funding_namespace,
            destination: sink.identity().into(),
            policy_source: policy.source_sha256.clone(),
            policy_runtime: policy.runtime_sha256.clone(),
            payload_bytes: budget.payload_bytes,
            preparation_records: budget.preparation.records,
            preparation_bytes: budget.preparation.live_bytes,
            acknowledgement_records: budget.acknowledgement.records,
            acknowledgement_bytes: budget.acknowledgement.live_bytes,
            audit_chain: self.chain.clone(),
            audit_sequence: sequence,
            source_guard: source_observation.map(|s| Guard {
                identity: s.identity().into(),
                payload_sha256: s.payload_sha256().into(),
                payload_bytes: s.bytes().len(),
            }),
            policy_bounds: source_observation.map(|_| PolicyBounds {
                fuel: policy.max_fuel,
                timeout_ms: policy.max_timeout_ms,
            }),
        };
        let raw = serde_json::to_string(&admission).map_err(|_| "export_admission")?;
        if raw.len() > 12_288 {
            return Err("export_admission");
        }
        let binding = super::completion::hash(&[b"sigil-export-reservation/v1", raw.as_bytes()]);
        let key = format!("admit:{}", admission.intent_binding);
        let related = Batch {
            checks: vec![
                source.intent,
                Check {
                    namespace: source.claim_namespace.clone(),
                    key: admission.intent_key.clone(),
                    revision: 0,
                },
                Check {
                    namespace: source.delivery_namespace.clone(),
                    key: admission.intent_key.clone(),
                    revision: 0,
                },
            ],
            writes: vec![Mutation {
                namespace: self.namespace.clone(),
                key: key.clone(),
                revision: 0,
                value: Some(raw.clone()),
            }],
        };
        let scope = store
            .scope(BTreeMap::from([
                (self.namespace.clone(), Access::ReadWrite),
                (self.heads.clone(), Access::ReadWrite),
                (self.records.clone(), Access::ReadWrite),
                (admission.intent_namespace.clone(), Access::Read),
                (admission.claim_namespace.clone(), Access::Read),
                (admission.delivery_namespace.clone(), Access::Read),
            ]))
            .map_err(|_| "export_scope")?;
        let allowance = self
            .log
            .prepare_allowance(
                store,
                &self.scope,
                &self.chain,
                head.revision,
                2,
                2 * self.log.encoded_entry_ceiling(),
            )
            .map_err(|_| "export_capacity")?;
        let envelope = serde_json::to_string(&serde_json::json!({
            "format":"sigil-native-export-admission-audit/v1", "namespace":self.namespace,
            "key":key, "sha256":digest(raw.as_bytes()),
            "batch_sha256":digest(&serde_json::to_vec(&related).map_err(|_| "export_admission")?),
        }))
        .map_err(|_| "export_admission")?;
        let request = Request {
            namespace: self.namespace.clone(),
            key: reservation_key,
            binding,
            credits: Credits {
                records: budget
                    .preparation
                    .records
                    .checked_add(budget.acknowledgement.records)
                    .ok_or("export_budget")?,
                live_bytes: budget
                    .preparation
                    .live_bytes
                    .checked_add(budget.acknowledgement.live_bytes)
                    .ok_or("export_budget")?,
            },
        };
        let reserved = if let Some(generation) = &generation {
            self.log.append_reserving_generation(
                store,
                &scope,
                &self.chain,
                head.revision,
                &envelope,
                &related,
                &request,
                &[allowance],
                generation,
            )
        } else {
            self.log.append_reserving(
                store,
                &scope,
                &self.chain,
                head.revision,
                &envelope,
                &related,
                &request,
                &[allowance],
            )
        }
        .map_err(|e| {
            if e == sigil_durable_store::store::Error::CommitUncertain {
                "commit_uncertain"
            } else {
                "export_capacity"
            }
        })?;
        Ok(Permit {
            admission,
            raw,
            namespace: self.namespace.clone(),
            held: reserved.held.ok_or("export_capacity")?,
            binding,
        })
    }

    pub(super) fn check_future_limits(&self, store: &Store, payload_bytes: usize) -> Result<()> {
        let limits = store.configured_limits().map_err(|_| "export_limits")?;
        let entry = self.log.encoded_entry_ceiling();
        // Preparation has six checks and three writes; acknowledgment has
        // seven checks and three writes. These are actual combined audit/data
        // batch shapes, independent of held record credits. Values include
        // bounded hex payload plus fixed canonical metadata; 8192 also covers
        // the authenticated head and remaining fixed encoding overhead.
        if !(1..=MAX_PAYLOAD).contains(&payload_bytes)
            || limits.batch_items < 10
            || (limits.value_bytes as u64) < (2 * payload_bytes as u64 + 8192).max(entry)
            || (limits.batch_bytes as u64) < 6 * payload_bytes as u64 + entry + 8192
        {
            return Err("export_limits");
        }
        Ok(())
    }
}

pub(super) fn admission_format(guarded: bool, generational: bool) -> &'static str {
    match (guarded, generational) {
        (false, false) => "sigil-native-export-admission/v1",
        (true, false) => "sigil-native-export-admission/v2",
        (false, true) => "sigil-native-export-admission/v3",
        (true, true) => "sigil-native-export-admission/v4",
    }
}

impl Permit {
    pub fn intent_binding(&self) -> &str {
        &self.admission.intent_binding
    }

    /// The dedicated export path must call this before claim. The ordinary
    /// non-export APIs retain their existing contracts; possessing this permit
    /// never widens them or turns the caller into an export successor.
    pub fn run_recorded(
        &self,
        attempt: &mut Attempt<'_>,
        recorder: &mut Recorder,
        cancel: &AtomicBool,
    ) -> Result<Recorded> {
        self.run_recorded_inner(attempt, recorder, cancel, None)
    }

    pub fn run_recorded_guarded(
        &self,
        attempt: &mut Attempt<'_>,
        recorder: &mut Recorder,
        cancel: &AtomicBool,
        source: &FixedSource,
    ) -> Result<Recorded> {
        self.run_recorded_inner(attempt, recorder, cancel, Some(source))
    }

    fn run_recorded_inner(
        &self,
        attempt: &mut Attempt<'_>,
        recorder: &mut Recorder,
        cancel: &AtomicBool,
        source_guard: Option<&FixedSource>,
    ) -> Result<Recorded> {
        if !recorder.has_dispatch_journal() {
            return Err("export_journal");
        }
        let source = attempt
            .funding
            .as_ref()
            .ok_or("funding")?
            .export_source(attempt.store)?;
        let (domain, epoch) = attempt
            .store
            .execution_identity()
            .map_err(|_| "execution_fence")?;
        if domain != self.admission.domain
            || epoch != self.admission.epoch
            || hex(source.intent_binding) != self.admission.intent_binding
            || source.intent != attempt.intent
            || source.snapshot != attempt.snapshot
            || source.claim_namespace != self.admission.claim_namespace
            || source.delivery_namespace != self.admission.delivery_namespace
            || source.execution_funding_namespace != self.admission.execution_funding_namespace
        {
            return Err("export_source");
        }
        attempt
            .store
            .check_reservation_binding(&self.held, self.binding)
            .map_err(|_| "export_capacity")?;
        let reads = attempt
            .store
            .scope(BTreeMap::from([(self.namespace.clone(), Access::Read)]))
            .map_err(|_| "export_scope")?;
        let retained = attempt
            .store
            .get(
                &reads,
                &self.namespace,
                &format!("admit:{}", self.admission.intent_binding),
            )
            .map_err(|_| "export_admission")?;
        if retained.revision != 1 || retained.value.as_deref() != Some(&self.raw) {
            return Err("export_admission");
        }
        checked_source(&self.admission, source_guard)?;
        let ticket = attempt.prepared.ticket.clone();
        attempt.run_recorded(&ticket, recorder, cancel)
    }
}

#[cfg(test)]
#[path = "export_capacity_tests.rs"]
mod tests;
