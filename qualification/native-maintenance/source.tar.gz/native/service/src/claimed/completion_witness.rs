//! Canonical, bounded facts from an actual native preparation. This does not
//! serialize a Held grant, establish worker cleanup, or authorize recovery.
use super::*;
use serde::{Deserialize, Serialize};

const FORMAT: &str = "sigil-completion-assignment/v1";
const FENCED_FORMAT: &str = "sigil-completion-assignment/v2";
const RETIREMENT_FORMAT: &str = "sigil-completion-assignment/v3";
const PARENT_FORMAT: &str = "sigil-completion-assignment/v4";
const SLOT_FORMAT: &str = "sigil-completion-assignment/v5";
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct RetirementAllowance {
    records: u64,
    live_bytes: u64,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ExecutionIdentity {
    domain: String,
    epoch: String,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Witness {
    format: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    reservation_generation: Option<sigil_durable_store::store::reservation::Generation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    intent_binding: Option<String>,
    intent_namespace: String,
    key: String,
    intent_revision: u64,
    intent_sha256: String,
    claim_namespace: String,
    delivery_namespace: String,
    reservation_namespace: String,
    reservation_key: String,
    generation: String,
    ticket: String,
    input_sha256: String,
    source_sha256: String,
    runtime_sha256: String,
    prepared_audit_sha256: String,
    result_records: u64,
    result_live_bytes: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    execution: Option<ExecutionIdentity>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    retirement: Option<RetirementAllowance>,
}

pub(in crate::claimed) struct Assignment {
    pub(in crate::claimed) binding: [u8; 32],
    pub(in crate::claimed) witness: Option<Vec<u8>>,
    pub(in crate::claimed) dispatch: Option<super::super::dispatch_journal::Prepared>,
}

fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn assigned(origin: [u8; 32], bytes: &[u8]) -> [u8; 32] {
    hash(&[b"sigil-completion-attempt/v2", &origin, bytes])
}
impl Assignment {
    pub(super) fn observe(funding: &CompletionCredit, attempt: &Attempt<'_>) -> Result<Self> {
        funding.check_attempt(attempt)?;
        let facts = attempt.worker.facts().map_err(|_| "worker")?;
        let (namespace, key) = funding.held.as_ref().ok_or("funding")?.coordinate();
        let execution = if attempt.store.has_execution_fence() {
            let (domain, epoch) = attempt
                .store
                .execution_identity()
                .map_err(|_| "execution_fence")?;
            if attempt
                .worker
                .execution_domain()
                .map_err(|_| "execution_fence")?
                != Some(domain)
                || attempt
                    .worker
                    .execution_epoch()
                    .map_err(|_| "execution_fence")?
                    != Some(epoch)
            {
                return Err("execution_fence");
            }
            Some(ExecutionIdentity {
                domain: domain.into(),
                epoch: epoch.into(),
            })
        } else {
            None
        };
        let reservation_generation = funding
            .held
            .as_ref()
            .ok_or("funding")?
            .generation()
            .cloned();
        if reservation_generation.is_some()
            && (funding.intent_binding.is_none() || funding.retirement.is_none())
        {
            return Err("funding_profile");
        }
        let witness = Witness {
            format: if reservation_generation.is_some() {
                SLOT_FORMAT
            } else if funding.intent_binding.is_some() {
                PARENT_FORMAT
            } else if funding.retirement.is_some() {
                RETIREMENT_FORMAT
            } else if execution.is_some() {
                FENCED_FORMAT
            } else {
                FORMAT
            }
            .into(),
            reservation_generation,
            intent_binding: funding
                .intent_binding
                .map(|b| b.iter().map(|v| format!("{v:02x}")).collect::<String>()),
            intent_namespace: attempt.intent.namespace.clone(),
            key: attempt.intent.key.clone(),
            intent_revision: attempt.intent.revision,
            intent_sha256: digest(
                attempt
                    .snapshot
                    .value
                    .as_deref()
                    .ok_or("intent")?
                    .as_bytes(),
            ),
            claim_namespace: attempt.claim_namespace.clone(),
            delivery_namespace: funding.identity.delivery_namespace.clone(),
            reservation_namespace: namespace.into(),
            reservation_key: key.into(),
            generation: attempt.prepared.generation.clone(),
            ticket: attempt.prepared.ticket.clone(),
            input_sha256: attempt.prepared.input_sha256.clone(),
            source_sha256: facts.source_sha256.into(),
            runtime_sha256: facts.runtime_sha256.into(),
            prepared_audit_sha256: digest(attempt.prepared_audit.as_bytes()),
            result_records: funding.budget.result.records,
            result_live_bytes: funding.budget.result.live_bytes,
            execution,
            retirement: funding.retirement.map(|credit| RetirementAllowance {
                records: credit.records,
                live_bytes: credit.live_bytes,
            }),
        };
        let bytes = serde_json::to_vec(&witness).map_err(|_| "funding_witness")?;
        if bytes.len() > sigil_durable_store::store::reservation::witness::BYTES {
            return Err("funding_witness");
        }
        Ok(Self {
            binding: assigned(funding.identity.binding, &bytes),
            witness: Some(bytes),
            dispatch: None,
        })
    }
}

/// Validated retained assignment, deliberately not an execution or spending
/// capability. Its private fields can later support a separately fenced recovery
/// path. No constructor accepts a caller's claimed cleanup observation.
pub struct AssignedCompletion {
    witness: Witness,
    snapshot: sigil_durable_store::store::reservation::witness::Snapshot,
    terminal: bool,
}
pub(in crate::claimed) struct PendingRecovery {
    pub(in crate::claimed) funding: CompletionCredit,
    pub(in crate::claimed) exclusion: String,
    pub(in crate::claimed) intent: Check,
    pub(in crate::claimed) snapshot: Record,
    pub(in crate::claimed) claim_namespace: String,
    pub(in crate::claimed) claim_generation: String,
}

impl AssignedCompletion {
    /// Read within the caller's existing scope and verify the actual intent and
    /// still-pending claim. A later transition must recheck these same revisions;
    /// this snapshot alone never authorizes dispatch, retirement or credit reuse.
    pub fn observe(store: &Store, scope: &Scope, namespace: &str, key: &str) -> Result<Self> {
        Self::observe_state(store, scope, namespace, key, false)
    }
    pub(in crate::claimed) fn observe_terminal(
        store: &Store,
        scope: &Scope,
        namespace: &str,
        key: &str,
    ) -> Result<Self> {
        Self::observe_state(store, scope, namespace, key, true)
    }
    fn observe_state(
        store: &Store,
        scope: &Scope,
        namespace: &str,
        key: &str,
        terminal: bool,
    ) -> Result<Self> {
        let snapshot = store
            .reservation_snapshot(scope, namespace, key)
            .map_err(|_| "funding_witness")?;
        let witness: Witness =
            serde_json::from_slice(&snapshot.assignment).map_err(|_| "funding_witness")?;
        if store.has_execution_fence() {
            let (domain, _) = store.execution_identity().map_err(|_| "execution_fence")?;
            let execution = witness.execution.as_ref().ok_or("execution_fence")?;
            if (witness.format != FENCED_FORMAT
                && witness.format != RETIREMENT_FORMAT
                && witness.format != PARENT_FORMAT
                && witness.format != SLOT_FORMAT)
                || execution.domain != domain
                || execution.epoch.len() != 64
                || !execution
                    .epoch
                    .bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
            {
                return Err("execution_fence");
            }
        } else if witness.format != FORMAT || witness.execution.is_some() {
            return Err("funding_witness");
        }
        if (witness.format == SLOT_FORMAT) != snapshot.generation.is_some()
            || witness.reservation_generation != snapshot.generation
            || matches!(
                witness.format.as_str(),
                RETIREMENT_FORMAT | PARENT_FORMAT | SLOT_FORMAT
            ) != witness.retirement.is_some()
            || matches!(witness.format.as_str(), PARENT_FORMAT | SLOT_FORMAT)
                != witness.intent_binding.is_some()
            || (terminal && witness.retirement.is_none())
            || witness
                .retirement
                .as_ref()
                .is_some_and(|r| r.records == 0 || r.live_bytes == 0)
        {
            return Err("funding_witness");
        }
        let remaining = if terminal {
            let r = witness.retirement.as_ref().ok_or("funding_witness")?;
            Credits {
                records: r.records,
                live_bytes: r.live_bytes,
            }
        } else {
            Credits {
                records: witness
                    .result_records
                    .checked_add(witness.retirement.as_ref().map_or(0, |r| r.records))
                    .ok_or("funding_witness")?,
                live_bytes: witness
                    .result_live_bytes
                    .checked_add(witness.retirement.as_ref().map_or(0, |r| r.live_bytes))
                    .ok_or("funding_witness")?,
            }
        };
        if witness.reservation_namespace != namespace
            || witness.reservation_key != key
            || witness.result_records == 0
            || witness.result_live_bytes == 0
            || remaining.records > snapshot.credits.records
            || remaining.live_bytes > snapshot.credits.live_bytes
            || serde_json::to_vec(&witness).map_err(|_| "funding_witness")? != snapshot.assignment
            || assigned(snapshot.origin, &snapshot.assignment) != snapshot.binding
        {
            return Err("funding_witness");
        }
        let intent = store
            .get(scope, &witness.intent_namespace, &witness.key)
            .map_err(|_| "storage")?;
        let value = intent.value.as_deref().ok_or("intent")?;
        let revision = intent.revision.to_be_bytes();
        if intent.revision != witness.intent_revision
            || digest(value.as_bytes()) != witness.intent_sha256
            || hash(&[
                b"sigil-completion-intent/v1",
                witness.intent_namespace.as_bytes(),
                witness.key.as_bytes(),
                &revision,
                value.as_bytes(),
                witness.claim_namespace.as_bytes(),
                witness.delivery_namespace.as_bytes(),
            ]) != match &witness.intent_binding {
                Some(binding) => crate::digest_bytes(binding).map_err(|_| "funding_identity")?,
                None => snapshot.origin,
            }
        {
            return Err("funding_identity");
        }
        let claim = store
            .get(scope, &witness.claim_namespace, &witness.key)
            .map_err(|_| "storage")?;
        if claim.revision != if terminal { 2 } else { 1 } {
            return Err("claim");
        }
        let sd = fields(claim.value.as_deref().ok_or("claim")?, "SD1\n", 5)?;
        if sd
            != [
                witness.intent_namespace.as_str(),
                witness.key.as_str(),
                &witness.intent_revision.to_string(),
                witness.generation.as_str(),
                if terminal { "4" } else { "1" },
            ]
        {
            return Err("claim");
        }
        if terminal {
            let delivery = store
                .get(scope, &witness.delivery_namespace, &witness.key)
                .map_err(|_| "storage")?;
            if delivery.revision != 1 {
                return Err("delivery");
            }
            let dr = fields(delivery.value.as_deref().ok_or("delivery")?, "DR1\n", 7)?;
            if dr[..5] != sd || !dr[5].is_empty() || !dr[6].is_empty() {
                return Err("delivery");
            }
        }
        Ok(Self {
            witness,
            snapshot,
            terminal,
        })
    }
    /// Revalidate the retained assignment against the actual exclusively held
    /// store domain. Current-epoch work cannot be treated as abandoned. This
    /// check creates no grant and performs no publication or credit return.
    pub fn check_prior_owner(&self, store: &Store, scope: &Scope) -> Result<()> {
        let (domain, epoch) = store.execution_identity().map_err(|_| "execution_fence")?;
        let execution = self.witness.execution.as_ref().ok_or("execution_fence")?;
        if execution.domain != domain || execution.epoch == epoch {
            return Err("execution_fence");
        }
        let current = Self::observe_state(
            store,
            scope,
            &self.witness.reservation_namespace,
            &self.witness.reservation_key,
            self.terminal,
        )?;
        if current.snapshot.revision != self.snapshot.revision
            || current.snapshot.binding != self.snapshot.binding
            || current.snapshot.assignment != self.snapshot.assignment
            || current.snapshot.generation != self.snapshot.generation
        {
            return Err("funding_witness");
        }
        Ok(())
    }
    fn resume(&self, store: &Store, scope: &Scope) -> Result<Held> {
        let w = &self.witness;
        match &w.reservation_generation {
            Some(g) => store.resume_reservation_generation(
                scope,
                &w.reservation_namespace,
                &w.reservation_key,
                self.snapshot.revision,
                self.snapshot.binding,
                g,
            ),
            None => store.resume_reservation(
                scope,
                &w.reservation_namespace,
                &w.reservation_key,
                self.snapshot.revision,
                self.snapshot.binding,
            ),
        }
        .map_err(|_| "funding")
    }

    /// Internal recovery handoff: retained facts alone never mint this credit.
    /// The real admitted store must exclude every prior execution holder first.
    pub(in crate::claimed) fn pending_recovery(
        &self,
        store: &Store,
        scope: &Scope,
    ) -> Result<PendingRecovery> {
        if self.terminal {
            return Err("claim");
        }
        self.check_prior_owner(store, scope)?;
        let witness = &self.witness;
        let exclusion = self.exclusion(store)?;
        let held = self.resume(store, scope)?;
        let snapshot = store
            .get(scope, &witness.intent_namespace, &witness.key)
            .map_err(|_| "storage")?;
        let intent = Check {
            namespace: witness.intent_namespace.clone(),
            key: witness.key.clone(),
            revision: witness.intent_revision,
        };
        let funding = CompletionCredit {
            intent_binding: witness
                .intent_binding
                .as_ref()
                .map(|s| crate::digest_bytes(s))
                .transpose()?,
            identity: CompletionIdentity {
                intent: intent.clone(),
                snapshot: snapshot.clone(),
                claim_namespace: witness.claim_namespace.clone(),
                delivery_namespace: witness.delivery_namespace.clone(),
                binding: self.snapshot.origin,
            },
            held: Some(held),
            budget: CompletionBudget {
                claim: Credits {
                    records: 0,
                    live_bytes: 0,
                },
                result: self.result_budget(),
            },
            retirement: self.witness.retirement.as_ref().map(|r| Credits {
                records: r.records,
                live_bytes: r.live_bytes,
            }),
            assigned: Some(self.snapshot.binding),
            returned: false,
            result_limit: None,
        };
        Ok(PendingRecovery {
            funding,
            exclusion,
            intent,
            snapshot,
            claim_namespace: witness.claim_namespace.clone(),
            claim_generation: witness.generation.clone(),
        })
    }
    fn exclusion(&self, store: &Store) -> Result<String> {
        let witness = &self.witness;
        let (domain, epoch) = store.execution_identity().map_err(|_| "execution_fence")?;
        let previous = witness.execution.as_ref().ok_or("execution_fence")?;
        let hex = |bytes: [u8; 32]| bytes.iter().map(|b| format!("{b:02x}")).collect::<String>();
        frame(
            "XF1\n",
            &[
                domain,
                &previous.epoch,
                epoch,
                &witness.reservation_namespace,
                &witness.reservation_key,
                &self.snapshot.revision.to_string(),
                &hex(self.snapshot.binding),
                &hex(self.snapshot.origin),
                &witness.result_records.to_string(),
                &witness.result_live_bytes.to_string(),
            ],
        )
    }
    pub(in crate::claimed) fn terminal_retirement(
        &self,
        store: &Store,
        scope: &Scope,
        generation: &str,
    ) -> Result<TerminalRetirement> {
        if !self.terminal {
            return Err("claim");
        }
        self.check_prior_owner(store, scope)?;
        let w = &self.witness;
        let intent = store
            .get(scope, &w.intent_namespace, &w.key)
            .map_err(|_| "storage")?;
        let claim = store
            .get(scope, &w.claim_namespace, &w.key)
            .map_err(|_| "storage")?;
        let delivery = store
            .get(scope, &w.delivery_namespace, &w.key)
            .map_err(|_| "storage")?;
        let credit = w.retirement.as_ref().ok_or("funding_witness")?;
        let exclusion = self.exclusion(store)?;
        let claim_value = claim.value.as_deref().ok_or("claim")?;
        let delivery_value = delivery.value.as_deref().ok_or("delivery")?;
        let input = frame(
            "TR1\n",
            &[
                &w.intent_namespace,
                &w.claim_namespace,
                &w.delivery_namespace,
                &w.key,
                &intent.revision.to_string(),
                intent.value.as_deref().ok_or("intent")?,
                &claim.revision.to_string(),
                claim_value,
                &delivery.revision.to_string(),
                delivery_value,
                generation,
                &exclusion,
                &credit.records.to_string(),
                &credit.live_bytes.to_string(),
            ],
        )?;
        let evidence = frame(
            "TF1\n",
            &[
                &exclusion,
                &credit.records.to_string(),
                &credit.live_bytes.to_string(),
                &digest(claim_value.as_bytes()),
                &digest(delivery_value.as_bytes()),
            ],
        )?;
        let facts = frame(
            "WF3\n",
            &[
                "retired",
                generation,
                "1",
                "0",
                "owner_excluded",
                "",
                "missing",
                "0",
                "",
                &evidence,
            ],
        )?;
        let held = self.resume(store, scope)?;
        Ok(TerminalRetirement {
            held,
            debit: Credits {
                records: credit.records,
                live_bytes: credit.live_bytes,
            },
            input,
            facts,
            intent: Check {
                namespace: w.intent_namespace.clone(),
                key: w.key.clone(),
                revision: intent.revision,
            },
            claim_namespace: w.claim_namespace.clone(),
            delivery_namespace: w.delivery_namespace.clone(),
            claim_generation: w.generation.clone(),
            checks: vec![
                Check {
                    namespace: w.intent_namespace.clone(),
                    key: w.key.clone(),
                    revision: intent.revision,
                },
                Check {
                    namespace: w.claim_namespace.clone(),
                    key: w.key.clone(),
                    revision: claim.revision,
                },
                Check {
                    namespace: w.delivery_namespace.clone(),
                    key: w.key.clone(),
                    revision: delivery.revision,
                },
            ],
        })
    }
    pub fn generation(&self) -> &str {
        &self.witness.generation
    }
    pub fn reservation_revision(&self) -> u64 {
        self.snapshot.revision
    }
    pub fn origin(&self) -> [u8; 32] {
        self.snapshot.origin
    }
    pub fn binding(&self) -> [u8; 32] {
        self.snapshot.binding
    }
    pub fn result_budget(&self) -> Credits {
        Credits {
            records: self.witness.result_records,
            live_bytes: self.witness.result_live_bytes,
        }
    }
}

#[cfg(test)]
#[path = "completion_witness_tests.rs"]
mod tests;

// Constructed only from current scope reads and a validated prior-owner assignment.
pub(in crate::claimed) struct TerminalRetirement {
    pub(in crate::claimed) held: Held,
    pub(in crate::claimed) debit: Credits,
    pub(in crate::claimed) input: String,
    pub(in crate::claimed) facts: String,
    pub(in crate::claimed) intent: Check,
    pub(in crate::claimed) claim_namespace: String,
    pub(in crate::claimed) delivery_namespace: String,
    pub(in crate::claimed) claim_generation: String,
    pub(in crate::claimed) checks: Vec<Check>,
}

#[path = "terminal_observer.rs"]
mod terminal_observer;
pub use terminal_observer::TerminalCompletion;
