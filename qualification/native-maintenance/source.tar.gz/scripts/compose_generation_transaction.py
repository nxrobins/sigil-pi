"""Generation-bound versions of the three funded SIGIL transaction producers."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_capacity import compose_capacity
from scripts.compose_context_window import compose_context_window

ROOT=Path(__file__).resolve().parent.parent
SHAPES={"turn_completion":("TF2",13,"GT3"),"settlement":("SF1",9,"GS1"),"preclaim_cancellable":("UF2",17,"GU3")}


def compose_generation_transaction(name, stdlib):
    if name not in SHAPES:
        raise ValueError("unsupported generation transaction")
    base=compose_capacity(name,stdlib) if name=="settlement" else compose_context_window(name,stdlib)
    marker="pub fn tool_main(input_ptr: i64,input_len: i64)"
    if base.text.count(marker)!=1:
        raise ValueError("generation transaction requires exactly one original entry")
    body=base.text.replace(marker,"fn generation_base(input_ptr: i64 @Internal,input_len: i64 @Internal)")
    inputs=dict(base.input_hashes)
    for relative in ["app/pi/reservation_identity.sigil","app/pi/generation_transaction.sigil"]:
        raw=(ROOT/relative).read_bytes();inputs[relative]=hashlib.sha256(raw).hexdigest()
        fragment=raw.decode()
        if relative.endswith("reservation_identity.sigil"):
            fragment=fragment.split("pub fn tool_main(")[0]
        body += "\n"+fragment
    old,count,new=SHAPES[name]
    body+=f'''
pub fn tool_main(input_ptr: i64, input_len: i64) -> i64 @Internal ! {{ Alloc }} {{
    let x: i64 @Internal = read_record(slice(input_ptr, input_len), "{new}\\n", {count+2});
    if x < 0 {{ return x; }}
    let old: i64 @Internal = write_record(x, "{old}\\n", {count});
    let proposed: i64 @Internal = generation_base(ptr(old), size(old));
    if proposed < 0 {{ return proposed; }}
    return bind_generation_transaction(proposed, get(x, {count}), get(x, {count+1}));
}}
'''
    body=compact(body)
    if len(body.encode())>65536 or body.count("pub fn tool_main(")!=1:
        raise ValueError(f"generation transaction exceeds source/entry contract: {len(body.encode())}")
    inputs["scripts/compose_generation_transaction.py"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body,inputs,base.stdlib_hash)
