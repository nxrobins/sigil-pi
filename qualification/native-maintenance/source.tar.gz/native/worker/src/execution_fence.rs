//! Local execution lifetime exclusion. An exclusive lock stays open in the
//! parent and every explicitly leased effect process. Drop NEVER unlocks it:
//! only closing all inherited descriptors releases this open-file-description
//! lock. This is separate from storage ownership, retry policy and remote effects.
//!
//! The admitted native runtime must retain the inherited descriptor until exit.
//! This is a trusted runtime/OS contract, not protection against arbitrary native
//! code closing descriptors. The embedding profile must bind this exact local
//! domain and acquisition epoch to storage and durable assignments. Identity
//! includes the original file and directory inode; copied/restored bytes do not
//! prove exclusion of processes that still hold the original inode.
use crate::Fault;
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::{AsRawFd, FromRawFd, RawFd};
use std::os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::sync::Arc;

const HEADER: &[u8] = b"SIGIL_EXECUTION_FENCE_V2\n";
const NAME: &str = "execution.lock";

#[derive(Clone, Copy)]
pub enum OpenMode {
    CreateNew,
    Existing,
}

struct Inner {
    file: File,
    directory: File,
    root: PathBuf,
    process: u32,
    identity: String,
    epoch: String,
    content: Vec<u8>,
}
/// Trusted bootstrap-owned exclusion domain; never deserializable or a public
/// request credential. Opening an existing domain fails while any holder lives.
pub struct ExecutionFence {
    inner: Arc<Inner>,
}
/// Only a real held fence creates a lease. No caller-supplied descriptor, PID or
/// boolean cleanup assertion is accepted by the effect-worker integration.
pub struct ExecutionLease {
    inner: Arc<Inner>,
}

fn metadata(path: &Path, directory: bool) -> Result<fs::Metadata, Fault> {
    let meta = fs::symlink_metadata(path).map_err(|_| Fault::Invalid)?;
    // SAFETY: no arguments or caller memory.
    if meta.uid() != unsafe { libc::geteuid() }
        || meta.mode() & 0o077 != 0
        || (directory && !meta.is_dir())
        || (!directory && (!meta.is_file() || meta.nlink() != 1))
    {
        return Err(Fault::Invalid);
    }
    Ok(meta)
}
fn same(a: &fs::Metadata, b: &fs::Metadata) -> bool {
    a.dev() == b.dev() && a.ino() == b.ino()
}
impl ExecutionFence {
    pub fn open(root: &Path, mode: OpenMode) -> Result<Self, Fault> {
        if !root.is_absolute() {
            return Err(Fault::Invalid);
        }
        let before = metadata(root, true)?;
        let root = root.canonicalize().map_err(|_| Fault::Invalid)?;
        let directory = File::open(&root).map_err(|_| Fault::Invalid)?;
        if !same(&before, &directory.metadata().map_err(|_| Fault::Invalid)?) {
            return Err(Fault::Invalid);
        }
        let path = root.join(NAME);
        let mut options = OpenOptions::new();
        options
            .read(true)
            .write(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK)
            .mode(0o600);
        if matches!(mode, OpenMode::CreateNew) {
            options.create_new(true);
        }
        let file = options.open(&path).map_err(|_| Fault::Invalid)?;
        // Even when the embedding starts with closed standard descriptors,
        // child's piped stdin/out/err setup must not replace the lease fd.
        // SAFETY: duplicate a live descriptor into a fresh owned descriptor.
        let fd = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_DUPFD_CLOEXEC, 3) };
        if fd < 0 {
            return Err(Fault::Invalid);
        }
        let mut file = unsafe { File::from_raw_fd(fd) };
        if !same(
            &metadata(&path, false)?,
            &file.metadata().map_err(|_| Fault::Invalid)?,
        ) {
            return Err(Fault::Invalid);
        }
        file.try_lock().map_err(|_| Fault::Busy)?;
        if matches!(mode, OpenMode::CreateNew) {
            let mut id = [0; 32];
            File::open("/dev/urandom")
                .and_then(|mut f| f.read_exact(&mut id))
                .map_err(|_| Fault::Invalid)?;
            file.write_all(HEADER)
                .and_then(|_| file.write_all(&id))
                .and_then(|_| file.sync_all())
                .map_err(|_| Fault::Invalid)?;
            directory.sync_all().map_err(|_| Fault::Invalid)?;
        }
        let mut content = vec![0; HEADER.len() + 32];
        if file.metadata().map_err(|_| Fault::Invalid)?.len() != content.len() as u64 {
            return Err(Fault::Invalid);
        }
        file.read_exact_at(&mut content, 0)
            .map_err(|_| Fault::Invalid)?;
        if &content[..HEADER.len()] != HEADER {
            return Err(Fault::Invalid);
        }
        // Bind the actual local inode and directory, not merely copyable file
        // bytes. Restoring into another domain requires explicit admission.
        let file_meta = file.metadata().map_err(|_| Fault::Invalid)?;
        let dir_meta = directory.metadata().map_err(|_| Fault::Invalid)?;
        let mut identity_bytes = content.clone();
        for value in [
            dir_meta.dev(),
            dir_meta.ino(),
            file_meta.dev(),
            file_meta.ino(),
        ] {
            identity_bytes.extend_from_slice(&value.to_be_bytes());
        }
        let identity = crate::digest(&identity_bytes);
        let mut epoch_bytes = [0u8; 32];
        File::open("/dev/urandom")
            .and_then(|mut f| f.read_exact(&mut epoch_bytes))
            .map_err(|_| Fault::Invalid)?;
        let epoch = crate::digest(&epoch_bytes);
        let fence = Self {
            inner: Arc::new(Inner {
                file,
                directory,
                root,
                process: std::process::id(),
                identity,
                epoch,
                content,
            }),
        };
        fence.inner.check()?;
        Ok(fence)
    }
    pub fn identity(&self) -> Result<&str, Fault> {
        self.inner.check()?;
        Ok(&self.inner.identity)
    }
    /// Fresh acquisition identity, not a caller credential or cleanup claim.
    pub fn epoch(&self) -> Result<&str, Fault> {
        self.inner.check()?;
        Ok(&self.inner.epoch)
    }
    pub fn lease(&self) -> Result<ExecutionLease, Fault> {
        self.inner.check()?;
        Ok(ExecutionLease {
            inner: Arc::clone(&self.inner),
        })
    }
}
impl Inner {
    fn check(&self) -> Result<(), Fault> {
        if self.process != std::process::id() {
            return Err(Fault::WrongProcess);
        }
        let file = self.file.metadata().map_err(|_| Fault::Invalid)?;
        if !same(
            &metadata(&self.root, true)?,
            &self.directory.metadata().map_err(|_| Fault::Invalid)?,
        ) || !same(&metadata(&self.root.join(NAME), false)?, &file)
            || file.len() != self.content.len() as u64
        {
            return Err(Fault::Invalid);
        }
        let mut observed = vec![0; self.content.len()];
        self.file
            .read_exact_at(&mut observed, 0)
            .map_err(|_| Fault::Invalid)?;
        if observed != self.content {
            return Err(Fault::Invalid);
        }
        Ok(())
    }
}
impl ExecutionLease {
    pub(crate) fn check(&self) -> Result<(), Fault> {
        self.inner.check()
    }
    pub(crate) fn descriptor(&self) -> Result<RawFd, Fault> {
        self.check()?;
        Ok(self.inner.file.as_raw_fd())
    }
    pub(crate) fn identity(&self) -> &str {
        &self.inner.identity
    }
    pub(crate) fn epoch(&self) -> &str {
        &self.inner.epoch
    }
}

#[cfg(test)]
#[path = "execution_fence_tests.rs"]
mod tests;
