"""Capture a real local-model repository work cycle; not pilot qualification."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tests"), str(ROOT)]
from api_support import TOKEN_A
from test_workspace_agent import WorkspaceApi
from acceptance.run_local import local_get
from acceptance.repository_assertions import check_task, files


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def wait(api, operation):
    until = time.monotonic() + 330
    while time.monotonic() < until:
        code, body = api.request("GET", "/v1/operations/" + operation)
        if code != 200:
            raise RuntimeError((code, body))
        if body["status"] != "accepted":
            return body
        time.sleep(0.5)
    raise TimeoutError("operation did not settle within its declared deadline")


def capture(root, api, report):
    db = sqlite3.connect(
        f"file:{api.root / 'records/records.sqlite'}?mode=ro", uri=True
    )
    try:
        save(
            root / "records.json",
            [
                {
                    "namespace": ns,
                    "key": key,
                    "revision": rev,
                    "value": bytes(v).decode(),
                }
                for ns, key, rev, v in db.execute(
                    "select namespace,key,revision,value from records order by namespace,key"
                )
            ],
        )
    finally:
        db.close()
    report["source_hashes"] = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [
            *ROOT.glob("app/pi/workspace_*.sigil"),
            ROOT / "scripts/compose_workspace.py",
            ROOT / "scripts/workspace_deployment.py",
            ROOT / "scripts/build_workspace_deployment.py",
            ROOT / "acceptance/run_repository_agent.py",
            ROOT / "native/service/target/release/sigil-application-host",
        ]
    }
    save(root / "report.json", report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--interface", choices=["api", "browser"], default="api")
    parser.add_argument("--cases", type=int, default=2)
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    workspace = root / "workspace"
    workspace.mkdir()
    (workspace / "README.md").write_text(
        "Release configuration: config/release.json. Deployment configuration: config/deploy.json. Use the approved JSON syntax check.\n"
    )
    (workspace / "config").mkdir()
    (workspace / "config/release.json").write_text(
        '{\n  "service": "atlas",\n  "port": 8080,\n  "note": "preserve this",\n}\n'
    )
    (workspace / "config/deploy.json").write_text(
        '{"environment":"staging","replicas":2,"note":"Keep café | unchanged"}\n'
    )
    before = {
        str(p.relative_to(workspace)): p.read_text()
        for p in workspace.rglob("*")
        if p.is_file()
    }
    save(root / "before.json", before)
    profile = json.loads((ROOT / "config/workspace-agent-development.json").read_text())
    installed = next(
        m for m in local_get("/api/tags")["models"] if m["name"] == profile["model"]
    )
    assert installed["digest"] == profile["model_digest"], (
        "installed model identity changed"
    )
    tasks = [
        {
            "id": "R01",
            "session": "release-repair",
            "prompt": "The release configuration will not load. Discover the relevant file, reproduce the problem with the approved check, make the smallest fix, check it again, and report what you observed. Preserve all existing settings.",
        },
        {
            "id": "R02",
            "session": "deploy-change",
            "prompt": "Find the deployment configuration and change staging replicas to 3. Preserve every other setting, run the approved check, and report its result and scope.",
        },
    ][: args.cases]
    report = {
        "profile": profile,
        "model": installed,
        "interface": args.interface,
        "tasks": tasks,
        "turns": [],
        "qualification": False,
    }
    save(root / "report.json", report)
    os.environ["SIGIL_PI_LOCAL_PROVIDER_TOKEN"] = "local-only-placeholder"
    with WorkspaceApi(root / "deployment", workspace, profile["endpoint"]) as api:
        print(json.dumps({"service": api.ready, "output": str(root)}), flush=True)
        if args.interface == "api":
            for task in tasks:
                before_task = files(workspace)
                start = time.monotonic()
                code, accepted = api.request(
                    body={
                        "session": task["session"],
                        "message": task["prompt"],
                        "submission_key": task["id"],
                    }
                )
                turn = {
                    "task": task["id"],
                    "acceptance": {"status": code, "body": accepted},
                }
                report["turns"].append(turn)
                save(root / "report.json", report)
                assert code == 202, accepted
                turn["result"] = wait(api, accepted["operation"])
                turn["elapsed_s"] = time.monotonic() - start
                print(json.dumps(turn), flush=True)
                capture(root, api, report)
                assert turn["result"]["status"] == "done", turn
                turn["verification"] = check_task(
                    api.root, workspace, accepted["operation"], task["id"], before_task
                )
                capture(root, api, report)
        else:
            report["browser_tasks"] = []
            for index, task in enumerate(tasks):
                before_task = files(workspace)
                browser_output = root / ("browser-" + task["id"])
                browser_output.mkdir()
                proc = subprocess.run(
                    ["node", str(ROOT / "acceptance/browser_repository.mjs")],
                    input=json.dumps(
                        {
                            "url": "http://" + api.ready["address"],
                            "token": TOKEN_A,
                            "tasks": [task],
                            "output": str(browser_output),
                            "interruptAfter": index == len(tasks) - 1,
                        }
                    ),
                    text=True,
                    capture_output=True,
                    timeout=500,
                )
                (browser_output / "browser.log").write_text(
                    proc.stdout + "\n" + proc.stderr
                )
                capture(root, api, report)
                assert proc.returncode == 0, proc.stderr
                ui = json.loads((browser_output / "browser-report.json").read_text())
                operation = ui["turns"][0]["operation"]
                verification = check_task(
                    api.root, workspace, operation, task["id"], before_task
                )
                report["browser_tasks"].append(
                    {"task": task["id"], "ui": ui, "verification": verification}
                )
                capture(root, api, report)
        if args.interface == "api":
            code, interrupted = api.request(
                body={
                    "session": "interrupted",
                    "message": "Inspect the repository",
                    "submission_key": "interrupted",
                }
            )
            assert code == 202, interrupted
            code, cancellation = api.request(
                "POST", interrupted["status_url"] + "/cancel", body={}
            )
            assert code in (200, 202), cancellation
            report["interruption"] = wait(api, interrupted["operation"])
            assert report["interruption"]["status"] in ("cancelled", "uncertain")
        else:
            report["interruption"] = report["browser_tasks"][-1]["ui"]["interruption"]
        report["after"] = {
            str(p.relative_to(workspace)): p.read_text()
            for p in workspace.rglob("*")
            if p.is_file()
        }
        report["file_assertions"] = {
            "release": json.loads((workspace / "config/release.json").read_text())
            == {"service": "atlas", "port": 8080, "note": "preserve this"},
            "deployment": json.loads((workspace / "config/deploy.json").read_text())
            == {
                "environment": "staging",
                "replicas": 3 if args.cases == 2 else 2,
                "note": "Keep café | unchanged",
            },
        }
        capture(root, api, report)
        assert all(report["file_assertions"].values()), report["file_assertions"]
    # Reopen the exact deployment after the native owner exits. No rebuild,
    # record manipulation, credential rotation, or hidden resubmission.
    with WorkspaceApi(
        root / "deployment", workspace, profile["endpoint"], mode="open"
    ) as api:
        old_id = report["interruption"]["operation"]
        code, previous = api.request("GET", "/v1/operations/" + old_id)
        assert code == 200 and previous["status"] in ("cancelled", "uncertain")
        if args.interface == "api":
            assert previous == report["interruption"]
            code, accepted = api.request(
                body={
                    "session": "interrupted",
                    "message": "Read config/deploy.json and report the actual replica count. Do not change files.",
                    "submission_key": "resume",
                }
            )
            assert code == 202, accepted
            report["continued_after_restart"] = wait(api, accepted["operation"])
            assert report["continued_after_restart"]["status"] == "done"
            assert api.request("GET", "/v1/operations/" + old_id)[1] == previous
        else:
            resumed = root / "restart-browser"
            resumed.mkdir()
            proc = subprocess.run(
                ["node", str(ROOT / "acceptance/browser_repository.mjs")],
                input=json.dumps(
                    {
                        "url": "http://" + api.ready["address"],
                        "token": TOKEN_A,
                        "resume": old_id,
                        "output": str(resumed),
                    }
                ),
                text=True,
                capture_output=True,
                timeout=400,
            )
            (resumed / "browser.log").write_text(proc.stdout + "\n" + proc.stderr)
            report["restart_browser_exit"] = proc.returncode
            capture(root, api, report)
            assert proc.returncode == 0, proc.stderr
        report["workspace_unchanged_by_continuation"] = report["after"] == {
            str(p.relative_to(workspace)): p.read_text()
            for p in workspace.rglob("*")
            if p.is_file()
        }
        assert report["workspace_unchanged_by_continuation"]
        capture(root, api, report)
    print(json.dumps({"complete": True, "output": str(root)}), flush=True)


if __name__ == "__main__":
    main()
