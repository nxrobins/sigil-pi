//! Generic, scoped logical-capacity publications. SIGIL supplies budgets and
//! retirement decisions; these mechanisms never interpret application records.
use crate::{Result, audited_transaction, automatic, digest_bytes};
use serde::{Deserialize, Serialize};
use sigil_durable_store::store::authenticated_log::AuthenticatedLog;
use sigil_durable_store::store::reservation::{Credits, Held, Request};
use sigil_durable_store::store::{Access, Batch, Mutation, Scope, Store};
use std::collections::BTreeMap;
use zeroize::Zeroizing;

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Amount {
    pub records: u64,
    pub live_bytes: u64,
}
impl Amount {
    pub fn credits(&self) -> Credits {
        Credits {
            records: self.records,
            live_bytes: self.live_bytes,
        }
    }
}
#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct AuditAmount {
    pub records: u64,
    pub bytes: u64,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Reserve {
    #[serde(default)]
    pub expected_generation: Option<crate::reservation_identity::ProposedGeneration>,
    pub namespace: String,
    pub key: String,
    pub binding: String,
    pub records: u64,
    pub live_bytes: u64,
    pub audits: BTreeMap<String, AuditAmount>,
}
#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Spend {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub identity: Option<crate::reservation_identity::Identity>,
    pub namespace: String,
    pub key: String,
    pub records: u64,
    pub live_bytes: u64,
    pub release: bool,
}
impl Spend {
    pub(crate) fn held(&self, store: &Store, scope: &Scope, require_idle: bool) -> Result<Held> {
        crate::reservation_identity::held(
            store,
            scope,
            &self.namespace,
            &self.key,
            self.identity.as_ref(),
            require_idle,
        )
    }
    pub(crate) fn debit(&self) -> Credits {
        Credits {
            records: self.records,
            live_bytes: self.live_bytes,
        }
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct EffectFunds {
    #[serde(default)]
    pub identity: Option<crate::reservation_identity::Identity>,
    pub namespace: String,
    pub key: String,
    pub claim: Amount,
    pub result: Amount,
    pub retirement: Amount,
    pub result_bytes: usize,
}
struct AdmittedLog {
    config: audited_transaction::Config,
    key: Zeroizing<Vec<u8>>,
}
struct AdmittedTarget {
    grants: BTreeMap<String, Access>,
    logs: BTreeMap<String, AdmittedLog>,
}
pub(crate) struct Admitted {
    targets: BTreeMap<String, AdmittedTarget>,
}
struct Log {
    config: audited_transaction::Config,
    log: AuthenticatedLog,
}
struct Target {
    scope: Scope,
    logs: BTreeMap<String, Log>,
}
pub(crate) struct Capacity {
    targets: BTreeMap<String, Target>,
}

impl Admitted {
    pub(crate) fn new(
        auto: &automatic::Config,
        credentials: &[crate::CredentialConfig],
        slots: &BTreeMap<String, u16>,
        allocation: &sigil_durable_store::store::capacity::Allocation,
    ) -> Result<Self> {
        let mut targets = BTreeMap::new();
        for p in &auto.participants {
            let ns = p.funding.as_ref().ok_or("config")?;
            let pool = allocation
                .pools
                .iter()
                .find(|p| p.namespaces.contains(ns))
                .ok_or("config")?;
            if !slots.contains_key(&pool.id) || targets.contains_key(ns) {
                return Err("config");
            }
            if p.dispatch_journal.as_ref().is_some_and(|journal| {
                !pool.namespaces.contains(journal)
                    || journal == ns
                    || journal == &p.claim_namespace
                    || journal == &p.delivery_namespace
                    || p.effect_audit.as_ref().is_none_or(|audit| {
                        !pool.namespaces.contains(&audit.heads)
                            || !pool.namespaces.contains(&audit.records)
                    })
            }) {
                return Err("config");
            }
            let c = credentials
                .iter()
                .find(|c| c.sha256 == p.credential_sha256)
                .ok_or("config")?;
            if c.grants.get(ns) != Some(&Access::ReadWrite) {
                return Err("config");
            }
            let mut grants = c.grants.clone();
            let mut logs = BTreeMap::new();
            for (alias, config) in [
                ("effect", &p.effect_audit),
                ("transaction", &p.transaction_audit),
            ] {
                let config = config.as_ref().ok_or("config")?;
                // Evaluator failure journaling needs its own funded obligations.
                if config.version != 1 || config.evaluation.is_some() {
                    return Err("config");
                }
                grants.insert(config.heads.clone(), Access::ReadWrite);
                grants.insert(config.records.clone(), Access::ReadWrite);
                logs.insert(
                    alias.into(),
                    AdmittedLog {
                        config: config.clone(),
                        key: audited_transaction::environment_key(&config.key_env)?,
                    },
                );
            }
            targets.insert(ns.clone(), AdmittedTarget { grants, logs });
        }
        if targets.len() != slots.len() {
            return Err("config");
        }
        Ok(Self { targets })
    }
    pub(crate) fn open(self, store: &Store) -> Result<Capacity> {
        let mut targets = BTreeMap::new();
        for (ns, target) in self.targets {
            let scope = store.scope(target.grants).map_err(|_| "config")?;
            let mut logs = BTreeMap::new();
            for (name, a) in target.logs {
                let log = AuthenticatedLog::new(
                    store,
                    &a.config.heads,
                    &a.config.records,
                    a.config.limits,
                    &a.key,
                )
                .map_err(|_| "config")?;
                logs.insert(
                    name,
                    Log {
                        config: a.config,
                        log,
                    },
                );
            }
            targets.insert(ns, Target { scope, logs });
        }
        Ok(Capacity { targets })
    }
}
fn owner(store: &Store, scope: &Scope, namespace: &str, key: &str) -> Result<()> {
    // Check the ORIGINAL caller's write scope before using private log scopes.
    store
        .check_batch(
            scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: namespace.into(),
                    key: key.into(),
                    revision: 1,
                    value: None,
                }],
            },
        )
        .map_err(|_| "capability")
}
impl Capacity {
    pub(crate) fn reserve(
        &self,
        store: &mut Store,
        scope: &Scope,
        batch: &Batch,
        r: Reserve,
    ) -> Result<sigil_durable_store::store::Receipt> {
        store.check_batch(scope, batch).map_err(|_| "capability")?;
        owner(store, scope, &r.namespace, &r.key)?;
        let expected = match (store.has_reservation_generations(), r.expected_generation) {
            (true, Some(generation)) => Some(generation.native()?),
            (false, None) => None,
            _ => return Err("funding_identity"),
        };
        let target = self.targets.get(&r.namespace).ok_or("capability")?;
        if r.audits.len() != target.logs.len() {
            return Err("funding");
        }
        let mut allowances = Vec::new();
        for (alias, a) in r.audits {
            let l = target.logs.get(&alias).ok_or("funding")?;
            if a.records
                .checked_mul(l.log.encoded_entry_ceiling())
                .is_none_or(|n| a.bytes < n)
            {
                return Err("capacity");
            }
            let head = store
                .get(&target.scope, &l.config.heads, &l.config.chain)
                .map_err(|_| "storage")?;
            allowances.push(
                l.log
                    .prepare_allowance(
                        store,
                        &target.scope,
                        &l.config.chain,
                        head.revision,
                        a.records,
                        a.bytes,
                    )
                    .map_err(|_| "capacity")?,
            );
        }
        let request = Request {
            namespace: r.namespace,
            key: r.key,
            binding: digest_bytes(&r.binding)?,
            credits: Credits {
                records: r.records,
                live_bytes: r.live_bytes,
            },
        };
        let result = if let Some(expected) = expected {
            store.commit_reserving_generation_audited(
                &target.scope,
                batch,
                &request,
                &allowances,
                &expected,
            )
        } else {
            store.commit_reserving_audited(&target.scope, batch, &request, &allowances)
        };
        result.map(|p| p.receipt).map_err(|e| match e {
            sigil_durable_store::store::Error::Limit => "capacity",
            sigil_durable_store::store::Error::CommitUncertain => "commit_uncertain",
            _ => "storage",
        })
    }
    pub(crate) fn spend(
        &self,
        store: &mut Store,
        scope: &Scope,
        batch: &Batch,
        s: Spend,
    ) -> Result<sigil_durable_store::store::Receipt> {
        store.check_batch(scope, batch).map_err(|_| "capability")?;
        owner(store, scope, &s.namespace, &s.key)?;
        if s.release || !self.targets.contains_key(&s.namespace) {
            return Err("capability");
        }
        let held = s.held(store, scope, false)?;
        store
            .commit_spending(scope, batch, &held, s.debit())
            .map(|p| p.receipt)
            .map_err(|_| "storage")
    }
}

#[cfg(test)]
#[path = "capacity_generation_tests.rs"]
mod generation_tests;
