//! Real native signed publication with controlled observations/responders.
//! This does not execute an external effect or validate a compiled SIGIL classifier.
use super::*;
use crate::evaluation_audit::Lookup;
use crate::shared_pure_tests::{
    audit_config, audit_environment_child, fixture_output, fixture_routes,
};
use sigil_durable_store::store::{Limits, Mutation, OpenMode};
use std::os::unix::fs::PermissionsExt;

#[test]
fn shared_effect_and_failure_publications_keep_keys_scopes_and_reopen_verification() {
    audit_environment_child("effect_audit::publication_tests::publication_child");
}

#[test]
fn publication_child() {
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let boot = frame("WB2\n", &["effect_audit_admitted", "fixture-binding"]).unwrap();
    let publication = frame("AR1\n", &["publish", "controlled effect publication"]).unwrap();
    let failure = frame("AR1\n", &["publish", "controlled recorder failure"]).unwrap();
    let (dir, formatter) = fixture_routes(&[
        ("WB1", &boot),
        ("WA1", &publication),
        ("EB1", "evaluation_audit_admitted"),
        ("EA1", &failure),
    ]);
    let state = dir.path().join("state");
    std::fs::create_dir(&state).unwrap();
    std::fs::set_permissions(&state, std::fs::Permissions::from_mode(0o700)).unwrap();
    let (_producer_dir, producer_worker) = fixture_output("invalid recorder result");
    let producer = crate::claimed::RecorderConfig {
        worker: producer_worker.clone(),
        delivery_namespace: "delivery".into(),
    };
    let effect = Bridge::new(producer_worker.clone()).unwrap();
    let admit = |side: &str, cache: &mut crate::PureCache| {
        let mut config = audit_config(formatter.clone(), side);
        config.version = 2;
        config.evaluation = Some(formatter.clone());
        Admitted::new_with_cache(
            config,
            &producer,
            &effect,
            &BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]),
            &format!("credential-{side}"),
            Some(cache),
        )
        .unwrap()
    };
    let mut cache = crate::PureCache::new();
    let mut store = Store::open(&state, OpenMode::CreateNew, Limits::default()).unwrap();
    let mut callers: Vec<_> = ["a", "b"]
        .into_iter()
        .map(|side| admit(side, &mut cache).open(&store).unwrap())
        .collect();
    assert_eq!(cache.len(), 1);
    let mut checkpoints = Vec::new();
    for (i, side) in ["a", "b"].into_iter().enumerate() {
        let batch = Batch {
            checks: vec![],
            writes: vec![Mutation {
                namespace: format!("{side}.domain"),
                key: "value".into(),
                revision: 0,
                value: Some(format!("{side}-only")),
            }],
        };
        let batch_text = serde_json::to_string(&batch).unwrap();
        let generation = "e".repeat(64);
        let facts = frame(
            "WF1\n",
            &[
                "observed",
                &generation,
                "fixture",
                "fixture",
                "fixture",
                "fixture",
                "string",
                "0",
                "controlled observation",
            ],
        )
        .unwrap();
        let intent = Check {
            namespace: format!("{side}.domain"),
            key: "intent".into(),
            revision: 0,
        };
        let deadline = Instant::now() + Duration::from_secs(5);
        let payload = callers[i]
            .propose(
                Recording {
                    intent: &intent,
                    claim_namespace: "claim",
                    delivery_namespace: "delivery",
                    claim_revision: 1,
                    claim_generation: &generation,
                    worker_facts: &facts,
                    prepared: Some("controlled preparation"),
                    input_sha256: &"a".repeat(64),
                    input_bytes: 1,
                    output: "controlled recorder output",
                    batch: &batch_text,
                    phase: "observed",
                    before: 1,
                    after: 2,
                    elapsed_ms: 1,
                    timeout_ms: 5000,
                },
                deadline,
            )
            .unwrap();
        callers[i]
            .commit(&mut store, &batch, &payload, deadline, None)
            .unwrap();
        assert_eq!(
            store
                .get(&callers[i].scope, &format!("{side}.domain"), "value")
                .unwrap()
                .value,
            Some(format!("{side}-only"))
        );
        // The failure observation comes from an actual fresh producer invocation.
        let mut function = Function::new(producer_worker.clone()).unwrap();
        let deadline = Instant::now() + Duration::from_secs(5);
        let observed = function.observe("controlled-recorder-input".into(), deadline);
        assert_eq!(observed.result.unwrap().0, "invalid recorder result");
        callers[i]
            .record_recorder_failure(
                &mut store,
                Pending::new(observed.facts, Lookup::new(&[]).unwrap(), deadline),
                "protocol",
            )
            .unwrap();
        let caller = &callers[i];
        let checkpoint = caller
            .log
            .verify(
                &mut store,
                &caller.scope,
                &caller.chain,
                None,
                Instant::now() + Duration::from_secs(1),
            )
            .unwrap();
        assert_eq!(checkpoint.count, 2);
        let (_, payload) = caller
            .log
            .verified_payload(
                &mut store,
                &caller.scope,
                &caller.chain,
                1,
                Instant::now() + Duration::from_secs(1),
            )
            .unwrap();
        assert_eq!(payload, "controlled recorder failure");
        let other = if i == 0 { "b" } else { "a" };
        let denied = Batch {
            checks: vec![],
            writes: vec![Mutation {
                namespace: format!("{other}.domain"),
                key: "forbidden".into(),
                revision: 0,
                value: Some("wrong tenant".into()),
            }],
        };
        assert!(
            caller
                .commit(
                    &mut store,
                    &denied,
                    "must not publish",
                    Instant::now() + Duration::from_secs(1),
                    None
                )
                .is_err()
        );
        assert_eq!(
            caller
                .log
                .verify(
                    &mut store,
                    &caller.scope,
                    &caller.chain,
                    None,
                    Instant::now() + Duration::from_secs(1)
                )
                .unwrap(),
            checkpoint
        );
        let cfg = audit_config(formatter.clone(), side);
        let key =
            environment_key(&format!("PI_SHARED_AUDIT_KEY_{}", other.to_uppercase())).unwrap();
        let wrong =
            AuthenticatedLog::new(&store, &cfg.heads, &cfg.records, cfg.limits, &key).unwrap();
        assert!(
            wrong
                .verify(
                    &mut store,
                    &caller.scope,
                    &caller.chain,
                    None,
                    Instant::now() + Duration::from_secs(1)
                )
                .is_err()
        );
        checkpoints.push(checkpoint);
    }
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    assert!(
        !std::fs::read_to_string(dir.path().join("calls"))
            .unwrap()
            .contains("test-only-key")
    );
    drop(callers);
    drop(store);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
    let mut reopened = Store::open(&state, OpenMode::Existing, Limits::default()).unwrap();
    for (side, expected) in ["a", "b"].into_iter().zip(checkpoints) {
        let caller = admit(side, &mut cache).open(&reopened).unwrap();
        assert_eq!(
            caller
                .log
                .verify(
                    &mut reopened,
                    &caller.scope,
                    &caller.chain,
                    Some(&expected),
                    Instant::now() + Duration::from_secs(1)
                )
                .unwrap(),
            expected
        );
        assert_eq!(
            reopened
                .get(&caller.scope, &format!("{side}.domain"), "forbidden")
                .unwrap()
                .revision,
            0
        );
        assert_eq!(
            reopened
                .get(&caller.scope, &format!("{side}.domain"), "value")
                .unwrap()
                .value,
            Some(format!("{side}-only"))
        );
    }
}
