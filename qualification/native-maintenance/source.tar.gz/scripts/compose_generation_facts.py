"""Explicit maintenance/process-facts integration; readiness route still pending."""
import hashlib
import json
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_modular_cancel import compose_modular_cancel
from scripts.compose_generation_admission import compose_generation_admission
from scripts.sigil_omit import omit_unreferenced_functions

ROOT = Path(__file__).resolve().parent.parent
COMMANDS = '["call","commit","commit_observed","inspect_execution","inspect_storage","metadata","read","read_many","read_observed","reply","reservation","reservation_plan","reserve","spend","temporary_read","temporary_write"]'
OLD_COMMANDS = '["call","commit","metadata","read","reply","reservation","reservation_plan","reserve","spend"]'


def compose_generation_facts(stdlib):
    programs = compose_modular_cancel(stdlib)
    result = {}
    for name, base in programs.items():
        body, inputs = base.text, dict(base.input_hashes)

        def replace(old, new, count):
            nonlocal body
            if body.count(old) != count:
                raise ValueError('generation/process composition changed: ' + old)
            body = body.replace(old, new)

        replace('"AH9\\n",13', '"AHA\\n",18', 3 if name == 'api_discovery' else 1)
        body = body.replace('"HC9\\n"', '"HCA\\n"')
        if name == 'api_discovery':
            replace(json.dumps(OLD_COMMANDS), json.dumps(COMMANDS), 1)
            replace('fn api_decision(input_ptr: i64,input_len: i64)',
                    'fn api_decision(input_ptr: i64 @Internal,input_len: i64 @Internal)', 1)
            replace('pub fn tool_main(input_ptr: i64,input_len: i64)',
                    'fn generation_response_core(input_ptr: i64 @Internal,input_len: i64 @Internal)', 1)
            gate = compact('''let gate: i64 @Internal = lifecycle_turn_gate(x);
                if gate != 0 { return gate; }''')
            anchor = 'if size(value)!= 0 || !operation_id(get(x,5)){return -400;}'
            replace(anchor, anchor + gate, 1)
            anchor = 'let action: i64 @Internal = read_record(command("reserve",get(planned,1),get(planned,3),get(x,5)),"HCA\\n",5);'
            replace(anchor, gate + anchor, 1)
            for relative in ['app/pi/http_request_id.sigil', 'app/pi/lifecycle.sigil', 'app/pi/generation_facts_entry.sigil']:
                raw = (ROOT / relative).read_bytes(); inputs[relative] = hashlib.sha256(raw).hexdigest()
                fragment = raw.decode()
                if relative.endswith('http_request_id.sigil'):
                    fragment = fragment.split('// REQUEST_ID_POLICY_BEGIN')[1].split('// REQUEST_ID_POLICY_END')[0]
                body += compact(fragment)
            pins_path = ROOT / 'scripts/generation_facts_omissions.json'
            pins = json.loads(pins_path.read_text())
            if hashlib.sha256(body.encode()).hexdigest() != pins['input_sha256']:
                raise ValueError('combined omission baseline changed')
            body = omit_unreferenced_functions(body, pins['functions']).text
            inputs['scripts/generation_facts_omissions.json'] = hashlib.sha256(pins_path.read_bytes()).hexdigest()
        if len(body.encode()) > 65536 or body.count('pub fn tool_main(') != 1:
            raise ValueError(f'combined entry exceeds unchanged source limit: {len(body.encode())}')
        inputs['scripts/compose_generation_facts.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result[name] = ApplicationSource(body, inputs, base.stdlib_hash)
    # GC2 embeds an action frame as well as reservation facts. Bind the same
    # explicit command ABI on both sides; GP1/AD2 allocation data is unchanged.
    base = compose_generation_admission(stdlib)
    if base.text.count('"HC9\\n"') != 2:
        raise ValueError('generation cancellation binding ABI changed')
    inputs = dict(base.input_hashes)
    inputs['scripts/compose_generation_facts.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['generation_admission'] = ApplicationSource(
        base.text.replace('"HC9\\n"', '"HCA\\n"'), inputs, base.stdlib_hash)
    return result
