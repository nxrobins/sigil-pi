"""SIGIL-owned allocation checks before the existing native effect dispatch."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_capacity import compose_capacity

ROOT=Path(__file__).resolve().parent.parent


def compose_generation_coordinator(stdlib):
    base=compose_capacity("coordinator",stdlib)
    marker="pub fn tool_main(input_ptr: i64,input_len: i64)"
    if base.text.count(marker)!=1:
        raise ValueError("one original coordinator entry required")
    body=base.text.replace(marker,"fn generation_coordinator_base(input_ptr: i64 @Internal,input_len: i64 @Internal)")
    inputs=dict(base.input_hashes)
    for name in ["app/pi/reservation_identity.sigil","app/pi/generation_coordinator.sigil"]:
        raw=(ROOT/name).read_bytes();inputs[name]=hashlib.sha256(raw).hexdigest()
        fragment=raw.decode()
        if name.endswith("reservation_identity.sigil"):
            fragment=fragment.split("pub fn tool_main(")[0]
        body+="\n"+fragment
    body=compact(body)
    if len(body.encode())>65536 or body.count("pub fn tool_main(")!=1:
        raise ValueError("generation coordinator exceeds source/entry contract")
    inputs["scripts/compose_generation_coordinator.py"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body,inputs,base.stdlib_hash)
