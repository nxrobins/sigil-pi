//! Fixed descriptor -> offline, disposable container. No tool selection or
//! application verdicts live here. Repository code never receives the engine
//! socket, host environment, or writable host paths.
use crate::{Config, Fault, Observation, Pending, strict};
use serde::Deserialize;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::ffi::{CStr, CString};
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::{MetadataExt, OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

#[cfg(test)]
#[path = "container/tests.rs"]
mod tests;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Descriptor {
    schema: String,
    socket: PathBuf,
    image: String,
    argv: Vec<String>,
    workspace: PathBuf,
    slot: String,
    wall_ms: u64,
    memory_bytes: u64,
    pids: u64,
    output_bytes: usize,
}
impl Descriptor {
    pub(crate) fn admit(source: &str, config: &Config) -> Result<Self, Fault> {
        let d: Self =
            serde_json::from_value(strict::parse(source.as_bytes()).map_err(|_| Fault::Invalid)?)
                .map_err(|_| Fault::Invalid)?;
        if d.schema != "sigil-container-command/v1"
            || !d.socket.is_absolute()
            || !d.workspace.is_absolute()
            || d.image.len() != 71
            || !d.image.starts_with("sha256:")
            || !d.image[7..]
                .bytes()
                .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
            || !d.slot.starts_with("sigil-pi-")
            || d.slot.len() > 80
            || !d
                .slot
                .bytes()
                .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b'-')
            || d.argv.is_empty()
            || d.argv.len() > 32
            || !Path::new(&d.argv[0]).is_absolute()
            || d.argv.iter().any(|s| s.len() > 4096 || s.contains('\0'))
            || !(1..=30_000).contains(&d.wall_ms)
            || !(64 * 1024 * 1024..=512 * 1024 * 1024).contains(&d.memory_bytes)
            || !(16..=128).contains(&d.pids)
            || !(1024..=16384).contains(&d.output_bytes)
            || config.fs != [d.workspace.to_string_lossy()]
            || !config.fs_write.is_empty()
            || !config.net.is_empty()
            || !config.secret_env.is_empty()
        {
            return Err(Fault::Invalid);
        }
        Ok(d)
    }

    fn cli(
        &self,
        config: &Config,
        args: &[String],
        deadline: Instant,
        cancel: &AtomicBool,
        cap: usize,
    ) -> Result<(i32, String, String), Fault> {
        if cancel.load(Ordering::Acquire) {
            return Err(Fault::Cancelled);
        }
        if Instant::now() >= deadline {
            return Err(Fault::Deadline);
        }
        let empty = tempfile::tempdir().map_err(|_| Fault::Spawn)?;
        let mut cmd = Command::new(&config.runtime);
        cmd.env_clear()
            .env("PATH", "/usr/bin:/bin")
            .env("LANG", "C.UTF-8")
            .current_dir("/")
            .args([
                "--config",
                empty.path().to_str().ok_or(Fault::Invalid)?,
                "--host",
            ])
            .arg(format!("unix://{}", self.socket.display()))
            .args(args)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        let mut child = cmd.spawn().map_err(|_| Fault::Spawn)?;
        let mut stdout = child.stdout.take().unwrap();
        let mut stderr = child.stderr.take().unwrap();
        let outcome = (|| {
            for fd in [stdout.as_raw_fd(), stderr.as_raw_fd()] {
                // SAFETY: live owned pipe handles; changing flags only.
                let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
                if flags < 0
                    || unsafe { libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK) } < 0
                {
                    return Err(Fault::Transport);
                }
            }
            let (mut out, mut err) = (Vec::new(), Vec::new());
            let (mut out_eof, mut err_eof) = (false, false);
            let mut status = None;
            loop {
                if cancel.load(Ordering::Acquire) {
                    return Err(Fault::Cancelled);
                }
                if Instant::now() >= deadline {
                    return Err(Fault::Deadline);
                }
                for (pipe, data, eof) in [
                    (&mut stdout as &mut dyn Read, &mut out, &mut out_eof),
                    (&mut stderr as &mut dyn Read, &mut err, &mut err_eof),
                ] {
                    let mut buf = [0u8; 8192];
                    match pipe.read(&mut buf) {
                        Ok(0) => *eof = true,
                        Ok(n) => {
                            if data.len() + n > cap {
                                return Err(Fault::Limit);
                            }
                            data.extend_from_slice(&buf[..n]);
                        }
                        Err(e)
                            if matches!(
                                e.kind(),
                                std::io::ErrorKind::WouldBlock | std::io::ErrorKind::Interrupted
                            ) => {}
                        Err(_) => return Err(Fault::Transport),
                    }
                }
                if status.is_none() {
                    status = child.try_wait().map_err(|_| Fault::Transport)?;
                }
                if out_eof
                    && err_eof
                    && let Some(status) = status
                {
                    return Ok((
                        status.code().unwrap_or(125),
                        String::from_utf8(out).map_err(|_| Fault::Protocol)?,
                        String::from_utf8(err).map_err(|_| Fault::Protocol)?,
                    ));
                }
                std::thread::sleep(Duration::from_millis(5));
            }
        })();
        if outcome.is_err() {
            let _ = child.kill();
            let _ = child.wait();
        }
        outcome
    }
    fn inspect(
        &self,
        config: &Config,
        deadline: Instant,
        cancel: &AtomicBool,
    ) -> Result<Option<Value>, Fault> {
        let (code, out, err) = self.cli(
            config,
            &["container".into(), "inspect".into(), self.slot.clone()],
            deadline,
            cancel,
            65536,
        )?;
        if code != 0 {
            if err.contains("No such container") || err.contains("No such object") {
                return Ok(None);
            }
            return Err(Fault::Transport);
        }
        let v = strict::parse(out.as_bytes()).map_err(|_| Fault::Protocol)?;
        let values = v.as_array().ok_or(Fault::Protocol)?;
        if values.len() != 1 {
            return Err(Fault::Protocol);
        }
        Ok(Some(values[0].clone()))
    }
    fn remove(&self, config: &Config, generation: &str) -> bool {
        let stop = AtomicBool::new(false);
        let deadline = Instant::now() + Duration::from_secs(5);
        let Ok(actual) = self.inspect(config, deadline, &stop) else {
            return false;
        };
        let Some(actual) = actual else {
            return true;
        };
        if actual["Config"]["Labels"]["io.sigil-pi.generation"] != generation {
            return false;
        }
        let Some(id) = actual["Id"].as_str() else {
            return false;
        };
        let Ok((0, _, _)) = self.cli(
            config,
            &["container".into(), "rm".into(), "--force".into(), id.into()],
            deadline,
            &stop,
            65536,
        ) else {
            return false;
        };
        matches!(self.inspect(config, deadline, &stop), Ok(None))
    }

    pub(crate) fn execute(
        &self,
        config: &Config,
        pending: Pending,
        cancel: &AtomicBool,
    ) -> Observation {
        let mut seen = Observation {
            generation: pending.ticket.clone(),
            request_may_have_run: false,
            worker_reaped: true,
            fault: None,
            result: None,
        };
        let mut created = false;
        let mut create_attempted = false;
        let mut snapshot = None;
        let run = (|| {
            // The source and argv are immutable. Even a directly embedded caller
            // cannot reinterpret input as an executable, path, env, or arguments.
            if pending.input != "CW1\n" {
                return Err(Fault::Invalid);
            }
            if let Some(old) = self.inspect(config, pending.deadline, cancel)? {
                if old["Config"]["Labels"]["io.sigil-pi.descriptor"] != config.source_sha256 {
                    return Err(Fault::Invalid);
                }
                if old["State"]["Running"] != false {
                    return Err(Fault::Busy);
                }
                let generation = old["Config"]["Labels"]["io.sigil-pi.generation"]
                    .as_str()
                    .ok_or(Fault::Protocol)?;
                if !self.remove(config, generation) {
                    return Err(Fault::CleanupUnconfirmed);
                }
                // A killed owner cannot run TempDir::drop. Reclaim only the
                // stopped, descriptor-matching container's own snapshot mount.
                reclaim_snapshot(&old)?;
            }
            let (directory, snapshot_hash) =
                snapshot_workspace(&self.workspace, pending.deadline, cancel)?;
            let mount = format!(
                "type=bind,source={},destination=/input,readonly",
                directory.path().join("input").display()
            );
            snapshot = Some(directory);
            let mut args: Vec<String> = vec![
                "container",
                "create",
                "--pull=never",
                "--name",
                &self.slot,
                "--network=none",
                "--read-only",
                "--cap-drop=ALL",
                "--cap-add=SETUID",
                "--cap-add=SETGID",
                "--security-opt=no-new-privileges",
                "--ipc=none",
                "--cgroupns=private",
                "--user=0:0",
                "--cpus=1",
                "--log-driver=none",
                "--ulimit=nofile=128:128",
                "--ulimit=core=0:0",
                "--tmpfs=/work:rw,exec,nosuid,nodev,size=67108864,mode=1777",
                "--tmpfs=/tmp:rw,nosuid,nodev,noexec,size=16777216,mode=1777",
                "--workdir=/work",
                "--entrypoint=/usr/local/bin/sigil-command-init",
            ]
            .into_iter()
            .map(String::from)
            .collect();
            args.extend([
                format!("--memory={}", self.memory_bytes),
                format!("--memory-swap={}", self.memory_bytes),
                format!("--pids-limit={}", self.pids),
                format!("--label=io.sigil-pi.descriptor={}", config.source_sha256),
                format!("--label=io.sigil-pi.generation={}", pending.ticket),
                "--mount".into(),
                mount,
                self.image.clone(),
                self.wall_ms.to_string(),
            ]);
            args.extend(self.argv.iter().cloned());
            create_attempted = true;
            let (code, id, _) = self.cli(config, &args, pending.deadline, cancel, 65536)?;
            if code != 0 {
                return Err(Fault::Spawn);
            }
            let id = id.trim();
            if id.len() != 64 || !id.bytes().all(|b| b.is_ascii_hexdigit()) {
                return Err(Fault::Protocol);
            }
            created = true;
            // Start may reach the daemon even if the client loses its reply.
            seen.request_may_have_run = true;
            let (client_code, out, err) = self.cli(
                config,
                &[
                    "container".into(),
                    "start".into(),
                    "--attach".into(),
                    id.into(),
                ],
                pending.deadline,
                cancel,
                self.output_bytes,
            )?;
            let actual = self
                .inspect(config, pending.deadline, cancel)?
                .ok_or(Fault::Protocol)?;
            if actual["Id"] != id
                || actual["State"]["Status"] != "exited"
                || actual["State"]["Running"] != false
                || actual["State"]["Error"] != ""
            {
                return Err(Fault::Protocol);
            }
            let code = actual["State"]["ExitCode"]
                .as_u64()
                .filter(|n| *n <= 255)
                .ok_or(Fault::Protocol)?;
            if i64::from(client_code) != code as i64 {
                return Err(Fault::Protocol);
            }
            let payload = frame(
                "CR1\n",
                &[&code.to_string(), &out, &err, &snapshot_hash, &self.image],
            );
            Ok(json!({"status":"ok", "data":{"output_text":frame("RF1\n", &["ok", &payload])}}))
        })();
        if create_attempted {
            // Inspect by immutable attempt label: never delete another attempt
            // after a create conflict or a lost create reply.
            seen.worker_reaped = self.remove(config, &pending.ticket);
            if !seen.worker_reaped && !created {
                // A differently labelled pre-existing slot is not our worker.
                let stop = AtomicBool::new(false);
                if let Ok(Some(v)) =
                    self.inspect(config, Instant::now() + Duration::from_secs(2), &stop)
                    && v["Config"]["Labels"]["io.sigil-pi.generation"]
                        .as_str()
                        .is_some_and(|g| g != pending.ticket)
                {
                    seen.worker_reaped = true;
                }
            }
        }
        if !seen.worker_reaped {
            // Retain the private ancestor as well as its mounted child while
            // cleanup is uncertain. PID 1 still enforces its own wall deadline.
            if let Some(directory) = snapshot {
                let _ = directory.keep();
            }
            seen.fault = Some(Fault::CleanupUnconfirmed);
        } else {
            match run {
                Ok(v) => seen.result = Some(v),
                Err(e) => seen.fault = Some(e),
            }
        }
        seen
    }
}
fn frame(marker: &str, values: &[&str]) -> String {
    let mut result = marker.to_string();
    for v in values {
        result.push_str(&format!("{:08}{}", v.len(), v));
    }
    result
}
fn snapshot_temporary_root() -> &'static Path {
    Path::new(if cfg!(target_os = "macos") {
        "/private/tmp"
    } else {
        "/tmp"
    })
}

fn reclaim_snapshot(actual: &Value) -> Result<(), Fault> {
    let mounts = actual["Mounts"].as_array().ok_or(Fault::Protocol)?;
    for mount in mounts {
        if mount["Destination"] != "/input" {
            continue;
        }
        if mount["Type"] != "bind" || mount["RW"] != false {
            return Err(Fault::Invalid);
        }
        let path = Path::new(mount["Source"].as_str().ok_or(Fault::Protocol)?);
        // New snapshots mount a readable child of a private ancestor. Support
        // only the old direct-child layout when reclaiming an older stopped
        // attempt; never widen the set of directories that may be removed.
        let (directory, private) = if path.parent() == Some(snapshot_temporary_root()) {
            (path, false)
        } else if path.file_name().is_some_and(|name| name == "input")
            && path.parent().and_then(Path::parent) == Some(snapshot_temporary_root())
        {
            (path.parent().ok_or(Fault::Invalid)?, true)
        } else {
            return Err(Fault::Invalid);
        };
        if !directory
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.starts_with("sigil-command-"))
        {
            return Err(Fault::Invalid);
        }
        let owner = unsafe { libc::geteuid() };
        match std::fs::symlink_metadata(directory) {
            Ok(meta) => {
                if !meta.is_dir()
                    || meta.uid() != owner
                    || (private && meta.mode() & 0o777 != 0o700)
                {
                    return Err(Fault::Invalid);
                }
                if private {
                    match std::fs::symlink_metadata(path) {
                        Ok(child) if child.is_dir() && child.uid() == owner => {}
                        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                        Ok(_) => return Err(Fault::Invalid),
                        Err(_) => return Err(Fault::Transport),
                    }
                }
                std::fs::remove_dir_all(directory).map_err(|_| Fault::Transport)?;
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(_) => return Err(Fault::Transport),
        }
    }
    Ok(())
}

fn snapshot_workspace(
    root: &Path,
    deadline: Instant,
    cancel: &AtomicBool,
) -> Result<(tempfile::TempDir, String), Fault> {
    let source = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_DIRECTORY | libc::O_CLOEXEC)
        .open(root)
        .map_err(|_| Fault::Invalid)?;
    let target = tempfile::Builder::new()
        .prefix("sigil-command-")
        .tempdir_in(snapshot_temporary_root())
        .map_err(|_| Fault::Spawn)?;
    // Other host UIDs must never traverse this ancestor, even after owner death.
    // The trusted daemon mounts only the child, whose permissions let the
    // existing unprivileged container command copy its input into private tmpfs.
    std::fs::set_permissions(target.path(), std::fs::Permissions::from_mode(0o700))
        .map_err(|_| Fault::Spawn)?;
    let input = target.path().join("input");
    std::fs::create_dir(&input).map_err(|_| Fault::Spawn)?;
    std::fs::set_permissions(&input, std::fs::Permissions::from_mode(0o755))
        .map_err(|_| Fault::Spawn)?;
    let mut budget = Snapshot {
        entries: 0,
        bytes: 0,
        hash: Sha256::new(),
        deadline,
        cancel,
    };
    budget.copy(&source, &input, "", 0)?;
    Ok((target, format!("{:x}", budget.hash.finalize())))
}
struct Snapshot<'a> {
    entries: usize,
    bytes: u64,
    hash: Sha256,
    deadline: Instant,
    cancel: &'a AtomicBool,
}
impl Snapshot<'_> {
    fn copy(
        &mut self,
        dir: &File,
        target: &Path,
        relative: &str,
        depth: usize,
    ) -> Result<(), Fault> {
        if depth > 16 {
            return Err(Fault::Limit);
        }
        // Descriptor-relative traversal prevents a directory/symlink replacement
        // race from redirecting a read outside the authorized root.
        let fd = unsafe { libc::dup(dir.as_raw_fd()) };
        if fd < 0 {
            return Err(Fault::Transport);
        }
        let stream = unsafe { libc::fdopendir(fd) };
        if stream.is_null() {
            unsafe {
                libc::close(fd);
            }
            return Err(Fault::Transport);
        }
        let names = (|| {
            let mut names = Vec::new();
            loop {
                let entry = unsafe { libc::readdir(stream) };
                if entry.is_null() {
                    break;
                }
                let name = unsafe { CStr::from_ptr((*entry).d_name.as_ptr()) }
                    .to_str()
                    .map_err(|_| Fault::Invalid)?;
                if name == "." || name == ".." {
                    continue;
                }
                self.entries += 1;
                if self.entries > 1024 {
                    return Err(Fault::Limit);
                }
                // Hidden metadata and credential files are not command inputs.
                if name.starts_with('.') {
                    continue;
                }
                names.push(name.to_string());
            }
            names.sort();
            Ok(names)
        })();
        unsafe {
            libc::closedir(stream);
        }
        for name in names? {
            if self.cancel.load(Ordering::Acquire) {
                return Err(Fault::Cancelled);
            }
            if Instant::now() >= self.deadline {
                return Err(Fault::Deadline);
            }
            let c = CString::new(name.as_bytes()).map_err(|_| Fault::Invalid)?;
            let fd = unsafe {
                libc::openat(
                    dir.as_raw_fd(),
                    c.as_ptr(),
                    libc::O_RDONLY | libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK,
                )
            };
            if fd < 0 {
                return Err(Fault::Invalid);
            }
            let mut file = unsafe { File::from_raw_fd(fd) };
            let meta = file.metadata().map_err(|_| Fault::Transport)?;
            let rel = format!("{relative}{name}");
            let dest = target.join(&name);
            self.hash.update((rel.len() as u64).to_be_bytes());
            self.hash.update(rel.as_bytes());
            if meta.is_dir() {
                self.hash.update(b"d");
                std::fs::create_dir(&dest).map_err(|_| Fault::Transport)?;
                std::fs::set_permissions(&dest, std::fs::Permissions::from_mode(0o755))
                    .map_err(|_| Fault::Transport)?;
                self.copy(&file, &dest, &(rel + "/"), depth + 1)?;
            } else if meta.is_file() && meta.nlink() == 1 {
                if meta.len() > 1024 * 1024 || self.bytes + meta.len() > 16 * 1024 * 1024 {
                    return Err(Fault::Limit);
                }
                let mut data = Vec::new();
                (&mut file)
                    .take(1024 * 1024 + 1)
                    .read_to_end(&mut data)
                    .map_err(|_| Fault::Transport)?;
                if data.len() as u64 != meta.len() {
                    return Err(Fault::Invalid);
                }
                let after = file.metadata().map_err(|_| Fault::Transport)?;
                if after.len() != meta.len()
                    || after.nlink() != 1
                    || (
                        after.mtime(),
                        after.mtime_nsec(),
                        after.ctime(),
                        after.ctime_nsec(),
                    ) != (
                        meta.mtime(),
                        meta.mtime_nsec(),
                        meta.ctime(),
                        meta.ctime_nsec(),
                    )
                {
                    return Err(Fault::Invalid);
                }
                self.bytes += data.len() as u64;
                self.hash.update(b"f");
                self.hash.update((data.len() as u64).to_be_bytes());
                self.hash.update(&data);
                let mut output = OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .mode(0o644)
                    .open(&dest)
                    .map_err(|_| Fault::Transport)?;
                output.write_all(&data).map_err(|_| Fault::Transport)?;
                output
                    .set_permissions(std::fs::Permissions::from_mode(0o644))
                    .map_err(|_| Fault::Transport)?;
            } else {
                return Err(Fault::Invalid);
            }
        }
        Ok(())
    }
}
