# Native one-use worker mechanism

Status: **EXECUTABLE LOCAL COMPONENT — NOT AUTHENTICATED PRODUCT DISPATCH**.
Protocols: `sigil-worker/v1`–`v4`. Sources: [bridge](../native/worker/src/lib.rs),
[Unix transport](../native/worker/src/transport.rs), [stdio adapter](../native/worker/src/main.rs),
and [locked dependencies](../native/worker/Cargo.lock).

This repo-local Rust component supplies fixed-source, fixed-grant execution with
one-use in-memory tickets and bounded worker transport. It contains no conversation,
company, authorization-policy, scheduling-policy or business-retry implementation.
It does not replace the product API or modify the pinned SIGIL runtime.

## Offline command workers (v4)

Version 4 explicitly admits a JSON command descriptor, rather than compiling it
as SIGIL. The [container backend](../native/worker/src/container.rs) supplies a
native execution mechanism; compiled SIGIL still authorizes dispatch, chooses the
tool, establishes the baseline requirement, and interprets results. Container
code itself is unverified. Admission trusts the operator's pinned image, Docker
client/engine, and [container supervisor](../native/command-image/init.c).

The pinned descriptor fixes `schema: sigil-container-command/v1`, local Unix
socket, image digest, argv, workspace, container slot, wall time, memory, process
count, and output limits. Worker `runtime` pins the Docker client executable and
`source` pins the descriptor. Only the fixed `CW1\n` input is accepted. Network,
secret, and host write grants must be empty; the sole read grant must equal the
descriptor's workspace. A v4 worker cannot serve as a pure application evaluator.
Actual EF3 dispatch facts and EM3 audit manifests distinguish `container-v1` from
SIGIL execution, preventing an older policy from overlooking the new mechanism.

Newly composed workspace deployments validate model tool arguments in the SIGIL
reducer before committing a tool intent. Malformed permitted calls receive a
paired `is_error` tool result saying that no tool ran; the next model step can
correct them. The dispatch adapter independently applies the same grammar after
checking authority, including for older retained intents. Unknown or duplicate
argument keys are refused. Workspace model responses are bounded to 256 KiB and
the configured history allowance before normalization; oversized responses end
with `response_limit`. These checks require a newly composed deployment and do
not rewrite artifacts or conversations pinned by an existing deployment.

Each run copies visible regular files using descriptor-relative traversal with
no symlink following. Hardlinks and special files are refused. Limits are 1 MiB
per file, 16 MiB total, 1,024 entries, and depth 16. Hidden files/directories are
excluded, including `.git` and `.env`. The copy is hashed and exposed read-only
to a fresh container. It is a captured set of bytes, not an atomic transaction
across concurrent source writers; this development profile requires exclusive
workspace use. Executable source modes are normalized to 0644, so scripts must
be invoked with an interpreter. Build outputs remain inside disposable scratch.

On the host, the snapshot lives in an owner-only `0700` temporary directory.
Its `input` child contains the normalized `0755` directories and `0644` files;
only that child is mounted into the container. The trusted daemon can admit the
mount and the unprivileged command can read it, while unrelated host accounts
cannot traverse the private ancestor. The parent remains private if the owner
dies or container cleanup cannot be confirmed. A stopped, descriptor-matching
attempt reclaims the whole parent. Recovery recognizes the older direct-child
snapshot layout only for narrowly scoped cleanup; it does not widen permissions
on new snapshots. A crash before container creation may leave a private orphan
with no container metadata from which to reclaim it automatically.

The image root is read-only. `/work` permits execution with a 64 MiB tmpfs;
`/tmp` is a non-executable 16 MiB tmpfs. The application profile limits each run
to one CPU, 256 MiB memory with no additional swap, 64 processes, 128 open files,
and 16 KiB of UTF-8 output per stream. Output overflow or invalid UTF-8 fails
explicitly. Docker's default syscall filtering remains enabled. No host
credentials, writable host mounts, Docker socket, or external network are
available to repository code. These are container restrictions, not a claim of
protection from a compromised engine or kernel. See Docker's documentation on
[resource limits](https://docs.docker.com/engine/containers/resource_constraints/)
and [container execution](https://docs.docker.com/engine/containers/run/).

A trusted PID 1 retains root solely to supervise a different-UID child. The
child runs as uid/gid 65534 with empty effective/permitted capabilities, no new
privileges, and a fixed environment. The supervisor enforces a monotonic
20-second wall deadline (descriptor maximum 30 seconds), independently of the
service owner. Repository children cannot signal that supervisor. PID-namespace
teardown ends detached descendants when PID 1 exits. The host also enforces its
45-second overall preparation/execution deadline plus bounded cleanup.

For this backend, `request_may_have_run` is conservatively set before requesting
container start. A result requires an exited container and matching native
client/container exit codes. `worker_reaped` requires confirmation that the
owned container is removed, or that no owned execution started. Cleanup checks
the immutable attempt label and container ID; a conflicting live slot is refused.
Cancellation force-removes that container. Owner death leaves a bounded running
container or an inert created container; it cannot mutate the real workspace.
The next authorized invocation reclaims a stopped, matching slot and its abandoned
snapshot. A delivery lost at owner death remains uncertain even if the container
later exits successfully; recovery does not infer success or replay the command.

Observed command output is `RF1(ok, CR1(exit_code, stdout, stderr, snapshot_sha256,
image_digest))`. SIGIL, not Rust, maps exit zero/nonzero to tool success/failure.
The `max_fuel` field is retained for the common ticket contract; container CPU
and time limits come from the engine and supervisor, not Wasm fuel accounting.

## Prepared execution and observations

A trusted local caller boots one bridge with a fixed runtime identity, SIGIL source,
grants and independent fuel/time ceilings. `prepare` holds the exact input, requested
fuel and monotonic deadline, then returns a random ticket/generation and input digest.
It does not start a worker. Only one unexpired preparation may exist at a time.

`execute` accepts only the matching ticket. It consumes that preparation before
any launch, send or failure; repeating the ticket cannot execute again in that bridge.
A wrong ticket does not consume the valid pending preparation. Every execution uses
a fresh runtime process and guest instance. It has no automatic retries.

In the [durable fixture](../tests/test_durable_turn.py), the sequence is:

1. Read the committed minimal intent and prepare its fixed effect in the native bridge.
2. Have the shared SIGIL executor produce a claim containing that native generation.
3. Commit the claim, then execute the ticket once.
4. Have SIGIL produce a delivery from the correlated observation, commit it, then let
   the pi SIGIL application interpret the result and produce its next state/intent.

The fixture now uses a [native durable-claim gate](claimed-worker.md) around this
bridge. That gate binds actual scoped intent reads, the prepared generation and its
own successful claim commit before allowing execution; a retained claim prevents
preparation at that coordinate after reopening. The bare bridge still has no storage
knowledge. Authenticated artifact/input/grant selection and semantic operation
admission remain product-integration requirements.
The draft uses the same random value for ticket and generation; neither is an
authenticated operation identity or a secret authorization credential. The stdio
channel is trusted and must not be exposed as a public or guest-callable API.

An execution observation contains:

| Field | Meaning |
|---|---|
| `generation` | The consumed preparation's identity, not a process ID |
| `request_may_have_run` | At least one forge-request byte was successfully written to the child pipe; a deliberately conservative signal, not proof of HTTP delivery |
| `worker_reaped` | No execution started, or the leader was reaped and the per-execution inherited lifetime endpoint closed; container execution instead requires its owned container to be removed. This does not undo a remote effect. |
| `fault` | Static local failure code, or null when a valid runtime result was observed |
| `result` | Strictly decoded runtime result, or null; its own `status` may be `error` |

Initialization traffic alone does not set `request_may_have_run`. A runtime error,
HTTP response, or stopped local process is not a business-success/rollback verdict.
No observed forge bytes plus trusted runtime behavior can establish that this bridge
did not request the effect; callers still need the full committed-attempt context.
If a claim exists but its owner's observation was lost, SIGIL preserves possible
delivery even when a test fixture knows the request had not actually been sent.

For native process workers, each spawn has a separate inherited socket endpoint.
The parent observes EOF only after all holders have closed it, including a
descendant that leaves the leader's process group. Stopping signals the owned
group before reaping its leader, then waits for both leader exit and endpoint
closure. Repeated cleanup after reaping never signals a possibly reused PID.
Failure to establish closure within the bounded cleanup interval yields
`CleanupUnconfirmed`, poisons the bridge, suppresses a successful result, and
keeps funded capacity assigned. Both synchronous and owned completion use this
same native observation. The global storage lease separately prevents a new
storage owner while inherited execution holders remain alive.

Both mechanisms require the trusted native runtime and its descendants to retain
their inherited descriptors until exit, without shutting down the endpoint.
They do not contain a malicious native executable that closes its descriptors.
The endpoint is never a SIGIL guest capability or an application completion
message. Docker-managed processes have a separate container-removal contract;
the Docker client's exit alone cannot establish container termination.

## Bootstrap and authority limits

The version-1 bootstrap requires absolute runtime/source paths with exact lowercase
SHA-256 digests. It rejects final-component symlinks, nonregular files, group/other
writable files, setuid/setgid modes, oversized files and digest mismatches. Source is
limited to 65,536 bytes, decoded once as UTF-8 and held in memory; changes to the
source path after preparation cannot replace the held program. Runtime bytes are
checked again before each launch, with a 256 MiB ceiling.

This is **not race-free authenticated artifact admission**: parent path components
are not descriptor-bound, runtime launch resolves a pathname after hashing, and a
trusted local package/filesystem is assumed. Hashes alone do not establish publisher
identity, verification provenance, host-contract compatibility or target approval.
The real configured runtime still compiles and verifies SIGIL on every execution;
there is no AOT deserialization or compile-once performance claim here.

The bootstrap fixes `net`, `fs` and `secret_env` for the bridge lifetime. Per-request
source/runtime/grant changes, extra fields, duplicate decoded JSON keys at any depth,
and type-coerced numbers are rejected. Bootstrap grants are operator/fixture inputs,
not SIGIL-authorized operation grants; full grant validation and policy admission
remain required before product use. The current tests select separate provider-only
and filesystem-only bridges, not a combined application-wide grant.

Only explicitly named parent environment secrets are loaded. Secret names and values
are bounded, and empty/newline/NUL-bearing values are refused. Provider values enter
the privileged MCP grant request, not guest input; the pinned runtime performs secret
injection. Each child starts with an empty environment except `LANG=C.UTF-8`, so
ambient credentials, proxy configuration and the unverified-certificate override are
not inherited. Worker stderr is counted and discarded, not returned in observations.
This is not a general output-redaction guarantee: an authorized remote provider can
return arbitrary content, and malformed/malicious approved runtimes are not admitted
by these tests. Secret-safe release admission and product redaction still matter.

## Time, cancellation and resource bounds

Worker bootstrap version 2 negotiates the `single-request-v1` HTTP budget
contract before submitting source/input. The runtime must advertise the integer
`http_timeout_ms` field with bounds 1..60,000 and the matching
`x-sigil-http-budget` marker. Missing or incompatible support stops before forge;
the observation reports no effect request sent. Version 1 remains compatible
with the unchanged upstream pin. Grantless reusable `PureBridge` accepts only
version 1, so it cannot silently ignore version-2 effect semantics.

Version 2 sends the lesser of 60 seconds and the remaining preparation deadline
as its HTTP budget. The original supervisor deadline continues to include
queueing, negotiation, compilation and response reading. No per-request caller
can add grants or reset that deadline. The runtime patch uses one monotonic HTTP
deadline, rejects every redirect, checks the body-read deadline, and refuses a
late result. A native process is still killed and reaped after each attempt;
the runtime's detached thread watchdog alone is not a termination guarantee.
None of this cancels an already-delivered remote effect.

The development patch is retained in
[the manifest](../runtime-patches/http-budget-v1.json) and
[patch](../runtime-patches/http-budget-v1.patch), against the existing `SIGIL_REV`
trees. In a **disposable checkout** of that pin, run
`python scripts/apply_http_runtime_patch.py /absolute/checkout --mode apply`
from this project. The helper verifies base trees and before/after file hashes.
Build there with the same solver and Lean prerequisites as `ci.sh`:
`cargo build --locked --release -p sigil-mcp --features sigil-mcp/solver`.
The focused runtime check is
`cargo test --locked -p sigil-runtime http_redirect_tests -- --test-threads=1`.
Use `--mode verify` to check the patched source. These commands do not change
`SIGIL_REV`, publish binaries, or qualify a release. Select the resulting binary
and its hash explicitly in a version-2 provider worker; grantless functions and
file workers keep their version-1 configuration. A release still needs approved
artifact provenance and Linux candidate-bound verification.

- Per-preparation fuel is positive and at most the configured ceiling (bootstrap
  maximum 1 billion). Its monotonic deadline starts during preparation, includes
  the wait for a claim and runtime launch, and is at most 300 seconds.
- Initialization is further limited to five seconds within that same deadline.
  Nonblocking stdin/stdout/stderr and polls of at most 20 ms prevent partial frames,
  blocked writes or continuous stderr from bypassing the transport's timer checks.
- Input is at most 4 MiB; each encoded child request/response including LF is at
  most 16 MiB; aggregate worker stderr is at most 256 KiB. JSON escape expansion can
  make a size-valid input exceed the wire ceiling and be refused before forge send.
- Duplicate/invalid JSON, wrong response IDs, unexpected envelope fields and multiple
  frames in a single read retire the worker. Only the correlated result is returned;
  buffered trailing output cannot become a later operation's result because the
  process is never reused. Inner results are also parsed with duplicate-key rejection.
- Cancellation before execution consumes the pending ticket without launch. The Rust
  API also accepts a concurrent cancellation flag during execution. The serial stdio
  adapter currently exposes only pre-execution cancellation, not in-flight cancellation.
- A stopped worker's process group receives SIGKILL before the leader is reaped,
  avoiding signals to a reused PID. Each cleanup attempt polls for both leader
  reaping and inherited lifetime-endpoint closure for up to two seconds.
  If cleanup cannot be confirmed, the bridge refuses subsequent work;
  it does not claim the old worker stopped. Handles also check their owning process.

This is bounded process/pipe supervision under a responsive local OS, not a proof
that filesystem reads, process creation, parsing, uninterruptible kernel waits or
all cleanup paths finish within a universal hard wall-clock bound. OS-level CPU,
memory, descriptor and process limits and the supported deployment envelope remain
to be qualified. Killing a local process cannot undo an external side effect.

On Linux the child also requests a parent-death SIGKILL and rechecks parent identity
after installing it. Linux defines this against the creating **thread**, and it is
not automatically inherited by descendants. macOS has no equivalent mechanism in
this implementation. The ready flag reports which code was compiled, not successful
qualification of parent-death behavior. This local macOS run does not test the Linux
path or establish whole-tree fencing across controller crashes. See the primary
[Linux parent-death contract](https://man7.org/linux/man-pages/man2/PR_SET_PDEATHSIG.2const.html)
and [Rust child-process hooks](https://doc.rust-lang.org/std/os/unix/process/trait.CommandExt.html).

## Verification and remaining integration

The required pytest fixture builds this component from its lockfile and runs Rust
formatting, Clippy and native tests before the executable integration cases. Tests
cover ticket replay, pre-start and in-flight cancellation, deadlines with partial
handshakes/responses and blocked writes, stdout/stderr limits, protocol confusion,
runtime replacement and a clean child environment. Real solver-verified SIGIL cases
cover immutable source/input, one observed provider request before timeout, recovery
with a fresh worker, scoped provider-secret injection, and durable model/file/response
execution with native storage restarts. These are local component assertions, not
an independent security review or a Rust/SIGIL coverage percentage.

Process-fault unit fixtures run serially: their deliberate pipe floods and short
deadlines must not prevent a neighboring fixture from reaching its intended phase.
The concurrent cancellation test still signals an actively running worker from a
second thread. Production deadlines and fault assertions are unchanged; this test
isolation is not a substitute for the product's separate concurrent load qualification.

The [claim gate](claimed-worker.md) now enforces actual snapshot/receipt binding and
create-once execution at a retained claim coordinate. The newer
[SIGIL dispatch policy](dispatch-policy.md) consumes this bridge's actual held
source/runtime hashes, grants and secret names before the gate is prepared; secret
values and environment-variable names are excluded from that metadata. The
[native-bound completion path](worker-completion.md) now supplies this bridge's actual
observations to the fixed SIGIL producer and owns its exact result commit. Abandoned
claims recover conservatively without asserting old-worker termination. The new
[automatic v4 API service](automatic-service.md) embeds these mechanisms; older
component evidence remains scoped to its controlled fixtures. Still required: complete authenticated
immutable operation/authority/artifact/input/grant admission; compiled artifact/import
provenance and actual output routing; qualified Linux owner-death/cancellation;
application quota/expiry/revocation and API cancellation policy.
[All M0–M8 gates](mvp-goal.md) remain unqualified. AIN compatibility
and a real control-plane consumer need their separate reviews; this mechanism makes
no AIN backend or cross-project conformance claim.


### HTTP-budget revision 2 review correction (2026-10-28)

`runtime-patches/http-budget-v2.json` identifies a second development patch against
unchanged `SIGIL_REV`. It preserves the `single-request-v1` contract, validates the
same bounds, and retains the first patch/evidence unchanged. The runtime review
found that the first patch changed legacy `Interrupted` body reads into 502 errors.
Revision 2 retries that condition through the same deadline check; other errors
still fail closed. Sixteen runtime HTTP tests passed, including successful retry
with/without a budget, expiry under repeated interruption, actual I/O failure,
body size, slow response, dribbling response and refused redirects.

The rebuilt macOS solver-enabled development runtime has SHA-256
`d2dcca14c4c48e6bc0d6e272a453484c83fa1e5bdb2d7ff169e741482bd787fe`.
The patch SHA-256 is
`a71e412f7747f3fbbfaf347d057a684890d0a1b0e54f539cb6cfb76bf1c53a9b`.
Verify it in a disposable checkout with:

```sh
python3 scripts/apply_http_runtime_patch.py /path/to/disposable/SIGIL \
  --manifest runtime-patches/http-budget-v2.json --mode check
# Use --mode apply to apply it, then --mode verify to check the resulting bytes.
```

The legacy Python client now also requires exactly one forge tool, the exact
contract marker, and the integer type/minimum/maximum advertised by native v2.
Field presence alone no longer passes negotiation. All 61 runtime-client tests
passed with 100% line and branch coverage against the original verified pin.
An initial invocation accidentally selected the ambient solver-off runtime and
failed the solver guard; that invocation is retained separately. It is not a
passing test run or a reason to relax verification.

The external review is static review, not independent test execution or upstream
admission. The watchdog rejects a late result; the fresh supervised process is
what supplies termination. Reaping a process cannot undo a possibly delivered
remote effect. Failed cleanup can consume two two-second waits because `Drop`
retries `stop()`; the configured work deadline is not a strict total API latency
bound including failed cleanup. These limits remain explicit in qualification.

The runtime task's revision-2 fix review confirms both findings resolved and no
new findings in that scope. It checked patch/source/binary identities and inspected
the supplied results, without rebuilding or rerunning tests. The retained review
is `dist/mvp-evidence/2026-10-28/http-budget-r2/sigil-http-budget-v2-fix-review-20261028.json`.
Full package regression and owner admission remain separate.

Revision 4 is the latest locally checked patch: `runtime-patches/http-budget-v4.json`.
It also conforms the test helpers to the repository style gate and uses an
equivalent let-chain for the grant bounds check. The original limits and test
gates are unchanged. Formatting, strict lint for both affected packages, the
solver-enabled build, 1,499 runtime tests and 28 MCP tests pass; two existing
runtime regeneration cases remain ignored. Runtime SHA-256:
`992b754cdf4be2594d7f352644ff3c4842cde1c74b20ca36152e7d1bbcceda4b`. Evidence is retained in
`dist/mvp-evidence/2026-10-28/http-budget-r4/`. The earlier revision-2/3 style and
lint failures remain separate. Reproduce the helper commands above with
`--manifest runtime-patches/http-budget-v4.json`. This is not a full-workspace,
Linux, reproducible-build or upstream-admission claim.

The final read-only runtime review also checked revision 4: both earlier fixes
remain intact, the grant-condition rewrite is equivalent, supplied identities
and results match, and no new finding was identified in that diff. The reviewer
did not rerun tests. The record is retained as
`http-budget-r4/sigil-http-budget-v4-final-review-20261028.json` under the dated
evidence directory. Real-model captures still identify their actual revision-2
runtime and are not assigned to revision 4.
