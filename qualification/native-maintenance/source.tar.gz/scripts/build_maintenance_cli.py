"""Materialize a fresh local development deployment; do not start or migrate it.

Run with ``python -m scripts.build_maintenance_cli`` from the source checkout.
The resulting artifacts can be copied by stage_native_deployment. This command
does not qualify a release, verify a model installation, or create live state.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path

from scripts.build_maintenance_deployment import build
from scripts.stage_native_deployment import (
    HASH, RUNTIME_BYTES, DeploymentError, _absolute, _json, _physical_destination,
    _portable_disjoint, _read, worker_sites,
)


def materialize(args):
    workspace = _absolute(args.workspace).resolve(strict=True)
    stdlib = _absolute(args.stdlib_root).resolve(strict=True)
    if not workspace.is_dir() or not (stdlib / "stdlib").is_dir():
        raise DeploymentError("workspace and stdlib directories must already exist")
    output = _physical_destination(_absolute(args.output))
    authority = _physical_destination(_absolute(args.restore_authority))
    for path in (output, authority):
        if path.exists() or path.is_symlink():
            raise DeploymentError("deployment and restore authority must be fresh paths")
    if not all(_portable_disjoint(a, b) for a, b in (
        (output, authority), (output, workspace), (authority, workspace)
    )):
        raise DeploymentError("workspace, deployment and restore authority must be separate")
    profile = _json(_read(_absolute(args.profile), 65536))
    if (not isinstance(profile, dict)
            or profile.get("schema") != "sigil-pi/maintenance-development/v1"
            or profile.get("endpoint") != "http://127.0.0.1:11434/v1/messages"):
        raise DeploymentError("the explicit local maintenance development profile is required")
    selected = [("runtime", args.runtime, args.runtime_sha256),
                ("evaluator", args.evaluator, args.evaluator_sha256)]
    commands = profile.get("commands")
    if commands is not None:
        if not isinstance(commands, dict) or "docker" not in commands:
            raise DeploymentError("command profile requires its declared executable")
        selected.append(("command runtime", commands["docker"], args.command_runtime_sha256))
    elif args.command_runtime_sha256 is not None:
        raise DeploymentError("a command runtime pin requires an explicit command profile")
    pins = {}
    for name, selected_path, expected in selected:
        if not isinstance(expected, str) or not HASH.fullmatch(expected):
            raise DeploymentError("every selected executable requires an explicit lowercase SHA-256 pin")
        raw = _read(_absolute(selected_path), RUNTIME_BYTES, executable=True)
        if hashlib.sha256(raw).hexdigest() != expected:
            raise DeploymentError(name + " does not match its supplied SHA-256 pin")
        pins[str(Path(selected_path).resolve(strict=True))] = expected
    token = os.environ.get(args.token_env)
    if token is None or len(token) < 32:
        raise DeploymentError("the selected token environment variable needs at least 32 characters")
    # Exclusive creation occurs only after all CLI preflight checks. Build-time
    # composition may fail, leaving this new directory for inspection; no live
    # state or restore authority is initialized by either builder.
    output.mkdir(mode=0o700)
    config, path = build(output, workspace, args.runtime.resolve(strict=True),
        args.evaluator.resolve(strict=True), stdlib,
        token, profile, restore_authority=authority)
    for _, worker in worker_sites(config):
        if pins.get(worker["runtime"]) != worker["runtime_sha256"]:
            raise DeploymentError("composed worker runtime does not match the selected pins")
    if config["version"] != 13 or Path(config["state_root"]).exists() or authority.exists():
        raise DeploymentError("materialization unexpectedly created live state")
    return {"service": str(path), "profile": profile["schema"], "native_version": 13,
        "state_initialized": False, "restore_authority_initialized": False,
        "runtime_sha256": args.runtime_sha256, "evaluator_sha256": args.evaluator_sha256,
        "command_runtime_sha256": args.command_runtime_sha256,
        "product_qualified": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("workspace", "output", "runtime", "evaluator", "stdlib-root",
                 "profile", "restore-authority"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--runtime-sha256", required=True)
    parser.add_argument("--evaluator-sha256", required=True)
    parser.add_argument("--command-runtime-sha256",
        help="required when the explicit profile includes container build/test commands")
    parser.add_argument("--token-env", required=True)
    args = parser.parse_args(argv)
    try:
        result = materialize(args)
    except (OSError, ValueError) as error:
        parser.exit(1, f"maintenance materialization refused: {error}\n")
    except (KeyError, TypeError):
        parser.exit(1, "maintenance materialization refused: incomplete or inconsistent profile\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
