use super::*;
use std::os::unix::fs::symlink;

fn mounted(path: &Path) -> Value {
    json!({"Mounts":[{"Destination":"/input", "Type":"bind", "RW":false, "Source":path}]})
}

fn snapshot() -> tempfile::TempDir {
    let source = tempfile::tempdir().unwrap();
    std::fs::create_dir(source.path().join("nested")).unwrap();
    let file = source.path().join("nested/canary");
    std::fs::write(&file, b"synthetic-private-data").unwrap();
    std::fs::set_permissions(&file, std::fs::Permissions::from_mode(0o600)).unwrap();
    snapshot_workspace(
        source.path(),
        Instant::now() + Duration::from_secs(5),
        &AtomicBool::new(false),
    )
    .unwrap()
    .0
}

#[test]
fn private_ancestor_exists_before_retention_and_protects_readable_input() {
    let snapshot = snapshot();
    assert_eq!(snapshot.path().metadata().unwrap().mode() & 0o777, 0o700);
    let input = snapshot.path().join("input");
    assert_eq!(input.metadata().unwrap().mode() & 0o777, 0o755);
    assert_eq!(
        std::fs::read(input.join("nested/canary")).unwrap(),
        b"synthetic-private-data"
    );
    let retained = snapshot.keep();
    assert_eq!(retained.metadata().unwrap().mode() & 0o777, 0o700);
    reclaim_snapshot(&mounted(&input)).unwrap();
    assert!(!retained.exists());
    reclaim_snapshot(&mounted(&input)).unwrap();
}

#[test]
fn reclaim_legacy_stopped_attempt_keeps_the_original_narrow_shape() {
    let old = tempfile::Builder::new()
        .prefix("sigil-command-")
        .tempdir_in(snapshot_temporary_root())
        .unwrap();
    std::fs::set_permissions(old.path(), std::fs::Permissions::from_mode(0o755)).unwrap();
    std::fs::write(old.path().join("canary"), b"legacy").unwrap();
    let old = old.keep();
    reclaim_snapshot(&mounted(&old)).unwrap();
    assert!(!old.exists());
}

#[test]
fn reclaim_refuses_public_parent_and_unexpected_child() {
    let snapshot = snapshot();
    let input = snapshot.path().join("input");
    std::fs::set_permissions(snapshot.path(), std::fs::Permissions::from_mode(0o755)).unwrap();
    assert_eq!(reclaim_snapshot(&mounted(&input)), Err(Fault::Invalid));
    std::fs::set_permissions(snapshot.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
    assert_eq!(
        reclaim_snapshot(&mounted(&snapshot.path().join("other"))),
        Err(Fault::Invalid)
    );
    assert!(input.join("nested/canary").is_file());
}

#[test]
fn reclaim_refuses_symlink_parent_and_child_without_touching_target() {
    let snapshot = snapshot();
    let input = snapshot.path().join("input");
    let outside = tempfile::tempdir().unwrap();
    std::fs::write(outside.path().join("canary"), b"untouched").unwrap();
    std::fs::remove_dir_all(&input).unwrap();
    symlink(outside.path(), &input).unwrap();
    assert_eq!(reclaim_snapshot(&mounted(&input)), Err(Fault::Invalid));
    std::fs::remove_file(&input).unwrap();
    std::fs::remove_dir(snapshot.path()).unwrap();
    symlink(outside.path(), snapshot.path()).unwrap();
    assert_eq!(reclaim_snapshot(&mounted(&input)), Err(Fault::Invalid));
    assert_eq!(
        std::fs::read(outside.path().join("canary")).unwrap(),
        b"untouched"
    );
}

#[test]
fn reclaim_refuses_other_roots_nested_paths_and_mount_modes() {
    let snapshot = snapshot();
    let input = snapshot.path().join("input");
    let outside = tempfile::tempdir().unwrap();
    for path in [outside.path().to_path_buf(), input.join("input")] {
        assert_eq!(reclaim_snapshot(&mounted(&path)), Err(Fault::Invalid));
    }
    for (key, value) in [("RW", json!(true)), ("Type", json!("volume"))] {
        let mut actual = mounted(&input);
        actual["Mounts"][0][key] = value;
        assert_eq!(reclaim_snapshot(&actual), Err(Fault::Invalid));
    }
    assert!(input.join("nested/canary").is_file());
    assert!(outside.path().is_dir());
}
