"""Real offline container boundary; opt in with PI_CONTAINER_TESTS=1."""

import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

import pytest

ROOT = Path(__file__).resolve().parent.parent
PROFILE = json.loads((ROOT / "config/build-test-development.json").read_text())
pytestmark = pytest.mark.skipif(
    os.environ.get("PI_CONTAINER_TESTS") != "1", reason="requires local Docker engine"
)


def configure(root, workspace, argv, *, wall_ms=3000, output_bytes=4096):
    root.mkdir(parents=True, exist_ok=True)
    commands = PROFILE["commands"]
    desc = {
        "schema": "sigil-container-command/v1",
        "socket": commands["socket"],
        "image": commands["image"],
        "workspace": str(workspace),
        "argv": argv,
        "slot": "sigil-pi-test-" + hashlib.sha256(str(root).encode()).hexdigest()[:24],
        "wall_ms": wall_ms,
        "memory_bytes": 134217728,
        "pids": 32,
        "output_bytes": output_bytes,
    }
    source = root / "command.json"
    source.write_text(json.dumps(desc))
    runtime = Path(commands["docker"])
    config = {
        "version": 4,
        "runtime": str(runtime),
        "runtime_sha256": hashlib.sha256(runtime.read_bytes()).hexdigest(),
        "source": str(source),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "max_fuel": 1000,
        "max_timeout_ms": 15000,
        "net": [],
        "fs": [str(workspace)],
        "secret_env": {},
    }
    path = root / "worker.json"
    path.write_text(json.dumps(config))
    return path, desc


class Worker:
    def __init__(self, path, env=None):
        self.proc = subprocess.Popen(
            [os.environ.get("PI_CONTAINER_WORKER", str(ROOT / "native/worker/target/release/sigil-worker")), str(path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )
        assert self.read()["status"] == "ready"

    def read(self, timeout=25):
        ready, _, _ = select.select([self.proc.stdout], [], [], timeout)
        assert ready, "worker timeout"
        line = self.proc.stdout.readline()
        assert line, self.proc.stderr.read()
        return json.loads(line)

    def send(self, value):
        self.proc.stdin.write(json.dumps(value) + "\n")
        self.proc.stdin.flush()

    def start(self, payload="CW1\n", timeout_ms=15000):
        self.send(
            {"op": "prepare", "input": payload, "fuel": 1000, "timeout_ms": timeout_ms}
        )
        prepared = self.read()["prepared"]
        self.send({"op": "execute", "ticket": prepared["ticket"]})
        return prepared

    def close(self):
        self.proc.stdin.close()
        self.proc.wait(timeout=10)


def fields(raw, tag, count):
    raw = raw.encode()
    assert raw.startswith(tag.encode())
    at, result = 4, []
    for _ in range(count):
        n = int(raw[at : at + 8])
        at += 8
        result.append(raw[at : at + n].decode())
        at += n
    assert at == len(raw)
    return result


def execute(tmp_path, argv, *, text="hello", env=None, payload="CW1\n", **kwargs):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "input.txt").write_text(text)
    (workspace / ".env").write_text("SIGIL_TEST_SECRET=workspace-hidden-canary\n")
    path, desc = configure(tmp_path / "deployment", workspace, argv, **kwargs)
    worker = Worker(path, env)
    try:
        worker.start(payload)
        observed = worker.read()["observation"]
    finally:
        worker.close()
    return observed, workspace, desc


def result(observed):
    assert observed["fault"] is None, observed
    assert observed["worker_reaped"] and observed["request_may_have_run"]
    raw = fields(observed["result"]["data"]["output_text"], "RF1\n", 2)
    assert raw[0] == "ok"
    return fields(raw[1], "CR1\n", 5)


def test_real_exit_output_and_snapshot_write_isolation(tmp_path):
    o, workspace, _ = execute(
        tmp_path,
        [
            "/bin/sh",
            "-c",
            "cat input.txt; echo changed > input.txt; echo diagnostic >&2; exit 7",
        ],
    )
    code, stdout, stderr, snapshot, image = result(o)
    assert code == "7" and stdout == "hello" and stderr == "diagnostic\n"
    assert len(snapshot) == 64 and image == PROFILE["commands"]["image"]
    assert (workspace / "input.txt").read_text() == "hello"


def inspect_container(desc):
    command = [PROFILE["commands"]["docker"], "--host", "unix://" + desc["socket"]]
    found = subprocess.run(command + ["inspect", desc["slot"]], capture_output=True, text=True)
    return json.loads(found.stdout)[0] if found.returncode == 0 else None


def assert_snapshot_private(desc, state):
    mounted = Path(next(m["Source"] for m in state["Mounts"] if m["Destination"] == "/input"))
    # Observe the actual host ancestor and copied-file modes. Docker Desktop
    # synthesizes bind-mount ownership as the caller, so it cannot stand in for
    # a second macOS account. Recreate those observed modes on a native Linux
    # tmpfs, then drop UID/GID and exercise both denial and a readable control.
    private = mounted.parent if mounted.name == "input" else mounted
    relative = "input/nested/canary.txt" if mounted.name == "input" else "nested/canary.txt"
    modes = (private.stat().st_mode & 0o777, mounted.stat().st_mode & 0o777,
             (mounted / 'nested').stat().st_mode & 0o777,
             (mounted / 'nested/canary.txt').stat().st_mode & 0o777)
    script = """import os
from pathlib import Path
root=Path('/proof/snapshot'); root.mkdir(); root.chmod(%d)
mounted=root / ('input' if %r else '')
if mounted != root: mounted.mkdir(); mounted.chmod(%d)
(mounted/'nested').mkdir(); (mounted/'nested').chmod(%d)
(mounted/'nested/canary.txt').write_text('synthetic-private-canary')
(mounted/'nested/canary.txt').chmod(%d)
Path('/proof/control').write_text('readable-control'); Path('/proof/control').chmod(0o644)
os.setgroups([]); os.setgid(65534); os.setuid(65534)
assert os.getuid() == 65534 and root.stat().st_uid != os.getuid()
assert Path('/proof/control').read_text() == 'readable-control'
for action in (lambda: os.listdir('/snapshot'), lambda: open('/snapshot/' + %r).read()):
    try: action()
    except PermissionError: pass
    else: raise AssertionError('another UID can read a private workspace snapshot')
print('private snapshot denied to unrelated UID')
""" % (modes[0], mounted.name == 'input', modes[1], modes[2], modes[3], relative)
    script = script.replace("'/snapshot", "'/proof/snapshot")
    probe = subprocess.run(
        [PROFILE["commands"]["docker"], "--host", "unix://" + desc["socket"],
         "run", "--rm", "--pull=never", "--network=none", "--read-only",
         "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
         "--security-opt=no-new-privileges", "--user=0:0",
         "--tmpfs=/proof:rw,noexec,nosuid,nodev,size=1048576,mode=1777",
         "--entrypoint=/usr/bin/python3", desc["image"], "-c", script],
        capture_output=True, text=True, timeout=20,
    )
    assert probe.returncode == 0, probe.stdout + probe.stderr
    assert private.stat().st_mode & 0o777 == 0o700
    assert mounted.name == "input" and mounted.is_dir()
    return private


def test_private_snapshot_blocks_other_uid_while_approved_command_reads(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir(mode=0o700)
    (workspace / "nested").mkdir(mode=0o700)
    canary = workspace / "nested/canary.txt"
    canary.write_text("synthetic-private-canary")
    canary.chmod(0o600)
    path, desc = configure(
        tmp_path / "deployment", workspace,
        ["/usr/bin/python3", "-c", "import time; print(open('nested/canary.txt').read(),flush=True); time.sleep(6)"],
        wall_ms=10000,
    )
    worker = Worker(path)
    try:
        worker.start()
        until = time.monotonic() + 10
        while time.monotonic() < until:
            state = inspect_container(desc)
            if state and state["State"]["Running"]:
                break
            time.sleep(.05)
        else:
            raise AssertionError("container did not start")
        private = assert_snapshot_private(desc, state)
        assert result(worker.read()["observation"])[0:2] == ["0", "synthetic-private-canary\n"]
        assert not private.exists()
    finally:
        worker.close()


def test_unconfirmed_cleanup_retains_private_parent_until_confirmed_reclaim(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir(mode=0o700)
    (workspace / "nested").mkdir(mode=0o700)
    canary = workspace / "nested/canary.txt"
    canary.write_text("synthetic-private-canary")
    canary.chmod(0o600)
    path, desc = configure(tmp_path / "deployment", workspace, ["/bin/cat", "nested/canary.txt"])
    original = json.loads(path.read_text())
    wrapper = tmp_path / "docker-cleanup-fault"
    docker = PROFILE["commands"]["docker"]
    wrapper.write_text(
        f"#!{sys.executable}\nimport os,sys\n"
        "if 'rm' in sys.argv and '--force' in sys.argv: sys.exit(1)\n"
        f"os.execv({docker!r}, [{docker!r}, *sys.argv[1:]])\n"
    )
    wrapper.chmod(0o700)
    changed = {**original, "runtime": str(wrapper),
               "runtime_sha256": hashlib.sha256(wrapper.read_bytes()).hexdigest()}
    path.write_text(json.dumps(changed))
    worker = Worker(path)
    try:
        worker.start()
        observed = worker.read()["observation"]
        assert observed["fault"] == "cleanup_unconfirmed", observed
        assert observed["request_may_have_run"] and not observed["worker_reaped"]
        assert observed["result"] is None
        state = inspect_container(desc)
        assert state and not state["State"]["Running"]
        private = assert_snapshot_private(desc, state)
    finally:
        worker.close()
        path.write_text(json.dumps(original))
    reopened = Worker(path)
    try:
        reopened.start()
        assert result(reopened.read()["observation"])[0:2] == ["0", "synthetic-private-canary"]
    finally:
        reopened.close()
    assert not private.exists()
    assert not containers(desc)


def test_no_network_host_paths_environment_or_privileges(tmp_path):
    secret = tmp_path / "outside-secret"
    secret.write_text("host-only-canary")
    program = """import os,socket
assert os.getuid() == 65534
assert 'SIGIL_TEST_SECRET' not in os.environ
assert not os.path.exists(%r)
assert not os.path.exists('/var/run/docker.sock')
assert not os.path.exists('/input/.env')
try: open('/input/input.txt','w')
except OSError: pass
else: raise AssertionError('writable input')
try: open('/etc/escape','w')
except OSError: pass
else: raise AssertionError('writable root')
s=socket.socket(); s.settimeout(.5)
assert s.connect_ex(('1.1.1.1',80)) != 0
try: os.kill(1,19)
except PermissionError: pass
else: raise AssertionError('untrusted process stopped deadline supervisor')
print('boundaries passed')
""" % str(secret)
    o, _, _ = execute(
        tmp_path,
        ["/usr/bin/python3", "-c", program],
        env={**os.environ, "SIGIL_TEST_SECRET": "must-not-leak"},
    )
    assert result(o)[0:2] == ["0", "boundaries passed\n"]


@pytest.mark.parametrize("kind", ["symlink", "hardlink", "fifo", "oversized"])
def test_snapshot_denies_unsafe_inputs(tmp_path, kind):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    outside = tmp_path / "outside"
    outside.write_text("secret")
    target = workspace / "bad"
    if kind == "symlink":
        target.symlink_to(outside)
    elif kind == "hardlink":
        os.link(outside, target)
    elif kind == "fifo":
        os.mkfifo(target)
    else:
        target.write_bytes(b"x" * (1024 * 1024 + 1))
    path, _ = configure(tmp_path / "deployment", workspace, ["/bin/true"])
    w = Worker(path)
    try:
        w.start()
        o = w.read()["observation"]
    finally:
        w.close()
    assert o["fault"] in ["invalid", "limit"]
    assert not o["request_may_have_run"] and o["worker_reaped"]


def test_caller_cannot_replace_fixed_command(tmp_path):
    o, _, _ = execute(tmp_path, ["/bin/true"], payload='{"command":"/bin/sh"}')
    assert o["fault"] == "invalid" and not o["request_may_have_run"]


def test_output_limit_removes_container(tmp_path):
    o, _, desc = execute(
        tmp_path, ["/usr/bin/python3", "-c", "while True: print('x'*4096,flush=True)"]
    )
    assert o["fault"] == "limit" and o["worker_reaped"]
    assert not containers(desc)


def test_actual_memory_pid_and_scratch_ceilings(tmp_path):
    program = """import errno,os,time
assert open('/sys/fs/cgroup/memory.max').read().strip() == '134217728'
assert open('/sys/fs/cgroup/pids.max').read().strip() == '32'
assert open('/sys/fs/cgroup/cpu.max').read().split() == ['100000','100000']
assert os.statvfs('/work').f_blocks * os.statvfs('/work').f_frsize == 67108864
assert os.statvfs('/tmp').f_blocks * os.statvfs('/tmp').f_frsize == 16777216
with open('/work/full','wb',buffering=0) as f:
    try:
        for _ in range(70): f.write(b'x'*1048576)
    except OSError as e: assert e.errno == errno.ENOSPC
    else: raise AssertionError('scratch space unbounded')
os.unlink('/work/full')
children=[]
try:
    for _ in range(40):
        p=os.fork()
        if p == 0: time.sleep(10); os._exit(0)
        children.append(p)
except OSError as e: assert e.errno == errno.EAGAIN
else: raise AssertionError('process count unbounded')
print('resource ceilings enforced',flush=True)
"""
    o, _, _ = execute(tmp_path, ["/usr/bin/python3", "-c", program])
    assert result(o)[0:2] == ["0", "resource ceilings enforced\n"]


def test_memory_exhaustion_is_failure_not_success(tmp_path):
    o, _, _ = execute(
        tmp_path,
        ["/usr/bin/python3", "-c", "x=bytearray(300*1024*1024); print('unbounded')"],
    )
    values = result(o)
    assert values[0] != "0" and "unbounded" not in values[1]


def test_invalid_output_is_not_silently_rewritten(tmp_path):
    o, _, _ = execute(
        tmp_path, ["/usr/bin/python3", "-c", "import os; os.write(1,b'\\xff')"]
    )
    assert o["fault"] == "protocol" and o["worker_reaped"]


def containers(desc):
    return subprocess.check_output(
        [
            PROFILE["commands"]["docker"],
            "--host",
            "unix://" + desc["socket"],
            "ps",
            "-a",
            "--filter",
            "name=^/" + desc["slot"] + "$",
            "--format",
            "{{.ID}}",
        ],
        text=True,
    ).strip()


def test_independent_deadline_includes_detached_descendants(tmp_path):
    script = (
        "import os,time; p=os.fork(); os.setsid() if p==0 else None; time.sleep(60)"
    )
    start = time.monotonic()
    o, _, desc = execute(tmp_path, ["/usr/bin/python3", "-c", script], wall_ms=500)
    assert result(o)[0] == "124"
    assert time.monotonic() - start < 8
    assert not containers(desc)


def test_parent_death_still_enforces_deadline_and_slot_can_recover(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir(mode=0o700)
    (workspace / "nested").mkdir(mode=0o700)
    canary = workspace / "nested/canary.txt"
    canary.write_text("synthetic-private-canary")
    canary.chmod(0o600)
    path, desc = configure(
        tmp_path / "deployment",
        workspace,
        [
            "/usr/bin/python3",
            "-c",
            "import os,time; os.fork(); os.setsid(); time.sleep(60)",
        ],
        wall_ms=1500,
    )
    w = Worker(path)
    w.start()
    docker = PROFILE["commands"]["docker"]
    until = time.monotonic() + 10
    while time.monotonic() < until:
        p = subprocess.run(
            [
                docker,
                "--host",
                "unix://" + desc["socket"],
                "inspect",
                "--format",
                "{{.State.Running}}",
                desc["slot"],
            ],
            capture_output=True,
            text=True,
        )
        if p.returncode == 0 and p.stdout.strip() == "true":
            break
        time.sleep(0.05)
    else:
        raise AssertionError("container did not start")
    w.proc.kill()
    w.proc.wait(timeout=5)
    time.sleep(2)
    state = json.loads(
        subprocess.check_output(
            [docker, "--host", "unix://" + desc["socket"], "inspect", desc["slot"]]
        )
    )[0]
    assert state["State"]["Running"] is False and state["State"]["ExitCode"] == 124
    old_snapshot = Path(
        next(m["Source"] for m in state["Mounts"] if m["Destination"] == "/input")
    )
    assert old_snapshot.is_dir()
    old_private = assert_snapshot_private(desc, state)
    reopened = Worker(path)
    try:
        reopened.start()
        assert result(reopened.read()["observation"])[0] == "124"
    finally:
        reopened.close()
    assert not containers(desc)
    assert not old_snapshot.exists()
    assert not old_private.exists()
