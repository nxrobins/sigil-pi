"""Line-framed stderr observations without mixing select with text buffering."""
import json
import queue
import threading

_END = object()


class EventStream:
    def __init__(self, stream):
        self.queue = queue.Queue(maxsize=1024)
        self.error = None
        self.observed = []
        self.thread = threading.Thread(target=self._read, args=(stream,), daemon=True)
        self.thread.start()

    def _read(self, stream):
        try:
            while True:
                line = stream.readline(65537)
                if len(line) > 65536 or (line and not line.endswith("\n")):
                    raise ValueError("unbounded or incomplete event line")
                self.queue.put_nowait(line if line else _END)
                if not line: return
        except (OSError, ValueError, queue.Full) as error:
            self.error = error

    def read(self, timeout=0):
        assert self.error is None, self.error
        try:
            line = self.queue.get(timeout=timeout)
        except queue.Empty:
            return None
        assert line is not _END, "service owner exited"
        event = json.loads(line)
        self.observed.append(event)
        return event


def event_stream(api):
    if not hasattr(api, "maintenance_events"):
        api.maintenance_events = EventStream(api.proc.stderr)
    return api.maintenance_events
