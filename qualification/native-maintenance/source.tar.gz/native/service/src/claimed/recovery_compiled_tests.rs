//! Real compiled SIGIL + native ownership + authenticated publication.
//! The effect worker is admitted but never invoked; no model/network is used.
use super::*;
use crate::claimed::{CompletionBudget, CompletionIdentity, RecorderConfig};
use sigil_durable_store::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use sigil_durable_store::store::reservation::{Credits, Request};
use sigil_durable_store::store::{Batch, Mutation};
use sigil_worker_bridge::Config as WorkerConfig;
use std::os::unix::fs::PermissionsExt;
use std::time::{Duration, Instant};

#[derive(serde::Deserialize)]
struct Programs {
    completion: WorkerConfig,
    audit: WorkerConfig,
    credential: String,
    report: std::path::PathBuf,
    #[serde(default)]
    retirement: bool,
    #[serde(default)]
    anchored: bool,
    #[serde(default)]
    failure: bool,
    #[serde(default)]
    refusal: bool,
}
fn limits(retirement: bool) -> ChainLimits {
    ChainLimits {
        payload_bytes: 16384,
        records: if retirement { 3 } else { 2 },
        bytes: 500_000,
    }
}
fn attach(programs: &Programs, worker: &Bridge, store: &Store, retiring: bool) -> Recorder {
    let mut domain = grant_map();
    if retiring {
        domain.insert("claim".into(), Access::Read);
        domain.insert("delivery".into(), Access::Read);
    }
    let config = RecorderConfig {
        worker: programs.completion.clone(),
        delivery_namespace: "delivery".into(),
    };
    let audit = crate::effect_audit::Admitted::new(
        crate::audited_transaction::Config {
            version: 1,
            worker: programs.audit.clone(),
            evaluation: None,
            key_env: "SIGIL_COMPILED_RECOVERY_AUDIT_KEY".into(),
            chain: "a".repeat(64),
            heads: "audit.heads".into(),
            records: "audit.entries".into(),
            limits: limits(programs.retirement),
        },
        &config,
        worker,
        &domain,
        &programs.credential,
    )
    .unwrap()
    .open(store)
    .unwrap();
    let mut recorder = Recorder::new(config).unwrap();
    recorder.attach_audit(audit);
    recorder
}
fn hex(value: [u8; 32]) -> String {
    value.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn open_profile(
    root: &Path,
    programs: &Programs,
    mode: OpenMode,
) -> sigil_durable_store::store::Result<Store> {
    let allocation = Allocation {
        version: 1,
        pools: vec![Pool {
            id: "tenant".into(),
            namespaces: [
                "intent",
                "claim",
                "delivery",
                "funds",
                "audit.heads",
                "audit.entries",
                "api",
            ]
            .into_iter()
            .map(String::from)
            .collect(),
            records: if programs.anchored { 21 } else { 13 },
            live_bytes: 4_000_000,
        }],
    };
    let slots = BTreeMap::from([("tenant".into(), 8)]);
    if programs.anchored {
        let authority = root.with_file_name("authority");
        if matches!(mode, OpenMode::CreateNew) {
            std::fs::create_dir(&authority).unwrap();
            std::fs::set_permissions(&authority, std::fs::Permissions::from_mode(0o700)).unwrap();
        }
        Store::open_anchored_reserved_bound(
            root,
            &authority.canonicalize().unwrap(),
            mode,
            Limits::default(),
            allocation,
            [3; 32],
            slots,
        )
    } else {
        Store::open_fenced_reserved_bound(root, mode, Limits::default(), allocation, [3; 32], slots)
    }
}

#[test]
#[ignore = "invoked by pytest with pinned actual SIGIL runtime and composed sources"]
fn pending_recovery_compiled_sigil_signs_actual_exclusion_at_full_pool() {
    let _serial = process_guard();
    let fixture = std::env::var("SIGIL_COMPILED_RECOVERY_FIXTURE").unwrap();
    let programs: Programs = serde_json::from_slice(&std::fs::read(fixture).unwrap()).unwrap();
    assert!(!programs.anchored || (programs.retirement && !programs.failure && !programs.refusal));
    let key_bytes = std::env::var("SIGIL_COMPILED_RECOVERY_AUDIT_KEY")
        .unwrap()
        .into_bytes();
    let directory = tempfile::tempdir().unwrap();
    let root = directory.path().join("store");
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let mut store = open_profile(&root, &programs, OpenMode::CreateNew).unwrap();
    let owner_scope = owner(&store);
    let operation_key = format!("{}:1", "b".repeat(64));
    store
        .commit(
            &owner_scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "intent".into(),
                    key: operation_key.clone(),
                    revision: 0,
                    value: Some("opaque intent".into()),
                }],
            },
        )
        .unwrap();
    let scope = store.scope(grant_map()).unwrap();
    let binding = crate::claimed::Binding {
        intent_namespace: "intent".into(),
        claim_namespace: "claim".into(),
        key: operation_key.clone(),
    };
    // A real admission with no effect invocation. Reuse the actual pinned runtime
    // and source metadata, but this test never calls its execution path.
    let mut worker = Bridge::new_fenced(
        programs.completion.clone(),
        store.execution_lease().unwrap(),
    )
    .unwrap();
    let mut recorder = attach(&programs, &worker, &store, false);
    let identity = CompletionIdentity::observe(&store, &scope, &binding, "delivery").unwrap();
    let origin = if programs.anchored {
        [0x91; 32]
    } else {
        identity.reservation_binding()
    };
    let log = AuthenticatedLog::new(
        &store,
        "audit.heads",
        "audit.entries",
        limits(programs.retirement),
        &key_bytes,
    )
    .unwrap();
    let count = if programs.retirement { 3 } else { 2 };
    let allowance = log
        .prepare_allowance(
            &store,
            &owner_scope,
            &"a".repeat(64),
            0,
            count,
            count * log.encoded_entry_ceiling(),
        )
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &owner_scope,
            &Batch {
                checks: vec![],
                writes: vec![Mutation {
                    namespace: "funds".into(),
                    key: "anchor".into(),
                    revision: 0,
                    value: Some("admitted budget".into()),
                }],
            },
            &Request {
                namespace: "funds".into(),
                key: operation_key.clone(),
                binding: origin,
                credits: Credits {
                    records: 10,
                    live_bytes: if programs.retirement {
                        700_000
                    } else {
                        500_000
                    },
                },
            },
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let budget = CompletionBudget {
        claim: Credits {
            records: 3,
            live_bytes: 200_000,
        },
        result: Credits {
            records: 2,
            live_bytes: 200_000,
        },
    };
    let slot_generation = held.generation().cloned();
    assert_eq!(slot_generation.is_some(), programs.anchored);
    let funding = if programs.anchored {
        identity.fund_from_parent(
            &store,
            held,
            budget,
            Credits {
                records: 1,
                live_bytes: 200_000,
            },
        )
    } else if programs.retirement {
        identity.fund_with_retirement(
            &store,
            held,
            budget,
            Credits {
                records: 1,
                live_bytes: 200_000,
            },
        )
    } else {
        identity.fund(&store, held, budget)
    }
    .unwrap();
    let overflow = Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "api".into(),
            key: "unrelated".into(),
            revision: 0,
            value: Some("full".into()),
        }],
    };
    assert!(store.commit(&owner_scope, &overflow).is_err());
    let (domain, prior_epoch) = store
        .execution_identity()
        .map(|(d, e)| (d.to_owned(), e.to_owned()))
        .unwrap();
    let mut clock = 0;
    let mut attempt = Attempt::begin(
        &mut store,
        &scope,
        &mut worker,
        &mut clock,
        binding,
        crate::claimed::Execution {
            input: "never executed".into(),
            fuel: 1000,
            timeout_ms: 30000,
            time_guard: frame("TG1\n", &["0", "9007199254740991"]).unwrap(),
        },
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    attempt.claim_recorded(&mut recorder).unwrap();
    let generation = attempt.prepared().generation.clone();
    if programs.refusal {
        assert!(programs.retirement);
        let assigned = attempt
            .store
            .reservation_snapshot(&owner_scope, "funds", &operation_key)
            .unwrap();
        let before_claim = attempt
            .store
            .get(&owner_scope, "claim", &operation_key)
            .unwrap();
        if programs.failure {
            let connection = rusqlite::Connection::open_with_flags(
                root.join("records.sqlite"),
                rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE,
            )
            .unwrap();
            connection.execute_batch("CREATE TRIGGER refuse_unsent BEFORE INSERT ON records WHEN NEW.namespace='audit.entries' BEGIN SELECT RAISE(ABORT,'injected refusal publication failure'); END;").unwrap();
        }
        // Deterministic authority expiry after the actual compiled signed claim.
        // The native gate supplies Err; no result or observation is invented.
        attempt.guard = ExecutionGuard::parse(&frame("TG1\n", &["0", "1"]).unwrap()).unwrap();
        let ticket = attempt.prepared().ticket.clone();
        let refusal = attempt
            .execute(&ticket, &std::sync::atomic::AtomicBool::new(false))
            .err()
            .unwrap();
        assert_eq!(refusal, "time_guard");
        assert!(attempt.take_returned_credit().is_none());
        let publication = attempt.persist_observation(&mut recorder, None, Some(refusal));
        let returned = if programs.failure {
            assert!(matches!(publication, Err("storage")));
            assert!(attempt.take_returned_credit().is_none());
            assert!(matches!(
                attempt.store.get(&owner_scope, "claim", &operation_key),
                Err(sigil_durable_store::store::Error::ReopenRequired)
            ));
            None
        } else {
            assert_eq!(publication.unwrap().0, "3");
            let credit = attempt
                .take_returned_credit()
                .expect("compiled signed refusal returns original credit");
            assert!(attempt.take_returned_credit().is_none());
            attempt
                .store
                .check_reservation_binding(&credit, origin)
                .unwrap();
            assert_eq!(
                credit.credits(),
                Credits {
                    records: 5,
                    live_bytes: 300000
                }
            );
            Some(credit.credits())
        };
        drop(attempt);
        drop(recorder);
        drop(log);
        drop(worker);
        drop(store);
        if programs.failure {
            // Remove only the injected fault before the normal strict schema
            // check on reopen; an unknown retained trigger correctly refuses.
            let connection = rusqlite::Connection::open_with_flags(
                root.join("records.sqlite"),
                rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE,
            )
            .unwrap();
            connection
                .execute_batch("DROP TRIGGER refuse_unsent;")
                .unwrap();
        }
        let mut store = open_profile(&root, &programs, OpenMode::Existing).unwrap();
        let owner_scope = owner(&store);
        let retained = store
            .reservation_snapshot(&owner_scope, "funds", &operation_key)
            .unwrap();
        let claim = store.get(&owner_scope, "claim", &operation_key).unwrap();
        let delivery = store.get(&owner_scope, "delivery", &operation_key).unwrap();
        let count = if programs.failure {
            assert_eq!(retained.revision, assigned.revision);
            assert_eq!(retained.binding, assigned.binding);
            assert_eq!(retained.assignment, assigned.assignment);
            assert_eq!(retained.credits, assigned.credits);
            assert_eq!(claim, before_claim);
            assert_eq!(delivery.revision, 0);
            assert!(
                store
                    .resume_reservation(&owner_scope, "funds", &operation_key, 3, origin)
                    .is_err()
            );
            1
        } else {
            assert_eq!(retained.revision, 3);
            assert_eq!(retained.binding, origin);
            assert!(retained.assignment.is_empty());
            assert_eq!(retained.credits, returned.unwrap());
            assert_eq!(claim.revision, 2);
            assert_eq!(delivery.revision, 1);
            assert_eq!(
                fields(claim.value.as_deref().unwrap(), "SD1\n", 5).unwrap()[4],
                "3"
            );
            let resumed = store
                .resume_reservation(&owner_scope, "funds", &operation_key, 3, origin)
                .unwrap();
            store.check_reservation_binding(&resumed, origin).unwrap();
            assert!(
                store
                    .resume_reservation(
                        &owner_scope,
                        "funds",
                        &operation_key,
                        assigned.revision,
                        assigned.binding
                    )
                    .is_err()
            );
            let worker = Bridge::new_fenced(
                programs.completion.clone(),
                store.execution_lease().unwrap(),
            )
            .unwrap();
            let mut recorder = attach(&programs, &worker, &store, false);
            assert!(
                recorder
                    .recover_funded_pending(&mut store, &owner_scope, "funds", &operation_key)
                    .is_err()
            );
            assert!(
                recorder
                    .retire_funded_terminal(&mut store, &owner_scope, "funds", &operation_key)
                    .is_err()
            );
            2
        };
        let log = AuthenticatedLog::new(
            &store,
            "audit.heads",
            "audit.entries",
            limits(true),
            &key_bytes,
        )
        .unwrap();
        assert_eq!(
            log.verify(
                &mut store,
                &owner_scope,
                &"a".repeat(64),
                None,
                Instant::now() + Duration::from_secs(1)
            )
            .unwrap()
            .count,
            count
        );
        let entries: Vec<String> = (0..count)
            .map(|sequence| {
                store
                    .get(
                        &owner_scope,
                        "audit.entries",
                        &format!("{}.{sequence:016x}", "a".repeat(64)),
                    )
                    .unwrap()
                    .value
                    .unwrap()
            })
            .collect();
        std::fs::write(&programs.report, serde_json::to_vec_pretty(&serde_json::json!({
            "entries":entries, "refusal":refusal, "failed_publication":programs.failure,
            "returned_records":returned.map_or(0, |v| v.records),
            "returned_bytes":returned.map_or(0, |v| v.live_bytes),
            "reservation_revision":retained.revision, "assignment_cleared":retained.assignment.is_empty(),
            "claim_revision":claim.revision, "delivery_revision":delivery.revision,
            "qualification":false, "scope":"actual compiled refusal publication and native restart; no effect invocation"
        })).unwrap()).unwrap();
        return;
    }
    if programs.retirement {
        // Private mechanism fixture: no actual failed cleanup or effect is
        // claimed by this integration test. The native persistence path and
        // both SIGIL policies are real, with an injected native Observation.
        let observed = sigil_worker_bridge::Observation {
            generation: generation.clone(),
            request_may_have_run: true,
            worker_reaped: false,
            fault: Some(sigil_worker_bridge::Fault::CleanupUnconfirmed),
            result: None,
        };
        assert_eq!(
            attempt
                .persist_observation(&mut recorder, Some(&observed), None)
                .unwrap()
                .0,
            "4"
        );
        assert!(attempt.take_returned_credit().is_none());
    }
    drop(attempt);
    let terminal_claim = store.get(&owner_scope, "claim", &operation_key).unwrap();
    let terminal_delivery = store.get(&owner_scope, "delivery", &operation_key).unwrap();
    if programs.retirement {
        assert!(matches!(
            recorder.retire_funded_terminal(&mut store, &owner_scope, "funds", &operation_key),
            Err("execution_fence")
        ));
    }
    let assigned = store
        .reservation_snapshot(&owner_scope, "funds", &operation_key)
        .unwrap();
    assert_eq!(assigned.revision, if programs.retirement { 3 } else { 2 });
    drop(recorder);
    drop(log);
    drop(store);
    assert!(matches!(
        open_profile(&root, &programs, OpenMode::Existing),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    drop(worker);
    let mut store = open_profile(&root, &programs, OpenMode::Existing).unwrap();
    let mut owner_scope = owner(&store);
    let mut current_epoch = store.execution_identity().unwrap().1.to_owned();
    assert_ne!(current_epoch, prior_epoch);
    let mut worker = Bridge::new_fenced(
        programs.completion.clone(),
        store.execution_lease().unwrap(),
    )
    .unwrap();
    let mut recorder = attach(&programs, &worker, &store, programs.retirement);
    if programs.failure {
        assert!(programs.retirement);
        let connection = rusqlite::Connection::open_with_flags(
            root.join("records.sqlite"),
            rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE,
        )
        .unwrap();
        connection.execute_batch("CREATE TRIGGER refuse_retirement BEFORE INSERT ON records WHEN NEW.namespace='audit.entries' BEGIN SELECT RAISE(ABORT,'injected retirement failure'); END;").unwrap();
        assert!(matches!(
            recorder.retire_funded_terminal(&mut store, &owner_scope, "funds", &operation_key),
            Err("storage")
        ));
        assert!(matches!(
            store.get(&owner_scope, "claim", &operation_key),
            Err(sigil_durable_store::store::Error::ReopenRequired)
        ));
        connection
            .execute_batch("DROP TRIGGER refuse_retirement;")
            .unwrap();
        drop(connection);
        drop(recorder);
        drop(worker);
        drop(store);
        store = open_profile(&root, &programs, OpenMode::Existing).unwrap();
        owner_scope = owner(&store);
        current_epoch = store.execution_identity().unwrap().1.to_owned();
        let unchanged = store
            .reservation_snapshot(&owner_scope, "funds", &operation_key)
            .unwrap();
        assert_eq!(unchanged.revision, assigned.revision);
        assert_eq!(unchanged.binding, assigned.binding);
        assert_eq!(unchanged.assignment, assigned.assignment);
        assert_eq!(unchanged.credits, assigned.credits);
        assert_eq!(
            store.get(&owner_scope, "claim", &operation_key).unwrap(),
            terminal_claim
        );
        assert_eq!(
            store.get(&owner_scope, "delivery", &operation_key).unwrap(),
            terminal_delivery
        );
        assert_eq!(
            store
                .get(&owner_scope, "audit.heads", &"a".repeat(64))
                .unwrap()
                .revision,
            2
        );
        worker = Bridge::new_fenced(
            programs.completion.clone(),
            store.execution_lease().unwrap(),
        )
        .unwrap();
        recorder = attach(&programs, &worker, &store, true);
    }
    let credit = if programs.retirement {
        let restricted = store
            .scope(BTreeMap::from([
                ("intent".into(), Access::Read),
                ("claim".into(), Access::Read),
                ("delivery".into(), Access::Read),
                ("funds".into(), Access::Read),
            ]))
            .unwrap();
        assert!(
            recorder
                .retire_funded_terminal(&mut store, &restricted, "funds", &operation_key)
                .is_err()
        );
        let minimal = BTreeMap::from([
            ("intent".into(), Access::Read),
            ("claim".into(), Access::Read),
            ("delivery".into(), Access::Read),
            ("funds".into(), Access::ReadWrite),
        ]);
        for namespace in ["intent", "claim", "delivery"] {
            let mut missing = minimal.clone();
            missing.remove(namespace);
            let denied = store.scope(missing).unwrap();
            assert!(
                recorder
                    .retire_funded_terminal(&mut store, &denied, "funds", &operation_key)
                    .is_err()
            );
        }
        let minimal_scope = store.scope(minimal).unwrap();
        let mut retired = recorder
            .retire_funded_terminal(&mut store, &minimal_scope, "funds", &operation_key)
            .unwrap();
        let credit = retired.take_returned_credit().unwrap();
        assert!(retired.take_returned_credit().is_none());
        assert_eq!(
            store.get(&owner_scope, "claim", &operation_key).unwrap(),
            terminal_claim
        );
        assert_eq!(
            store.get(&owner_scope, "delivery", &operation_key).unwrap(),
            terminal_delivery
        );
        credit
    } else {
        let mut recovered = recorder
            .recover_funded_pending(&mut store, &owner_scope, "funds", &operation_key)
            .unwrap();
        assert_eq!(recovered.recovered.phase, "4");
        assert_eq!(recovered.recovered.claim_generation, generation);
        let credit = recovered.take_returned_credit().unwrap();
        assert!(recovered.take_returned_credit().is_none());
        credit
    };
    store.check_reservation_binding(&credit, origin).unwrap();
    assert_eq!(credit.generation(), slot_generation.as_ref());
    assert_eq!(
        (credit.credits().records, credit.credits().live_bytes),
        (if programs.retirement { 4 } else { 5 }, 100_000)
    );
    let log = AuthenticatedLog::new(
        &store,
        "audit.heads",
        "audit.entries",
        limits(programs.retirement),
        &key_bytes,
    )
    .unwrap();
    let verified = log
        .verify(
            &mut store,
            &owner_scope,
            &"a".repeat(64),
            None,
            Instant::now() + Duration::from_secs(1),
        )
        .unwrap();
    assert_eq!(verified.count, count);
    let entries: Vec<String> = (0..count)
        .map(|sequence| {
            store
                .get(
                    &owner_scope,
                    "audit.entries",
                    &format!("{}.{sequence:016x}", "a".repeat(64)),
                )
                .unwrap()
                .value
                .unwrap()
        })
        .collect();
    let signed: Value = serde_json::from_str(entries.last().unwrap()).unwrap();
    let event: Value = serde_json::from_str(signed["body"]["payload"].as_str().unwrap()).unwrap();
    let expected = serde_json::json!({ "schema":"sigil/local-exclusion/v1", "domain":domain,
        "prior_epoch":prior_epoch, "current_epoch":current_epoch, "reservation_namespace":"funds",
        "reservation_key":operation_key, "reservation_revision":assigned.revision, "assignment_binding":hex(assigned.binding),
        "origin_binding":hex(origin), "result_records":2, "result_live_bytes":200000 });
    assert_eq!(
        event["schema"],
        if programs.retirement {
            "sigil-pi/worker-lifecycle-audit/v4"
        } else {
            "sigil-pi/worker-lifecycle-audit/v3"
        }
    );
    if programs.retirement {
        assert_eq!(
            event["retirement"],
            serde_json::json!({"records":1,"live_bytes":200000,
            "claim_sha256":crate::effect_audit::digest(terminal_claim.value.as_deref().unwrap()),
            "delivery_sha256":crate::effect_audit::digest(terminal_delivery.value.as_deref().unwrap())})
        );
    }
    assert_eq!(event["local_exclusion"], expected);
    assert_eq!(
        event["event"],
        if programs.retirement {
            "retired"
        } else {
            "abandoned"
        }
    );
    assert_eq!(event["phase"], 4);
    assert_eq!(event["request_may_have_run"], 1);
    assert_eq!(event["worker_reaped"], 0);
    assert!(event["effect"].is_null());
    assert_eq!(event["claim_generation"], generation);
    let delivery = store.get(&owner_scope, "delivery", &operation_key).unwrap();
    let dr = fields(delivery.value.as_deref().unwrap(), "DR1\n", 7).unwrap();
    assert_eq!(&dr[3..], &[generation.as_str(), "4", "", ""]);
    assert!(
        recorder
            .recover_funded_pending(&mut store, &owner_scope, "funds", &operation_key)
            .is_err()
    );
    assert!(
        recorder
            .retire_funded_terminal(&mut store, &owner_scope, "funds", &operation_key)
            .is_err()
    );
    assert_eq!(
        store
            .reservation_snapshot(&owner_scope, "funds", &operation_key)
            .unwrap()
            .revision,
        if programs.retirement { 4 } else { 3 }
    );
    std::fs::write(
        &programs.report,
        serde_json::to_vec_pretty(&serde_json::json!({
            "entries": entries, "expected_exclusion": expected, "phase":4, "replayed_effects":0,
            "returned_records":if programs.retirement {4} else {5}, "returned_bytes":100000, "qualified":false,
            "reservation_generation":slot_generation, "anchored":programs.anchored,
        }))
        .unwrap(),
    )
    .unwrap();
}

#[cfg(target_os = "macos")]
#[path = "live_recovery_tests.rs"]
mod live;
