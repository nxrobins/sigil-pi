use super::*;
use crate::{Bridge, Config};
use std::collections::BTreeMap;
use std::os::unix::fs::PermissionsExt;
use std::sync::atomic::AtomicBool;
use std::time::{Duration, Instant};

fn root() -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    dir
}
fn config(root: &Path, script: &str) -> Config {
    let runtime = root.join("runtime");
    let body = format!("#!/bin/sh\n{script}\n");
    fs::write(&runtime, &body).unwrap();
    fs::set_permissions(&runtime, fs::Permissions::from_mode(0o700)).unwrap();
    let source = root.join("program");
    fs::write(&source, "native fence fixture").unwrap();
    Config {
        version: 1,
        runtime,
        runtime_sha256: crate::digest(body.as_bytes()),
        source,
        source_sha256: crate::digest(b"native fence fixture"),
        max_fuel: 1000,
        max_timeout_ms: 30_000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    }
}
#[test]
fn fence_is_explicit_exclusive_and_retained_until_the_last_lease_closes() {
    // Other parallel tests fork process workers. Before exec closes CLOEXEC
    // handles, such a child is a real holder of this test's open description.
    // Run the immediate last-holder assertion in a fresh process, where no
    // unrelated test can acquire an inherited copy. Do not weaken Busy checks.
    const ISOLATED: &str = "SIGIL_FENCE_LAST_LEASE_TEST";
    if std::env::var_os(ISOLATED).is_none() {
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "execution_fence::tests::fence_is_explicit_exclusive_and_retained_until_the_last_lease_closes",
                "--nocapture",
            ])
            .env(ISOLATED, "1")
            .status()
            .unwrap();
        assert!(status.success(), "isolated last-lease test failed");
        return;
    }
    let root = root();
    assert!(ExecutionFence::open(root.path(), OpenMode::Existing).is_err());
    let fence = ExecutionFence::open(root.path(), OpenMode::CreateNew).unwrap();
    let id = fence.identity().unwrap().to_owned();
    let epoch = fence.epoch().unwrap().to_owned();
    assert!(matches!(
        ExecutionFence::open(root.path(), OpenMode::Existing),
        Err(Fault::Busy)
    ));
    assert!(ExecutionFence::open(root.path(), OpenMode::CreateNew).is_err());
    let lease = fence.lease().unwrap();
    assert!(lease.descriptor().unwrap() >= 3);
    let flags = unsafe { libc::fcntl(lease.descriptor().unwrap(), libc::F_GETFD) };
    assert_ne!(flags & libc::FD_CLOEXEC, 0);
    drop(fence);
    assert!(matches!(
        ExecutionFence::open(root.path(), OpenMode::Existing),
        Err(Fault::Busy)
    ));
    drop(lease);
    let next = ExecutionFence::open(root.path(), OpenMode::Existing).unwrap();
    assert_eq!(next.identity().unwrap(), id);
    assert_ne!(next.epoch().unwrap(), epoch);
}

#[test]
fn malformed_linked_nonprivate_or_special_files_are_refused_without_repair() {
    use std::os::unix::fs::symlink;
    for kind in [
        "short", "large", "header", "public", "symlink", "hardlink", "fifo",
    ] {
        let root = root();
        let path = root.path().join(NAME);
        let fence = ExecutionFence::open(root.path(), OpenMode::CreateNew).unwrap();
        drop(fence);
        match kind {
            "short" => fs::write(&path, b"short").unwrap(),
            "large" => fs::write(&path, vec![0; 4096]).unwrap(),
            "header" => fs::write(&path, vec![0; HEADER.len() + 32]).unwrap(),
            "public" => fs::set_permissions(&path, fs::Permissions::from_mode(0o644)).unwrap(),
            "hardlink" => fs::hard_link(&path, root.path().join("alias")).unwrap(),
            "symlink" => {
                fs::rename(&path, root.path().join("original")).unwrap();
                symlink(root.path().join("original"), &path).unwrap();
            }
            "fifo" => {
                fs::remove_file(&path).unwrap();
                let path = std::ffi::CString::new(path.as_os_str().as_encoded_bytes()).unwrap();
                assert_eq!(unsafe { libc::mkfifo(path.as_ptr(), 0o600) }, 0);
            }
            _ => unreachable!(),
        }
        let before = fs::symlink_metadata(&path).unwrap();
        let started = Instant::now();
        assert!(
            ExecutionFence::open(root.path(), OpenMode::Existing).is_err(),
            "{kind}"
        );
        assert!(started.elapsed() < Duration::from_secs(1));
        let after = fs::symlink_metadata(&path).unwrap();
        assert_eq!(
            (before.ino(), before.len(), before.mode()),
            (after.ino(), after.len(), after.mode())
        );
    }
}

#[test]
fn replaced_fence_or_changed_owner_cannot_prepare_or_dispatch() {
    let root = root();
    let mut fence = ExecutionFence::open(root.path(), OpenMode::CreateNew).unwrap();
    Arc::get_mut(&mut fence.inner).unwrap().process = std::process::id().wrapping_add(1);
    assert!(matches!(fence.lease(), Err(Fault::WrongProcess)));
    Arc::get_mut(&mut fence.inner).unwrap().process = std::process::id();
    let script = format!(": > '{}'", root.path().join("started").display());
    let mut bridge =
        Bridge::new_fenced(config(root.path(), &script), fence.lease().unwrap()).unwrap();
    assert_eq!(
        bridge.execution_domain().unwrap(),
        Some(fence.identity().unwrap())
    );
    let prepared = bridge.prepare("input".into(), 100, 5000).unwrap();
    fs::rename(root.path().join(NAME), root.path().join("old.lock")).unwrap();
    let _replacement = ExecutionFence::open(root.path(), OpenMode::CreateNew).unwrap();
    assert!(bridge.execution_domain().is_err());
    assert!(
        bridge
            .execute(&prepared.ticket, &AtomicBool::new(false))
            .is_err()
    );
    assert!(!root.path().join("started").exists());
}

#[test]
fn actual_successful_effect_keeps_parent_descriptor_close_on_exec_and_releases_on_drop() {
    let root = root();
    let fence = ExecutionFence::open(root.path(), OpenMode::CreateNew).unwrap();
    let script = "read -r line\nprintf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}'\nread -r line\nprintf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"{\\\"status\\\":\\\"ok\\\"}\"}]}}'\nwhile :; do /bin/sleep 1; done";
    let mut bridge =
        Bridge::new_fenced(config(root.path(), script), fence.lease().unwrap()).unwrap();
    let prepared = bridge.prepare("input".into(), 100, 5000).unwrap();
    let seen = bridge
        .execute(&prepared.ticket, &AtomicBool::new(false))
        .unwrap();
    assert!(seen.worker_reaped && seen.request_may_have_run);
    assert_eq!(seen.fault, None);
    let flags = unsafe { libc::fcntl(fence.inner.file.as_raw_fd(), libc::F_GETFD) };
    assert_ne!(flags & libc::FD_CLOEXEC, 0);
    drop(fence);
    assert!(matches!(
        ExecutionFence::open(root.path(), OpenMode::Existing),
        Err(Fault::Busy)
    ));
    drop(bridge);
    let until = Instant::now() + Duration::from_secs(5);
    loop {
        match ExecutionFence::open(root.path(), OpenMode::Existing) {
            Ok(_) => break,
            Err(Fault::Busy) if Instant::now() < until => {
                std::thread::sleep(Duration::from_millis(5))
            }
            _ => panic!("fence not released after effect cleanup"),
        }
    }
}

struct Cleanup {
    child: std::process::Child,
    release: PathBuf,
}
impl Drop for Cleanup {
    fn drop(&mut self) {
        let _ = fs::write(&self.release, b"");
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}
#[test]
fn fence_owner_process_child() {
    use std::io::Write;
    let Ok(root) = std::env::var("SIGIL_FENCE_PROCESS_ROOT") else {
        return;
    };
    let root = PathBuf::from(root);
    let fence = ExecutionFence::open(&root, OpenMode::CreateNew).unwrap();
    let release = root.join("release");
    let descendant = root.join("descendant");
    let received = root.join("received");
    // The deliberately surviving descendant proves inherited-descriptor lifetime
    // even on Linux where the actual runtime leader has a parent-death signal.
    // It exits on a private release marker or after a bounded watchdog interval.
    let helper = root.join("helper");
    fs::write(&helper, format!("#!/bin/sh\n: > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done\n", descendant.display(), release.display())).unwrap();
    fs::set_permissions(&helper, fs::Permissions::from_mode(0o700)).unwrap();
    let script = format!(
        "'{}' &\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nread -r line\n: > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done",
        helper.display(),
        received.display(),
        release.display()
    );
    let mut bridge = Bridge::new_fenced(config(&root, &script), fence.lease().unwrap()).unwrap();
    let prepared = bridge
        .prepare("actual invocation".into(), 100, 30_000)
        .unwrap();
    std::thread::spawn(move || {
        let until = Instant::now() + Duration::from_secs(15);
        while !received.exists() || !descendant.exists() {
            assert!(Instant::now() < until);
            std::thread::sleep(Duration::from_millis(5));
        }
        println!("ACTUAL_LEASED_EFFECT_RECEIVED");
        std::io::stdout().flush().unwrap();
    });
    let _ = bridge.execute(&prepared.ticket, &AtomicBool::new(false));
    panic!("test owner should have been killed while effect was held");
}

#[test]
fn actual_parent_death_cannot_admit_successor_while_inherited_effect_holder_survives() {
    use std::io::{BufRead, BufReader};
    use std::process::{Command, Stdio};
    let root = root();
    let mut cleanup = Cleanup {
        child: Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "execution_fence::tests::fence_owner_process_child",
                "--nocapture",
            ])
            .env("SIGIL_FENCE_PROCESS_ROOT", root.path())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap(),
        release: root.path().join("release"),
    };
    let output = cleanup.child.stdout.take().unwrap();
    let (tx, rx) = std::sync::mpsc::channel();
    let reader = std::thread::spawn(move || {
        for line in BufReader::new(output)
            .lines()
            .map_while(std::result::Result::ok)
        {
            if line.contains("ACTUAL_LEASED_EFFECT_RECEIVED") {
                let _ = tx.send(());
                break;
            }
        }
    });
    rx.recv_timeout(Duration::from_secs(20))
        .expect("actual leased effect did not receive invocation");
    cleanup.child.kill().unwrap();
    assert!(!cleanup.child.wait().unwrap().success());
    reader.join().unwrap();
    // The original owner is actually dead; a retained runtime/descendant holds
    // the same kernel lock. A fresh bootstrap cannot pass by releasing SQLite.
    assert!(matches!(
        ExecutionFence::open(root.path(), OpenMode::Existing),
        Err(Fault::Busy)
    ));
    fs::write(&cleanup.release, b"").unwrap();
    let until = Instant::now() + Duration::from_secs(5);
    loop {
        match ExecutionFence::open(root.path(), OpenMode::Existing) {
            Ok(next) => {
                assert_eq!(next.identity().unwrap().len(), 64);
                break;
            }
            Err(Fault::Busy) if Instant::now() < until => {
                std::thread::sleep(Duration::from_millis(5))
            }
            _ => panic!("fence did not release after surviving holders exited"),
        }
    }
}

#[test]
fn closed_standard_descriptors_process_child() {
    let Ok(path) = std::env::var("SIGIL_FENCE_CLOSED_STDIO_ROOT") else {
        return;
    };
    // Only this dedicated subprocess loses stdio. Exit directly afterward so
    // libtest does not try to report through descriptors the test has closed.
    unsafe {
        libc::close(0);
        libc::close(1);
        libc::close(2);
    }
    let result = (|| -> Result<(), Fault> {
        let root = PathBuf::from(path);
        let fence = ExecutionFence::open(&root, OpenMode::CreateNew)?;
        let script = "read -r line\nprintf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}'\nread -r line\nprintf '%s\\n' '{\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"{\\\"status\\\":\\\"ok\\\"}\"}]}}'\nwhile :; do /bin/sleep 1; done";
        let lease = fence.lease()?;
        if lease.descriptor()? < 3 {
            return Err(Fault::Invalid);
        }
        let mut bridge = Bridge::new_fenced(config(&root, script), lease)?;
        let prepared = bridge.prepare("input".into(), 100, 5000)?;
        let seen = bridge.execute(&prepared.ticket, &AtomicBool::new(false))?;
        if !seen.worker_reaped || !seen.request_may_have_run || seen.fault.is_some() {
            return Err(Fault::Invalid);
        }
        Ok(())
    })();
    std::process::exit(if result.is_ok() { 0 } else { 1 });
}
#[test]
fn closed_parent_stdio_does_not_let_child_pipe_setup_replace_the_execution_lease() {
    let root = root();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            "execution_fence::tests::closed_standard_descriptors_process_child",
            "--nocapture",
        ])
        .env("SIGIL_FENCE_CLOSED_STDIO_ROOT", root.path())
        .status()
        .unwrap();
    assert!(
        status.success(),
        "leased effect failed with initially closed stdio"
    );
}

#[test]
fn copied_lock_bytes_cannot_represent_the_original_live_domain() {
    let original = root();
    let copy = root();
    let fence = ExecutionFence::open(original.path(), OpenMode::CreateNew).unwrap();
    fs::copy(original.path().join(NAME), copy.path().join(NAME)).unwrap();
    let replacement = ExecutionFence::open(copy.path(), OpenMode::Existing).unwrap();
    assert_ne!(fence.identity().unwrap(), replacement.identity().unwrap());
    assert!(matches!(
        ExecutionFence::open(original.path(), OpenMode::Existing),
        Err(Fault::Busy)
    ));
}
