//! Real admission with a controlled responder, not a compiled audit policy.
use super::*;
use crate::shared_pure_tests::{audit_config, audit_environment_child, fixture_output};

#[test]
fn shared_transaction_and_failure_publications_verify_with_each_callers_key_after_reopen() {
    audit_environment_child("audited_transaction::cache_tests::audit_publication_child");
}

#[test]
fn audit_publication_child() {
    use crate::policy::{Input, Key};
    use crate::shared_pure_tests::fixture_routes;
    use sigil_durable_store::store::{Limits, OpenMode};
    use std::os::unix::fs::PermissionsExt;
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let published = frame("AR1\n", &["publish", "controlled transaction publication"]).unwrap();
    let failed = frame("AR1\n", &["publish", "controlled evaluation failure"]).unwrap();
    let (dir, formatter) = fixture_routes(&[
        ("AB1", "transaction_audit_admitted"),
        ("EB1", "evaluation_audit_admitted"),
        ("TA1", &published),
        ("EA1", &failed),
    ]);
    let state = dir.path().join("state");
    std::fs::create_dir(&state).unwrap();
    std::fs::set_permissions(&state, std::fs::Permissions::from_mode(0o700)).unwrap();
    let mut producers = Vec::new();
    for side in ["a", "b"] {
        let batch = json!({"op":"commit","checks":[],"writes":[{"namespace":format!("{side}.domain"),"key":"value","revision":0,"value":format!("{side}-only") }]}).to_string();
        let output = frame("TX1\n", &["context", "result", &batch]).unwrap();
        producers.push(fixture_output(&output));
        producers.push(fixture_output("invalid transaction response"));
    }
    let admit = |i: usize, cache: &mut crate::PureCache| {
        let side = if i < 2 { "a" } else { "b" };
        let tx = transaction::Config {
            worker: producers[i].1.clone(),
            marker: "IN1\n".into(),
            values: 0,
            inputs: vec![Input::Read {
                namespace: format!("{side}.domain"),
                key: Key::Literal {
                    value: "value".into(),
                },
            }],
            grants: BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]),
        };
        let mut config = audit_config(formatter.clone(), side);
        config.version = 2;
        config.evaluation = Some(formatter.clone());
        let mut admitted = Admitted::new_with_cache(tx, config, Some(cache)).unwrap();
        admitted.admit_policy().unwrap();
        admitted
    };
    let mut cache = crate::PureCache::new();
    let mut store = Store::open(&state, OpenMode::CreateNew, Limits::default()).unwrap();
    let mut callers: Vec<_> = (0..4)
        .map(|i| admit(i, &mut cache).open(&store).unwrap())
        .collect();
    assert_eq!(
        cache.len(),
        1,
        "formatter and evaluation roles should reuse the exact worker"
    );
    let mut clock = 0;
    let mut checkpoints = Vec::new();
    for i in [0, 2] {
        assert!(
            callers[i]
                .apply(&mut store, &mut clock, &[])
                .unwrap()
                .receipt
                .is_some()
        );
        assert!(matches!(
            callers[i + 1].apply(&mut store, &mut clock, &[]),
            Err("protocol")
        ));
        let observed = callers[i].verify(&mut store, None).unwrap();
        assert_eq!(observed["count"], 2);
        let side = if i == 0 { "a" } else { "b" };
        assert_eq!(
            store
                .get(&callers[i].scope, &format!("{side}.domain"), "value")
                .unwrap()
                .value
                .as_deref(),
            Some(if i == 0 { "a-only" } else { "b-only" })
        );
        assert!(
            store
                .get(
                    &callers[i].scope,
                    if i == 0 { "b.domain" } else { "a.domain" },
                    "value"
                )
                .is_err()
        );
        let (_, payload) = callers[i]
            .log
            .verified_payload(
                &mut store,
                &callers[i].scope,
                &callers[i].chain,
                1,
                Instant::now() + Duration::from_secs(1),
            )
            .unwrap();
        assert_eq!(payload, "controlled evaluation failure");
        let wrong_key = environment_key(if i == 0 {
            "PI_SHARED_AUDIT_KEY_B"
        } else {
            "PI_SHARED_AUDIT_KEY_A"
        })
        .unwrap();
        let cfg = audit_config(formatter.clone(), side);
        let wrong = AuthenticatedLog::new(&store, &cfg.heads, &cfg.records, cfg.limits, &wrong_key)
            .unwrap();
        assert!(
            wrong
                .verify(
                    &mut store,
                    &callers[i].scope,
                    &callers[i].chain,
                    None,
                    Instant::now() + Duration::from_secs(1)
                )
                .is_err()
        );
        checkpoints.push(observed);
    }
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    let calls = std::fs::read_to_string(dir.path().join("calls")).unwrap();
    assert!(!calls.contains("test-only-key"));
    drop(callers);
    drop(store);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
    let mut reopened = Store::open(&state, OpenMode::Existing, Limits::default()).unwrap();
    for (i, expected) in [0, 2].into_iter().zip(checkpoints) {
        let caller = admit(i, &mut cache).open(&reopened).unwrap();
        assert_eq!(caller.verify(&mut reopened, None).unwrap(), expected);
    }
}

#[test]
fn warm_shared_transaction_formatter_refuses_second_caller_boot() {
    audit_environment_child("audited_transaction::cache_tests::audit_rejection_child");
}

#[test]
fn audit_rejection_child() {
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let (dir, worker) = crate::shared_pure_tests::fixture_rejecting_input(
        "transaction_audit_admitted",
        &"b".repeat(64),
        "transaction_audit_denied",
    );
    let tx = |side: &str| transaction::Config {
        worker: worker.clone(),
        marker: "IN1\n".into(),
        values: 0,
        inputs: vec![crate::policy::Input::Clock],
        grants: BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]),
    };
    let mut cache = crate::PureCache::new();
    let mut a =
        Admitted::new_with_cache(tx("a"), audit_config(worker.clone(), "a"), Some(&mut cache))
            .unwrap();
    a.admit_policy().unwrap();
    let mut b =
        Admitted::new_with_cache(tx("b"), audit_config(worker.clone(), "b"), Some(&mut cache))
            .unwrap();
    assert_eq!(b.admit_policy(), Err("config"));
    drop(b);
    a.admit_policy().unwrap();
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    assert_eq!(
        std::fs::read_to_string(dir.path().join("calls"))
            .unwrap()
            .lines()
            .count(),
        3
    );
    drop(a);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}

#[test]
fn shared_audit_formatter_keeps_scopes_keys_and_boot_decisions_per_caller() {
    audit_environment_child("audited_transaction::cache_tests::audit_scope_child");
}

#[test]
fn audit_scope_child() {
    if std::env::var_os("PI_SHARED_AUDIT_FIXTURE").is_none() {
        return;
    }
    let (dir, worker) = fixture_output("transaction_audit_admitted");
    let transaction = |side: &str| transaction::Config {
        worker: worker.clone(),
        marker: "IN1\n".into(),
        values: 0,
        inputs: vec![crate::policy::Input::Clock],
        grants: BTreeMap::from([(format!("{side}.domain"), Access::ReadWrite)]),
    };
    let mut cache = crate::PureCache::new();
    let mut a = Admitted::new_with_cache(
        transaction("a"),
        audit_config(worker.clone(), "a"),
        Some(&mut cache),
    )
    .unwrap();
    let mut b = Admitted::new_with_cache(
        transaction("b"),
        audit_config(worker.clone(), "b"),
        Some(&mut cache),
    )
    .unwrap();
    let (crate::PureExecution::SharedCached(wa), crate::PureExecution::SharedCached(wb)) =
        (&a.formatter.worker, &b.formatter.worker)
    else {
        panic!("expected sharing");
    };
    assert!(std::sync::Arc::ptr_eq(wa, wb));
    assert_ne!(&*a.key, &*b.key);
    assert!(a.scope.contains_key("a.domain") && !a.scope.contains_key("b.domain"));
    assert!(b.scope.contains_key("b.domain") && !b.scope.contains_key("a.domain"));
    assert!(a.scope.contains_key("a.heads") && !a.scope.contains_key("b.heads"));
    assert!(b.scope.contains_key("b.heads") && !b.scope.contains_key("a.heads"));
    a.admit_policy().unwrap();
    b.admit_policy().unwrap();
    let calls = std::fs::read_to_string(dir.path().join("calls")).unwrap();
    let decoded: Vec<Value> = calls
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(decoded.len(), 2);
    for (row, side) in decoded.iter().zip(["a", "b"]) {
        let input = row["params"]["arguments"]["input"].as_str().unwrap();
        let fields = fields(input, "AB1\n", 4).unwrap();
        assert_eq!(fields[0], side.repeat(64));
        assert_eq!(
            serde_json::from_str::<Value>(fields[3]).unwrap(),
            json!({format!("{side}.domain"):"read_write"})
        );
    }
    assert!(!calls.contains("test-only-key"));
    let mut invalid = audit_config(worker.clone(), "b");
    invalid.key_env = "PI_MISSING_AUDIT_KEY".into();
    assert!(Admitted::new_with_cache(transaction("b"), invalid, Some(&mut cache)).is_err());
    a.admit_policy().unwrap();
    assert_eq!(
        std::fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
    drop(a);
    drop(b);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
}
