use super::*;
use std::fs;
use std::io::{Cursor, Error, ErrorKind};
use std::os::unix::fs::{PermissionsExt, symlink};

#[test]
fn streaming_and_retained_hashes_agree_at_file_and_buffer_boundaries() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("artifact");
    for length in [0, 1, 16383, 16384, 16385, 65536, 65537] {
        let bytes: Vec<_> = (0..length).map(|i| (i % 251) as u8).collect();
        fs::write(&path, &bytes).unwrap();
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
        let expected = digest(&bytes);
        assert_eq!(verify_pinned_file(&path, &expected, length), Ok(()));
        assert_eq!(pinned_file(&path, &expected, length), Ok(bytes));
        assert_eq!(
            verify_pinned_file(&path, &"f".repeat(64), length),
            Err(Fault::Invalid)
        );
        if length > 0 {
            assert_eq!(
                verify_pinned_file(&path, &expected, length - 1),
                Err(Fault::Invalid)
            );
            assert_eq!(
                pinned_file(&path, &expected, length - 1),
                Err(Fault::Invalid)
            );
        }
    }
}

#[test]
fn hash_read_is_bounded_and_read_errors_never_produce_success() {
    struct Observed {
        input: Cursor<Vec<u8>>,
        largest_request: usize,
        interrupt: bool,
    }
    impl Read for Observed {
        fn read(&mut self, buffer: &mut [u8]) -> std::io::Result<usize> {
            self.largest_request = self.largest_request.max(buffer.len());
            if self.interrupt {
                self.interrupt = false;
                return Err(ErrorKind::Interrupted.into());
            }
            self.input.read(buffer)
        }
    }
    let mut observed = Observed {
        input: Cursor::new(vec![7; 25000]),
        largest_request: 0,
        interrupt: true,
    };
    assert_eq!(bounded_digest(&mut observed, 20000), Err(Fault::Invalid));
    assert_eq!(
        observed.input.position(),
        20001,
        "consume at most one byte beyond the ceiling"
    );
    assert!(observed.largest_request <= 16384);
    observed.input.set_position(0);
    observed.interrupt = true;
    assert_eq!(
        bounded_digest(&mut observed, 25000),
        Ok(digest(&vec![7; 25000]))
    );
    struct Broken;
    impl Read for Broken {
        fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
            Err(Error::other("controlled read failure"))
        }
    }
    assert_eq!(bounded_digest(Broken, 1), Err(Fault::Invalid));
}

#[test]
fn streaming_verification_preserves_path_mode_and_digest_refusals() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("artifact");
    fs::write(&path, b"verified").unwrap();
    let expected = digest(b"verified");
    for mode in [0o622, 0o602, 0o620] {
        fs::set_permissions(&path, fs::Permissions::from_mode(mode)).unwrap();
        assert_eq!(
            verify_pinned_file(&path, &expected, 100),
            Err(Fault::Invalid)
        );
    }
    fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
    assert_eq!(
        verify_pinned_file(&path, &expected.to_uppercase(), 100),
        Err(Fault::Invalid)
    );
    assert_eq!(
        verify_pinned_file(Path::new("relative"), &expected, 100),
        Err(Fault::Invalid)
    );
    assert_eq!(
        verify_pinned_file(dir.path(), &expected, 100),
        Err(Fault::Invalid)
    );
    let link = dir.path().join("link");
    symlink(&path, &link).unwrap();
    assert_eq!(
        verify_pinned_file(&link, &expected, 100),
        Err(Fault::Invalid)
    );
    assert_eq!(verify_pinned_file(&path, &expected, 100), Ok(()));
    fs::write(&path, b"replaced").unwrap();
    assert_eq!(
        verify_pinned_file(&path, &expected, 100),
        Err(Fault::Invalid)
    );
}

#[test]
fn fifo_without_a_writer_is_refused_in_a_bounded_child() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("fifo");
    let name = std::ffi::CString::new(path.to_str().unwrap()).unwrap();
    // SAFETY: a NUL-terminated path in this test's private temporary directory.
    assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "pinned_tests::fifo_child", "--nocapture"])
        .env("PI_PINNED_FIFO_FIXTURE", &path)
        .spawn()
        .unwrap();
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if let Some(status) = child.try_wait().unwrap() {
            assert!(status.success());
            break;
        }
        if Instant::now() >= deadline {
            child.kill().unwrap();
            child.wait().unwrap();
            panic!("artifact admission blocked waiting for a FIFO writer");
        }
        std::thread::sleep(Duration::from_millis(10));
    }
}

#[test]
fn fifo_child() {
    let Some(path) = std::env::var_os("PI_PINNED_FIFO_FIXTURE") else {
        return;
    };
    let path = Path::new(&path);
    assert_eq!(
        verify_pinned_file(path, &digest(b""), 100),
        Err(Fault::Invalid)
    );
    assert_eq!(pinned_file(path, &digest(b""), 100), Err(Fault::Invalid));
}
