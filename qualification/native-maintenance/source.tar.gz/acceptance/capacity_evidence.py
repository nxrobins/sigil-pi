"""Independent read-only oracle for retained native capacity/audit evidence."""

import hashlib
import hmac
import json
import sqlite3
from pathlib import Path


def inspect_capacity(deployment, key):
    deployment = Path(deployment)
    config = json.loads((deployment / "service.json").read_text())
    assert config["version"] == 11
    result = {
        "schema": "sigil-pi/capacity-evidence/v1",
        "chains": [],
        "reservations": [],
    }
    with sqlite3.connect(
        f"file:{deployment / 'records' / 'records.sqlite'}?mode=ro", uri=True
    ) as db:
        db.execute("BEGIN")
        for (
            namespace,
            coordinate,
            revision,
            records,
            size,
            audits,
            origin,
            binding,
            witness,
        ) in db.execute(
            "SELECT namespace,key,revision,records,bytes,audits,origin,binding,witness FROM reservations ORDER BY namespace,key"
        ):
            result["reservations"].append(
                {
                    "namespace": namespace,
                    "key": coordinate,
                    "revision": revision,
                    "records": records,
                    "live_bytes": size,
                    "audits": json.loads(audits),
                    "origin": bytes(origin).hex(),
                    "binding": bytes(binding).hex(),
                    "assignment": json.loads(witness) if witness else None,
                }
            )
        for participant in config["automatic"]["participants"]:
            for kind in ["effect", "transaction"]:
                c = participant[f"{kind}_audit"]

                def verify(raw, subject):
                    signed = json.loads(raw)
                    body = json.dumps(
                        signed["body"], ensure_ascii=False, separators=(",", ":")
                    ).encode()
                    frame = (
                        f"sigil-authenticated-log/{subject}/v1\0".encode()
                        + b"".join(
                            len(part).to_bytes(8, "big") + part
                            for part in [
                                c["heads"].encode(),
                                c["records"].encode(),
                                body,
                            ]
                        )
                    )
                    assert hmac.compare_digest(
                        signed["tag"], hmac.new(key, frame, hashlib.sha256).hexdigest()
                    )
                    assert signed["body"]["chain"] == c["chain"]
                    return signed["body"]

                entries = db.execute(
                    "SELECT key,revision,value FROM records WHERE namespace=? ORDER BY key",
                    (c["records"],),
                ).fetchall()
                head = db.execute(
                    "SELECT revision,value FROM records WHERE namespace=? AND key=?",
                    (c["heads"], c["chain"]),
                ).fetchone()
                if not entries:
                    assert head is None
                    continue
                events, total, previous = [], 0, "0" * 64
                for sequence, (coordinate, revision, raw) in enumerate(entries):
                    raw = bytes(raw)
                    assert (
                        coordinate == c["chain"] + f".{sequence:016x}" and revision == 1
                    )
                    signed = verify(raw, "record")
                    assert (
                        signed["sequence"] == sequence
                        and signed["previous"] == previous
                    )
                    events.append(json.loads(signed["payload"]))
                    total += len(raw)
                    previous = hashlib.sha256(raw).hexdigest()
                assert head is not None and head[0] == len(entries)
                signed = verify(bytes(head[1]), "head")
                assert (
                    signed["count"] == len(entries)
                    and signed["bytes"] == total
                    and signed["tip"] == previous
                )
                assert signed["limits"] == c["limits"]
                result["chains"].append(
                    {
                        "kind": kind,
                        "namespace": c["records"],
                        "head": signed,
                        "events": events,
                    }
                )
    return result


def assert_returned(report):
    assert report["reservations"]
    for row in report["reservations"]:
        assert row["records"] == row["live_bytes"] == 0
        assert row["assignment"] is None and row["binding"] == row["origin"]
        assert all(a["records"] == a["bytes"] == 0 for a in row["audits"])
