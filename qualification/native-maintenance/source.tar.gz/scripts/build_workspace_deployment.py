"""Assemble an explicit local repository-agent development deployment.

Build time only. Start the native host with the emitted service.json; no Python
process is needed to handle either chat or API requests.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from scripts.compose_workspace import compose_workspace
from scripts.public_asset_manifest import manifest
from scripts.workspace_deployment import (
    COMMAND_CODECS,
    TOOL_CODECS,
    configuration,
    record,
)
from sigil_compose import compose_with_stdlib


def specifications(*, commands=False):
    descriptions = {
        "list_dir": "List names in one permitted directory. Start with path . to discover files.",
        "read_file": "Read one permitted UTF-8 file, at most 65500 bytes.",
        "edit_file": "Replace exactly one occurrence of old with new in a permitted file. Read it first. An absent or ambiguous old returns an error without changing the file.",
        "check_json": "Run the approved JSON syntax check on the actual permitted file. Returns PASS or FAIL. Does not check a schema or execute code.",
        "grep_file": "Find lines containing a literal pattern in one permitted file.",
        "build_project": "Run the operator-approved real build on a fresh private copy of the workspace. Always use path '.'. Returns actual exit code, stdout and stderr. No command arguments are accepted; build artifacts are temporary.",
        "test_project": "Run the operator-approved real test suite on a fresh private copy of the workspace. Always use path '.'. Returns actual exit code, stdout and stderr. Tests may perform their own build; no command arguments are accepted.",
    }
    result = []
    for name in [*TOOL_CODECS, *(COMMAND_CODECS if commands else [])]:
        properties = {"path": {"type": "string"}}
        for arg in (
            ["old", "new"]
            if name == "edit_file"
            else ["pattern"]
            if name == "grep_file"
            else []
        ):
            properties[arg] = {"type": "string"}
        result.append(
            {
                "name": name,
                "description": descriptions[name],
                "input_schema": {
                    "type": "object",
                    "properties": properties,
                    "required": list(properties),
                    "additionalProperties": False,
                },
            }
        )
    return result


def build(
    root, workspace, runtime, evaluator, stdlib, token, profile, *, endpoint=None
):
    root, workspace = Path(root).resolve(), Path(workspace).resolve(strict=True)
    if root.exists() and any(root.iterdir()):
        raise ValueError(
            "deployment output must be empty; reopen existing service.json without rebuilding"
        )
    root.mkdir(parents=True, exist_ok=True)
    if (
        not workspace.is_dir()
        or root == workspace
        or workspace in root.parents
        or root in workspace.parents
    ):
        raise ValueError("workspace and deployment must be separate directories")
    if len(token) < 32:
        raise ValueError("use a bearer token of at least 32 characters")
    commands = profile.get("commands")
    funded = profile.get("completion_capacity")
    lifecycle = profile.get("conversation_lifecycle")
    journal = profile.get("dispatch_journal")
    if journal is not None and (journal != "v1" or funded is None):
        raise ValueError("dispatch journal v1 requires explicit completion capacity")
    if lifecycle is not None and (lifecycle != "archive-v1" or funded is None):
        raise ValueError("archive-v1 lifecycle requires explicit completion capacity")
    catalog = specifications(commands=commands is not None)
    cfg = record(
        "PC1\n",
        [
            profile["model"],
            str(profile["max_tokens"]),
            str(profile["max_steps"]),
            profile["system"],
            json.dumps(catalog),
            "131072" if funded is not None else "1048576",
            "65536",
        ],
    )
    bp = record("BP1\n", [cfg, "2", "2000000", "262144", "1000000"])
    namespaces = [
        "workspace" + suffix
        for suffix in (
            ".requests",
            ".operations",
            ".state",
            ".intent",
            ".budget",
            ".reservation",
        )
    ]
    facts = record(
        "CF2\n",
        [
            "local-user",
            "local-workspace",
            "workspace-v1",
            "100",
            "9000000000",
            json.dumps(["chat", "ops:read", "sessions:read"]),
            json.dumps([t["name"] for t in catalog]),
            namespaces[0],
            namespaces[1],
            str(profile["operation_timeout_s"]),
            *namespaces[2:],
            bp,
        ],
    )
    rows = [
        {
            "sha256": hashlib.sha256(token.encode()).hexdigest(),
            "facts": facts,
            "grants": dict.fromkeys(namespaces, "read_write"),
        }
    ]
    if lifecycle is not None:
        rows[0]["grants"][namespaces[2] + ".archive"] = "read_write"
    programs = {
        name: compose_workspace(
            "edit_file_checked"
            if commands is not None and name == "edit_file"
            else name,
            stdlib,
        ).text
        for name in TOOL_CODECS
    }
    if commands is not None:
        for name in COMMAND_CODECS:
            descriptor = {
                "schema": "sigil-container-command/v1",
                "socket": commands["socket"],
                "image": commands["image"],
                "argv": commands[name],
                "workspace": str(workspace),
                "slot": "sigil-pi-"
                + hashlib.sha256(str(root).encode()).hexdigest()[:24]
                + "-"
                + name.replace("_", "-"),
                "wall_ms": commands.get("wall_ms", 20000),
                "memory_bytes": 268435456,
                "pids": 64,
                "output_bytes": 16384,
            }
            programs[name] = json.dumps(
                descriptor, sort_keys=True, separators=(",", ":")
            )
    programs["provider"] = compose_with_stdlib(
        (ROOT / "tools/agent_turn.sigil").read_text(), ["http"], stdlib
    ).text
    config = configuration(
        root,
        programs,
        endpoint or profile["endpoint"],
        workspace,
        rows,
        Path(runtime).resolve(strict=True),
        Path(evaluator).resolve(strict=True),
        stdlib,
        commands=commands,
        funded=funded,
        lifecycle=lifecycle,
        journal=journal,
    )
    path = root / "service.json"
    path.write_text(json.dumps(config, indent=2) + "\n")
    web = root / "public"
    shutil.copytree(ROOT / "web", web)
    (root / "public-assets.json").write_text(
        json.dumps(manifest(web), sort_keys=True, separators=(",", ":"))
    )
    (root / "profile.json").write_text(json.dumps(profile, indent=2) + "\n")
    hashes = {
        str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(root.rglob("*"))
        if p.is_file()
    }
    (root / "build-inputs.json").write_text(json.dumps(hashes, indent=2) + "\n")
    return config, path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--stdlib-root", type=Path, required=True)
    parser.add_argument(
        "--evaluator",
        type=Path,
        default=ROOT / "native/evaluator/target/release/sigil-fixed-evaluator",
    )
    parser.add_argument("--token-env", default="SIGIL_PI_TOKEN")
    parser.add_argument(
        "--profile", type=Path, default=ROOT / "config/workspace-agent-development.json"
    )
    args = parser.parse_args()
    profile = json.loads(args.profile.read_text())
    if profile["endpoint"] != "http://127.0.0.1:11434/v1/messages":
        parser.error("this development builder allows the local model endpoint only")
    _, path = build(
        args.output,
        args.workspace,
        args.runtime,
        args.evaluator,
        args.stdlib_root,
        os.environ[args.token_env],
        profile,
    )
    print(
        json.dumps(
            {
                "config": str(path),
                "assets": str(path.parent / "public-assets.json"),
                "start": [
                    str(ROOT / "native/service/target/release/sigil-application-host"),
                    "init",
                    str(path),
                    "0",
                    "--public-assets",
                    str(path.parent / "public-assets.json"),
                ],
                "provider_token_environment": "SIGIL_PI_LOCAL_PROVIDER_TOKEN (local placeholder; never exposed to guests)",
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
