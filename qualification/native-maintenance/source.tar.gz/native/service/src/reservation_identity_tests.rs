use super::*;
use sigil_durable_store::store::{
    Access, Batch, Limits, Mutation, OpenMode,
    capacity::{Allocation, Pool},
    reservation::{Credits, Request, slots::Retirement},
};
use std::collections::BTreeMap;
use std::os::unix::fs::PermissionsExt;

fn fixture() -> (tempfile::TempDir, Store, Scope) {
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let p = d.path().join(name);
        std::fs::create_dir(&p).unwrap();
        std::fs::set_permissions(p, std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let s = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "pool".into(),
                namespaces: vec!["a".into()],
                records: 100,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("pool".into(), 8)]),
    )
    .unwrap();
    let scope = s
        .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap();
    (d, s, scope)
}
fn batch(revision: u64, value: &str) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: "intent".into(),
            revision,
            value: Some(value.into()),
        }],
    }
}
fn request() -> Request {
    Request {
        namespace: "a".into(),
        key: "funding".into(),
        binding: [8; 32],
        credits: Credits {
            records: 1,
            live_bytes: 1000,
        },
    }
}

#[test]
fn explicit_identity_round_trip_resumes_only_the_exact_native_generation() {
    let (_d, mut s, scope) = fixture();
    s.commit_reserving(&scope, &batch(0, "accepted"), &request())
        .unwrap();
    let identity = Identity::observe(&s, &scope, "a", "funding").unwrap();
    let raw = serde_json::to_string(&identity).unwrap();
    let identity: Identity = serde_json::from_str(&raw).unwrap();
    assert_eq!(identity.generation, "1");
    assert_eq!(identity.revision, "1");
    let grant = held(&s, &scope, "a", "funding", Some(&identity), true).unwrap();
    assert_eq!(grant.generation().unwrap().generation, 1);
    assert!(matches!(
        held(&s, &scope, "a", "funding", None, true),
        Err("funding_identity")
    ));
    for field in [
        "pool",
        "slot",
        "generation",
        "revision",
        "binding",
        "version",
    ] {
        let mut wrong = identity.clone();
        match field {
            "pool" => wrong.pool = "other".into(),
            "slot" => wrong.slot += 1,
            "generation" => wrong.generation = "2".into(),
            "revision" => wrong.revision = "2".into(),
            "binding" => wrong.binding = "09".repeat(32),
            _ => wrong.version = 2,
        };
        assert!(wrong.resume(&s, &scope, "a", "funding").is_err(), "{field}");
    }
}

#[test]
fn service_spend_cannot_adopt_the_latest_generation_after_coordinate_reuse() {
    let (_d, mut s, scope) = fixture();
    let old = s
        .commit_reserving(&scope, &batch(0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    let identity = Identity::observe(&s, &scope, "a", "funding").unwrap();
    s.commit_spending(&scope, &batch(1, "completed"), &old, old.credits())
        .unwrap();
    let facts = s.reservation_snapshot(&scope, "a", "funding").unwrap();
    s.commit_retiring_reservation(
        &scope,
        &batch(2, "retired"),
        &Retirement {
            namespace: "a".into(),
            key: "funding".into(),
            revision: facts.revision,
            binding: facts.binding,
            generation: facts.generation.unwrap(),
        },
    )
    .unwrap();
    s.commit_reserving(&scope, &batch(3, "accepted again"), &request())
        .unwrap();
    let spend = |identity| crate::capacity::Spend {
        identity,
        namespace: "a".into(),
        key: "funding".into(),
        records: 1,
        live_bytes: 1,
        release: false,
    };
    assert!(spend(Some(identity)).held(&s, &scope, true).is_err());
    assert!(matches!(
        spend(None).held(&s, &scope, true),
        Err("funding_identity")
    ));
    let current = Identity::observe(&s, &scope, "a", "funding").unwrap();
    assert_eq!(current.generation, "2");
    assert!(spend(Some(current)).held(&s, &scope, true).is_ok());
}

#[test]
fn wire_identity_rejects_noncanonical_or_out_of_range_numbers() {
    let (_d, mut s, scope) = fixture();
    s.commit_reserving(&scope, &batch(0, "accepted"), &request())
        .unwrap();
    let original = Identity::observe(&s, &scope, "a", "funding").unwrap();
    for bad in [
        "0",
        "01",
        "+1",
        "-1",
        "1.0",
        " 1",
        "9223372036854775808",
        "18446744073709551616",
    ] {
        let mut identity = original.clone();
        identity.generation = bad.into();
        assert!(
            matches!(
                identity.resume(&s, &scope, "a", "funding"),
                Err("funding_identity")
            ),
            "{bad}"
        );
        identity.generation = "1".into();
        identity.revision = bad.into();
        assert!(
            matches!(
                identity.resume(&s, &scope, "a", "funding"),
                Err("funding_identity")
            ),
            "{bad}"
        );
    }
    let mut json = serde_json::to_value(&original).unwrap();
    json["generation"] = serde_json::json!(1.0);
    assert!(serde_json::from_value::<Identity>(json).is_err());
    let mut json = serde_json::to_value(&original).unwrap();
    json["unknown"] = serde_json::json!(true);
    assert!(serde_json::from_value::<Identity>(json).is_err());
}

#[test]
fn explicit_generation_query_requires_scope_time_and_matching_entry_contract() {
    use crate::action::{EntryContract, Step, perform_with_contract};
    use std::time::{Duration, Instant};
    let (_d, mut store, scope) = fixture();
    store
        .commit_reserving(&scope, &batch(0, "accepted"), &request())
        .unwrap();
    let read = store
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    let denied = store
        .scope(BTreeMap::from([("a".into(), Access::CreateOnly)]))
        .unwrap();
    let guard = crate::frame("TG1\n", &["1", "20"]).unwrap();
    let command = |marker, time: &str| {
        crate::frame(marker, &["reservation", "a", "funding", "continue", time]).unwrap()
    };
    let run = |store: &mut Store, scope: &Scope, contract, marker, time: &str| {
        perform_with_contract(
            contract,
            Some(store),
            Some(scope),
            &mut 5,
            Instant::now() + Duration::from_secs(1),
            &command(marker, time),
            || Ok(5),
        )
    };
    let before = store.get(&scope, "a", "intent").unwrap();
    let Step::Continue {
        stage,
        observation,
        continuation,
    } = run(
        &mut store,
        &read,
        EntryContract::Generational,
        "HC9\n",
        &guard,
    )
    .unwrap()
    else {
        panic!("expected scoped facts");
    };
    assert_eq!(stage, "reservation");
    assert_eq!(continuation, "continue");
    let fields = crate::fields(&observation, "GI1\n", 7).unwrap();
    assert_eq!(&fields[..2], &["a", "funding"]);
    let observed: Identity = serde_json::from_str(fields[2]).unwrap();
    assert_eq!(observed.generation, "1");
    assert_eq!(fields[3], observed.binding);
    assert_eq!(fields[4], "idle");
    // Read facts cannot mint a spending grant through a read-only scope.
    assert!(observed.resume(&store, &read, "a", "funding").is_err());
    assert!(
        run(
            &mut store,
            &denied,
            EntryContract::Generational,
            "HC9\n",
            &guard
        )
        .is_err()
    );
    assert!(run(&mut store, &scope, EntryContract::Funded, "HC8\n", &guard).is_err());
    assert!(
        run(
            &mut store,
            &scope,
            EntryContract::Generational,
            "HC8\n",
            &guard
        )
        .is_err()
    );
    let expired = crate::frame("TG1\n", &["1", "5"]).unwrap();
    assert!(matches!(
        run(
            &mut store,
            &read,
            EntryContract::Generational,
            "HC9\n",
            &expired
        ),
        Err("time_guard")
    ));
    assert_eq!(store.get(&scope, "a", "intent").unwrap(), before);
}

#[test]
#[ignore = "invoked with pinned actual compiled SIGIL allocation comparator"]
fn actual_native_generation_observations_are_checked_by_compiled_sigil() {
    let config_path = std::env::var("SIGIL_GENERATION_COMPARATOR_FIXTURE").unwrap();
    let config: crate::WorkerConfig =
        serde_json::from_slice(&std::fs::read(config_path).unwrap()).unwrap();
    let mut function = crate::Function::new(config).unwrap();
    let (_d, mut store, scope) = fixture();
    let old = store
        .commit_reserving(&scope, &batch(0, "accepted"), &request())
        .unwrap()
        .held
        .unwrap();
    let bound = |identity: &Identity| {
        crate::frame(
            "GB1\n",
            &[
                "a",
                "funding",
                &identity.pool,
                &identity.slot.to_string(),
                &identity.generation,
                &identity.binding,
            ],
        )
        .unwrap()
    };
    let initial = Identity::observe(&store, &scope, "a", "funding").unwrap();
    let expected = bound(&initial);
    let mut observations = Vec::new();
    let mut compare = |store: &Store, expected: &str| {
        let wire = observe_wire(store, &scope, "a", "funding").unwrap();
        observations.push(wire.clone());
        function.invoke(
            crate::frame("GV1\n", &[&wire, expected]).unwrap(),
            std::time::Instant::now() + std::time::Duration::from_secs(30),
        )
    };
    let first: Identity = serde_json::from_str(&compare(&store, &expected).unwrap()).unwrap();
    assert_eq!(first.generation, "1");
    assert_eq!(first.revision, "1");
    store
        .commit_spending(&scope, &batch(1, "completed"), &old, old.credits())
        .unwrap();
    let spent: Identity = serde_json::from_str(&compare(&store, &expected).unwrap()).unwrap();
    assert_eq!(spent.generation, "1");
    assert_eq!(spent.revision, "2");
    let snapshot = store.reservation_snapshot(&scope, "a", "funding").unwrap();
    store
        .commit_retiring_reservation(
            &scope,
            &batch(2, "retired"),
            &Retirement {
                namespace: "a".into(),
                key: "funding".into(),
                revision: snapshot.revision,
                binding: snapshot.binding,
                generation: snapshot.generation.unwrap(),
            },
        )
        .unwrap();
    store
        .commit_reserving(&scope, &batch(3, "accepted again"), &request())
        .unwrap();
    assert!(compare(&store, &expected).is_err());
    let current = Identity::observe(&store, &scope, "a", "funding").unwrap();
    let latest: Identity =
        serde_json::from_str(&compare(&store, &bound(&current)).unwrap()).unwrap();
    assert_eq!(latest.generation, "2");
    assert_eq!(latest.revision, "1");
    let report = std::env::var("SIGIL_GENERATION_COMPARATOR_REPORT").unwrap();
    std::fs::write(
        report,
        serde_json::to_vec_pretty(&serde_json::json!({
            "observations": observations, "first_generation":"1", "reused_generation":"2",
            "same_coordinate_and_binding":true, "stale_binding_refused":true,
            "actual_native_store":true, "actual_compiled_sigil":true, "product_qualified":false,
        }))
        .unwrap(),
    )
    .unwrap();
}

#[test]
#[ignore = "invoked with pinned compiled SIGIL admission and actual allocation proposal"]
fn actual_sigil_allocation_identity_and_reservation_commit_atomically() {
    #[derive(serde::Deserialize)]
    struct Fixture {
        worker: crate::WorkerConfig,
        admitted: String,
        report: std::path::PathBuf,
    }
    let path = std::env::var("SIGIL_GENERATION_ADMISSION_FIXTURE").unwrap();
    let f: Fixture = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let mut function = crate::Function::new(f.worker).unwrap();
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let path = d.path().join(name);
        std::fs::create_dir(&path).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let namespaces: Vec<String> = [
        "a.requests",
        "a.operations",
        "a.state",
        "a.intent",
        "a.budget",
        "a.reservation",
    ]
    .into_iter()
    .map(String::from)
    .collect();
    let mut store = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "pool".into(),
                namespaces: namespaces.clone(),
                records: 10000,
                live_bytes: 100_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("pool".into(), 128)]),
    )
    .unwrap();
    let scope = store
        .scope(
            namespaces
                .into_iter()
                .map(|n| (n, Access::ReadWrite))
                .collect(),
        )
        .unwrap();
    let original = crate::fields(&f.admitted, "AD2\n", 4).unwrap();
    let requested: crate::capacity::Reserve = serde_json::from_str(original[3]).unwrap();
    let proposal = plan_wire(&store, &scope, &requested.namespace, &requested.key).unwrap();
    let output = function
        .invoke(
            crate::frame("GP1\n", &[&proposal, &f.admitted]).unwrap(),
            std::time::Instant::now() + std::time::Duration::from_secs(30),
        )
        .unwrap();
    let bound = crate::fields(&output, "AD2\n", 4).unwrap();
    assert_eq!(bound[2], original[2]);
    let batch = crate::action::commit_batch(bound[1]).unwrap();
    let planned: crate::capacity::Reserve = serde_json::from_str(bound[3]).unwrap();
    let expected = planned.expected_generation.unwrap().native().unwrap();
    // This integration exercises the allocation/data boundary. Audit allowance
    // admission has separate tests; no effect or full service turn occurs here.
    let published = store
        .commit_reserving_generation_audited(
            &scope,
            &batch,
            &Request {
                namespace: planned.namespace.clone(),
                key: planned.key.clone(),
                binding: crate::digest_bytes(&planned.binding).unwrap(),
                credits: Credits {
                    records: planned.records,
                    live_bytes: planned.live_bytes,
                },
            },
            &[],
            &expected,
        )
        .unwrap();
    assert_eq!(published.held.unwrap().generation(), Some(&expected));
    for write in &batch.writes {
        assert_eq!(
            store
                .get(&scope, &write.namespace, &write.key)
                .unwrap()
                .value,
            write.value
        );
    }
    let identity_record = store
        .get(
            &scope,
            &planned.namespace,
            &format!("generation:{}", planned.key),
        )
        .unwrap();
    let values = crate::fields(identity_record.value.as_deref().unwrap(), "GB1\n", 6).unwrap();
    assert_eq!(
        values,
        [
            planned.namespace.as_str(),
            planned.key.as_str(),
            expected.pool.as_str(),
            &expected.slot.to_string(),
            &expected.generation.to_string(),
            planned.binding.as_str()
        ]
    );
    assert_eq!(identity_record.revision, published.receipt.revision);
    std::fs::write(f.report,serde_json::to_vec_pretty(&serde_json::json!({
        "native_proposal":proposal,"retained_identity":identity_record.value,"commit_revision":published.receipt.revision,
        "records":batch.writes.len(),"allocation":expected,"actual_compiled_sigil":true,
        "actual_native_commit":true,"audit_allowances_qualified":false,"product_qualified":false,
    })).unwrap()).unwrap();
}
