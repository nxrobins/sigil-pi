//! Frozen explicit ledger-slot allocations. SIGIL supplies the policy; this
//! mechanism checks summed ceilings and persists the exact admitted map.
use super::*;
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Stored {
    limits: Limits,
    allocation: capacity::Allocation,
    admission: [u8; 32],
    reservation_slots: BTreeMap<String, u16>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Witnessed {
    format: String,
    configuration: Stored,
}

pub(in crate::store) fn validate(
    allocation: &capacity::Allocation,
    slots: &BTreeMap<String, u16>,
) -> Result<()> {
    if slots.len() != allocation.pools.len() {
        return Err(Error::Invalid);
    }
    let mut total = 0usize;
    for pool in &allocation.pools {
        let n = *slots.get(&pool.id).ok_or(Error::Invalid)?;
        if n == 0 || u64::from(n) > pool.records {
            return Err(Error::Invalid);
        }
        total = total.checked_add(usize::from(n)).ok_or(Error::Limit)?;
    }
    if total > ENTRIES {
        return Err(Error::Limit);
    }
    Ok(())
}
pub(in crate::store) fn encode(
    limits: &Limits,
    allocation: Option<&capacity::Allocation>,
    admission: Option<[u8; 32]>,
    slots: Option<&BTreeMap<String, u16>>,
    profile: u8,
) -> Result<String> {
    let Some(slots) = slots else {
        return capacity::encode(limits, allocation, admission);
    };
    let allocation = allocation.ok_or(Error::Invalid)?;
    validate(allocation, slots)?;
    let stored = Stored {
        limits: limits.clone(),
        allocation: allocation.clone(),
        admission: admission.ok_or(Error::Invalid)?,
        reservation_slots: slots.clone(),
    };
    let raw = if profile >= 5 {
        serde_json::to_string(&Witnessed {
            format: if profile == 7 {
                super::super::anchored::FORMAT
            } else if profile == 6 {
                super::super::fenced::FORMAT
            } else {
                witness::FORMAT
            }
            .into(),
            configuration: stored,
        })
    } else {
        serde_json::to_string(&stored)
    }
    .map_err(|_| Error::Invalid)?;
    if raw.len() > capacity::ENCODED_BYTES {
        return Err(Error::Limit);
    }
    Ok(raw)
}
pub(in crate::store) fn matches(
    raw: &str,
    limits: &Limits,
    allocation: Option<&capacity::Allocation>,
    admission: Option<[u8; 32]>,
    slots: Option<&BTreeMap<String, u16>>,
    profile: u8,
) -> Result<bool> {
    let Some(slots) = slots else {
        return capacity::matches(raw, limits, allocation, admission);
    };
    if raw.len() > capacity::ENCODED_BYTES {
        return Err(Error::Corrupt);
    }
    let mut stored: Stored = if profile >= 5 {
        let decoded: Witnessed = serde_json::from_str(raw).map_err(|_| Error::Corrupt)?;
        if decoded.format
            != if profile == 7 {
                super::super::anchored::FORMAT
            } else if profile == 6 {
                super::super::fenced::FORMAT
            } else {
                witness::FORMAT
            }
        {
            return Err(Error::Corrupt);
        }
        decoded.configuration
    } else {
        serde_json::from_str(raw).map_err(|_| Error::Corrupt)?
    };
    stored
        .allocation
        .validate(&stored.limits)
        .map_err(|_| Error::Corrupt)?;
    validate(&stored.allocation, &stored.reservation_slots).map_err(|_| Error::Corrupt)?;
    Ok(stored.limits == *limits
        && Some(&stored.allocation) == allocation
        && Some(stored.admission) == admission
        && stored.reservation_slots == *slots)
}
