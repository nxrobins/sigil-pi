"""Opt-in bounded context on top of atomic archive-v1 admission."""

import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_lifecycle import compose_lifecycle

ROOT = Path(__file__).resolve().parent.parent


def compose_context_window(name, stdlib):
    starts = {"admission", "turn", "turn_completion"}
    if name not in starts | {"dispatch_cancellable", "preclaim_cancellable"}:
        raise ValueError("context window composes only turn and model-request consumers")
    base = compose_lifecycle(name, stdlib)
    inputs = dict(base.input_hashes)
    body = base.text
    if name in starts:
        old = "history = workspace_history(previous);"
        if body.count(old) != 1:
            raise ValueError("context window requires exactly one continuation site")
        raw = (ROOT / "app/pi/context_window.sigil").read_bytes()
        body = compact(body.replace(old, "history = context_window(previous,cfg);if history < 0{return history;}")
                       + "\n" + raw.decode())
        inputs["app/pi/context_window.sigil"] = hashlib.sha256(raw).hexdigest()
    # This explicit local-model profile controls thinking in the SIGIL request,
    # not in the test relay or a native application branch. Without it the local
    # model can exhaust the whole output/deadline budget on auxiliary thinking.
    model_prefix = r'text("{\"model\":")'
    if body.count(model_prefix) != 1:
        raise ValueError("context profile requires one model-request constructor")
    body = body.replace(model_prefix, r'text("{\"thinking\":{\"type\":\"disabled\"},\"model\":")')
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("context window exceeds source/entry contract")
    inputs["scripts/compose_context_window.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return ApplicationSource(body, inputs, base.stdlib_hash)
