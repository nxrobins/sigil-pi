use super::*;
use sigil_durable_store::store::{
    Limits, OpenMode,
    capacity::{Allocation, Pool},
};
use std::os::unix::fs::PermissionsExt;

#[test]
fn generational_capacity_requires_exact_proposal_before_any_publication() {
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let path = d.path().join(name);
        std::fs::create_dir(&path).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let mut store = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        &d.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "pool".into(),
                namespaces: vec!["a".into()],
                records: 128,
                live_bytes: 1000000,
            }],
        },
        [3; 32],
        BTreeMap::from([("pool".into(), 8)]),
    )
    .unwrap();
    let grants = BTreeMap::from([("a".into(), Access::ReadWrite)]);
    let scope = store.scope(grants.clone()).unwrap();
    // Empty logs isolate the exact allocation dispatch. Production admission
    // independently requires the configured signed effect/transaction logs.
    let capacity = Capacity {
        targets: BTreeMap::from([(
            "a".into(),
            Target {
                scope: store.scope(grants).unwrap(),
                logs: BTreeMap::new(),
            },
        )]),
    };
    let batch = |key: &str| Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: key.into(),
            revision: 0,
            value: Some("SIGIL proposed record".into()),
        }],
    };
    let mut raw = serde_json::json!({"namespace":"a","key":"first","binding":"8".repeat(64),"records":1,"live_bytes":1000,"audits":{}});
    assert_eq!(
        capacity.reserve(
            &mut store,
            &scope,
            &batch("first"),
            serde_json::from_value(raw.clone()).unwrap()
        ),
        Err("funding_identity")
    );
    assert_eq!(store.get(&scope, "a", "first").unwrap().revision, 0);
    raw["expected_generation"] = serde_json::json!({"pool":"pool","slot":0,"generation":"1"});
    capacity
        .reserve(
            &mut store,
            &scope,
            &batch("first"),
            serde_json::from_value(raw.clone()).unwrap(),
        )
        .unwrap();
    assert_eq!(
        store
            .reservation_snapshot(&scope, "a", "first")
            .unwrap()
            .generation
            .unwrap()
            .slot,
        0
    );
    raw["key"] = serde_json::json!("second");
    assert!(
        capacity
            .reserve(
                &mut store,
                &scope,
                &batch("second"),
                serde_json::from_value(raw.clone()).unwrap()
            )
            .is_err()
    );
    assert_eq!(store.get(&scope, "a", "second").unwrap().revision, 0);
    assert_eq!(
        store
            .next_reservation_generation(&scope, "a", "second")
            .unwrap()
            .slot,
        1
    );
    raw["expected_generation"]["slot"] = serde_json::json!(1);
    capacity
        .reserve(
            &mut store,
            &scope,
            &batch("second"),
            serde_json::from_value(raw).unwrap(),
        )
        .unwrap();
    assert_eq!(
        store
            .reservation_snapshot(&scope, "a", "second")
            .unwrap()
            .generation
            .unwrap()
            .slot,
        1
    );
}

#[test]
fn generation_entry_has_an_explicit_bounded_step_budget() {
    use crate::action::EntryContract;
    assert_eq!(EntryContract::Generational.max_steps(), 12);
    for profile in [
        EntryContract::Funded,
        EntryContract::Legacy,
        EntryContract::Metadata,
        EntryContract::HttpExchange,
        EntryContract::RequestAdmission,
        EntryContract::ProcessFacts,
    ] {
        assert_eq!(profile.max_steps(), 8);
    }
}

#[test]
#[ignore = "invoked with pinned SIGIL API, admission and generation functions"]
fn actual_sigil_api_admission_binds_generation_and_signed_capacity() {
    use sigil_durable_store::store::authenticated_log::ChainLimits;
    #[derive(serde::Deserialize)]
    struct Fixture {
        entry: crate::WorkerConfig,
        functions: BTreeMap<String, crate::WorkerConfig>,
        facts: String,
        body: String,
        report: std::path::PathBuf,
    }
    let f: Fixture = serde_json::from_slice(
        &std::fs::read(std::env::var("SIGIL_GENERATION_API_FIXTURE").unwrap()).unwrap(),
    )
    .unwrap();
    let audit_worker = f.functions["admission"].clone();
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let path = d.path().join(name);
        std::fs::create_dir(&path).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let namespaces: Vec<String> = [
        "a.requests",
        "a.operations",
        "a.state",
        "a.intent",
        "a.budget",
        "a.reservation",
        "a.state.archive",
        "a.effect.heads",
        "a.effect.records",
        "a.transaction.heads",
        "a.transaction.records",
    ]
    .into_iter()
    .map(String::from)
    .collect();
    let limits = Limits::default();
    let allocation = Allocation {
        version: 1,
        pools: vec![Pool {
            id: "pool".into(),
            namespaces: namespaces.clone(),
            records: 10000,
            live_bytes: 100_000_000,
        }],
    };
    let storage = crate::storage_admission::Config {
        policy: "storage".into(),
        parameters: String::new(),
        allocation: allocation.clone(),
        reservation_slots: Some(BTreeMap::from([("pool".into(), 128)])),
        restore_authority: Some(d.path().join("authority").canonicalize().unwrap()),
    };
    let mut machine = crate::Machine::new(
        f.entry,
        f.functions,
        None,
        crate::action::EntryContract::Generational,
        None,
        None,
        Some(&storage),
    )
    .unwrap();
    let mut store = Store::open_anchored_reserved_bound(
        &d.path().join("data").canonicalize().unwrap(),
        storage.restore_authority.as_ref().unwrap(),
        OpenMode::CreateNew,
        limits,
        allocation,
        [3; 32],
        BTreeMap::from([("pool".into(), 128)]),
    )
    .unwrap();
    let grants: BTreeMap<_, _> = namespaces
        .into_iter()
        .map(|n| (n, Access::ReadWrite))
        .collect();
    let scope = store.scope(grants.clone()).unwrap();
    let read_scope = store
        .scope(grants.keys().map(|n| (n.clone(), Access::Read)).collect())
        .unwrap();
    let mut logs = BTreeMap::new();
    for (alias, digit) in [("effect", '6'), ("transaction", '7')] {
        let config = audited_transaction::Config {
            version: 1,
            worker: audit_worker.clone(),
            evaluation: None,
            key_env: "FIXTURE_ONLY".into(),
            chain: digit.to_string().repeat(64),
            heads: format!("a.{alias}.heads"),
            records: format!("a.{alias}.records"),
            limits: ChainLimits {
                payload_bytes: 8192,
                records: 1000,
                bytes: 16 * 1024 * 1024,
            },
        };
        let log = AuthenticatedLog::new(
            &store,
            &config.heads,
            &config.records,
            config.limits,
            b"fixture-signing-key-not-for-deployment-0123456789",
        )
        .unwrap();
        logs.insert(alias.into(), Log { config, log });
    }
    machine.capacity = Some(Capacity {
        targets: BTreeMap::from([(
            "a.reservation".into(),
            Target {
                scope: store.scope(grants).unwrap(),
                logs,
            },
        )]),
    });
    let context = |id: &str, body: &str, facts: &str| crate::Context {
        request: crate::Request {
            method: "POST".into(),
            path: "/v1/operations".into(),
            authorization: None,
            body: body.into(),
            request_id_hints: vec![],
        },
        facts: facts.into(),
        id: id.repeat(64),
        mode: "request",
        http_request_facts: String::new(),
        presentation: crate::Presentation::Other,
    };
    let mut clock = 0;
    let first = machine
        .run(
            context("a", &f.body, &f.facts),
            Some(&mut store),
            Some(&scope),
            &mut clock,
            None,
            None,
        )
        .unwrap();
    assert_eq!(first.reply.status, 202, "{}", first.reply.body);
    let op = "a".repeat(64);
    let snapshot = store
        .reservation_snapshot(&scope, "a.reservation", &op)
        .unwrap();
    let generation = snapshot.generation.unwrap();
    let retained = store
        .get(&scope, "a.reservation", &format!("generation:{op}"))
        .unwrap();
    assert_eq!(
        crate::fields(retained.value.as_ref().unwrap(), "GB1\n", 6).unwrap(),
        ["a.reservation", op.as_str(), "pool", "0", "1", op.as_str()]
    );
    for (namespace, key) in [
        ("a.operations", op.as_str()),
        ("a.reservation", op.as_str()),
        ("a.state", "same-session"),
        ("a.budget", "active"),
    ] {
        assert_eq!(
            store.get(&scope, namespace, key).unwrap().revision,
            retained.revision
        );
    }
    let held = crate::reservation_identity::Identity::observe(&store, &scope, "a.reservation", &op)
        .unwrap()
        .resume(&store, &scope, "a.reservation", &op)
        .unwrap();
    let logs = &machine.capacity.as_ref().unwrap().targets["a.reservation"].logs;
    let mut audit_allowances = 0;
    for log in logs.values() {
        log.log
            .check_held_allowance(&held, &log.config.chain, 1, log.log.encoded_entry_ceiling())
            .unwrap();
        audit_allowances += 1;
    }
    assert_eq!(audit_allowances, 2);
    let replay = machine
        .run(
            context("b", &f.body, &f.facts),
            Some(&mut store),
            Some(&scope),
            &mut clock,
            None,
            None,
        )
        .unwrap();
    assert_eq!(replay.reply.status, 202);
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(&replay.reply.body).unwrap()["replayed"],
        true
    );
    assert_eq!(
        store
            .next_reservation_generation(&scope, "a.reservation", &"b".repeat(64))
            .unwrap()
            .slot,
        1
    );
    let mut other: serde_json::Value = serde_json::from_str(&f.body).unwrap();
    other["session"] = "other-session".into();
    other["submission_key"] = "other-key".into();
    let denied = machine
        .run(
            context("c", &other.to_string(), &f.facts),
            Some(&mut store),
            Some(&read_scope),
            &mut clock,
            None,
            None,
        )
        .unwrap();
    assert_eq!(denied.reply.status, 503);
    assert_eq!(
        store
            .get(&scope, "a.operations", &"c".repeat(64))
            .unwrap()
            .revision,
        0
    );
    assert_eq!(
        store
            .next_reservation_generation(&scope, "a.reservation", &"c".repeat(64))
            .unwrap()
            .slot,
        1
    );
    let unauthorized = machine
        .run(
            context("d", &other.to_string(), ""),
            Some(&mut store),
            None,
            &mut clock,
            None,
            None,
        )
        .unwrap();
    assert_eq!(unauthorized.reply.status, 401);
    std::fs::write(f.report,serde_json::to_vec_pretty(&serde_json::json!({"actual_compiled_api":true,"actual_native_machine":true,
        "generation":generation,"audit_allowances":audit_allowances,"commit_revision":retained.revision,
        "accepted":first.reply.status,"replay":replay.reply.status,"readonly_refused":denied.reply.status,"unauthorized":unauthorized.reply.status,
        "next_slot":1,"http_transport_qualified":false,"effect_qualified":false,"product_qualified":false})).unwrap()).unwrap();
}

#[test]
fn prefixed_lookup_is_bounded_and_never_expands_the_declared_namespace() {
    use crate::policy::{Input, Key};
    let key = Key::PrefixedValue {
        prefix: "generation:".into(),
        index: 0,
    };
    assert!(key.valid(1));
    assert!(!key.valid(0));
    assert_eq!(
        key.resolve(&["a".repeat(64)]).unwrap(),
        format!("generation:{}", "a".repeat(64))
    );
    assert_eq!(key.resolve(&["a".repeat(245)]).unwrap().len(), 256);
    for value in [
        "a".repeat(246),
        "../other".into(),
        "x\0y".into(),
        " space".into(),
    ] {
        assert_eq!(key.resolve(&[value]), Err("protocol"));
    }
    assert_eq!(key.resolve(&[]), Err("protocol"));
    for raw in [
        r#"{"kind":"prefixed_value","prefix":"generation:","index":0,"namespace":"other"}"#,
        r#"{"kind":"prefixed_value","prefix":null,"index":0}"#,
    ] {
        assert!(serde_json::from_str::<Key>(raw).is_err());
    }
    let parsed: Input = serde_json::from_str(
        r#"{"kind":"reservation","namespace":"a.reservation","key":{"kind":"value","index":0}}"#,
    )
    .unwrap();
    assert!(matches!(parsed, Input::Reservation { .. }));
}
