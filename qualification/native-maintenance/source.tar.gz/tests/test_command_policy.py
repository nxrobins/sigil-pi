"""Compiled SIGIL authority and input checks for command workers."""

import pytest
import json
from conftest import SIGIL_ROOT, forge_ok
from scripts.compose_workspace import compose_workspace
from test_workspace_agent import dispatch_view
from turn_support import fields, record, refused


def command_view(mcp, arguments=None):
    values = dispatch_view(
        mcp,
        tool="build_project",
        arguments={"path": "."},
    )
    if arguments is not None:
        # Exercise dispatch independently of the reducer's earlier argument
        # rejection, including retained malformed intents from an older build.
        state_read = fields(values[6], "SR1\n", 3)
        state = fields(state_read[2], "PT1\n", 17)
        pending = json.loads(state[6])
        pending[0]["input"] = arguments
        state[6] = json.dumps(pending)
        history = json.loads(state[5])
        history[-1]["content"] = pending
        state[5] = json.dumps(history)
        state_read[2] = record("PT1\n", state)
        values[6] = record("SR1\n", state_read)
        intent_read = fields(values[7], "SR1\n", 3)
        intent = fields(intent_read[2], "SI1\n", 5)
        intent[4] = json.dumps(arguments)
        intent_read[2] = record("SI1\n", intent)
        values[7] = record("SR1\n", intent_read)
    actual = fields(values[10], "EF2\n", 8)
    actual[7] = "[]"
    values[10] = record("EF3\n", actual + ["container-v1"])
    return values


def test_command_policy_produces_fixed_input_only(mcp):
    source = compose_workspace("dispatch_cancellable", SIGIL_ROOT).text
    out = fields(
        forge_ok(mcp, source, record("DF2\n", command_view(mcp)), fuel=300000000),
        "DW1\n",
        7,
    )
    assert out[1] == "CW1\n"


@pytest.mark.parametrize(
    "arguments",
    [
        {"path": ".", "command": "sh"},
        {"path": ".", "argv": ["/bin/sh"]},
        {"path": ".", "env": {"TOKEN": "secret"}},
        {"path": ".", "image": "other"},
        {"path": "../other"},
        {"path": "/etc"},
        {"path": ".;echo bad"},
        {},
    ],
)
def test_command_policy_denies_model_selected_authority(mcp, arguments):
    refused(
        mcp,
        compose_workspace("dispatch_cancellable", SIGIL_ROOT).text,
        record("DF2\n", command_view(mcp, arguments)),
        400,
    )


@pytest.mark.parametrize(
    "index,value",
    [
        (2, "e" * 64),
        (3, "e" * 64),
        (4, '["example.com"]'),
        (5, '["/permitted","/elsewhere"]'),
        (6, '["provider"]'),
        (7, '["/permitted"]'),
        (8, "sigil"),
        (8, "unknown"),
    ],
)
def test_command_policy_requires_actual_scoped_container_facts(mcp, index, value):
    values = command_view(mcp)
    actual = fields(values[10], "EF3\n", 9)
    actual[index] = value
    values[10] = record("EF3\n", actual)
    refused(
        mcp,
        compose_workspace("dispatch_cancellable", SIGIL_ROOT).text,
        record("DF2\n", values),
        403,
    )


def test_old_dispatch_policy_does_not_accept_new_executor_facts(mcp):
    from scripts.compose_application import compose_application

    refused(
        mcp,
        compose_application("dispatch_cancellable", SIGIL_ROOT).text,
        record("DF2\n", command_view(mcp)),
        400,
    )


@pytest.mark.parametrize(
    "variant,expected",
    [
        ("pass", True),
        ("fail", True),
        ("pending", True),
        ("narration", False),
        ("user_text", False),
        ("previous_turn", False),
        ("wrong_id", False),
        ("uncertain", False),
        ("worker_error", False),
    ],
)
def test_baseline_requires_current_turn_observed_command(mcp, variant, expected):
    source = compose_workspace("dispatch_cancellable", SIGIL_ROOT).text.replace(
        "pub fn tool_main(", "fn dispatch_main("
    )
    source += """
pub fn tool_main(input_ptr: i64, input_len: i64) -> i64 @Internal ! { Alloc } {
    let values: i64 @Internal = read_record(slice(input_ptr, input_len), "BC1\\n", 3);
    if values < 0 { return values; }
    let turn_state: i64 @Internal = alloc(136);
    put(turn_state, 5, get(values, 0)); put(turn_state, 6, get(values, 1)); put(turn_state, 8, get(values, 2));
    if workspace_baseline(turn_state) { return text("yes"); } return text("no");
}
"""
    call = {
        "type": "tool_use",
        "id": "check",
        "name": "build_project",
        "input": {"path": "."},
    }
    content = '[build_project path="."]\n' + (
        "FAIL: command exited 2\nstderr: compiler error"
        if variant == "fail"
        else "PASS: command exited 0."
    )
    if variant == "uncertain":
        content = "This tool may have run; do not repeat it automatically."
    if variant == "worker_error":
        content = '[build_project path="."]\nbuild_project returned error code 413'
    result = {
        "type": "tool_result",
        "tool_use_id": "other" if variant == "wrong_id" else "check",
        "content": content,
    }
    history = [
        {"role": "user", "content": "repair"},
        {"role": "assistant", "content": [call]},
        {"role": "user", "content": [result]},
    ]
    pending, results = [], []
    if variant == "pending":
        history = history[:-1]
        pending, results = [call], [result]
    if variant == "narration":
        history = [
            {"role": "assistant", "content": [{"type": "text", "text": content}]}
        ]
    if variant == "user_text":
        history = [{"role": "user", "content": json.dumps(result)}]
    if variant == "previous_turn":
        history += [{"role": "user", "content": "a new task"}]
    raw = record(
        "BC1\n", [json.dumps(history), json.dumps(pending), json.dumps(results)]
    )
    assert forge_ok(mcp, source, raw, fuel=300000000) == ("yes" if expected else "no")
