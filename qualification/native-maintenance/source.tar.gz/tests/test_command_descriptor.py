"""Reject bad native command descriptors before contacting the engine."""

import hashlib
import json
import subprocess

import pytest
from test_container_worker import ROOT, configure
from test_container_worker import pytestmark as pytestmark


@pytest.mark.parametrize(
    "field,value",
    [
        ("schema", "other"),
        ("image", "rust:latest"),
        ("image", "sha256:" + "z" * 64),
        ("argv", []),
        ("argv", ["make"]),
        ("socket", "relative.sock"),
        ("workspace", "/other-root"),
        ("slot", "other-slot"),
        ("wall_ms", 0),
        ("wall_ms", 30001),
        ("memory_bytes", 1),
        ("memory_bytes", 1024 * 1024 * 1024),
        ("pids", 0),
        ("pids", 129),
        ("output_bytes", 65536),
        ("unexpected_grant", True),
    ],
)
def test_invalid_descriptor_never_starts_worker(tmp_path, field, value):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    path, descriptor = configure(tmp_path / "deployment", workspace, ["/bin/true"])
    descriptor[field] = value
    config = json.loads(path.read_text())
    source = path.parent / "command.json"
    source.write_text(json.dumps(descriptor))
    config["source_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
    path.write_text(json.dumps(config))
    proc = subprocess.run(
        [str(ROOT / "native/worker/target/release/sigil-worker"), str(path)],
        input="",
        text=True,
        capture_output=True,
        timeout=10,
    )
    assert proc.returncode == 2 and proc.stdout == ""
    assert json.loads(proc.stderr)["code"] == "invalid"


@pytest.mark.parametrize(
    "field,value",
    [
        ("net", ["example.com"]),
        ("fs_write", ["/anything"]),
        ("secret_env", {"provider": "UNAVAILABLE_SECRET"}),
        ("source_sha256", "0" * 64),
        ("runtime_sha256", "0" * 64),
    ],
)
def test_command_worker_refuses_extra_authority_or_changed_artifact(
    tmp_path, field, value
):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    path, _ = configure(tmp_path / "deployment", workspace, ["/bin/true"])
    config = json.loads(path.read_text())
    config[field] = value
    path.write_text(json.dumps(config))
    proc = subprocess.run(
        [str(ROOT / "native/worker/target/release/sigil-worker"), str(path)],
        input="",
        text=True,
        capture_output=True,
        timeout=10,
    )
    assert proc.returncode == 2 and proc.stdout == ""
    assert json.loads(proc.stderr)["code"] == "invalid"
