"""Actual authenticated native/SIGIL archive reads, not a projection-only oracle."""

import hashlib
import json
import os
from pathlib import Path
import sqlite3
import time

from api_support import TOKEN_A, TOKEN_B
from automatic_support import wait_operation
from conftest import MCP_BIN, FIXED_EVALUATOR_BIN, SIGIL_ROOT
from scripts.build_archive_export_deployment import build, add_projection
from scripts.workspace_deployment import configuration, record
from test_completion_capacity_service import setup_env, prepared_service
from test_history_archive_service import archived_profile, response
from test_workspace_agent import call
from turn_support import fields


def rows(root):
    with sqlite3.connect(f"file:{root / 'records/records.sqlite'}?mode=ro", uri=True) as db:
        return db.execute("SELECT namespace,key,revision,value FROM records ORDER BY namespace,key").fetchall()


def test_export_is_revision_bound_read_only_and_tenant_scoped(scripted_llm, tmp_path, monkeypatch):
    setup_env(monkeypatch)
    evaluator = Path(os.environ.get("PI_ARCHIVE_EXPORT_EVALUATOR", str(FIXED_EVALUATOR_BIN)))
    areas = [tmp_path / "a", tmp_path / "b"]
    for area in areas:
        area.mkdir()
    profile = {**archived_profile(), "public_archive_export": "v1"}
    template, _ = build(tmp_path / "seed", areas[0], MCP_BIN, evaluator,
                        SIGIL_ROOT, TOKEN_A, profile, endpoint=scripted_llm.url)
    first = template["credentials"][0]
    facts = fields(first["facts"], "CF2\n", 15)
    facts[0], facts[1], facts[2] = "second-user", "Équipe 一 / example.org", "second-policy"
    for index in [7, 8, 10, 11, 12, 13]:
        facts[index] = "second" + facts[index][len("workspace"):]
    second = {"sha256": hashlib.sha256(TOKEN_B.encode()).hexdigest(), "facts": record("CF2\n", facts),
              "grants": {facts[i]: "read_write" for i in [7, 8, 10, 11, 12, 13]}}
    second["grants"][facts[10] + ".archive"] = "read_write"
    programs = {alias: Path(effect["worker"]["source"]).read_text()
                for alias, effect in template["automatic"]["participants"][0]["effects"].items()}
    root = tmp_path / "deployment"
    config = configuration(root, programs, scripted_llm.url, areas, [first, second], MCP_BIN,
                           evaluator, SIGIL_ROOT, funded=profile["completion_capacity"], lifecycle="archive-v1")
    add_projection(root, config, SIGIL_ROOT)
    (root / "service.json").write_text(json.dumps(config))
    scripted_llm.script = [response("A-private-history"), response("B-private-history"), response("A-follow-up"), response("B-follow-up"), response("A-third")]
    accepted = []
    with prepared_service(root) as api:
        for key in ["first", "second"]:
            for token in [TOKEN_A, TOKEN_B]:
                code, operation = api.request(token=token, body={"session": "same", "submission_key": key, "message": "Remember this"})
                assert code == 202, operation
                assert wait_operation(api, operation["operation"], token=token)["status"] == "done"
                accepted.append(operation)
        before = rows(root)
        assert api.request("GET", "/v1/sessions/same/export")[0] == 501
        index_revisions = []
        for index, token in enumerate([TOKEN_A, TOKEN_B]):
            status, directory = api.request("GET", "/v1/sessions/same/archives?limit=1", token=token)
            assert status == 200, directory
            assert directory["archives"] == [{"operation": accepted[index]["operation"], "archive_revision": "1"}]
            assert directory["current"]["operation"] == accepted[index + 2]["operation"]
            index_revisions.append(directory["state_revision"])
            status, end = api.request("GET", "/v1/sessions/same/archives?limit=1&after=" + directory["next_after"]
                                      + "&revision=" + directory["state_revision"], token=token)
            assert status == 200 and end["archives"] == [] and end["next_after"] is None
            assert api.request("GET", directory["current"]["messages_url"], token=token)[0] == 200
            path = "/v1/sessions/same/archives?operation=" + accepted[index]["operation"]
            status, first_page = api.request("GET", path + "&limit=1", token=token)
            assert status == 200, first_page
            assert first_page["context_snapshot"]["next_offset"] == 1
            assert first_page["operation_result"]["reply"] == ["A-private-history", "B-private-history"][index]
            status, last_page = api.request("GET", path + "&revision=1&offset=1&limit=1", token=token)
            assert status == 200 and last_page["context_snapshot"]["next_offset"] is None
            assert ["B-private-history", "A-private-history"][index] not in json.dumps(last_page)
            assert api.request("GET", path, token=[TOKEN_B, TOKEN_A][index])[0] == 404
            assert api.request("GET", path + "&revision=2", token=token)[0] == 409
            assert api.request("GET", path + "&offset=1", token=token)[0] == 400
            assert api.request("GET", path + "&limit=0", token=token)[0] == 400
            assert api.request("GET", path + "&limit=1&limit=2", token=token)[0] == 400
            assert api.request("GET", path + "&unknown=1", token=token)[0] == 400
            assert api.request("GET", path, token="invalid")[0] == 401
        assert rows(root) == before, "exports must not create or modify persistent data"
        code, third = api.request(body={"session": "same", "submission_key": "third", "message": "Continue"})
        assert code == 202 and wait_operation(api, third["operation"])["status"] == "done"
        assert api.request("GET", "/v1/sessions/same/archives?revision=" + index_revisions[0])[0] == 409
        calls = len(scripted_llm.requests)
    with prepared_service(root, mode="open") as api:
        path = "/v1/sessions/same/archives?operation=" + accepted[0]["operation"]
        status, exported = api.request("GET", path)
        assert status == 200 and exported["operation_result"]["reply"] == "A-private-history"
    assert len(scripted_llm.requests) == calls


def test_archive_read_scope_is_checked_before_existence_or_storage_access(scripted_llm, tmp_path, monkeypatch):
    setup_env(monkeypatch)
    evaluator = Path(os.environ.get("PI_ARCHIVE_EXPORT_EVALUATOR", str(FIXED_EVALUATOR_BIN)))
    area = tmp_path / "workspace"
    area.mkdir()
    profile = {**archived_profile(), "public_archive_export": "v1"}
    template, _ = build(tmp_path / "seed", area, MCP_BIN, evaluator,
                        SIGIL_ROOT, TOKEN_A, profile, endpoint=scripted_llm.url)
    credential = template["credentials"][0]
    facts = fields(credential["facts"], "CF2\n", 15)
    facts[5] = json.dumps(["chat"])
    credential["facts"] = record("CF2\n", facts)
    programs = {alias: Path(effect["worker"]["source"]).read_text()
                for alias, effect in template["automatic"]["participants"][0]["effects"].items()}
    root = tmp_path / "deployment"
    config = configuration(root, programs, scripted_llm.url, area, [credential], MCP_BIN,
                           evaluator, SIGIL_ROOT, funded=profile["completion_capacity"], lifecycle="archive-v1")
    add_projection(root, config, SIGIL_ROOT)
    (root / "service.json").write_text(json.dumps(config))
    with prepared_service(root) as api:
        before = rows(root)
        for suffix in ("", "?operation=" + "a" * 64):
            status, body = api.request("GET", "/v1/sessions/missing/archives" + suffix)
            assert status == 403 and body["error"]["code"] == "permission_denied"
        assert rows(root) == before
    assert scripted_llm.requests == []


def test_partial_batch_cancellation_exports_observation_and_unfinished_calls_after_restart(scripted_llm, tmp_path, monkeypatch):
    setup_env(monkeypatch)
    evaluator = Path(os.environ.get("PI_ARCHIVE_EXPORT_EVALUATOR", str(FIXED_EVALUATOR_BIN)))
    area, root = tmp_path / "workspace", tmp_path / "deployment"
    area.mkdir()
    marker = "actual first read observation"
    (area / "note.txt").write_text(marker)
    batch = call("read_file", {"path": "note.txt"}, id="read-0")
    batch["content"] += [call("read_file", {"path": "note.txt"}, id=f"read-{i}")["content"][0] for i in range(1, 4)]
    scripted_llm.script = [batch, response("new authorized turn")]
    build(root, area, MCP_BIN, evaluator, SIGIL_ROOT, TOKEN_A,
          {**archived_profile(), "public_archive_export": "v1"}, endpoint=scripted_llm.url)
    with prepared_service(root) as api:
        code, first = api.request(body={"session": "partial", "submission_key": "first", "message": "Read notes"})
        assert code == 202
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            current = [r for r in rows(root) if r[0] == "workspace.state"]
            if current:
                state = fields(bytes(current[0][3]).decode(), "PT1\n", 17)
                if state[1] == "tool" and state[7] == "1":
                    assert marker in state[8]
                    break
                assert state[1] in {"model", "tool"} and int(state[7]) <= 1, state[1:3]
            time.sleep(0.01)
        else:
            raise AssertionError("did not observe the first committed tool result")
        code, cancelled = api.request("POST", first["status_url"] + "/cancel", body={})
        assert code == 202, cancelled
        stopped = wait_operation(api, first["operation"])
        assert stopped["status"] == "cancelled", stopped
        assert len(scripted_llm.requests) == 1
        before = rows(root)
        code, current = api.request("GET", "/v1/sessions/partial/messages")
        assert code == 200 and current["state_phase"] == "cancelled", current
        results = current["messages"][-2]["content"]
        assert [r["call_id"] for r in results] == [f"read-{i}" for i in range(4)]
        assert marker in results[0]["text"] and not results[0]["is_error"]
        assert all(r["is_error"] and "may have run" in r["text"] for r in results[1:])
        assert rows(root) == before
    with prepared_service(root, mode="open") as api:
        assert len(scripted_llm.requests) == 1
        assert api.request("GET", "/v1/sessions/partial/messages")[1] == current
        code, follow = api.request(body={"session": "partial", "submission_key": "follow", "message": "Continue without repeating reads"})
        assert code == 202 and wait_operation(api, follow["operation"])["status"] == "done"
        assert api.request("GET", "/v1/sessions/partial/messages?revision=" + current["state_revision"])[0] == 409
        before = rows(root)
        code, public = api.request("GET", "/v1/sessions/partial/archives?operation=" + first["operation"])
        assert code == 200, public
        messages = public["context_snapshot"]["messages"]
        results = messages[-2]["content"]
        assert [r["call_id"] for r in results] == [f"read-{i}" for i in range(4)]
        assert marker in results[0]["text"] and not results[0]["is_error"]
        assert all(r["is_error"] and "No confirmed result" in r["text"] for r in results[1:])
        assert public["operation_result"] == stopped
        assert public["context_snapshot"]["messages"] == current["messages"]
        assert rows(root) == before
    with prepared_service(root, mode="open") as api:
        assert api.request("GET", "/v1/sessions/partial/archives?operation=" + first["operation"])[1] == public
    assert len(scripted_llm.requests) == 2


def test_truncated_proposals_export_not_executed_after_actual_refusal_and_restart(scripted_llm, tmp_path, monkeypatch):
    setup_env(monkeypatch)
    evaluator = Path(os.environ.get("PI_ARCHIVE_EXPORT_EVALUATOR", str(FIXED_EVALUATOR_BIN)))
    area, root = tmp_path / "workspace", tmp_path / "deployment"
    area.mkdir()
    (area / "note.txt").write_text("must not be read")
    limited = call("read_file", {"path": "note.txt"}, id="never-dispatched")
    limited["stop_reason"] = "max_tokens"
    scripted_llm.script = [limited, response("new authorized turn")]
    build(root, area, MCP_BIN, evaluator, SIGIL_ROOT, TOKEN_A,
          {**archived_profile(), "public_archive_export": "v1"}, endpoint=scripted_llm.url)
    with prepared_service(root) as api:
        code, first = api.request(body={"session": "limited", "submission_key": "first", "message": "Read notes"})
        assert code == 202
        result = wait_operation(api, first["operation"])
        assert result["status"] == "failed" and result["error"] == "model_output_limit"
        assert len([r for r in rows(root) if r[0] == "executor0.delivery"]) == 1
        before = rows(root)
        code, current = api.request("GET", "/v1/sessions/limited/messages")
        assert code == 200 and current["state_phase"] == "failed", current
        feedback = current["messages"][-2]["content"][0]
        assert feedback["call_id"] == "never-dispatched" and feedback["is_error"]
        assert feedback["text"].startswith("Not executed:")
        assert "must not be read" not in json.dumps(current)
        assert rows(root) == before
    with prepared_service(root, mode="open") as api:
        assert api.request("GET", "/v1/sessions/limited/messages")[1] == current
        code, follow = api.request(body={"session": "limited", "submission_key": "follow", "message": "Continue"})
        assert code == 202 and wait_operation(api, follow["operation"])["status"] == "done"
        code, public = api.request("GET", "/v1/sessions/limited/archives?operation=" + first["operation"])
        assert code == 200, public
        feedback = public["context_snapshot"]["messages"][-2]["content"][0]
        assert feedback["call_id"] == "never-dispatched" and feedback["is_error"]
        assert feedback["text"].startswith("Not executed:") and "before dispatch" in feedback["text"]
        assert "must not be read" not in json.dumps(public)
        assert public["operation_result"] == result
        assert public["context_snapshot"]["messages"] == current["messages"]
        assert len([r for r in rows(root) if r[0] == "executor0.delivery"]) == 2
    assert len(scripted_llm.requests) == 2
