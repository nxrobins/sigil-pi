"""Bind allocation facts to SIGIL admission, without host application policy."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource, strip_line_comments
from scripts.compose_reservation_identity import compose_reservation_identity

ROOT = Path(__file__).resolve().parent.parent


def compose_generation_admission(stdlib, *, root=ROOT):
    root = Path(root)
    base = compose_reservation_identity(stdlib, root=root)
    marker = "pub fn tool_main(input_ptr: i64, input_len: i64)"
    if base.text.count(marker) != 1:
        raise ValueError("generation comparator entry changed")
    body = base.text.replace(marker, "fn compare_allocation(input_ptr: i64 @Internal, input_len: i64 @Internal)")
    protocol = (root / "app/shared/store_protocol.sigil").read_text()
    if protocol.count("// STORE_READ_HELPERS_END") != 1:
        raise ValueError("store helper boundary changed")
    fragment = (root / "app/pi/generation_admission.sigil").read_bytes()
    cancel = (root / "app/pi/generation_cancel_binding.sigil").read_bytes()
    body += protocol.split("// STORE_READ_HELPERS_END")[1] + cancel.decode() + fragment.decode()
    text = strip_line_comments(body, compact_indent=True)
    if len(text.encode()) > 65536 or text.count("pub fn tool_main(") != 1:
        raise ValueError("generation admission exceeds source/entry limits")
    inputs = {**base.input_hashes,
        "app/pi/generation_admission.sigil":hashlib.sha256(fragment).hexdigest(),
        "app/pi/generation_cancel_binding.sigil":hashlib.sha256(cancel).hexdigest(),
        "scripts/compose_generation_admission.py":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    return ApplicationSource(text, inputs, base.stdlib_hash)
