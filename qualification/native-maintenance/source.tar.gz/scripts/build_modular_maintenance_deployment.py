"""Unpromoted profile-13 development assembly with an explicit seventh function."""
import hashlib
import json
from pathlib import Path

from scripts.build_maintenance_deployment import build as maintenance_build
from scripts.compose_dispatch_journal import with_dispatch_journal
from scripts.compose_modular_cancel import compose_modular_cancel


def build(root, workspace, runtime, evaluator, stdlib, token, profile, **kwargs):
    programs = compose_modular_cancel(stdlib)
    if profile.get('dispatch_journal') is not None:
        programs = {name: with_dispatch_journal(value) for name, value in programs.items()}
    config, path = maintenance_build(root, workspace, runtime, evaluator, stdlib, token, profile, **kwargs)
    root = Path(root).resolve()
    if config['version'] != 13 or len(config['functions']) != 6:
        raise ValueError('exact maintenance profile required')
    helper = dict(config['functions']['generation_admission'])
    if helper['net'] or helper['fs'] or helper.get('fs_write') or helper['secret_env'] or helper['version'] == 4:
        raise ValueError('cancellation helper must be grantless')
    config['functions']['cancel_core'] = helper
    for name, worker in [('api_discovery', config['worker']), ('cancel_core', helper)]:
        source = root / (name + '.sigil')
        source.write_text(programs[name].text)
        worker.update(source=str(source), source_sha256=programs[name].compiler_input_sha256)
    path.write_text(json.dumps(config, indent=2) + '\n')
    inventory = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'build-inputs.json'}
    (root / 'build-inputs.json').write_text(json.dumps(inventory, indent=2) + '\n')
    return config, path
