# Fixed local result publication

`native/worker/src/publication.rs` supplies a native create-only file publisher.
It is a component for the planned export-only successor, not an admitted product
export endpoint or a completed control-plane integration.

Trusted bootstrap admits one private existing directory, one simple child name
and an independent payload ceiling of at most 1 MiB. Admission walks every
directory component without following symlinks and binds the actual directory
inode and owner process. `publish` accepts bytes, never a destination path.
Root replacement, nonprivate files, extended/default ACLs, symlinks and foreign
hardlinks refuse. ACL checks use the actual directory/file descriptors at
admission and publication; ordinary mode bits alone do not establish privacy on
macOS. ACL inspection failure refuses. Bootstrap owns the directory permissions
throughout publication; this does not protect against a same-UID administrator
changing permissions concurrently.

Each destination has one fixed temporary coordinate. Exclusive creation and an
OS lock exclude simultaneous mutation of that temporary inode. Another publisher
can obtain a new temporary inode after unlink; create-only destination linking
and exact comparison still govern its result. After an interrupted temporary write, the
next owner can repair it from the same previously prepared bytes. Publication
syncs the temporary file, uses an atomic create-only hardlink, removes the
temporary link, syncs the directory and checks exact destination bytes. Existing
identical content is re-synced and checked; different content is never replaced.
The native receipt binds destination identity, payload digest and length. It is
not deserializable and cannot be supplied as request JSON.

The embedding must first persist the immutable prepared export, reserve its
storage/receipt/retry obligations and validate the source intent and terminal
snapshot. It must persist the actual receipt before acknowledging publication,
and consult that retained acknowledgement before a later replay. Calling this
primitive again after the recipient removes the destination would publish again;
the higher-level export ledger is responsible for preventing that. A receipt
proves local publication, not source interpretation. There is no cross-store
transaction or concurrent source-slot reuse protocol here.

The supported hosts are macOS and Linux on local POSIX storage with working file locks, hardlink
creation and file/directory sync. Process-death tests cover cuts after temporary
write, file sync, link, unlink, directory sync and readback; they do not simulate
physical power loss. The destination catalog and its cardinality are trusted
bootstrap inputs and still require the independent per-pool export funding gate.
