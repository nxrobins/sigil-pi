"""Exact real control-plane vectors through the solver-verifying SIGIL codec.

Generated negatives are mutations of captured bytes, never new qualification
evidence. Nothing here sends a historical intent or grants effect authority.
"""

import hashlib
import gzip
import json

import pytest

from conftest import PI_ROOT, SIGIL_ROOT, needs_toolchain
from runtime_client import ProductionSigilMCP
from scripts.compose_application import compose_application
from turn_support import FUEL, fields, record, refused


FIXTURE = json.loads((PI_ROOT / "tests/fixtures/control-plane-adapter-v1/captured.json").read_text())
VECTORS = FIXTURE["vectors"]


@pytest.fixture(scope="module")
def program():
    needs_toolchain()
    return compose_application("control_plane_codec", SIGIL_ROOT).text


def envelope(intent, delivery=b""):
    return record("CB1\n", [intent.hex(), delivery.hex()])


def raw_vector(index=0):
    row = VECTORS[index]
    return bytes.fromhex(row["intent"]["hex"]), bytes.fromhex(row["delivery"]["hex"])


def decode(mcp, program, intent, delivery=b""):
    result = mcp.forge(program, input=envelope(intent, delivery), fuel=FUEL)
    assert result["status"] == "ok", result
    return fields(result["data"]["output_text"], "CF1\n", 16)


def little(raw, start, count):
    return int.from_bytes(raw[start:start + count], "little")


def patch(raw, offset, replacement):
    return raw[:offset] + replacement + raw[offset + len(replacement):]


def request_hash(intent):
    return hashlib.sha256(intent[1:2] + intent[4:8] + intent[72:]).digest()


def redigest(intent):
    return patch(intent, 40, request_hash(intent))


def delivery_for(intent, *, phase=2, detail=204, started=100, terminal=101, origin=1, count=1):
    # Independent test-only encoder of the documented legacy binary ABI.
    return (bytes([1, phase]) + detail.to_bytes(2, "little") + intent[8:16]
            + intent[40:72] + hashlib.sha256(intent).digest() + bytes(4)
            + started.to_bytes(6, "little") + terminal.to_bytes(6, "little")
            + origin.to_bytes(2, "little") + count.to_bytes(2, "little"))


def test_captured_fixture_integrity_and_tenant_coverage():
    assert FIXTURE["source_report_sha256"] == "698e3cc86fcad9951c419d280b0412fc2b18c4d39f0db3a2d5cb77c0f2b6c5f7"
    source_bytes = gzip.decompress((PI_ROOT / "tests/fixtures/control-plane-adapter-v1/source-report.json.gz").read_bytes())
    assert hashlib.sha256(source_bytes).hexdigest() == FIXTURE["source_report_sha256"]
    source = json.loads(source_bytes)
    assert source["rawGeneratedCredentialsRetained"] is False
    assert source["isolatedInputs"]["app/src/adapter_executor_v3.sigil"] == FIXTURE["source_codec_sha256"]
    assert len(source["capturedVectors"]) == len(VECTORS)
    for actual, original in zip(VECTORS, source["capturedVectors"], strict=True):
        assert actual == {key: ({k: original[key][k] for k in ("hex", "sha256")}
                               if key in ("intent", "delivery") else original[key]) for key in actual}
    assert len(VECTORS) == 6
    assert {v["tenant"] for v in VECTORS} == {"company-a", "company-b"}
    for row in VECTORS:
        intent = bytes.fromhex(row["intent"]["hex"])
        assert intent[40:72] == request_hash(intent)
        for kind in ("intent", "delivery"):
            assert hashlib.sha256(bytes.fromhex(row[kind]["hex"])).hexdigest() == row[kind]["sha256"]
        key = "application/" + ("tenant-2/" if row["tenant"] == "company-b" else "") + "adapter-intent/v1"
        assert row["intentRecord"] == f"adapter_intent/{hashlib.sha256(key.encode()).hexdigest()}.kv"
        body = json.loads(intent[72 + little(intent, 4, 2):])
        assert (body["companyId"], body["runId"]) == (row["companyId"], row["runId"])


@pytest.mark.parametrize("index", range(6))
def test_real_records_decode_losslessly_with_exact_original_delivery(mcp, program, index):
    intent, delivery = raw_vector(index)
    values = decode(mcp, program, intent, delivery)
    assert values[:5] == [intent.hex(), delivery.hex(), intent[8:16].hex(), intent[40:72].hex(),
                          hashlib.sha256(intent).hexdigest()]
    assert values[5:8] == [str(little(intent, start, 6)) for start in (16, 22, 28)]
    length = little(intent, 4, 2)
    assert values[8:10] == [intent[72:72 + length].hex(), intent[72 + length:].hex()]
    assert values[10:] == [str(delivery[1]), str(little(delivery, 2, 2)),
                           str(little(delivery, 80, 6)), str(little(delivery, 86, 6)),
                           str(little(delivery, 92, 2)), str(little(delivery, 94, 2))]


def test_absent_delivery_stays_absent_and_is_not_invented_as_not_sent(mcp, program):
    intent, _ = raw_vector()
    values = decode(mcp, program, intent)
    assert values[1] == "" and values[10:] == [""] * 6


@pytest.mark.parametrize("attempt", [1, 2**63, 2**64 - 1])
def test_unsigned_attempt_identity_is_preserved_as_eight_bytes(mcp, program, attempt):
    intent, _ = raw_vector()
    intent = patch(intent, 8, attempt.to_bytes(8, "little"))
    assert decode(mcp, program, intent, delivery_for(intent))[2] == attempt.to_bytes(8, "little").hex()


@pytest.mark.parametrize("target,body", [(b"x", b""), (bytes(range(256)), bytes(range(256)) * 16)])
def test_codec_preserves_non_utf8_and_maximum_binary_payloads_without_interpreting_them(mcp, program, target, body):
    intent, _ = raw_vector()
    intent = redigest(patch(intent[:72], 4, len(target).to_bytes(2, "little") + len(body).to_bytes(2, "little")) + target + body)
    values = decode(mcp, program, intent)
    assert values[8:10] == [target.hex(), body.hex()]


@pytest.mark.parametrize("changes", [
    {"phase": 1, "detail": 0, "terminal": 0, "origin": 0, "count": 0},
    {"phase": 2, "detail": 100}, {"phase": 2, "detail": 599, "terminal": 0},
    {"phase": 3, "detail": 1},
    {"phase": 3, "detail": 65535, "started": 0, "origin": 3, "count": 0},
    {"phase": 3, "origin": 4, "count": 0},
    {"phase": 3, "terminal": 0, "origin": 5, "count": 0},
    {"phase": 4, "detail": 1},
    {"phase": 4, "origin": 2, "count": 65535, "terminal": 0},
])
def test_all_legacy_observation_classes_including_unknown_invocation_count(mcp, program, changes):
    intent, _ = raw_vector()
    delivery = delivery_for(intent, **changes)
    values = decode(mcp, program, intent, delivery)
    assert values[10] == str(delivery[1]) and values[15] == str(little(delivery, 94, 2))


@pytest.mark.parametrize("offset,replacement", [
    (0, b"\x02"), (1, b"\x00"), (2, b"\x01"), (3, b"\x01"),
    (4, b"\x00\x00"), (4, b"\x01\x01"), (6, b"\x01\x10"),
    (8, bytes(8)), (16, bytes(6)), (28, bytes(6)), (34, b"\x01"), (39, b"\x01"), (40, bytes(32)),
])
def test_invalid_intent_shape_is_refused(mcp, program, offset, replacement):
    intent, _ = raw_vector()
    refused(mcp, program, envelope(patch(intent, offset, replacement)), 400)


@pytest.mark.parametrize("delta", [0, -1, 30001])
def test_deadline_window_is_validated_in_exact_milliseconds(mcp, program, delta):
    intent, _ = raw_vector()
    deadline = little(intent, 16, 6) + delta
    refused(mcp, program, envelope(patch(intent, 22, deadline.to_bytes(6, "little"))), 400)


@pytest.mark.parametrize("offset", [40, 71, 72, 100, -1])
def test_modified_request_bytes_or_digest_are_rejected(mcp, program, offset):
    intent, _ = raw_vector()
    offset %= len(intent)
    refused(mcp, program, envelope(patch(intent, offset, bytes([intent[offset] ^ 1]))), 409)


@pytest.mark.parametrize("offset,count", [(8, 8), (16, 6), (22, 6), (28, 6)])
def test_changed_attempt_or_metadata_cannot_reuse_delivery_even_with_same_request_digest(mcp, program, offset, count):
    intent, delivery = raw_vector()
    changed = patch(intent, offset, (little(intent, offset, count) + 1).to_bytes(count, "little"))
    if offset == 22:
        changed = patch(changed, 16, (little(intent, 16, 6) + 1).to_bytes(6, "little"))
    assert changed[40:72] == intent[40:72]
    refused(mcp, program, envelope(changed, delivery), 409)


def test_cross_tenant_and_different_capture_deliveries_do_not_correlate(mcp, program):
    intent, _ = raw_vector(0)
    for other in (1, 2, 3, 4, 5):
        refused(mcp, program, envelope(intent, raw_vector(other)[1]), 409)


@pytest.mark.parametrize("changes", [
    {"phase": 0}, {"phase": 5}, {"detail": 99}, {"detail": 600}, {"started": 0},
    {"terminal": 99}, {"origin": 0}, {"origin": 2}, {"count": 0}, {"count": 65535},
    {"phase": 1, "detail": 0, "origin": 0, "count": 0},
    {"phase": 1, "detail": 1, "terminal": 0, "origin": 0, "count": 0},
    {"phase": 3, "detail": 0}, {"phase": 3, "origin": 2},
    {"phase": 3, "origin": 3, "count": 0},
    {"phase": 3, "started": 0, "terminal": 0, "origin": 3, "count": 0},
    {"phase": 3, "terminal": 0, "origin": 4, "count": 0},
    {"phase": 3, "origin": 5, "count": 1},
    {"phase": 4, "origin": 2, "count": 0}, {"phase": 4, "origin": 2, "count": 1},
    {"phase": 4, "started": 0}, {"phase": 4, "origin": 3},
])
def test_invalid_observation_combinations_are_refused(mcp, program, changes):
    intent, _ = raw_vector()
    refused(mcp, program, envelope(intent, delivery_for(intent, **changes)), 400)


@pytest.mark.parametrize("offset,replacement", [(0, b"\x02"), (4, bytes(8)), (12, bytes(32)),
    (44, bytes(32)), (76, b"\x01"), (79, b"\x01")])
def test_invalid_delivery_shape_is_refused(mcp, program, offset, replacement):
    intent, delivery = raw_vector()
    refused(mcp, program, envelope(intent, patch(delivery, offset, replacement)), 400)


@pytest.mark.parametrize("offset", [4, 12, 44])
def test_nonzero_but_wrong_delivery_identity_is_refused(mcp, program, offset):
    intent, delivery = raw_vector()
    refused(mcp, program, envelope(intent, patch(delivery, offset, bytes([delivery[offset] ^ 2]))), 409)


@pytest.mark.parametrize("case", ["short", "long", "odd", "upper", "nonhex", "unicode", "delivery-short", "delivery-long", "trailing", "version"])
def test_noncanonical_or_malformed_envelope_is_refused(mcp, program, case):
    intent, delivery = raw_vector()
    ih, dh = intent.hex(), delivery.hex()
    if case == "short": ih = ih[:144]
    if case == "long": ih += "00"
    if case == "odd": ih = ih[:-1]
    if case == "upper": ih = ih.upper()
    if case == "nonhex": ih = "gg" + ih[2:]
    if case == "unicode": ih = "é" + ih[2:]
    if case == "delivery-short": dh = dh[:-2]
    if case == "delivery-long": dh += "00"
    value = record("CB2\n" if case == "version" else "CB1\n", [ih, dh])
    if case == "trailing": value += "0"
    refused(mcp, program, value, 400)


def test_oversized_input_is_refused_before_decode(mcp, program):
    refused(mcp, program, "x" * 9061, 413)


def test_fixed_grantless_evaluator_reuses_code_with_fresh_independent_inputs(program, native_fixed_evaluator_binary):
    with ProductionSigilMCP.spawn(native_fixed_evaluator_binary) as runtime:
        runtime.initialize()
        for index in (0, 5, 0):
            intent, delivery = raw_vector(index)
            result = runtime.forge(program, input=envelope(intent, delivery), fuel=FUEL,
                                   grants={"net": [], "fs": [], "secret": []})
            assert result["status"] == "ok", result
            assert result["data"]["fixed_evaluator"]["solver_verified"] is True
            assert result["data"]["fixed_evaluator"]["compilations"] == 1
            assert fields(result["data"]["output_text"], "CF1\n", 16)[:2] == [intent.hex(), delivery.hex()]
