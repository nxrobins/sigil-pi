use super::*;
use crate::claimed::audit_tests::{formatter, grant_map};
use crate::claimed::completion_tests::{fund_fixture, owner};
use crate::claimed::tests::{Fixture, binding, execution, fixture_recorder, process_guard};
use sigil_durable_store::store::capacity::{Allocation, Pool};
use sigil_durable_store::store::{Limits, OpenMode};
use std::path::Path;
use tempfile::TempDir;

fn open(root: &Path) -> sigil_durable_store::store::Result<Store> {
    Store::open_fenced_reserved_bound(
        root,
        OpenMode::Existing,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records: 13,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
}
fn open_anchored(directory: &Path) -> sigil_durable_store::store::Result<Store> {
    Store::open_anchored_reserved_bound(
        &directory.join("store"),
        &directory.join("authority").canonicalize().unwrap(),
        OpenMode::Existing,
        Limits::default(),
        Allocation {
            version: 1,
            pools: vec![Pool {
                id: "tenant".into(),
                namespaces: [
                    "intent",
                    "claim",
                    "delivery",
                    "funds",
                    "audit.heads",
                    "audit.entries",
                    "api",
                    "exports",
                    "exports.heads",
                    "exports.entries",
                ]
                .into_iter()
                .map(String::from)
                .collect(),
                records: 64,
                live_bytes: 4_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("tenant".into(), 8)]),
    )
}

#[test]
fn anchored_pending_recovery_preserves_slot_identity_after_actual_owner_handoff() {
    let _serial = process_guard();
    let (mut f, mut old_recorder, funding, origin) =
        super::completion_tests::fund_parent_phase_fixture(Fixture::anchored(64), "4");
    let slot = funding.held.as_ref().unwrap().generation().unwrap().clone();
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    attempt.claim_recorded(&mut old_recorder).unwrap();
    let generation = attempt.prepared().generation.clone();
    drop(attempt);
    let scope = owner(&f.store);
    let retained = AssignedCompletion::observe(&f.store, &scope, "funds", "operation:1").unwrap();
    assert_eq!(
        retained.check_prior_owner(&f.store, &scope),
        Err("execution_fence")
    );
    drop(old_recorder);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    assert!(matches!(
        open_anchored(directory.path()),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    drop(worker);
    let mut store = open_anchored(directory.path()).unwrap();
    let scope = owner(&store);
    retained.check_prior_owner(&store, &scope).unwrap();
    let mut recorder = fixture_recorder(directory.path(), &generation, "4", 0);
    recorder.attach_audit(EffectAudit::fixture(
        &mut store,
        formatter(directory.path(), 0),
        grant_map(),
        3,
        false,
    ));
    let mut recovered = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(recovered.recovered.phase, "4");
    assert_eq!(recovered.recovered.claim_generation, generation);
    let credit = recovered.take_returned_credit().unwrap();
    assert_eq!(credit.generation(), Some(&slot));
    store.check_reservation_binding(&credit, origin).unwrap();
    let snapshot = store
        .reservation_snapshot(&scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(snapshot.generation, Some(slot));
    assert!(snapshot.assignment.is_empty());
    assert_eq!(snapshot.binding, origin);
    let after = state(&store, &scope);
    assert!(retained.check_prior_owner(&store, &scope).is_err());
    assert!(
        recorder
            .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
            .is_err()
    );
    assert_eq!(state(&store, &scope), after);
    assert!(!directory.path().join("started").exists());
}
fn claimed() -> (Fixture, Recorder, String, [u8; 32]) {
    let (mut f, mut recorder, funding, origin) = fund_fixture(Fixture::fenced(13), 2, "4");
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let generation = a.prepared().generation.clone();
    drop(a);
    (f, recorder, generation, origin)
}
fn recorder(root: &Path, store: &mut Store, generation: &str) -> Recorder {
    let mut recorder = fixture_recorder(root, generation, "4", 0);
    recorder.attach_audit(EffectAudit::fixture(
        store,
        formatter(root, 0),
        grant_map(),
        2,
        false,
    ));
    recorder
}
fn reopened() -> (TempDir, Store, Scope, Recorder, String, [u8; 32]) {
    let (f, old_recorder, generation, origin) = claimed();
    drop(old_recorder);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    assert!(matches!(
        open(&directory.path().join("store")),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    drop(worker);
    let mut store = open(&directory.path().join("store")).unwrap();
    let scope = owner(&store);
    let recorder = recorder(directory.path(), &mut store, &generation);
    (directory, store, scope, recorder, generation, origin)
}
fn state(store: &Store, scope: &Scope) -> (u64, u64, u64, u64, [u8; 32], Vec<u8>) {
    let assigned = store
        .reservation_snapshot(scope, "funds", "operation:1")
        .unwrap();
    (
        store.get(scope, "claim", "operation:1").unwrap().revision,
        store
            .get(scope, "delivery", "operation:1")
            .unwrap()
            .revision,
        store
            .get(scope, "audit.heads", &"a".repeat(64))
            .unwrap()
            .revision,
        assigned.revision,
        assigned.binding,
        assigned.assignment,
    )
}
#[test]
fn pending_recovery_publishes_uncertainty_audit_and_credit_return_atomically_at_full_pool() {
    let _serial = process_guard();
    let (directory, mut store, scope, mut recorder, generation, origin) = reopened();
    let before = state(&store, &scope);
    assert_eq!((before.0, before.1, before.2, before.3), (1, 0, 1, 2));
    let mut result = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(result.recovered.phase, "4");
    assert_eq!(result.recovered.claim_generation, generation);
    assert_ne!(result.recovered.recovery_generation, generation);
    let credit = result.take_returned_credit().unwrap();
    assert!(result.take_returned_credit().is_none());
    store.check_reservation_binding(&credit, origin).unwrap();
    assert_eq!(credit.credits().records, 5);
    assert_eq!(credit.credits().live_bytes, 40_000);
    let after = state(&store, &scope);
    assert_eq!((after.0, after.1, after.2, after.3), (2, 1, 2, 3));
    assert_eq!(after.4, origin);
    assert!(after.5.is_empty());
    let delivery = store.get(&scope, "delivery", "operation:1").unwrap();
    let dr = fields(delivery.value.as_deref().unwrap(), "DR1\n", 7).unwrap();
    assert_eq!(dr[3], generation);
    assert_eq!(dr[4], "4");
    assert!(dr[5].is_empty() && dr[6].is_empty());
    let request: Value = serde_json::from_str(
        &std::fs::read_to_string(directory.path().join("recorder-input")).unwrap(),
    )
    .unwrap();
    let wr = fields(
        request["params"]["arguments"]["input"].as_str().unwrap(),
        "WR1\n",
        10,
    )
    .unwrap();
    let wf = fields(wr[9], "WF2\n", 10).unwrap();
    assert_eq!(wf[0], "abandoned");
    assert_eq!(wf[2], "1");
    assert_eq!(wf[3], "0");
    assert_eq!(wf[4], "owner_unavailable");
    assert!(!directory.path().join("started").exists());
    assert!(
        recorder
            .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
            .is_err()
    );
    assert_eq!(state(&store, &scope), after);
}
#[test]
fn pending_recovery_refuses_current_owner_before_evaluation_or_credit_change() {
    let _serial = process_guard();
    let (mut f, mut recorder, _, _) = claimed();
    let scope = owner(&f.store);
    let before = state(&f.store, &scope);
    assert!(matches!(
        recorder.recover_funded_pending(&mut f.store, &scope, "funds", "operation:1"),
        Err("execution_fence")
    ));
    assert_eq!(state(&f.store, &scope), before);
    assert!(!f.directory.path().join("started").exists());
}
#[test]
fn pending_recovery_needs_existing_write_scope_and_matching_signed_recorder() {
    let _serial = process_guard();
    let (directory, mut store, scope, mut recorder, _, _) = reopened();
    let before = state(&store, &scope);
    let read = store
        .scope(
            ["intent", "claim", "delivery", "funds"]
                .into_iter()
                .map(|n| (n.into(), Access::Read))
                .collect(),
        )
        .unwrap();
    assert!(
        recorder
            .recover_funded_pending(&mut store, &read, "funds", "operation:1")
            .is_err()
    );
    recorder.delivery_namespace = "wrong".into();
    assert!(matches!(
        recorder.recover_funded_pending(&mut store, &scope, "funds", "operation:1"),
        Err("funding_identity")
    ));
    recorder.delivery_namespace = "delivery".into();
    recorder.audit = None;
    assert!(matches!(
        recorder.recover_funded_pending(&mut store, &scope, "funds", "operation:1"),
        Err("funding_audit")
    ));
    assert_eq!(state(&store, &scope), before);
    assert!(!directory.path().join("started").exists());
}
#[test]
fn pending_recovery_rejects_wrong_claim_generation_without_releasing_capacity() {
    let _serial = process_guard();
    let (directory, mut store, scope, old_recorder, _, _) = reopened();
    drop(old_recorder);
    let mut recorder = recorder(directory.path(), &mut store, &"f".repeat(64));
    let before = state(&store, &scope);
    assert!(matches!(
        recorder.recover_funded_pending(&mut store, &scope, "funds", "operation:1"),
        Err("recording")
    ));
    assert_eq!(state(&store, &scope), before);
    assert!(!directory.path().join("started").exists());
}
#[test]
fn pending_recovery_never_accepts_an_unfenced_storage_profile() {
    let _serial = process_guard();
    let (mut f, mut recorder, _, _) = fund_fixture(Fixture::witnessed(13), 2, "4");
    let scope = owner(&f.store);
    assert!(matches!(
        recorder.recover_funded_pending(&mut f.store, &scope, "funds", "operation:1"),
        Err("execution_fence")
    ));
    assert!(!f.directory.path().join("started").exists());
}

struct ProcessCleanup {
    child: std::process::Child,
    release: Option<std::path::PathBuf>,
}
impl Drop for ProcessCleanup {
    fn drop(&mut self) {
        if let Some(release) = &self.release {
            let _ = std::fs::write(release, b"");
        }
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}
#[test]
fn pending_recovery_owner_process_child() {
    use sha2::{Digest, Sha256};
    use sigil_worker_bridge::{Bridge, Config};
    use std::os::unix::fs::PermissionsExt;
    let Ok(control) = std::env::var("SIGIL_PENDING_RECOVERY_PROCESS_ROOT") else {
        return;
    };
    let control = std::path::PathBuf::from(control);
    let (mut f, mut recorder, funding, _) = fund_fixture(Fixture::fenced(13), 2, "4");
    std::fs::write(
        control.join("fixture-path"),
        f.directory.path().as_os_str().as_encoded_bytes(),
    )
    .unwrap();
    let release = f.directory.path().join("release");
    let received = f.directory.path().join("received");
    let descendant = f.directory.path().join("descendant");
    let helper = f.directory.path().join("holder");
    std::fs::write(&helper,format!("#!/bin/sh\n: > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done\n",descendant.display(),release.display())).unwrap();
    std::fs::set_permissions(&helper, std::fs::Permissions::from_mode(0o700)).unwrap();
    let runtime = f.directory.path().join("held-runtime");
    let body = format!(
        "#!/bin/sh\n'{}' &\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nread -r line\nprintf 'request\\n' >> '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done\n",
        helper.display(),
        received.display(),
        release.display()
    );
    std::fs::write(&runtime, &body).unwrap();
    std::fs::set_permissions(&runtime, std::fs::Permissions::from_mode(0o700)).unwrap();
    let source = f.directory.path().join("source");
    f.worker = Bridge::new_fenced(
        Config {
            version: 1,
            runtime,
            runtime_sha256: format!("{:x}", Sha256::digest(&body)),
            source: source.clone(),
            source_sha256: format!("{:x}", Sha256::digest(std::fs::read(source).unwrap())),
            max_fuel: 1000,
            max_timeout_ms: 30_000,
            net: vec![],
            fs: vec![],
            fs_write: vec![],
            secret_env: BTreeMap::new(),
        },
        f.store.execution_lease().unwrap(),
    )
    .unwrap();
    let mut x = execution();
    x.timeout_ms = 30_000;
    let mut a = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        x,
    )
    .unwrap();
    a.attach_funding(funding).unwrap();
    a.claim_recorded(&mut recorder).unwrap();
    let ticket = a.prepared().ticket.clone();
    std::fs::write(control.join("generation"), &a.prepared().generation).unwrap();
    std::thread::spawn(move || {
        let until = Instant::now() + Duration::from_secs(20);
        while !received.exists() || !descendant.exists() {
            assert!(Instant::now() < until);
            std::thread::sleep(Duration::from_millis(5));
        }
        std::fs::write(
            control.join("ready"),
            b"actual invocation and retained descendant",
        )
        .unwrap();
    });
    let _ = a.execute(&ticket, &AtomicBool::new(false));
    panic!("owner should be killed after effect receipt");
}
#[test]
fn pending_recovery_after_actual_owner_death_waits_for_survivor_and_never_replays_effect() {
    use std::process::{Command, Stdio};
    let _serial = process_guard();
    let control = tempfile::tempdir().unwrap();
    let stderr = std::fs::File::create(control.path().join("child.stderr")).unwrap();
    let mut cleanup = ProcessCleanup {
        child: Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "claimed::recorded::recovery::tests::pending_recovery_owner_process_child",
                "--nocapture",
            ])
            .env("SIGIL_PENDING_RECOVERY_PROCESS_ROOT", control.path())
            .stdout(Stdio::null())
            .stderr(stderr)
            .spawn()
            .unwrap(),
        release: None,
    };
    let until = Instant::now() + Duration::from_secs(30);
    while !control.path().join("ready").exists() {
        if control.path().join("fixture-path").exists() {
            let path = std::path::PathBuf::from(
                std::fs::read_to_string(control.path().join("fixture-path")).unwrap(),
            );
            cleanup.release = Some(path.join("release"));
        }
        assert!(
            cleanup.child.try_wait().unwrap().is_none(),
            "{}",
            std::fs::read_to_string(control.path().join("child.stderr")).unwrap()
        );
        assert!(Instant::now() < until, "actual effect did not become ready");
        std::thread::sleep(Duration::from_millis(5));
    }
    let path = std::path::PathBuf::from(
        std::fs::read_to_string(control.path().join("fixture-path")).unwrap(),
    );
    cleanup.release = Some(path.join("release"));
    cleanup.child.kill().unwrap();
    assert!(!cleanup.child.wait().unwrap().success());
    assert!(matches!(
        open(&path.join("store")),
        Err(sigil_durable_store::store::Error::Busy)
    ));
    assert_eq!(
        std::fs::read_to_string(path.join("received")).unwrap(),
        "request\n"
    );
    std::fs::write(path.join("release"), b"").unwrap();
    let until = Instant::now() + Duration::from_secs(5);
    let mut store = loop {
        match open(&path.join("store")) {
            Ok(store) => break store,
            Err(sigil_durable_store::store::Error::Busy) if Instant::now() < until => {
                std::thread::sleep(Duration::from_millis(5))
            }
            other => panic!("post-exclusion open: {:?}", other.err()),
        }
    };
    let generation = std::fs::read_to_string(control.path().join("generation")).unwrap();
    let scope = owner(&store);
    let original = store
        .reservation_snapshot(&scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(original.revision, 2);
    let mut recorder = recorder(&path, &mut store, &generation);
    let mut result = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(result.recovered.phase, "4");
    assert_eq!(result.recovered.claim_generation, generation);
    let returned = result.take_returned_credit().unwrap();
    store
        .check_reservation_binding(&returned, original.origin)
        .unwrap();
    assert_eq!(state(&store, &scope).0, 2);
    assert_eq!(
        std::fs::read_to_string(path.join("received")).unwrap(),
        "request\n"
    );
    drop(recorder);
    drop(store);
    std::fs::remove_dir_all(&path).unwrap();
    cleanup.release = None;
}

#[test]
fn pending_recovery_failed_database_write_keeps_original_assignment_audit_and_credit() {
    let _serial = process_guard();
    let (directory, mut store, scope, mut recorder, generation, origin) = reopened();
    let before = state(&store, &scope);
    let connection = rusqlite::Connection::open_with_flags(
        directory.path().join("store/records.sqlite"),
        rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE,
    )
    .unwrap();
    connection.execute_batch("CREATE TRIGGER refuse_recovery BEFORE INSERT ON records WHEN NEW.namespace='delivery' BEGIN SELECT RAISE(ABORT,'injected recovery failure'); END;").unwrap();
    assert!(matches!(
        recorder.recover_funded_pending(&mut store, &scope, "funds", "operation:1"),
        Err("storage")
    ));
    assert!(matches!(
        store.get(&scope, "claim", "operation:1"),
        Err(sigil_durable_store::store::Error::ReopenRequired)
    ));
    connection
        .execute_batch("DROP TRIGGER refuse_recovery;")
        .unwrap();
    drop(connection);
    drop(recorder);
    drop(store);
    let mut store = open(&directory.path().join("store")).unwrap();
    let scope = owner(&store);
    assert_eq!(state(&store, &scope), before);
    let credits = store
        .reservation_snapshot(&scope, "funds", "operation:1")
        .unwrap()
        .credits;
    assert_eq!(credits.records, 7);
    assert_eq!(credits.live_bytes, 45_000);
    let mut recorder = self::recorder(directory.path(), &mut store, &generation);
    let mut recovered = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    store
        .check_reservation_binding(&recovered.take_returned_credit().unwrap(), origin)
        .unwrap();
    assert_eq!(state(&store, &scope).2, 2);
    assert!(!directory.path().join("started").exists());
}

#[test]
fn pending_recovery_commit_process_child() {
    use sha2::{Digest, Sha256};
    use sigil_worker_bridge::Config;
    let Ok(control) = std::env::var("SIGIL_RECOVERY_COMMIT_ROOT") else {
        return;
    };
    let control = std::path::PathBuf::from(control);
    let cut = std::env::var("SIGIL_RECOVERY_COMMIT_CUT").unwrap();
    let (directory, mut store, scope, old_recorder, generation, _) = reopened();
    drop(old_recorder);
    std::fs::write(
        control.join("fixture-path"),
        directory.path().as_os_str().as_encoded_bytes(),
    )
    .unwrap();
    std::fs::write(control.join("generation"), &generation).unwrap();
    let mut recorder = if cut == "before" {
        // Stop the real recorder after receiving the recovery request, before
        // returning a proposal. No native database publication has begun.
        drop(fixture_recorder(directory.path(), &generation, "4", 0));
        let runtime = directory.path().join("recorder-runtime");
        let body = std::fs::read_to_string(&runtime).unwrap();
        assert_eq!(body.matches("/bin/sleep 0; ").count(), 1);
        let body=body.replace("/bin/sleep 0; ",&format!(": > '{}'\nn=0\nwhile [ ! -f '{}' ] && [ $n -lt 1500 ]; do /bin/sleep 0.02; n=$((n+1)); done\n",control.join("ready").display(),directory.path().join("release-recovery").display()));
        std::fs::write(&runtime, &body).unwrap();
        let source = directory.path().join("recorder-source");
        let mut recorder = Recorder::new(RecorderConfig {
            delivery_namespace: "delivery".into(),
            worker: Config {
                version: 1,
                runtime,
                runtime_sha256: format!("{:x}", Sha256::digest(&body)),
                source: source.clone(),
                source_sha256: format!("{:x}", Sha256::digest(std::fs::read(source).unwrap())),
                max_fuel: 1000,
                max_timeout_ms: 5000,
                net: vec![],
                fs: vec![],
                fs_write: vec![],
                secret_env: BTreeMap::new(),
            },
        })
        .unwrap();
        recorder.attach_audit(EffectAudit::fixture(
            &mut store,
            formatter(directory.path(), 0),
            grant_map(),
            2,
            false,
        ));
        recorder
    } else {
        recorder(directory.path(), &mut store, &generation)
    };
    let mut result = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    assert!(result.take_returned_credit().is_some());
    assert_eq!(cut, "after");
    std::fs::write(control.join("ready"), b"committed recovery").unwrap();
    // Keep the real storage owner alive until the parent kills it.
    std::thread::sleep(Duration::from_secs(30));
    panic!("recovery owner should have been killed");
}
#[test]
fn pending_recovery_hard_death_before_and_after_publication_has_only_atomic_outcomes() {
    use std::process::{Command, Stdio};
    let _serial = process_guard();
    for cut in ["before", "after"] {
        let control = tempfile::tempdir().unwrap();
        let stderr = std::fs::File::create(control.path().join("child.stderr")).unwrap();
        let mut cleanup = ProcessCleanup {
            child: Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "claimed::recorded::recovery::tests::pending_recovery_commit_process_child",
                    "--nocapture",
                ])
                .env("SIGIL_RECOVERY_COMMIT_ROOT", control.path())
                .env("SIGIL_RECOVERY_COMMIT_CUT", cut)
                .stdout(Stdio::null())
                .stderr(stderr)
                .spawn()
                .unwrap(),
            release: None,
        };
        let until = Instant::now() + Duration::from_secs(20);
        while !control.path().join("ready").exists() {
            if control.path().join("fixture-path").exists() {
                let path = std::path::PathBuf::from(
                    std::fs::read_to_string(control.path().join("fixture-path")).unwrap(),
                );
                cleanup.release = Some(path.join("release-recovery"));
            }
            assert!(
                cleanup.child.try_wait().unwrap().is_none(),
                "{cut}: {}",
                std::fs::read_to_string(control.path().join("child.stderr")).unwrap()
            );
            assert!(Instant::now() < until, "{cut}: recovery cut not reached");
            std::thread::sleep(Duration::from_millis(5));
        }
        let path = std::path::PathBuf::from(
            std::fs::read_to_string(control.path().join("fixture-path")).unwrap(),
        );
        cleanup.release = Some(path.join("release-recovery"));
        cleanup.child.kill().unwrap();
        assert!(!cleanup.child.wait().unwrap().success());
        std::fs::write(path.join("release-recovery"), b"").unwrap();
        let mut store = open(&path.join("store")).unwrap();
        let scope = owner(&store);
        let observed = state(&store, &scope);
        let credit = store
            .reservation_snapshot(&scope, "funds", "operation:1")
            .unwrap();
        let generation = std::fs::read_to_string(control.path().join("generation")).unwrap();
        let mut recorder = recorder(&path, &mut store, &generation);
        if cut == "before" {
            assert_eq!(
                (observed.0, observed.1, observed.2, observed.3),
                (1, 0, 1, 2)
            );
            assert_eq!(credit.credits.records, 7);
            assert!(!observed.5.is_empty());
            let mut recovered = recorder
                .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
                .unwrap();
            store
                .check_reservation_binding(
                    &recovered.take_returned_credit().unwrap(),
                    credit.origin,
                )
                .unwrap();
        } else {
            assert_eq!(
                (observed.0, observed.1, observed.2, observed.3),
                (2, 1, 2, 3)
            );
            assert_eq!(credit.credits.records, 5);
            assert_eq!(observed.4, credit.origin);
            assert!(observed.5.is_empty());
            assert!(
                recorder
                    .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
                    .is_err()
            );
            assert_eq!(state(&store, &scope), observed);
        }
        assert!(!path.join("started").exists());
        drop(recorder);
        drop(store);
        std::fs::remove_dir_all(&path).unwrap();
        cleanup.release = None;
    }
}

#[path = "recovery_compiled_tests.rs"]
mod compiled;

#[test]
fn pending_recovery_of_retirement_assignment_returns_unused_third_allowance() {
    use crate::claimed::completion_tests::fund_retirement_fixture;
    let _serial = process_guard();
    let (mut f, mut old_recorder, funding, origin) =
        fund_retirement_fixture(Fixture::fenced(13), 3, "4");
    let mut attempt = Attempt::begin(
        &mut f.store,
        &f.scope,
        &mut f.worker,
        &mut f.clock,
        binding(),
        execution(),
    )
    .unwrap();
    attempt.attach_funding(funding).unwrap();
    attempt.claim_recorded(&mut old_recorder).unwrap();
    let generation = attempt.prepared().generation.clone();
    drop(attempt);
    drop(old_recorder);
    let Fixture {
        directory,
        store,
        worker,
        ..
    } = f;
    drop(store);
    drop(worker);
    let mut store = open(&directory.path().join("store")).unwrap();
    let scope = owner(&store);
    let mut recorder = fixture_recorder(directory.path(), &generation, "4", 0);
    recorder.attach_audit(EffectAudit::fixture(
        &mut store,
        formatter(directory.path(), 0),
        grant_map(),
        3,
        false,
    ));
    let mut recovered = recorder
        .recover_funded_pending(&mut store, &scope, "funds", "operation:1")
        .unwrap();
    assert_eq!(recovered.recovered.phase, "4");
    let credit = recovered.take_returned_credit().unwrap();
    store.check_reservation_binding(&credit, origin).unwrap();
    assert_eq!(credit.credits().records, 5);
    assert_eq!(credit.credits().live_bytes, 40_000);
    assert!(
        store
            .reservation_snapshot(&scope, "funds", "operation:1")
            .unwrap()
            .assignment
            .is_empty()
    );
    assert!(
        recorder
            .retire_funded_terminal(&mut store, &scope, "funds", "operation:1")
            .is_err()
    );
    assert!(!directory.path().join("started").exists());
}
