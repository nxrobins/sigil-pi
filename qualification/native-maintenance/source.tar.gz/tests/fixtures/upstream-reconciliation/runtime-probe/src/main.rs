//! Trusted-embedder combined HTTP/capability probe, outside the product profile.
//! The Python harness owns synthetic loopback servers and freezes each oracle.
use serde::Deserialize;
use serde_json::json;
use sigil_compiler::{CompileLimits, CompilerContext, compile_tool_with_limits_and_context};
use sigil_runtime::{CapGrant, HttpMethod, IoGrants, NetGrant, ToolError, execute_ephemeral};
use std::io::{self, BufRead, Write};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    source: String,
    input: String,
    caps: Vec<String>,
    net: bool,
    http_timeout_ms: Option<u64>,
    #[serde(default)]
    handwritten_wasm: bool,
}

fn main() {
    for line in io::stdin().lock().lines() {
        let request: Request =
            serde_json::from_str(&line.expect("request line")).expect("request shape");
        let (wasm, provenance) = if request.handwritten_wasm {
            let wasm = wat::parse_str(&request.source).expect("fixed synthetic Wasm fixture");
            for section in wasmparser::Parser::new(0).parse_all(&wasm) {
                assert!(
                    !matches!(
                        section.expect("valid fixture section"),
                        wasmparser::Payload::StartSection { .. }
                    ),
                    "combined entry refusal fixture cannot have a start section"
                );
            }
            (
                wasm,
                json!({"fixture_kind":"handwritten-wasm","source_certificate":null,
                "solver_verified":null,"entry_caps":null,"verdict_scope":"trusted-embedder-runtime-only","has_start_section":false}),
            )
        } else {
            let context = CompilerContext::with_host_profile(
                sigil_runtime::host_profile_by_name("ephemeral").expect("ephemeral profile"),
            );
            let compiled = match compile_tool_with_limits_and_context(
                &request.source,
                &CompileLimits::default(),
                &context,
            ) {
                Ok(c) => c,
                Err(e) => {
                    println!(
                        "{}",
                        json!({"status":"compile_error","detail":format!("{e:?}")})
                    );
                    io::stdout().flush().unwrap();
                    continue;
                }
            };
            assert!(
                compiled.solver_verified,
                "probe requires actual solver verification"
            );
            (
                compiled.wasm,
                json!({"fixture_kind":"compiled-sigil","entry_caps":compiled.entry_caps,
            "solver_verified":true,"verdict_scope":"fresh-verified-source"}),
            )
        };
        let grants = IoGrants {
            caps: request
                .caps
                .into_iter()
                .map(|type_name| CapGrant { type_name })
                .collect(),
            net: if request.net {
                vec![NetGrant {
                    host_pattern: "127.0.0.1".into(),
                    methods: vec![HttpMethod::Get],
                }]
            } else {
                vec![]
            },
            http_timeout_ms: request.http_timeout_ms,
            ..IoGrants::none()
        };
        let outcome = match execute_ephemeral(&wasm, request.input.as_bytes(), 1_000_000, &grants) {
            Ok(result) => {
                json!({"status":"ok","output":String::from_utf8(result.output).expect("synthetic UTF-8")})
            }
            Err(ToolError::EntryCapsUngranted { params, granted }) => {
                json!({"status":"entry_caps_ungranted","params":params,"granted":granted})
            }
            Err(ToolError::Trapped { message }) => json!({"status":"trapped","message":message}),
            Err(other) => json!({"status":"other_error","detail":format!("{other:?}")}),
        };
        let mut result = provenance;
        result["outcome"] = outcome;
        println!("{}", result);
        io::stdout().flush().unwrap();
    }
}
