use super::*;
use std::os::unix::fs::PermissionsExt;

fn fresh() -> (tempfile::TempDir, Store, Scope) {
    let dir = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let path = dir.path().join(name);
        fs::create_dir(&path).unwrap();
        fs::set_permissions(path, fs::Permissions::from_mode(0o700)).unwrap();
    }
    let mut store = Store::open_anchored_reserved_bound(
        &dir.path().join("data").canonicalize().unwrap(),
        &dir.path().join("authority").canonicalize().unwrap(),
        OpenMode::CreateNew,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "pool".into(),
                namespaces: vec!["a".into(), "b".into()],
                records: 1000,
                live_bytes: 10_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("pool".into(), 128)]),
    )
    .unwrap();
    let scope = store
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("b".into(), Access::ReadWrite),
        ]))
        .unwrap();
    let held = store
        .commit_reserving(
            &scope,
            &batch("state", 0, Some("kept")),
            &reservation::Request {
                namespace: "b".into(),
                key: "hold".into(),
                binding: [9; 32],
                credits: reservation::Credits {
                    records: 1,
                    live_bytes: 1000,
                },
            },
        )
        .unwrap()
        .held
        .unwrap();
    store
        .commit_spending(
            &scope,
            &batch("state", 1, Some("done")),
            &held,
            held.credits(),
        )
        .unwrap();
    (dir, store, scope)
}

fn key(namespace: &str, key: &str) -> ReadKey {
    ReadKey {
        namespace: namespace.into(),
        key: key.into(),
    }
}
fn batch(key: &str, revision: u64, value: Option<&str>) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: key.into(),
            revision,
            value: value.map(str::to_owned),
        }],
    }
}

#[test]
fn records_and_exact_generation_share_one_verified_snapshot_without_writes() {
    let (_dir, mut s, scope) = fresh();
    s.commit(&scope, &batch("empty", 0, Some(""))).unwrap();
    s.commit(&scope, &batch("gone", 0, None)).unwrap();
    let before = anchored::snapshot(&s.connection, 7).unwrap();
    let (rows, fact) = s
        .get_many_with_reservation(
            &scope,
            &[key("a", "missing"), key("a", "empty"), key("a", "gone")],
            &key("b", "hold"),
        )
        .unwrap();
    assert_eq!(
        rows,
        vec![
            Record {
                revision: 0,
                value: None
            },
            Record {
                revision: 1,
                value: Some("".into())
            },
            Record {
                revision: 1,
                value: None
            }
        ]
    );
    assert_eq!(fact.revision, 2);
    assert_eq!(fact.binding, [9; 32]);
    assert_eq!(fact.origin, [9; 32]);
    assert!(fact.assignment.is_empty());
    assert_eq!(
        fact.credits,
        reservation::Credits {
            records: 0,
            live_bytes: 0
        }
    );
    assert_eq!(
        fact.generation.unwrap(),
        reservation::Generation {
            pool: "pool".into(),
            slot: 0,
            generation: 1
        }
    );
    assert_eq!(anchored::snapshot(&s.connection, 7).unwrap(), before);
}

#[test]
fn all_scopes_and_bounds_precede_observation_and_no_partial_result_escapes() {
    let (_dir, mut s, scope) = fresh();
    let reader = s
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    let (_other_dir, _other, foreign) = fresh();
    for denied in [&reader, &foreign] {
        assert_eq!(
            s.get_many_snapshot_inner(
                denied,
                &[key("a", "state")],
                Some(&key("b", "hold")),
                || panic!("unauthorized prefix read")
            )
            .err()
            .map(ReadSnapshotError::error),
            Some(Error::Denied)
        );
    }
    for keys in [
        vec![],
        vec![key("a", "state"); 2],
        vec![key("a", "state"); 4],
        vec![key("a", "../bad")],
    ] {
        assert_eq!(
            s.get_many_snapshot_inner(&scope, &keys, Some(&key("b", "hold")), || panic!(
                "invalid prefix read"
            ))
            .err()
            .map(ReadSnapshotError::error),
            Some(Error::Invalid)
        );
    }
    assert_eq!(
        s.get_many_with_reservation(&scope, &[key("a", "state")], &key("b", "absent"))
            .err()
            .map(ReadSnapshotError::error),
        Some(Error::Missing)
    );
    s.poisoned = true;
    assert_eq!(
        s.get_many_snapshot_inner(
            &scope,
            &[key("a", "state")],
            Some(&key("b", "hold")),
            || panic!("poisoned prefix read")
        )
        .err()
        .map(ReadSnapshotError::error),
        Some(Error::ReopenRequired)
    );
}

#[test]
fn combined_payload_limit_is_preserved_before_any_record_is_allocated() {
    let (_dir, mut s, scope) = fresh();
    let value = "é".repeat(READ_SET_VALUE_BYTES / 4);
    for name in ["one", "two"] {
        s.commit(&scope, &batch(name, 0, Some(&value))).unwrap();
    }
    let (rows, _) = s
        .get_many_with_reservation(
            &scope,
            &[key("a", "one"), key("a", "two")],
            &key("b", "hold"),
        )
        .unwrap();
    assert_eq!(
        rows.iter()
            .map(|r| r.value.as_ref().unwrap().len())
            .sum::<usize>(),
        READ_SET_VALUE_BYTES
    );
    assert_eq!(
        s.get_many_snapshot_inner(
            &scope,
            &[key("a", "one"), key("a", "two"), key("a", "state")],
            Some(&key("b", "hold")),
            || panic!("oversized prefix allocated")
        )
        .err()
        .map(ReadSnapshotError::error),
        Some(Error::Limit)
    );
}

#[test]
fn actual_competing_commit_cannot_mix_record_and_reservation_observations() {
    let (dir, mut s, scope) = fresh();
    let (rows, fact) = s
        .get_many_snapshot_inner(
            &scope,
            &[key("a", "state")],
            Some(&key("b", "hold")),
            || {
                let mut writer = Connection::open(dir.path().join("data/records.sqlite")).unwrap();
                writer.busy_timeout(Duration::ZERO).unwrap();
                let tx = writer
                    .transaction_with_behavior(TransactionBehavior::Immediate)
                    .unwrap();
                tx.execute("DELETE FROM records", []).unwrap();
                tx.execute("DELETE FROM reservations", []).unwrap();
                assert_eq!(
                    tx.commit().unwrap_err().sqlite_error_code(),
                    Some(rusqlite::ErrorCode::DatabaseBusy)
                );
            },
        )
        .unwrap();
    assert_eq!(rows[0].value.as_deref(), Some("done"));
    assert_eq!(fact.unwrap().revision, 2);
    // Once the read snapshot ends, even tampering outside the requested rows
    // must be detected by the next combined read and the actual write path.
    let writer = Connection::open(dir.path().join("data/records.sqlite")).unwrap();
    writer
        .execute("UPDATE meta SET revision=revision+1", [])
        .unwrap();
    assert_eq!(
        s.get_many_with_reservation(&scope, &[key("a", "state")], &key("b", "hold"))
            .err()
            .map(ReadSnapshotError::error),
        Some(Error::Denied)
    );
    assert_eq!(
        s.commit(&scope, &batch("state", 2, Some("bad"))),
        Err(Error::Denied)
    );
}

#[test]
fn physical_owner_replacement_during_snapshot_is_refused() {
    for filename in ["owner.lock", "records.sqlite"] {
        let (dir, mut s, scope) = fresh();
        assert_eq!(
            s.get_many_snapshot_inner(
                &scope,
                &[key("a", "state")],
                Some(&key("b", "hold")),
                || {
                    let path = dir.path().join("data").join(filename);
                    fs::rename(&path, path.with_extension("old")).unwrap();
                    fs::write(&path, b"").unwrap();
                    fs::set_permissions(path, fs::Permissions::from_mode(0o600)).unwrap();
                }
            )
            .err()
            .map(ReadSnapshotError::error),
            Some(Error::Denied)
        );
    }
}

#[test]
fn combined_snapshot_refuses_a_foreign_process_before_reading() {
    let (_dir, mut s, scope) = fresh();
    let actual = s.owner.process;
    s.owner.process = actual.wrapping_add(1);
    assert_eq!(
        s.get_many_snapshot_inner(
            &scope,
            &[key("a", "state")],
            Some(&key("b", "hold")),
            || panic!("foreign process read storage")
        )
        .err()
        .map(ReadSnapshotError::error),
        Some(Error::Denied)
    );
    s.owner.process = actual;
}

#[test]
fn intervening_record_change_and_reused_generation_refuse_old_observations() {
    let (_dir, mut s, scope) = fresh();
    let (_, fact) = s
        .get_many_with_reservation(&scope, &[key("a", "state")], &key("b", "hold"))
        .unwrap();
    let request = reservation::slots::Retirement {
        namespace: "b".into(),
        key: "hold".into(),
        revision: fact.revision,
        binding: fact.binding,
        generation: fact.generation.unwrap(),
    };
    s.commit(&scope, &batch("state", 2, Some("changed")))
        .unwrap();
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("state", 2, Some("bad")), &request),
        Err(Error::Conflict)
    );
    s.commit_retiring_reservation(&scope, &batch("state", 3, Some("retired")), &request)
        .unwrap();
    let next = s
        .commit_reserving(
            &scope,
            &batch("state", 4, Some("next")),
            &reservation::Request {
                namespace: "b".into(),
                key: "hold".into(),
                binding: [8; 32],
                credits: reservation::Credits {
                    records: 1,
                    live_bytes: 1000,
                },
            },
        )
        .unwrap()
        .held
        .unwrap();
    s.commit_spending(
        &scope,
        &batch("state", 5, Some("done-next")),
        &next,
        next.credits(),
    )
    .unwrap();
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("state", 6, Some("bad")), &request),
        Err(Error::Conflict)
    );
    assert_eq!(
        s.get(&scope, "a", "state").unwrap().value.as_deref(),
        Some("done-next")
    );
}

#[test]
fn maintenance_requires_at_most_four_full_history_scans_and_rechecks_at_commit() {
    let (dir, mut s, scope) = fresh();
    anchored::ROOT_CALLS.with(|n| n.set(0));
    let (_, fact) = s
        .get_many_with_reservation(&scope, &[key("a", "state")], &key("b", "hold"))
        .unwrap();
    let request = reservation::slots::Retirement {
        namespace: "b".into(),
        key: "hold".into(),
        revision: fact.revision,
        binding: fact.binding,
        generation: fact.generation.unwrap(),
    };
    s.commit_retiring_reservation(&scope, &batch("state", 2, Some("retired")), &request)
        .unwrap();
    assert!(anchored::ROOT_CALLS.with(|n| n.get()) <= 4);
    drop(s);
    // A new fixture exercises a real logical change between observation and
    // retirement; the removed preflight scan must not become a stale trust cache.
    let (_dir2, mut s, scope) = fresh();
    let (_, fact) = s
        .get_many_with_reservation(&scope, &[key("a", "state")], &key("b", "hold"))
        .unwrap();
    let request = reservation::slots::Retirement {
        namespace: "b".into(),
        key: "hold".into(),
        revision: fact.revision,
        binding: fact.binding,
        generation: fact.generation.unwrap(),
    };
    s.connection
        .execute("UPDATE meta SET revision=revision+1", [])
        .unwrap();
    assert_eq!(
        s.commit_retiring_reservation(&scope, &batch("state", 2, Some("bad")), &request),
        Err(Error::Denied)
    );
    assert_eq!(
        s.connection
            .query_row(
                "SELECT value FROM records WHERE namespace='a' AND key='state'",
                [],
                |r| r.get::<_, Vec<u8>>(0)
            )
            .unwrap(),
        b"done"
    );
    drop(dir);
}
