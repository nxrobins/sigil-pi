use super::*;
use crate::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use std::os::unix::fs::PermissionsExt;
use std::time::Instant;

fn signed_log(store: &Store) -> AuthenticatedLog {
    AuthenticatedLog::new(
        store,
        "heads",
        "events",
        ChainLimits {
            payload_bytes: 1024,
            records: 2,
            bytes: 65_536,
        },
        &[4; 32],
    )
    .unwrap()
}
fn signed_reserve(store: &mut Store, scope: &Scope) -> Held {
    let log = signed_log(store);
    let allowance = log
        .prepare_allowance(store, scope, &"a".repeat(64), 0, 2, 20_000)
        .unwrap();
    store
        .commit_reserving_audited(
            scope,
            &batch("intent", 0, "accepted"),
            &Request {
                namespace: "a".into(),
                key: "hold".into(),
                binding: [7; 32],
                credits: Credits {
                    records: 10,
                    live_bytes: 50_000,
                },
            },
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap()
}

fn allocation(bytes: u64) -> capacity::Allocation {
    capacity::Allocation {
        version: 1,
        pools: vec![capacity::Pool {
            id: "p".into(),
            namespaces: vec!["a".into(), "heads".into(), "events".into()],
            records: 1000,
            live_bytes: bytes,
        }],
    }
}
fn open(root: &Path, mode: OpenMode, bytes: u64) -> Store {
    Store::open_witnessed_reserved_bound(
        root,
        mode,
        Limits::default(),
        allocation(bytes),
        [3; 32],
        BTreeMap::from([("p".into(), 8)]),
    )
    .unwrap()
}
fn fresh(bytes: u64) -> (tempfile::TempDir, Store, Scope) {
    let root = tempfile::tempdir().unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let store = open(root.path(), OpenMode::CreateNew, bytes);
    let scope = owner(&store);
    (root, store, scope)
}
fn owner(store: &Store) -> Scope {
    store
        .scope(
            ["a", "heads", "events"]
                .into_iter()
                .map(|n| (n.into(), Access::ReadWrite))
                .collect(),
        )
        .unwrap()
}
fn batch(key: &str, revision: u64, value: &str) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: key.into(),
            revision,
            value: Some(value.into()),
        }],
    }
}
fn reserve(store: &mut Store, scope: &Scope, credits: Credits) -> Held {
    store
        .commit_reserving(
            scope,
            &batch("i", 0, "x"),
            &Request {
                namespace: "a".into(),
                key: "hold".into(),
                binding: [7; 32],
                credits,
            },
        )
        .unwrap()
        .held
        .unwrap()
}
fn zero() -> Credits {
    Credits {
        records: 0,
        live_bytes: 0,
    }
}
fn snapshot(store: &Store) -> Vec<Vec<rusqlite::types::Value>> {
    let mut result = vec![];
    for (sql, n) in [
        ("SELECT revision FROM meta", 1),
        (
            "SELECT namespace,key,revision,value,digest FROM records ORDER BY namespace,key",
            5,
        ),
        (
            "SELECT namespace,key,revision,binding,records,bytes,audits,origin,witness,digest FROM reservations ORDER BY namespace,key",
            10,
        ),
    ] {
        result.extend(
            store
                .connection
                .prepare(sql)
                .unwrap()
                .query_map([], |r| {
                    (0..n)
                        .map(|i| r.get(i))
                        .collect::<rusqlite::Result<Vec<_>>>()
                })
                .unwrap()
                .collect::<rusqlite::Result<Vec<_>>>()
                .unwrap(),
        );
    }
    result
}

#[test]
fn refresh_accepts_only_debits_of_the_same_assignment() {
    let (root, mut store, scope) = fresh(1_000_000);
    let original = reserve(
        &mut store,
        &scope,
        Credits {
            records: 10,
            live_bytes: 50_000,
        },
    );
    let assigned = store
        .commit_assigning_witness(
            &scope,
            &batch("claim", 0, "x"),
            &original,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
            &[],
            [8; 32],
            b"actual assignment",
        )
        .unwrap()
        .held
        .unwrap();
    assert!(matches!(
        store.refresh_reservation(&original),
        Err(Error::Denied)
    ));
    let debited = store
        .commit_spending(
            &scope,
            &batch("cancel", 0, "x"),
            &assigned,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
        )
        .unwrap()
        .held
        .unwrap();
    let refreshed = store.refresh_reservation(&assigned).unwrap();
    assert_eq!(refreshed.revision(), debited.revision());
    assert_eq!(refreshed.credits(), debited.credits());
    let returned = store
        .commit_assigning_witness(
            &scope,
            &batch("result", 0, "x"),
            &refreshed,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
            &[],
            [7; 32],
            b"",
        )
        .unwrap()
        .held
        .unwrap();
    assert!(matches!(
        store.refresh_reservation(&assigned),
        Err(Error::Conflict)
    ));
    drop(store);
    let reopened = open(root.path(), OpenMode::Existing, 1_000_000);
    assert!(matches!(
        reopened.refresh_reservation(&returned),
        Err(Error::Denied)
    ));
}

#[test]
fn final_signed_release_is_atomic_and_cannot_discard_an_assignment() {
    let (_root, mut store, scope) = fresh(1_000_000);
    let held = signed_reserve(&mut store, &scope);
    let log = signed_log(&store);
    let chain = "a".repeat(64);
    let before = snapshot(&store);
    assert!(
        log.append_releasing(
            &mut store,
            &scope,
            &chain,
            0,
            "settled",
            &batch("intent", 99, "wrong revision"),
            &held
        )
        .is_err()
    );
    assert_eq!(snapshot(&store), before);
    let assigned = store
        .commit_assigning_witness(
            &scope,
            &batch("claim", 0, "x"),
            &held,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
            &[],
            [8; 32],
            b"actual assignment",
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    assert!(matches!(
        log.append_releasing(
            &mut store,
            &scope,
            &chain,
            0,
            "settled",
            &batch("done", 0, "x"),
            &assigned
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    let returned = store
        .commit_assigning_witness(
            &scope,
            &batch("result", 0, "x"),
            &assigned,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
            &[],
            [7; 32],
            b"",
        )
        .unwrap()
        .held
        .unwrap();
    log.append_releasing(
        &mut store,
        &scope,
        &chain,
        0,
        "settled",
        &batch("done", 0, "x"),
        &returned,
    )
    .unwrap();
    let facts = store.reservation_snapshot(&scope, "a", "hold").unwrap();
    assert_eq!(facts.credits, zero());
    assert!(facts.assignment.is_empty());
    let before = snapshot(&store);
    assert!(
        log.append_releasing(
            &mut store,
            &scope,
            &chain,
            1,
            "duplicate",
            &batch("done", 1, "again"),
            &returned
        )
        .is_err()
    );
    assert_eq!(snapshot(&store), before);
}

#[test]
fn origin_and_assignment_survive_reopen_while_read_facts_never_issue_credit_authority() {
    let (root, mut store, scope) = fresh(1_000_000);
    let held = reserve(
        &mut store,
        &scope,
        Credits {
            records: 10,
            live_bytes: 50_000,
        },
    );
    assert_eq!(held.coordinate(), ("a", "hold"));
    let initial = store.reservation_snapshot(&scope, "a", "hold").unwrap();
    assert_eq!(initial.origin, [7; 32]);
    assert_eq!(initial.binding, [7; 32]);
    assert!(initial.assignment.is_empty());
    let assigned = store
        .commit_assigning_witness(
            &scope,
            &batch("claim", 0, "claimed"),
            &held,
            zero(),
            &[],
            [8; 32],
            b"opaque actual assignment",
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(assigned.revision(), 2);
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning(
            &scope,
            &batch("other", 0, "x"),
            &assigned,
            zero(),
            &[],
            [9; 32]
        ),
        Err(Error::Invalid)
    ));
    assert_eq!(snapshot(&store), before);
    drop(store);
    let mut store = open(root.path(), OpenMode::Existing, 1_000_000);
    let read = store
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    let observed = store.reservation_snapshot(&read, "a", "hold").unwrap();
    assert_eq!(observed.origin, [7; 32]);
    assert_eq!(observed.binding, [8; 32]);
    assert_eq!(observed.revision, 2);
    assert_eq!(observed.assignment, b"opaque actual assignment");
    assert!(matches!(
        store.resume_reservation(&read, "a", "hold", 2, [8; 32]),
        Err(Error::Denied)
    ));
    let scope = owner(&store);
    let resumed = store
        .resume_reservation(&scope, "a", "hold", 2, [8; 32])
        .unwrap();
    assert!(matches!(
        store.commit_spending(
            &scope,
            &batch("old", 0, "x"),
            &assigned,
            Credits {
                records: 1,
                live_bytes: 0
            }
        ),
        Err(Error::Denied)
    ));
    let next = store
        .commit_spending(
            &scope,
            &batch("result", 0, "known result"),
            &resumed,
            Credits {
                records: 1,
                live_bytes: 1000,
            },
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(
        store
            .reservation_snapshot(&scope, "a", "hold")
            .unwrap()
            .assignment,
        b"opaque actual assignment"
    );
    let returned = store
        .commit_assigning_witness(
            &scope,
            &batch("retired", 0, "explicit disposition"),
            &next,
            zero(),
            &[],
            [7; 32],
            b"",
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(returned.revision(), 4);
    let facts = store.reservation_snapshot(&scope, "a", "hold").unwrap();
    assert_eq!(facts.origin, [7; 32]);
    assert_eq!(facts.binding, [7; 32]);
    assert!(facts.assignment.is_empty());
    assert!(
        store
            .resume_reservation(&scope, "a", "hold", 1, [7; 32])
            .is_err()
    );
}

#[test]
fn witness_bytes_and_immutable_origin_are_metered_exactly() {
    // Data99 + ledger149 + origin32 + empty audit array2 + heldbytes2 =284.
    let (_root, mut store, scope) = fresh(284);
    let held = reserve(
        &mut store,
        &scope,
        Credits {
            records: 0,
            live_bytes: 2,
        },
    );
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning_witness(
            &scope,
            &batch("i", 1, "x"),
            &held,
            zero(),
            &[],
            [8; 32],
            b"x"
        ),
        Err(Error::Limit)
    ));
    assert_eq!(snapshot(&store), before);
    let assigned = store
        .commit_assigning_witness(
            &scope,
            &batch("i", 1, "x"),
            &held,
            Credits {
                records: 0,
                live_bytes: 1,
            },
            &[],
            [8; 32],
            b"x",
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(assigned.credits().live_bytes, 1);
    let returned = store
        .commit_assigning_witness(
            &scope,
            &batch("i", 2, "x"),
            &assigned,
            zero(),
            &[],
            [7; 32],
            b"",
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(returned.credits().live_bytes, 1);
    store.commit(&scope, &batch("i", 3, "é")).unwrap();
    assert_eq!(
        store.commit(&scope, &batch("i", 4, "éx")),
        Err(Error::Limit)
    );
}

#[test]
fn witness_bounds_structure_stale_handles_and_scope_refuse_atomically() {
    let (_root, mut store, scope) = fresh(1_000_000);
    let held = reserve(
        &mut store,
        &scope,
        Credits {
            records: 10,
            live_bytes: 50_000,
        },
    );
    let before = snapshot(&store);
    for bytes in [vec![], vec![b'x'; BYTES + 1]] {
        assert!(
            store
                .commit_assigning_witness(
                    &scope,
                    &batch("claim", 0, "x"),
                    &held,
                    zero(),
                    &[],
                    [8; 32],
                    &bytes
                )
                .is_err()
        );
        assert_eq!(snapshot(&store), before);
    }
    let readonly = store
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    assert!(matches!(
        store.commit_assigning_witness(
            &readonly,
            &batch("claim", 0, "x"),
            &held,
            zero(),
            &[],
            [8; 32],
            b"x"
        ),
        Err(Error::Denied)
    ));
    assert_eq!(snapshot(&store), before);
    let assigned = store
        .commit_assigning_witness(
            &scope,
            &batch("claim", 0, "x"),
            &held,
            zero(),
            &[],
            [8; 32],
            &vec![b'x'; BYTES],
        )
        .unwrap()
        .held
        .unwrap();
    assert_eq!(
        store
            .reservation_snapshot(&scope, "a", "hold")
            .unwrap()
            .assignment
            .len(),
        BYTES
    );
    let before = snapshot(&store);
    assert!(matches!(
        store.commit_assigning_witness(
            &scope,
            &batch("rival", 0, "x"),
            &held,
            zero(),
            &[],
            [9; 32],
            b"rival"
        ),
        Err(Error::Conflict)
    ));
    assert_eq!(snapshot(&store), before);
    assert!(matches!(
        store.commit_assigning_witness(
            &scope,
            &batch("badreturn", 0, "x"),
            &assigned,
            zero(),
            &[],
            [7; 32],
            b"notempty"
        ),
        Err(Error::Invalid)
    ));
    assert_eq!(snapshot(&store), before);
}

#[test]
fn witnessed_profile_is_explicit_and_corrupt_metadata_is_never_repaired() {
    let (root, mut store, scope) = fresh(1_000_000);
    let _held = reserve(
        &mut store,
        &scope,
        Credits {
            records: 1,
            live_bytes: 100,
        },
    );
    assert!(store.has_reservation_witnesses());
    let raw: String = store
        .connection
        .query_row("SELECT limits FROM meta", [], |r| r.get(0))
        .unwrap();
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(&raw).unwrap()["format"],
        FORMAT
    );
    drop(store);
    assert!(
        Store::open_audit_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(1_000_000),
            [3; 32],
            BTreeMap::from([("p".into(), 8)])
        )
        .is_err()
    );
    let mut store = open(root.path(), OpenMode::Existing, 1_000_000);
    let scope = owner(&store);
    store
        .connection
        .execute(
            "UPDATE reservations SET witness=zeroblob(?1)",
            [BYTES as i64 + 1],
        )
        .unwrap();
    let before = snapshot(&store);
    assert!(store.reservation_snapshot(&scope, "a", "hold").is_err());
    assert!(
        store
            .inspect_namespaces(
                &scope,
                &["a".into()],
                std::time::Instant::now() + Duration::from_secs(2)
            )
            .is_err()
    );
    assert_eq!(snapshot(&store), before);
    drop(store);
    assert!(
        Store::open_witnessed_reserved_bound(
            root.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(1_000_000),
            [3; 32],
            BTreeMap::from([("p".into(), 8)])
        )
        .is_err()
    );
}

#[test]
fn signed_assignment_witness_and_result_are_atomic_and_uncertain_commit_requires_reopen() {
    let (root, mut store, scope) = fresh(1_000_000);
    let log = AuthenticatedLog::new(
        &store,
        "heads",
        "events",
        ChainLimits {
            payload_bytes: 1024,
            records: 2,
            bytes: 65_536,
        },
        &[4; 32],
    )
    .unwrap();
    let chain = "a".repeat(64);
    let allowance = log
        .prepare_allowance(&store, &scope, &chain, 0, 2, 20_000)
        .unwrap();
    let held = store
        .commit_reserving_audited(
            &scope,
            &batch("intent", 0, "x"),
            &Request {
                namespace: "a".into(),
                key: "hold".into(),
                binding: [7; 32],
                credits: Credits {
                    records: 10,
                    live_bytes: 50_000,
                },
            },
            &[allowance],
        )
        .unwrap()
        .held
        .unwrap();
    let assigned = log
        .append_assigning_witness(
            &mut store,
            &scope,
            &chain,
            0,
            "prepared",
            &batch("claim", 0, "x"),
            &held,
            Credits {
                records: 3,
                live_bytes: 5000,
            },
            [8; 32],
            b"actual claim witness",
        )
        .unwrap()
        .held
        .unwrap();
    let before = snapshot(&store);
    store.connection.commit_hook(Some(|| true)).unwrap();
    assert!(matches!(
        log.append_assigning_witness(
            &mut store,
            &scope,
            &chain,
            1,
            "observed",
            &batch("result", 0, "x"),
            &assigned,
            Credits {
                records: 2,
                live_bytes: 5000
            },
            [7; 32],
            b""
        ),
        Err(Error::CommitUncertain)
    ));
    assert!(matches!(
        store.reservation_snapshot(&scope, "a", "hold"),
        Err(Error::ReopenRequired)
    ));
    drop(store);
    let store = open(root.path(), OpenMode::Existing, 1_000_000);
    assert_eq!(snapshot(&store), before);
    let scope = owner(&store);
    let facts = store.reservation_snapshot(&scope, "a", "hold").unwrap();
    assert_eq!(facts.origin, [7; 32]);
    assert_eq!(facts.binding, [8; 32]);
    assert_eq!(facts.revision, 2);
    assert_eq!(facts.assignment, b"actual claim witness");
}

struct Child(std::process::Child);
impl Drop for Child {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn kill_at(root: &Path, kind: &str, phase: &str) {
    use std::io::{BufRead, BufReader};
    use std::process::{Command, Stdio};
    let mut child = Child(
        Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::reservation::witness::tests::witness_phase_worker_child",
                "--nocapture",
            ])
            .env("SIGIL_WITNESS_ROOT", root)
            .env("SIGIL_WITNESS_KIND", kind)
            .env("SIGIL_WITNESS_PHASE", phase)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap(),
    );
    let output = child.0.stdout.take().unwrap();
    let (tx, rx) = std::sync::mpsc::channel();
    let reader = std::thread::spawn(move || {
        for line in BufReader::new(output)
            .lines()
            .map_while(std::result::Result::ok)
        {
            if line.contains("WITNESS_COMMIT_BOUNDARY") {
                let _ = tx.send(());
                break;
            }
        }
    });
    rx.recv_timeout(Duration::from_secs(15))
        .expect("actual witness transaction boundary not reached");
    child.0.kill().unwrap();
    assert!(!child.0.wait().unwrap().success());
    reader.join().unwrap();
}
#[test]
fn witness_phase_worker_child() {
    use std::io::Write;
    let Ok(root) = std::env::var("SIGIL_WITNESS_ROOT") else {
        return;
    };
    let kind = std::env::var("SIGIL_WITNESS_KIND").unwrap();
    let phase = std::env::var("SIGIL_WITNESS_PHASE").unwrap();
    let mut store = open(Path::new(&root), OpenMode::Existing, 1_000_000);
    let scope = owner(&store);
    let log = signed_log(&store);
    let park = || {
        println!("WITNESS_COMMIT_BOUNDARY");
        std::io::stdout().flush().unwrap();
        loop {
            std::thread::park();
        }
    };
    if kind == "create" {
        let allowance = log
            .prepare_allowance(&store, &scope, &"a".repeat(64), 0, 2, 20_000)
            .unwrap();
        store
            .commit_reserving_audited_inner(
                &scope,
                &batch("intent", 0, "accepted"),
                &Request {
                    namespace: "a".into(),
                    key: "hold".into(),
                    binding: [7; 32],
                    credits: Credits {
                        records: 10,
                        live_bytes: 50_000,
                    },
                },
                &[allowance],
                None,
                || {
                    if phase == "before" {
                        park();
                    }
                },
            )
            .unwrap();
    } else {
        let terminal = kind == "terminal";
        let held = store
            .resume_reservation(
                &scope,
                "a",
                "hold",
                if terminal { 2 } else { 1 },
                if terminal { [8; 32] } else { [7; 32] },
            )
            .unwrap();
        log.append_credit_update_witness(
            &mut store,
            &scope,
            &"a".repeat(64),
            u64::from(terminal),
            if terminal { "observed" } else { "prepared" },
            &batch(if terminal { "result" } else { "claim" }, 0, "x"),
            &held,
            Credits {
                records: 3,
                live_bytes: 5000,
            },
            Some(if terminal { [7; 32] } else { [8; 32] }),
            Some(if terminal {
                b""
            } else {
                b"actual claim witness"
            }),
            || {
                if phase == "before" {
                    park();
                }
            },
        )
        .unwrap();
    }
    park();
}
#[test]
fn hard_death_at_six_witness_boundaries_preserves_atomic_origin_assignment_data_and_audit() {
    for kind in ["create", "assign", "terminal"] {
        for phase in ["before", "after"] {
            let (root, mut store, scope) = fresh(1_000_000);
            if kind != "create" {
                let held = signed_reserve(&mut store, &scope);
                if kind == "terminal" {
                    signed_log(&store)
                        .append_assigning_witness(
                            &mut store,
                            &scope,
                            &"a".repeat(64),
                            0,
                            "prepared",
                            &batch("claim", 0, "x"),
                            &held,
                            Credits {
                                records: 3,
                                live_bytes: 5000,
                            },
                            [8; 32],
                            b"actual claim witness",
                        )
                        .unwrap();
                }
            }
            let before = snapshot(&store);
            drop(store);
            kill_at(root.path(), kind, phase);
            let mut store = open(root.path(), OpenMode::Existing, 1_000_000);
            let scope = owner(&store);
            if phase == "before" {
                assert_eq!(
                    snapshot(&store),
                    before,
                    "{kind}: uncommitted transaction changed storage"
                );
            } else {
                let expected = match kind {
                    "create" => (1, 10, 50_000, 0),
                    "assign" => (2, 7, 45_000, 1),
                    _ => (3, 4, 40_000, 2),
                };
                let seen = store.reservation_snapshot(&scope, "a", "hold").unwrap();
                assert_eq!(
                    (seen.revision, seen.credits.records, seen.credits.live_bytes),
                    (expected.0, expected.1, expected.2)
                );
                assert_eq!(seen.origin, [7; 32]);
                assert_eq!(
                    seen.binding,
                    if kind == "assign" { [8; 32] } else { [7; 32] }
                );
                assert_eq!(
                    seen.assignment,
                    if kind == "assign" {
                        b"actual claim witness".as_slice()
                    } else {
                        b""
                    }
                );
                assert_eq!(
                    store.get(&scope, "a", "intent").unwrap().value.as_deref(),
                    Some("accepted")
                );
                assert_eq!(
                    store.get(&scope, "a", "claim").unwrap().revision,
                    u64::from(kind != "create")
                );
                assert_eq!(
                    store.get(&scope, "a", "result").unwrap().revision,
                    u64::from(kind == "terminal")
                );
                assert_eq!(
                    store
                        .get(&scope, "heads", &"a".repeat(64))
                        .unwrap()
                        .revision,
                    expected.3
                );
                let events: i64 = store
                    .connection
                    .query_row(
                        "SELECT count(*) FROM records WHERE namespace='events'",
                        [],
                        |r| r.get(0),
                    )
                    .unwrap();
                assert_eq!(events, expected.3 as i64);
                signed_log(&store)
                    .inspect_existing(
                        &mut store,
                        &scope,
                        &"a".repeat(64),
                        None,
                        Instant::now() + Duration::from_secs(1),
                    )
                    .unwrap();
            }
        }
    }
}
