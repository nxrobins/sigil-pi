//! Retained native facts at the durable local dispatch boundary. These facts
//! prove neither HTTP initiation nor remote delivery. No caller clock, receipt,
//! result, execution grant or recovery decision is accepted by this module.
use super::*;
use serde::Serialize;
use sha2::{Digest, Sha256};
use sigil_durable_store::store::{Batch, Mutation};

fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn hex(bytes: [u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

// Non-deserializable preparation. Only an actual held Attempt constructs it;
// only the original atomic claim transaction may publish it.
pub(crate) struct Prepared {
    forbidden_namespaces: Vec<String>,
    claimed_at_unix_ms: u64,
    intent_binding: String,
    assignment_binding: String,
    assignment_origin: String,
    assignment: String,
    claim_sha256: String,
    policy_batch_sha256: String,
}

#[derive(Serialize)]
struct Fact<'a> {
    format: &'static str,
    claimed_at_unix_ms: u64,
    intent_binding: &'a str,
    assignment_binding: &'a str,
    assignment_origin: &'a str,
    assignment: &'a str,
    claim_sha256: &'a str,
    policy_batch_sha256: &'a str,
    audit_chain: &'a str,
    audit_sequence: u64,
}

impl Prepared {
    pub(super) fn observe(
        attempt: &mut Attempt<'_>,
        assignment: &completion::witness::Assignment,
        raw: &str,
        delivery: &str,
    ) -> Result<Self> {
        if !attempt.store.has_execution_fence() {
            return Err("execution_fence");
        }
        // The assignment already binds the actual original domain/epoch,
        // intent revision/hash, generation, ticket, input, source and runtime.
        let assignment_bytes = assignment.witness.as_deref().ok_or("funding_witness")?;
        let binding = completion::hash(&[
            b"sigil-completion-intent/v1",
            attempt.intent.namespace.as_bytes(),
            attempt.intent.key.as_bytes(),
            &attempt.intent.revision.to_be_bytes(),
            attempt
                .snapshot
                .value
                .as_deref()
                .ok_or("intent")?
                .as_bytes(),
            attempt.claim_namespace.as_bytes(),
            delivery.as_bytes(),
        ]);
        let batch = commit_batch(raw)?;
        let claim = batch
            .writes
            .first()
            .and_then(|w| w.value.as_deref())
            .ok_or("claim")?;
        let claimed_at_unix_ms = attempt
            .guard
            .admit_observed_millis(attempt.last_clock, attempt.deadline)?;
        Ok(Self {
            forbidden_namespaces: vec![
                attempt.intent.namespace.clone(),
                attempt.claim_namespace.clone(),
                delivery.into(),
                attempt
                    .funding
                    .as_ref()
                    .and_then(|f| f.held.as_ref())
                    .ok_or("funding")?
                    .coordinate()
                    .0
                    .into(),
            ],
            claimed_at_unix_ms,
            intent_binding: hex(binding),
            assignment_binding: hex(assignment.binding),
            assignment_origin: hex(attempt.funding.as_ref().ok_or("funding")?.origin_binding()),
            assignment: std::str::from_utf8(assignment_bytes)
                .map_err(|_| "funding_witness")?
                .into(),
            claim_sha256: digest(claim.as_bytes()),
            policy_batch_sha256: digest(raw.as_bytes()),
        })
    }

    pub(crate) fn couple(
        &self,
        namespace: &str,
        chain: &str,
        sequence: u64,
        policy_payload: &str,
        batch: &Batch,
    ) -> Result<(Batch, String)> {
        if self
            .forbidden_namespaces
            .iter()
            .any(|name| name == namespace)
        {
            return Err("dispatch_journal");
        }
        let fact = serde_json::to_string(&Fact {
            format: "sigil-native-dispatch-start/v1",
            claimed_at_unix_ms: self.claimed_at_unix_ms,
            intent_binding: &self.intent_binding,
            assignment_binding: &self.assignment_binding,
            assignment_origin: &self.assignment_origin,
            assignment: &self.assignment,
            claim_sha256: &self.claim_sha256,
            policy_batch_sha256: &self.policy_batch_sha256,
            audit_chain: chain,
            audit_sequence: sequence,
        })
        .map_err(|_| "dispatch_journal")?;
        if fact.len() > 12_288 {
            return Err("dispatch_journal");
        }
        let mut related = batch.clone();
        related.writes.push(Mutation {
            namespace: namespace.into(),
            key: self.intent_binding.clone(),
            revision: 0,
            value: Some(fact.clone()),
        });
        // Keep the policy-selected/redacted payload as its own value. This
        // native envelope binds both the additional fact and the exact related
        // mutation set; atomic related writes alone are not a signed binding.
        let payload = serde_json::to_string(&serde_json::json!({
            "format":"sigil-native-dispatch-audit/v1",
            "policy_payload":policy_payload,
            "policy_batch_sha256":self.policy_batch_sha256,
            "journal_namespace":namespace,
            "journal_key":self.intent_binding,
            "journal_sha256":digest(fact.as_bytes()),
            "related_batch_sha256":digest(&serde_json::to_vec(&related).map_err(|_| "dispatch_journal")?),
        })).map_err(|_| "dispatch_journal")?;
        Ok((related, payload))
    }
}

#[cfg(test)]
#[path = "dispatch_journal_tests.rs"]
mod tests;
