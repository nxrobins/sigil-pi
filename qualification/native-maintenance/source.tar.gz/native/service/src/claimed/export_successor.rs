//! Export-only recovery of an already terminal, separately funded operation.
//! No worker, execution ticket, provider credential or application write scope
//! is accepted here. SIGIL selects bytes; native code commits them before I/O.
use super::export_capacity::{Admission, Ledger, Policy};
use super::*;
use serde::{Deserialize, Serialize};
use sigil_durable_store::store::reservation::{Credits, Held};
use sigil_durable_store::store::{Access, Batch, Mutation};
use sigil_worker_bridge::publication::{DurablePublication, FixedSink, FixedSource};
use std::collections::BTreeMap;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PreparedExport {
    format: String,
    admission_sha256: String,
    terminal_facts_sha256: String,
    destination: String,
    payload_hex: String,
    payload_sha256: String,
    payload_bytes: usize,
    audit_sequence: u64,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PublicationFact {
    destination: String,
    payload_sha256: String,
    payload_bytes: usize,
    existing: bool,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Ack {
    format: String,
    admission_sha256: String,
    prepared_sha256: String,
    publication: PublicationFact,
    audit_sequence: u64,
}

/// A verified historical local publication. It does not assert current file
/// presence, remote consumption, or permission to advance an application lane.
pub struct Acknowledged {
    pub destination: String,
    pub payload_sha256: String,
    pub payload_bytes: usize,
    pub replayed: bool,
}

fn digest(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    format!("{:x}", Sha256::digest(bytes))
}
fn decode_hex(value: &str, limit: usize) -> Result<Vec<u8>> {
    if value.is_empty()
        || value.len() > limit * 2
        || !value.len().is_multiple_of(2)
        || !value
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("export_payload");
    }
    value
        .as_bytes()
        .as_chunks::<2>()
        .0
        .iter()
        .map(|pair| {
            let n = |b: u8| if b <= b'9' { b - b'0' } else { b - b'a' + 10 };
            Ok(n(pair[0]) * 16 + n(pair[1]))
        })
        .collect()
}
fn storage(error: sigil_durable_store::store::Error) -> &'static str {
    if error == sigil_durable_store::store::Error::CommitUncertain {
        "commit_uncertain"
    } else {
        "export_storage"
    }
}

fn source_facts(
    terminal: &TerminalCompletion,
    store: &Store,
    caller: &Scope,
    a: &Admission,
    source: Option<&FixedSource>,
) -> Result<(String, Vec<Check>)> {
    let (native, checks) = terminal.export_facts(store, caller, a)?;
    let native = if let Some(external) = super::export_capacity::checked_source(a, source)? {
        frame("GX1\n", &[&native, &external])?
    } else {
        native
    };
    Ok((native, checks))
}

impl Ledger {
    fn read_record(&self, store: &Store, key: &str, limit: usize) -> Result<Option<String>> {
        let r = store
            .get(&self.scope, &self.namespace, key)
            .map_err(|_| "export_record")?;
        match (r.revision, r.value) {
            (0, None) => Ok(None),
            (1, Some(raw)) if raw.len() <= limit => Ok(Some(raw)),
            _ => Err("export_record"),
        }
    }

    fn verify_event(
        &self,
        store: &mut Store,
        key: &str,
        raw: &str,
        sequence: u64,
        format: &str,
        deadline: Instant,
    ) -> Result<()> {
        let (_, payload) = self
            .log
            .verified_payload(store, &self.scope, &self.chain, sequence, deadline)
            .map_err(|_| "export_authentication")?;
        let event: serde_json::Value =
            serde_json::from_str(&payload).map_err(|_| "export_authentication")?;
        if event["format"] != format
            || event["namespace"] != self.namespace
            || event["key"] != key
            || event["sha256"] != digest(raw.as_bytes())
        {
            return Err("export_authentication");
        }
        Ok(())
    }

    fn admission(
        &self,
        store: &mut Store,
        intent: &str,
        sink: &FixedSink,
        policy: &Policy,
        deadline: Instant,
    ) -> Result<(Admission, String)> {
        crate::digest_bytes(intent)?;
        let key = format!("admit:{intent}");
        let raw = self
            .read_record(store, &key, 12_288)?
            .ok_or("export_admission")?;
        let a: Admission = serde_json::from_str(&raw).map_err(|_| "export_admission")?;
        let (domain, epoch) = store.execution_identity().map_err(|_| "execution_fence")?;
        if a.format
            != super::export_capacity::admission_format(
                a.source_guard.is_some(),
                store.has_reservation_generations(),
            )
            || a.reservation_generation.is_some() != store.has_reservation_generations()
            || a.execution_generation.is_some() != store.has_reservation_generations()
            || a.intent_binding != intent
            || a.domain != domain
            || a.epoch == epoch
            || a.audit_chain != self.chain
            || a.destination != sink.identity()
            || a.policy_source != policy.config.source_sha256
            || a.policy_runtime != policy.config.runtime_sha256
            || policy.config.version != 1
            || !(1..=65_536).contains(&a.payload_bytes)
            || a.payload_bytes > sink.payload_limit()
            || a.preparation_records < 3
            || a.acknowledgement_records < 3
            || a.preparation_bytes
                < 6 * a.payload_bytes as u64 + self.log.encoded_entry_ceiling() + 8192
            || a.acknowledgement_bytes < self.log.encoded_entry_ceiling() + 8192
            || serde_json::to_string(&a).map_err(|_| "export_admission")? != raw
        {
            return Err("export_admission");
        }
        crate::digest_bytes(&a.epoch)?;
        if let Some(guard) = &a.source_guard {
            crate::digest_bytes(&guard.identity)?;
            crate::digest_bytes(&guard.payload_sha256)?;
            if !(1..=1_048_576).contains(&guard.payload_bytes) {
                return Err("export_admission");
            }
            let bounds = a.policy_bounds.as_ref().ok_or("export_admission")?;
            if bounds.fuel != policy.config.max_fuel
                || bounds.timeout_ms != policy.config.max_timeout_ms
            {
                return Err("export_admission");
            }
        } else if a.policy_bounds.is_some() {
            return Err("export_admission");
        }
        self.check_future_limits(store, a.payload_bytes)?;
        crate::Function::manifest(&policy.config)?;
        // Re-admit the actual pinned files even when a prepared projection
        // skips evaluation. Cached objects cannot mask changed artifacts.
        let _pinned = crate::Function::cached(policy.config.clone())?;
        self.verify_event(
            store,
            &key,
            &raw,
            a.audit_sequence,
            "sigil-native-export-admission-audit/v1",
            deadline,
        )?;
        Ok((a, raw))
    }

    fn prepared(
        &self,
        store: &mut Store,
        a: &Admission,
        admission_raw: &str,
        deadline: Instant,
    ) -> Result<Option<(PreparedExport, String, Vec<u8>)>> {
        let key = format!("prepare:{}", a.intent_binding);
        let Some(raw) = self.read_record(store, &key, 2 * a.payload_bytes + 8192)? else {
            return Ok(None);
        };
        let p: PreparedExport = serde_json::from_str(&raw).map_err(|_| "export_prepared")?;
        let bytes = decode_hex(&p.payload_hex, a.payload_bytes)?;
        if p.format != "sigil-native-export-prepared/v1"
            || p.admission_sha256 != digest(admission_raw.as_bytes())
            || p.destination != a.destination
            || p.payload_bytes != bytes.len()
            || p.payload_sha256 != digest(&bytes)
            || p.audit_sequence <= a.audit_sequence
            || serde_json::to_string(&p).map_err(|_| "export_prepared")? != raw
        {
            return Err("export_prepared");
        }
        crate::digest_bytes(&p.terminal_facts_sha256)?;
        self.verify_event(
            store,
            &key,
            &raw,
            p.audit_sequence,
            "sigil-native-export-prepared-audit/v1",
            deadline,
        )?;
        Ok(Some((p, raw, bytes)))
    }

    fn ack(
        &self,
        store: &mut Store,
        a: &Admission,
        admission_raw: &str,
        deadline: Instant,
    ) -> Result<Option<Acknowledged>> {
        let key = format!("ack:{}", a.intent_binding);
        let Some(raw) = self.read_record(store, &key, 8192)? else {
            return Ok(None);
        };
        let ack: Ack = serde_json::from_str(&raw).map_err(|_| "export_ack")?;
        let (p, prepared_raw, _) = self
            .prepared(store, a, admission_raw, deadline)?
            .ok_or("export_ack")?;
        if ack.format != "sigil-native-export-ack/v1"
            || ack.admission_sha256 != digest(admission_raw.as_bytes())
            || ack.prepared_sha256 != digest(prepared_raw.as_bytes())
            || ack.publication.destination != p.destination
            || ack.publication.payload_sha256 != p.payload_sha256
            || ack.publication.payload_bytes != p.payload_bytes
            || ack.audit_sequence <= p.audit_sequence
            || serde_json::to_string(&ack).map_err(|_| "export_ack")? != raw
        {
            return Err("export_ack");
        }
        self.verify_event(
            store,
            &key,
            &raw,
            ack.audit_sequence,
            "sigil-native-export-ack-audit/v1",
            deadline,
        )?;
        Ok(Some(Acknowledged {
            destination: p.destination,
            payload_sha256: p.payload_sha256,
            payload_bytes: p.payload_bytes,
            replayed: true,
        }))
    }

    /// Authenticate an existing local acknowledgment before asking for current
    /// source records or capacity. Never recreates a missing target file.
    pub fn replay_ack(
        &self,
        store: &mut Store,
        intent: &str,
        sink: &FixedSink,
        policy: &Policy,
        deadline: Instant,
    ) -> Result<Option<Acknowledged>> {
        let (a, raw) = self.admission(store, intent, sink, policy, deadline)?;
        self.ack(store, &a, &raw, deadline)
    }

    fn held(&self, store: &Store, a: &Admission, raw: &str, prepared: bool) -> Result<Held> {
        let binding = super::completion::hash(&[b"sigil-export-reservation/v1", raw.as_bytes()]);
        let key = format!("funds:{}", a.intent_binding);
        let revision = if prepared { 2 } else { 1 };
        let held = if let Some(generation) = &a.reservation_generation {
            store.resume_reservation_generation(
                &self.scope,
                &self.namespace,
                &key,
                revision,
                binding,
                generation,
            )
        } else {
            store.resume_reservation(&self.scope, &self.namespace, &key, revision, binding)
        }
        .map_err(|_| "export_capacity")?;
        let expected = Credits {
            records: a
                .acknowledgement_records
                .checked_add(if prepared { 0 } else { a.preparation_records })
                .ok_or("export_capacity")?,
            live_bytes: a
                .acknowledgement_bytes
                .checked_add(if prepared { 0 } else { a.preparation_bytes })
                .ok_or("export_capacity")?,
        };
        if !held.unassigned() || held.credits() != expected {
            return Err("export_capacity");
        }
        Ok(held)
    }

    fn write_scope(&self, store: &Store, checks: &[Check]) -> Result<Scope> {
        let mut permissions = BTreeMap::from([
            (self.namespace.clone(), Access::ReadWrite),
            (self.heads.clone(), Access::ReadWrite),
            (self.records.clone(), Access::ReadWrite),
        ]);
        for check in checks {
            if [&self.namespace, &self.heads, &self.records].contains(&&check.namespace) {
                return Err("export_namespace");
            }
            permissions.insert(check.namespace.clone(), Access::Read);
        }
        store.scope(permissions).map_err(|_| "export_scope")
    }

    fn event(&self, format: &str, key: &str, raw: &str, batch: &Batch) -> Result<String> {
        serde_json::to_string(&serde_json::json!({
            "format":format,"namespace":self.namespace,"key":key,"sha256":digest(raw.as_bytes()),
            "batch_sha256":digest(&serde_json::to_vec(batch).map_err(|_| "export_record")?)
        }))
        .map_err(|_| "export_record")
    }

    fn next(&self, store: &Store) -> Result<(u64, u64)> {
        let head = store
            .get(&self.scope, &self.heads, &self.chain)
            .map_err(|_| "export_audit")?;
        let sequence = self
            .log
            .next_sequence(store, &self.scope, &self.chain, head.revision)
            .map_err(|_| "export_audit")?;
        Ok((head.revision, sequence))
    }

    /// One synchronous export-only slice, under the actual exclusive execution
    /// lease and store borrow. Restarts use the exact committed projection.
    /// Application source namespaces are read-only throughout.
    #[allow(clippy::too_many_arguments)]
    pub fn export_terminal(
        &self,
        store: &mut Store,
        caller: &Scope,
        intent: &str,
        terminal: &TerminalCompletion,
        sink: &mut FixedSink,
        policy: &mut Policy,
        deadline: Instant,
    ) -> Result<Acknowledged> {
        self.export_inner(
            store,
            caller,
            intent,
            terminal,
            sink,
            policy,
            deadline,
            |_| Ok(()),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn export_terminal_guarded(
        &self,
        store: &mut Store,
        caller: &Scope,
        intent: &str,
        terminal: &TerminalCompletion,
        sink: &mut FixedSink,
        policy: &mut Policy,
        source: &FixedSource,
        deadline: Instant,
    ) -> Result<Acknowledged> {
        self.export_with_source(
            store,
            caller,
            intent,
            terminal,
            sink,
            policy,
            deadline,
            Some(source),
            |_| Ok(()),
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn export_inner(
        &self,
        store: &mut Store,
        caller: &Scope,
        intent: &str,
        terminal: &TerminalCompletion,
        sink: &mut FixedSink,
        policy: &mut Policy,
        deadline: Instant,
        boundary: impl FnMut(&str) -> Result<()>,
    ) -> Result<Acknowledged> {
        self.export_with_source(
            store, caller, intent, terminal, sink, policy, deadline, None, boundary,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn export_with_source(
        &self,
        store: &mut Store,
        caller: &Scope,
        intent: &str,
        terminal: &TerminalCompletion,
        sink: &mut FixedSink,
        policy: &mut Policy,
        deadline: Instant,
        source: Option<&FixedSource>,
        mut boundary: impl FnMut(&str) -> Result<()>,
    ) -> Result<Acknowledged> {
        let (a, admission_raw) = self.admission(store, intent, sink, policy, deadline)?;
        if let Some(ack) = self.ack(store, &a, &admission_raw, deadline)? {
            return Ok(ack);
        }
        let (facts, checks) = source_facts(terminal, store, caller, &a, source)?;
        let scope = self.write_scope(store, &checks)?;
        let prepared = self.prepared(store, &a, &admission_raw, deadline)?;
        let (p, prepared_raw, bytes, held) = if let Some((p, raw, bytes)) = prepared {
            if p.terminal_facts_sha256 != digest(facts.as_bytes()) {
                return Err("export_source");
            }
            let held = self.held(store, &a, &admission_raw, true)?;
            (p, raw, bytes, held)
        } else {
            let held = self.held(store, &a, &admission_raw, false)?;
            let input = frame("XP1\n", &["project", &facts])?;
            let output = policy.function.invoke(input, deadline)?;
            if output.len() > 2 * a.payload_bytes + 128 {
                return Err("export_payload");
            }
            let parts = fields(&output, "EP1\n", 2)?;
            if parts[0] != "publish" {
                return Err("export_policy");
            }
            let bytes = decode_hex(parts[1], a.payload_bytes)?;
            // A policy evaluation cannot substitute clocks or a newer source.
            if source_facts(terminal, store, caller, &a, source)?.0 != facts {
                return Err("export_source");
            }
            let (head, sequence) = self.next(store)?;
            let p = PreparedExport {
                format: "sigil-native-export-prepared/v1".into(),
                admission_sha256: digest(admission_raw.as_bytes()),
                terminal_facts_sha256: digest(facts.as_bytes()),
                destination: a.destination.clone(),
                payload_hex: parts[1].into(),
                payload_sha256: digest(&bytes),
                payload_bytes: bytes.len(),
                audit_sequence: sequence,
            };
            let raw = serde_json::to_string(&p).map_err(|_| "export_prepared")?;
            let key = format!("prepare:{intent}");
            let mut batch = Batch {
                checks: checks.clone(),
                writes: vec![Mutation {
                    namespace: self.namespace.clone(),
                    key: key.clone(),
                    revision: 0,
                    value: Some(raw.clone()),
                }],
            };
            batch.checks.push(Check {
                namespace: self.namespace.clone(),
                key: format!("admit:{intent}"),
                revision: 1,
            });
            let event = self.event("sigil-native-export-prepared-audit/v1", &key, &raw, &batch)?;
            if Instant::now() >= deadline {
                return Err("deadline");
            }
            boundary("before_prepared")?;
            let result = self
                .log
                .append_spending(
                    store,
                    &scope,
                    &self.chain,
                    head,
                    &event,
                    &batch,
                    &held,
                    Credits {
                        records: a.preparation_records,
                        live_bytes: a.preparation_bytes,
                    },
                )
                .map_err(storage)?;
            (p, raw, bytes, result.held.ok_or("export_capacity")?)
        };
        boundary("prepared")?;
        source_facts(terminal, store, caller, &a, source)?;
        store
            .check_reservation_binding(
                &held,
                super::completion::hash(&[
                    b"sigil-export-reservation/v1",
                    admission_raw.as_bytes(),
                ]),
            )
            .map_err(|_| "export_capacity")?;
        if Instant::now() >= deadline {
            return Err("deadline");
        }
        let receipt = sink
            .publish(&bytes)
            .map_err(|_| "export_publication_unconfirmed")?;
        boundary("published")?;
        // A concurrent external source change cannot become a local ack. The
        // already-published bytes remain a possibly observed external effect.
        if source_facts(terminal, store, caller, &a, source)?.0 != facts {
            return Err("export_external_source");
        }
        let result = self.acknowledge(
            store,
            &scope,
            &checks,
            &a,
            &admission_raw,
            &p,
            &prepared_raw,
            &held,
            receipt,
            deadline,
        )?;
        boundary("acknowledged")?;
        Ok(result)
    }

    #[allow(clippy::too_many_arguments)]
    fn acknowledge(
        &self,
        store: &mut Store,
        scope: &Scope,
        checks: &[Check],
        a: &Admission,
        admission_raw: &str,
        p: &PreparedExport,
        prepared_raw: &str,
        held: &Held,
        receipt: DurablePublication,
        deadline: Instant,
    ) -> Result<Acknowledged> {
        if receipt.destination() != p.destination
            || receipt.payload_sha256() != p.payload_sha256
            || receipt.payload_bytes() != p.payload_bytes
        {
            return Err("export_receipt");
        }
        let (head, sequence) = self.next(store)?;
        let ack = Ack {
            format: "sigil-native-export-ack/v1".into(),
            admission_sha256: digest(admission_raw.as_bytes()),
            prepared_sha256: digest(prepared_raw.as_bytes()),
            publication: PublicationFact {
                destination: receipt.destination().into(),
                payload_sha256: receipt.payload_sha256().into(),
                payload_bytes: receipt.payload_bytes(),
                existing: receipt.already_present(),
            },
            audit_sequence: sequence,
        };
        let raw = serde_json::to_string(&ack).map_err(|_| "export_ack")?;
        let key = format!("ack:{}", a.intent_binding);
        let mut batch = Batch {
            checks: checks.to_vec(),
            writes: vec![Mutation {
                namespace: self.namespace.clone(),
                key: key.clone(),
                revision: 0,
                value: Some(raw.clone()),
            }],
        };
        for prefix in ["admit", "prepare"] {
            batch.checks.push(Check {
                namespace: self.namespace.clone(),
                key: format!("{prefix}:{}", a.intent_binding),
                revision: 1,
            });
        }
        let event = self.event("sigil-native-export-ack-audit/v1", &key, &raw, &batch)?;
        if Instant::now() >= deadline {
            return Err("deadline");
        }
        let result = self
            .log
            .append_releasing(store, scope, &self.chain, head, &event, &batch, held)
            .map_err(storage)?;
        if result.held.is_some() {
            return Err("export_capacity");
        }
        Ok(Acknowledged {
            destination: p.destination.clone(),
            payload_sha256: p.payload_sha256.clone(),
            payload_bytes: p.payload_bytes,
            replayed: false,
        })
    }
}

#[cfg(test)]
#[path = "export_successor_tests.rs"]
mod tests;
