"""Malformed model proposals recover through real SIGIL and durable native state."""

import json
import os
import sqlite3
import time

import pytest

from acceptance.build_test_fixtures import FILES, TASKS, populate
from acceptance.capacity_evidence import assert_returned, inspect_capacity
from automatic_support import wait_operation
from conftest import PI_ROOT
from test_build_test_service import AUDIT_KEY, reply
from test_workspace_agent import WorkspaceApi, call
from turn_support import fields


pytestmark = pytest.mark.skipif(
    os.environ.get("PI_CONTAINER_TESTS") != "1", reason="requires local Docker engine"
)


def retained(root):
    with sqlite3.connect(f"file:{root / 'records/records.sqlite'}?mode=ro", uri=True) as db:
        intents = [fields(bytes(v).decode(), "SI1\n", 5) for (v,) in db.execute(
            "SELECT value FROM records WHERE namespace='workspace.intent' ORDER BY key"
        )]
        states = [fields(bytes(v).decode(), "PT1\n", 17) for (v,) in db.execute(
            "SELECT value FROM records WHERE namespace='workspace.state'"
        )]
    return intents, states


def test_invalid_command_recovers_without_effect_or_baseline_and_stays_settled_after_reopen(
    scripted_llm, tmp_path, monkeypatch
):
    monkeypatch.setenv("SIGIL_PI_LOCAL_PROVIDER_TOKEN", "local-placeholder")
    monkeypatch.setenv("SIGIL_PI_AUDIT_KEY", AUDIT_KEY)
    workspace = tmp_path / "workspace"
    populate(workspace, TASKS[0])
    edit = {"path": "src/scale.c", "old": "+ 32\n", "new": "+ 32;\n"}
    scripted_llm.script = [
        call("build_project", {"path": ".", "argv": ["/bin/sh"]}, id="invalid-command"),
        call("edit_file", edit, id="premature-edit"),
        call("build_project", {"path": "."}, id="baseline"),
        call("edit_file", edit, id="repair"),
        call("build_project", {"path": "."}, id="build"),
        call("test_project", {"path": "."}, id="tests"),
        reply(),
    ]
    profile = json.loads((PI_ROOT / "config/completion-capacity-development.json").read_text())
    profile["operation_timeout_s"] = 120
    root = tmp_path / "deployment"
    with WorkspaceApi(root, workspace, scripted_llm.url, profile=profile) as api:
        started = time.monotonic()
        status, accepted = api.request(body={
            "session": "correction", "message": "Repair and verify", "submission_key": "first"
        })
        assert status == 202, accepted
        result = wait_operation(api, accepted["operation"])
        assert result["status"] == "done", result
        assert time.monotonic() - started < 110
        assert len(scripted_llm.requests) == 7
        seen = [r["messages"][-1]["content"][0] for r in scripted_llm.requests[1:]]
        assert seen[0]["tool_use_id"] == "invalid-command" and seen[0]["is_error"]
        assert "No tool ran. Invalid arguments" in seen[0]["content"]
        assert seen[1]["is_error"] and "No file changed" in seen[1]["content"]
        assert seen[2]["is_error"] and "FAIL: command exited 2" in seen[2]["content"]
        assert "PASS: command exited 0" in seen[4]["content"]
        assert "PASS: command exited 0" in seen[5]["content"]
        assert all((workspace / name).read_text() == content for name, content in FILES.items())
        before = retained(root)
        tools = [intent for intent in before[0] if intent[2] == "tool"]
        assert len(tools) == 5
        assert all("argv" not in json.loads(intent[4]) for intent in tools)
        history = json.loads(before[1][0][5])
        rejected = [block for message in history if isinstance(message["content"], list)
                    for block in message["content"] if block.get("type") == "tool_result"
                    and block.get("tool_use_id") == "invalid-command"]
        assert len(rejected) == 1 and rejected[0]["is_error"]
        assert_returned(inspect_capacity(root, AUDIT_KEY.encode()))
    with WorkspaceApi(root, workspace, scripted_llm.url, mode="open") as api:
        assert api.request("GET", accepted["status_url"])[1] == result
        assert retained(root) == before
        assert len(scripted_llm.requests) == 7
        assert_returned(inspect_capacity(root, AUDIT_KEY.encode()))
