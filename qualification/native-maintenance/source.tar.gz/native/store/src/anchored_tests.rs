use super::*;
use std::os::unix::fs::PermissionsExt;

fn fixture() -> tempfile::TempDir {
    let d = tempfile::tempdir().unwrap();
    for name in ["data", "authority"] {
        let p = d.path().join(name);
        fs::create_dir(&p).unwrap();
        fs::set_permissions(p, fs::Permissions::from_mode(0o700)).unwrap();
    }
    d
}
fn open(d: &Path, mode: OpenMode) -> Result<Store> {
    Store::open_anchored_reserved_bound(
        &d.join("data").canonicalize().unwrap(),
        &d.join("authority").canonicalize().unwrap(),
        mode,
        Limits::default(),
        capacity::Allocation {
            version: 1,
            pools: vec![capacity::Pool {
                id: "p".into(),
                namespaces: vec!["a".into()],
                records: 1000,
                live_bytes: 1_000_000,
            }],
        },
        [3; 32],
        BTreeMap::from([("p".into(), 128)]),
    )
}
fn grants(s: &Store) -> Scope {
    s.scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap()
}
fn batch(value: Option<&str>, revision: u64) -> Batch {
    Batch {
        checks: vec![],
        writes: vec![Mutation {
            namespace: "a".into(),
            key: "state".into(),
            revision,
            value: value.map(String::from),
        }],
    }
}

#[test]
fn all_commits_reopen_and_legacy_admission_refuses_the_new_profile() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    assert_eq!(
        s.commit(&scope, &batch(Some("one"), 0)).unwrap().revision,
        1
    );
    s.commit(&scope, &batch(None, 1)).unwrap();
    drop(s);
    let s = open(d.path(), OpenMode::Existing).unwrap();
    let scope = grants(&s);
    let row = s.get(&scope, "a", "state").unwrap();
    assert_eq!(row.revision, 2);
    assert_eq!(row.value, None);
    drop(s);
    assert!(
        Store::open(
            &d.path().join("data"),
            OpenMode::Existing,
            Limits::default()
        )
        .is_err()
    );
}

#[test]
fn coherent_full_and_partial_restore_refuse_even_with_current_revision() {
    for partial in [false, true] {
        let d = fixture();
        let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
        let scope = grants(&s);
        s.commit(&scope, &batch(Some("old"), 0)).unwrap();
        let old = fs::read(d.path().join("data/records.sqlite")).unwrap();
        s.commit(&scope, &batch(Some("current"), 1)).unwrap();
        drop(s);
        if partial {
            let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
            c.execute("UPDATE records SET revision=1,value=?1,digest=?2 WHERE namespace='a' AND key='state'",params![b"old".as_slice(),record_digest("a","state",1,Some("old"))]).unwrap();
            assert_eq!(
                c.query_row("SELECT revision FROM meta", [], |r| r.get::<_, i64>(0))
                    .unwrap(),
                2
            );
        } else {
            fs::write(d.path().join("data/records.sqlite"), old).unwrap();
        }
        assert!(matches!(
            open(d.path(), OpenMode::Existing),
            Err(Error::Denied)
        ));
    }
}

#[test]
fn admitted_owner_checks_state_before_reading_or_mutating() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
    let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
    c.execute("DELETE FROM records", []).unwrap();
    assert_eq!(s.get(&scope, "a", "state"), Err(Error::Denied));
    assert_eq!(
        s.commit(&scope, &batch(Some("replacement"), 0)),
        Err(Error::Denied)
    );
}

#[test]
fn missing_authority_never_initializes_over_existing_database() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
    drop(s);
    fs::remove_file(d.path().join("authority/anchor.0")).unwrap();
    assert!(open(d.path(), OpenMode::Existing).is_err());
    assert!(open(d.path(), OpenMode::CreateNew).is_err());
    assert!(!d.path().join("authority/anchor.0").exists());
}

#[test]
fn failed_transaction_publishes_neither_store_mutation_nor_new_authority() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
    let before = fs::read(d.path().join("authority/anchor.0")).unwrap();
    assert_eq!(
        s.commit(&scope, &batch(Some("bad revision"), 0)),
        Err(Error::Conflict)
    );
    assert_eq!(
        fs::read(d.path().join("authority/anchor.0")).unwrap(),
        before
    );
    drop(s);
    open(d.path(), OpenMode::Existing).unwrap();
}

#[test]
fn reservation_change_is_bound_and_cannot_be_partially_restored() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    let held = s
        .commit_reserving(
            &scope,
            &batch(Some("intent"), 0),
            &reservation::Request {
                namespace: "a".into(),
                key: "hold".into(),
                binding: [9; 32],
                credits: reservation::Credits {
                    records: 10,
                    live_bytes: 5000,
                },
            },
        )
        .unwrap()
        .held
        .unwrap();
    s.commit_spending(
        &scope,
        &batch(Some("intent"), 1),
        &held,
        reservation::Credits {
            records: 1,
            live_bytes: 0,
        },
    )
    .unwrap();
    drop(s);
    // A partial restoration that retains the newest global revision still fails.
    let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
    c.execute("DELETE FROM reservations", []).unwrap();
    drop(c);
    assert!(matches!(
        open(d.path(), OpenMode::Existing),
        Err(Error::Denied)
    ));
}

#[test]
fn actual_store_crash_child() {
    let Ok(path) = std::env::var("SIGIL_TEST_STORE_ANCHOR_PATH") else {
        return;
    };
    let path = Path::new(&path);
    let mut store = open(path, OpenMode::Existing).unwrap();
    let scope = grants(&store);
    let receipt = store.commit(&scope, &batch(Some("confirmed"), 0)).unwrap();
    fs::write(path.join("receipt"), receipt.revision.to_be_bytes()).unwrap();
    fs::File::open(path.join("receipt"))
        .unwrap()
        .sync_all()
        .unwrap();
    fs::File::open(path).unwrap().sync_all().unwrap();
    restore_anchor::cut("after_store_receipt");
}

#[test]
fn actual_store_recovery_at_every_commit_boundary_preserves_returned_receipts() {
    use std::os::unix::process::ExitStatusExt;
    let mut stages = vec![
        "before_store_database_commit".to_string(),
        "after_store_database_commit".to_string(),
        "before_store_receipt".to_string(),
        "after_store_receipt".to_string(),
    ];
    for record in ["prepared", "confirmed_first", "confirmed_mirror"] {
        stages.push(format!("before_{record}_write"));
        stages.push(format!("after_{record}_write"));
        stages.push(format!("after_{record}_sync"));
    }
    for stage in stages {
        let d = fixture();
        drop(open(d.path(), OpenMode::CreateNew).unwrap());
        let initial = fs::read(d.path().join("data/records.sqlite")).unwrap();
        let result = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "store::anchored::tests::actual_store_crash_child",
                "--nocapture",
            ])
            .env("SIGIL_TEST_STORE_ANCHOR_PATH", d.path())
            .env("SIGIL_TEST_ANCHOR_CUT", &stage)
            .output()
            .unwrap();
        assert_eq!(
            result.status.signal(),
            Some(libc::SIGKILL),
            "{stage}: {}",
            String::from_utf8_lossy(&result.stderr)
        );
        let s = open(d.path(), OpenMode::Existing).unwrap();
        let row = s.get(&grants(&s), "a", "state").unwrap();
        if d.path().join("receipt").exists() {
            assert_eq!(row.value.as_deref(), Some("confirmed"), "{stage}");
        }
        drop(s);
        if row.revision == 1 {
            fs::write(d.path().join("data/records.sqlite"), &initial).unwrap();
            assert!(
                matches!(open(d.path(), OpenMode::Existing), Err(Error::Denied)),
                "{stage}"
            );
        }
    }
}

#[test]
fn sqlite_like_wildcard_names_cannot_hide_unexpected_schema_objects() {
    for sql in [
        "CREATE TRIGGER sqliteXhidden AFTER UPDATE ON meta BEGIN DELETE FROM records; END",
        "CREATE VIEW sqliteXview AS SELECT * FROM records",
        "CREATE INDEX sqliteXindex ON records(revision)",
    ] {
        let d = fixture();
        let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
        let scope = grants(&s);
        s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
        let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
        c.execute_batch(sql).unwrap();
        assert_eq!(
            s.commit(&scope, &batch(Some("changed"), 1)),
            Err(Error::Corrupt)
        );
        assert_eq!(
            c.query_row("SELECT value FROM records", [], |r| r.get::<_, Vec<u8>>(0))
                .unwrap(),
            b"kept"
        );
        drop(c);
        drop(s);
        assert!(matches!(
            open(d.path(), OpenMode::Existing),
            Err(Error::Corrupt)
        ));
    }
}

#[test]
fn retained_verified_read_snapshot_blocks_a_competing_restore_commit() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
    let c = Connection::open(d.path().join("data/records.sqlite")).unwrap();
    c.busy_timeout(Duration::ZERO).unwrap();
    let value = s
        .get_observed_inner(&scope, "a", "state", || {
            let error = c.execute("DELETE FROM records", []).unwrap_err();
            assert_eq!(
                error.sqlite_error_code(),
                Some(rusqlite::ErrorCode::DatabaseBusy)
            );
        })
        .unwrap();
    assert_eq!(value.value.as_deref(), Some("kept"));
    c.execute("DELETE FROM records", []).unwrap();
    assert_eq!(s.get(&scope, "a", "state"), Err(Error::Denied));
}

#[test]
fn anchored_namespace_inspection_accepts_the_complete_new_schema() {
    let d = fixture();
    let mut s = open(d.path(), OpenMode::CreateNew).unwrap();
    let scope = grants(&s);
    s.commit(&scope, &batch(Some("kept"), 0)).unwrap();
    s.inspect_namespaces(
        &scope,
        &["a".into()],
        std::time::Instant::now() + Duration::from_secs(1),
    )
    .unwrap();
}

#[test]
fn actual_store_uncertain_io_child() {
    let Ok(path) = std::env::var("SIGIL_TEST_STORE_IO_PATH") else {
        return;
    };
    let mut s = open(Path::new(&path), OpenMode::Existing).unwrap();
    let scope = grants(&s);
    assert_eq!(
        s.commit(&scope, &batch(Some("possibly committed"), 0)),
        Err(Error::CommitUncertain)
    );
    assert_eq!(s.get(&scope, "a", "state"), Err(Error::ReopenRequired));
    assert_eq!(
        s.commit(&scope, &batch(Some("retry"), 0)),
        Err(Error::ReopenRequired)
    );
}

#[test]
fn uncertain_authority_writes_poison_owner_and_require_actual_recovery() {
    for record in ["prepared", "confirmed_first", "confirmed_mirror"] {
        for action in ["partial", "after_write", "after_sync"] {
            let fault = match action {
                "partial" => format!("partial_{record}_write"),
                "after_write" => format!("after_{record}_write"),
                _ => format!("after_{record}_sync"),
            };
            let d = fixture();
            drop(open(d.path(), OpenMode::CreateNew).unwrap());
            let result = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "store::anchored::tests::actual_store_uncertain_io_child",
                    "--nocapture",
                ])
                .env("SIGIL_TEST_STORE_IO_PATH", d.path())
                .env("SIGIL_TEST_ANCHOR_IO", &fault)
                .output()
                .unwrap();
            assert!(
                result.status.success(),
                "{fault}: {}",
                String::from_utf8_lossy(&result.stdout)
            );
            let reopened = open(d.path(), OpenMode::Existing);
            if fault == "partial_confirmed_first_write" {
                assert!(matches!(reopened, Err(Error::Corrupt)));
            } else {
                let s = reopened.unwrap();
                let row = s.get(&grants(&s), "a", "state").unwrap();
                assert_eq!(
                    row.revision,
                    if record == "prepared" { 0 } else { 1 },
                    "{fault}"
                );
            }
        }
    }
}
