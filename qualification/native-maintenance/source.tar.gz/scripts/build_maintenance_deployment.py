"""Fresh profile 13 with SIGIL maintenance and actual owner replacement."""
import hashlib
import json
from pathlib import Path
from scripts.build_generation_deployment import build as generation_build
from scripts.compose_generation_maintenance import compose_handoff, compose_maintenance
from scripts.compose_dispatch_journal import with_dispatch_journal
from scripts.workspace_deployment import fields, runtime_digest


def share_generated_audit_sources(participants):
    """Give byte-identical pure audit workers one generated artifact path.

    Native admission still checks every caller and the complete worker config.
    Chain, key, scope and producer metadata remain separate caller-owned fields.
    This only removes redundant generated paths that defeat exact-worker reuse.
    """
    admitted, updates = {}, []
    for participant in participants:
        for name in ("transaction_audit", "effect_audit"):
            audit = participant.get(name)
            if audit is None:
                continue
            workers = [audit["worker"]]
            if "evaluation" in audit:
                workers.append(audit["evaluation"])
            for worker in workers:
                if (worker["net"] or worker["fs"] or worker.get("fs_write")
                        or worker["secret_env"] or worker["version"] == 4):
                    raise ValueError("only grantless generated audit workers may share source paths")
                path = Path(worker["source"])
                raw = path.read_bytes()
                if not raw or len(raw) > 65536 or hashlib.sha256(raw).hexdigest() != worker["source_sha256"]:
                    raise ValueError("generated audit source does not match its declared digest")
                key = json.dumps({k: v for k, v in worker.items() if k != "source"}, sort_keys=True)
                if key not in admitted:
                    admitted[key] = (str(path), raw)
                canonical, prior = admitted[key]
                if raw != prior:
                    raise ValueError("generated audit sources must match exactly")
                updates.append((worker, canonical))
    for worker, canonical in updates:
        worker["source"] = canonical


def build(root, workspace, runtime, evaluator, stdlib, token, profile, *, restore_authority,
          endpoint=None, handoff_slot=31, base_config=None):
    programs = {"coordinator": compose_handoff(stdlib, handoff_slot=handoff_slot),
                "retirement": compose_maintenance(stdlib)}
    if profile.get("dispatch_journal") is not None:
        programs["coordinator"] = with_dispatch_journal(programs["coordinator"])
    config, path = generation_build(root, workspace, runtime, evaluator, stdlib, token, profile,
        restore_authority=restore_authority, endpoint=endpoint, base_config=base_config)
    root = Path(root).resolve()
    config["version"] = 13
    config["automatic"].pop("coordinator_cache", None)
    config["automatic"]["pure_cache"] = "owner-local-exact-worker/v1"

    def bind(worker, name):
        source = root / (name + ".sigil"); source.write_text(programs[name].text)
        worker.update(source=str(source), source_sha256=programs[name].compiler_input_sha256)

    for p in config["automatic"]["participants"]:
        row = next(c for c in config["credentials"] if c["sha256"] == p["credential_sha256"])
        c = fields(row["facts"], "CF2\n", 15)
        ops, reservation = c[8], c[13]
        worker = dict(p["transactions"]["settle"]["worker"])
        # Maintenance is a grantless cached function. Bind the existing fixed
        # evaluator so one verified artifact serves fresh guest instances for
        # this owner's bounded catalog, without recompiling every allocation.
        worker.update(runtime=str(evaluator), runtime_sha256=runtime_digest(str(evaluator)))
        bind(p["worker"], "coordinator"); bind(worker, "retirement")
        p["retirement"] = dict(worker=worker, marker="RM2\n", values=1,
            grants={ops: "read", reservation: "read_write"}, inputs=[
                {"kind": "credential_facts"}, {"kind": "bundle"}, {"kind": "value", "index": 0}, {"kind": "clock"},
                {"kind": "read", "namespace": ops, "key": {"kind": "value", "index": 0}},
                {"kind": "read", "namespace": reservation, "key": {"kind": "value", "index": 0}},
                {"kind": "read", "namespace": reservation, "key": {"kind": "prefixed_value", "prefix": "generation:", "index": 0}},
                {"kind": "reservation", "namespace": reservation, "key": {"kind": "value", "index": 0}}])
    share_generated_audit_sources(config["automatic"]["participants"])
    path.write_text(json.dumps(config, indent=2) + "\n")
    inputs = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(root.rglob("*")) if p.is_file() and p.name != "build-inputs.json"}
    (root / "build-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
    return config, path
