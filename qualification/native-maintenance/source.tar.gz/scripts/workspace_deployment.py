"""Build-only repository-agent deployment assembly; SIGIL runs the application."""

import hashlib
import json
from pathlib import Path
from scripts.compose_workspace import compose_workspace

FUEL = 300_000_000
LIMITS = {
    "value_bytes": 2097152,
    "batch_bytes": 8388608,
    "batch_items": 64,
    "live_bytes": 134217728,
    "records": 100000,
    "database_pages": 262144,
}
TOOL_CODECS = {
    "list_dir": "path",
    "read_file": "path",
    "edit_file": "edit",
    "check_json": "path",
    "grep_file": "grep",
}
COMMAND_CODECS = {"build_project": "container", "test_project": "container"}


def runtime_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(marker, values):
    return marker + "".join(f"{len(value.encode()):08d}" + value for value in values)


def fields(value, marker, count):
    raw = value.encode()
    if not raw.startswith(marker.encode()):
        raise ValueError("record marker mismatch")
    at, result = 4, []
    for _ in range(count):
        length = int(raw[at : at + 8])
        at += 8
        result.append(raw[at : at + length].decode())
        at += length
    if at != len(raw):
        raise ValueError("record length mismatch")
    return result


def configuration(
    root,
    programs,
    endpoint,
    workspace,
    rows,
    runtime,
    evaluator,
    stdlib,
    *,
    commands=None,
    funded=None,
    lifecycle=None,
    journal=None,
):
    if journal is not None and (journal != "v1" or funded is None):
        raise ValueError("dispatch journal v1 requires explicit completion capacity")
    if lifecycle is not None and (lifecycle != "archive-v1" or funded is None):
        raise ValueError("archive-v1 lifecycle requires explicit completion capacity")
    root.mkdir(parents=True, exist_ok=True)

    def worker(
        name,
        source,
        *,
        net=None,
        fs=None,
        secrets=None,
        runtime=runtime,
        suffix=".sigil",
    ):
        path = root / (name + suffix)
        path.write_text(source)
        return {
            "version": 1,
            "runtime": str(runtime),
            "runtime_sha256": runtime_digest(str(runtime)),
            "source": str(path),
            "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
            "max_fuel": FUEL,
            "max_timeout_ms": 15000,
            "net": net or [],
            "fs": fs or [],
            "secret_env": secrets or {},
        }

    def component(name):
        selected_runtime = (
            evaluator
            if name in {"api", "api_discovery", "listing", "admission", "history", "coordinator"}
            else runtime
        )
        if lifecycle is not None:
            from scripts.compose_lifecycle import compose_lifecycle
            built = compose_lifecycle(name, stdlib)
        elif funded is not None:
            from scripts.compose_capacity import compose_capacity
            built = compose_capacity(name, stdlib)
        else:
            built = compose_workspace(name, stdlib)
        if journal is not None:
            from scripts.compose_dispatch_journal import with_dispatch_journal
            built = with_dispatch_journal(built)
        configured = worker(name, built.text, runtime=selected_runtime)
        if funded is not None and name == "api_discovery":
            configured["max_timeout_ms"] = 30000
        return configured

    def value(index):
        return {"kind": "value", "index": index}

    def literal(value):
        return {"kind": "literal", "value": value}

    def read(ns, key):
        return {"kind": "read", "namespace": ns, "key": key}

    result = {
        "version": 4,
        "state_root": str(root / "records"),
        "limits": LIMITS,
        "credentials": rows,
        "worker": component("api"),
        "functions": {name: component(name) for name in ("admission", "history")},
    }
    pure = {
        name: component(name)
        for name in (
            "dispatch_cancellable",
            "worker_completion",
            "turn_completion",
            "settlement",
            "coordinator",
            "preclaim_cancellable",
        )
    }
    participants = []
    for index, row in enumerate(rows):
        facts = fields(row["facts"], "CF2\n", 15)
        ops, state, intent, budget, reservation = (
            facts[8],
            facts[10],
            facts[11],
            facts[12],
            facts[13],
        )
        claim, delivery = f"executor{index}.claim", f"executor{index}.delivery"
        area = workspace[index] if isinstance(workspace, list) else workspace
        area = str(area)
        effects = {}
        for alias, role in [
            ("provider", "model"),
            *[(name, name) for name in programs if name != "provider"],
        ]:
            effect_worker = worker(
                f"effect-{index}-{alias}",
                programs["provider" if role == "model" else role],
                suffix=".json" if role in COMMAND_CODECS else ".sigil",
                net=["127.0.0.1"] if role == "model" else [],
                fs=[area] if role != "model" else [],
                secrets={"anthropic": "SIGIL_PI_LOCAL_PROVIDER_TOKEN"}
                if role == "model"
                else {},
            )
            if role == "model":
                effect_worker.update(version=2, max_timeout_ms=60000)
                binding = record(
                    "EB1\n",
                    [
                        facts[1],
                        role,
                        effect_worker["source_sha256"],
                        effect_worker["runtime_sha256"],
                        endpoint,
                        "127.0.0.1",
                        "anthropic",
                    ],
                )
            else:
                codec = {**TOOL_CODECS, **COMMAND_CODECS}[role]
                if codec == "edit":
                    effect_worker.update(version=3, fs_write=[area])
                    if commands is not None:
                        codec = "edit_checked"
                if codec == "container":
                    if commands is None:
                        raise ValueError(
                            "command tools require an explicit command profile"
                        )
                    docker = Path(commands["docker"]).resolve(strict=True)
                    effect_worker.update(
                        version=4,
                        runtime=str(docker),
                        runtime_sha256=runtime_digest(docker),
                        max_timeout_ms=45000,
                    )
                binding = record(
                    "EB2\n",
                    [
                        facts[1],
                        role,
                        effect_worker["source_sha256"],
                        effect_worker["runtime_sha256"],
                        area,
                        area,
                        "",
                        codec,
                    ],
                )
            policy = {
                "worker": pure["dispatch_cancellable"],
                "marker": "DF2\n",
                "values": 4,
                "inputs": [
                    {"kind": "credential_facts"},
                    {"kind": "bundle"},
                    value(0),
                    {"kind": "clock"},
                    read(ops, value(0)),
                    read(reservation, value(0)),
                    read(state, value(1)),
                    read(intent, value(2)),
                    read(budget, literal("active")),
                    value(2),
                    {"kind": "worker_facts"},
                    value(3),
                    read(ops, value(3)),
                ],
                "read_grants": dict.fromkeys(
                    [ops, reservation, state, intent, budget], "read"
                ),
                "alias": alias,
                "binding": binding,
                "claim_namespace": claim,
            }
            effects[alias] = {
                "worker": effect_worker,
                "policy": policy,
                "recorder": {
                    "worker": pure["worker_completion"],
                    "delivery_namespace": delivery,
                },
                "grants": {
                    intent: "read",
                    claim: "read_write",
                    delivery: "create_only",
                },
            }
        interpret = {
            "worker": pure["turn_completion"],
            "marker": "TF1\n",
            "values": 4,
            "grants": {state: "read_write", intent: "read_write", delivery: "read"},
            "inputs": [
                literal(state),
                literal(intent),
                literal(delivery),
                value(0),
                value(1),
                value(2),
                value(3),
                {"kind": "clock"},
                read(state, value(0)),
                read(intent, value(2)),
                read(delivery, value(2)),
                read(intent, value(3)),
            ],
        }
        settle = {
            "worker": pure["settlement"],
            "marker": "SF1\n",
            "values": 2,
            "grants": {
                state: "read",
                ops: "read_write",
                reservation: "read_write",
                budget: "read_write",
            },
            "inputs": [
                {"kind": "credential_facts"},
                {"kind": "bundle"},
                value(0),
                value(1),
                {"kind": "clock"},
                read(ops, value(0)),
                read(state, value(1)),
                read(reservation, value(0)),
                read(budget, literal("active")),
            ],
        }
        preclaim = {
            "worker": pure["preclaim_cancellable"],
            "marker": "UF2\n",
            "values": 4,
            "grants": {
                ops: "read_write",
                reservation: "read_write",
                state: "read_write",
                budget: "read_write",
                intent: "read",
                claim: "read",
                delivery: "read",
            },
            "inputs": [
                {"kind": "credential_facts"},
                {"kind": "bundle"},
                value(0),
                value(1),
                value(2),
                literal(claim),
                literal(delivery),
                {"kind": "clock"},
                read(ops, value(0)),
                read(reservation, value(0)),
                read(state, value(1)),
                read(intent, value(2)),
                read(budget, literal("active")),
                read(claim, value(2)),
                read(delivery, value(2)),
                value(3),
                read(ops, value(3)),
            ],
        }
        participants.append(
            {
                "credential_sha256": row["sha256"],
                "worker": pure["coordinator"],
                "binding": record(
                    "LB4\n",
                    [
                        "provider",
                        json.dumps(
                            [
                                {"name": name, "alias": name}
                                for name in programs
                                if name != "provider"
                            ]
                        ),
                        "interpret",
                        "settle",
                        "preclaim",
                    ],
                ),
                "claim_namespace": claim,
                "delivery_namespace": delivery,
                "read_grants": dict.fromkeys(
                    [name for name in row["grants"] if lifecycle is None or name != state + ".archive"]
                    + [claim, delivery], "read"),
                "effects": effects,
                "transactions": {
                    "interpret": interpret,
                    "settle": settle,
                    "preclaim": preclaim,
                },
            }
        )
    result["automatic"] = {"participants": participants}
    result["version"] = 6
    for name in ("api_discovery", "listing"):
        configured = component(name)
        if name == "api_discovery":
            result["worker"] = configured
        else:
            result["functions"][name] = configured
    if funded is not None:
        from scripts.compose_capacity import compose_capacity
        from scripts.compose_effect_audit import compose_effect_audit
        from scripts.compose_transaction_audit import compose_transaction_audit
        result["version"] = 11
        result["limits"] = {**LIMITS, "live_bytes": 1073741824}
        if lifecycle is not None:
            from scripts.compose_lifecycle import compose_lifecycle
            storage = compose_lifecycle("storage", stdlib)
        else:
            storage = compose_capacity("storage", stdlib)
        result["functions"]["storage"] = worker("storage", storage.text, runtime=evaluator)
        pools, bindings, slots = [], [], {}
        for index, (row, participant) in enumerate(zip(rows, participants, strict=True)):
            facts = fields(row["facts"], "CF2\n", 15)
            ns, pool = facts[13], f"workspace-pool-{index}"
            participant["funding"] = ns
            for effect in participant["effects"].values():
                effect["grants"][ns] = "read_write"
                effect["grants"][participant["delivery_namespace"]] = "read_write"
            for transaction in participant["transactions"].values():
                transaction["grants"][ns] = "read_write"
            interpretation = participant["transactions"]["interpret"]
            interpretation["marker"] = "TF2\n"
            interpretation["inputs"].append(literal(ns))
            for kind, compose in [("effect", compose_effect_audit), ("transaction", compose_transaction_audit)]:
                participant[f"{kind}_audit"] = {
                    "version": 1,
                    "worker": worker(f"{kind}-audit-{index}", compose(Path(__file__).resolve().parent.parent, stdlib).text, runtime=evaluator),
                    "key_env": funded["audit_key_env"],
                    "chain": hashlib.sha256(f"funded-workspace-v1:{index}:{kind}".encode()).hexdigest(),
                    "heads": f"audit{index}.{kind}.heads",
                    "records": f"audit{index}.{kind}.records",
                    "limits": {"payload_bytes": 8192, "records": funded["audit_records"], "bytes": funded["audit_bytes"]},
                }
            names = set(row["grants"]) | {participant["claim_namespace"], participant["delivery_namespace"]}
            for kind in ["effect", "transaction"]:
                names.update([participant[f"{kind}_audit"]["heads"], participant[f"{kind}_audit"]["records"]])
            if journal is not None:
                participant["dispatch_journal"] = participant["claim_namespace"] + ".journal"
                names.add(participant["dispatch_journal"])
            pools.append({"id": pool, "namespaces": sorted(names), "records": funded["records_per_tenant"], "live_bytes": funded["bytes_per_tenant"]})
            bindings.append(record("ST1\n", [facts[1], pool]))
            slots[pool] = funded["reservation_slots"]
        result["storage"] = {"policy": "storage", "parameters": json.dumps(bindings),
            "allocation": {"version": 1, "pools": pools}, "reservation_slots": slots}
    return result
