//! Native process/cache boundaries with a controlled transport, not guest-isolation evidence.
use super::*;
use serde_json::json;
use std::fs;
use std::os::unix::fs::PermissionsExt;

fn fixture() -> (tempfile::TempDir, WorkerConfig) {
    fixture_with("")
}

fn fixture_with(before_reply: &str) -> (tempfile::TempDir, WorkerConfig) {
    fixture_reply(before_reply, "PROCESS_ID")
}
pub(crate) fn fixture_output(output: &str) -> (tempfile::TempDir, WorkerConfig) {
    fixture_reply("", output)
}
pub(crate) fn fixture_routes(routes: &[(&str, &str)]) -> (tempfile::TempDir, WorkerConfig) {
    let mut before = String::from("case \"$line\" in\n");
    for (marker, output) in routes {
        assert!(marker.bytes().all(|b| b.is_ascii_alphanumeric()));
        let result = json!({"status":"ok","data":{"output_text":output}}).to_string();
        let reply =
            json!({"jsonrpc":"2.0","id":2,"result":{"content":[{"type":"text","text":result}]}})
                .to_string()
                .replace("\"id\":2", "\"id\":'\"$n\"'");
        before.push_str(&format!(
            "*{marker}*) printf '%s\\n' '{reply}'; n=$((n + 1)); continue;;\n"
        ));
    }
    before.push_str("esac");
    fixture_reply(&before, "unexpected fixture input")
}

#[test]
fn shared_cache_counts_distinct_live_configs_and_reclaims_failed_admission() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let mut held = Vec::new();
    for fuel in 1..=64 {
        let mut worker = config.clone();
        worker.max_fuel = fuel;
        held.push(Function::cached_shared(worker, &mut cache).unwrap());
    }
    assert_eq!(cache.len(), 64);
    let mut extra = config.clone();
    extra.max_fuel = 65;
    assert!(Function::cached_shared(extra.clone(), &mut cache).is_err());
    let mut same = config.clone();
    same.max_fuel = 1;
    let alias = Function::cached_shared(same, &mut cache).unwrap();
    assert_eq!(cache.len(), 64);
    assert!(
        !dir.path().join("starts").exists(),
        "admission alone spawned a process"
    );
    drop(held.pop());
    let replacement = Function::cached_shared(extra, &mut cache).unwrap();
    assert_eq!(cache.len(), 64);
    drop(held);
    drop(alias);
    drop(replacement);
    assert!(cache.values().all(|entry| entry.upgrade().is_none()));
    let retry = Function::cached_shared(config, &mut cache).unwrap();
    assert_eq!(cache.len(), 1);
    drop(retry);
}
pub(crate) fn fixture_rejecting_input(
    output: &str,
    needle: &str,
    denied: &str,
) -> (tempfile::TempDir, WorkerConfig) {
    assert!(needle.bytes().all(|b| b.is_ascii_alphanumeric()));
    let result = json!({"status":"ok","data":{"output_text":denied}}).to_string();
    let reply =
        json!({"jsonrpc":"2.0","id":2,"result":{"content":[{"type":"text","text":result}]}})
            .to_string()
            .replace("\"id\":2", "\"id\":'\"$n\"'");
    fixture_reply(
        &format!(
            "case \"$line\" in *{needle}*) printf '%s\\n' '{reply}'; n=$((n + 1)); continue;; esac"
        ),
        output,
    )
}
pub(crate) fn audit_config(worker: WorkerConfig, side: &str) -> crate::audited_transaction::Config {
    crate::audited_transaction::Config {
        version: 1,
        worker,
        evaluation: None,
        key_env: format!("PI_SHARED_AUDIT_KEY_{}", side.to_uppercase()),
        chain: side.repeat(64),
        heads: format!("{side}.heads"),
        records: format!("{side}.records"),
        limits: sigil_durable_store::store::authenticated_log::ChainLimits {
            payload_bytes: 16384,
            records: 100,
            bytes: 1_000_000,
        },
    }
}
pub(crate) fn audit_environment_child(name: &str) {
    let mut child = std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--exact", name, "--nocapture"])
        .env_clear()
        .env("LANG", "C.UTF-8")
        .env("PI_SHARED_AUDIT_FIXTURE", "1")
        .env(
            "PI_SHARED_AUDIT_KEY_A",
            "test-only-key-a-012345678901234567890123456789",
        )
        .env(
            "PI_SHARED_AUDIT_KEY_B",
            "test-only-key-b-012345678901234567890123456789",
        )
        .stdout(std::process::Stdio::piped())
        .spawn()
        .unwrap();
    let deadline = Instant::now() + Duration::from_secs(30);
    loop {
        if child.try_wait().unwrap().is_some() {
            break;
        }
        if Instant::now() >= deadline {
            child.kill().unwrap();
            child.wait().unwrap();
            panic!("audit fixture child timed out");
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    let output = child.wait_with_output().unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains("1 passed; 0 failed"),
        "child test was not selected"
    );
}
fn fixture_reply(before_reply: &str, output: &str) -> (tempfile::TempDir, WorkerConfig) {
    let dir = tempfile::tempdir().unwrap();
    let runtime = dir.path().join("runtime");
    let source = dir.path().join("source");
    let result = json!({"status":"ok","data":{"output_text":output}}).to_string();
    let reply =
        json!({"jsonrpc":"2.0","id":2,"result":{"content":[{"type":"text","text":result}]}})
            .to_string()
            .replace("\"id\":2", "\"id\":'\"$n\"'")
            .replace("PROCESS_ID", "'\"$$\"'");
    let body = format!(
        "#!/bin/sh\nprintf '%s\\n' \"$$\" >> '{}'\nread -r line\nprintf '%s\\n' '{{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{{}}}}'\nn=2\nwhile read -r line; do\nprintf '%s\\n' \"$line\" >> '{}'\n{before_reply}\nprintf '%s\\n' '{reply}'\nn=$((n + 1))\ndone\n",
        dir.path().join("starts").display(),
        dir.path().join("calls").display()
    );
    fs::write(&runtime, &body).unwrap();
    fs::set_permissions(&runtime, fs::Permissions::from_mode(0o700)).unwrap();
    let text = "controlled fixed-source native fixture";
    fs::write(&source, text).unwrap();
    let config = WorkerConfig {
        version: 1,
        runtime,
        runtime_sha256: format!("{:x}", Sha256::digest(body.as_bytes())),
        source,
        source_sha256: format!("{:x}", Sha256::digest(text.as_bytes())),
        max_fuel: 1000,
        max_timeout_ms: 5000,
        net: vec![],
        fs: vec![],
        fs_write: vec![],
        secret_env: BTreeMap::new(),
    };
    (dir, config)
}

fn call(function: &mut Function, input: &str) -> String {
    function
        .invoke(input.into(), Instant::now() + Duration::from_secs(5))
        .unwrap()
}

#[test]
fn exact_workers_share_one_process_but_keep_distinct_calls_and_drop_with_last_owner() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let mut a = Function::cached_shared(config.clone(), &mut cache).unwrap();
    let pid = call(&mut a, "tenant-a");
    let mut b = Function::cached_shared(config.clone(), &mut cache).unwrap();
    assert_eq!(call(&mut b, "tenant-b"), pid);
    let calls: Vec<serde_json::Value> = fs::read_to_string(dir.path().join("calls"))
        .unwrap()
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(calls.len(), 2);
    assert_eq!(calls[0]["params"]["arguments"]["input"], "tenant-a");
    assert_eq!(calls[1]["params"]["arguments"]["input"], "tenant-b");
    assert_eq!(calls[0]["id"], 2);
    assert_eq!(calls[1]["id"], 3);
    drop(a);
    assert_eq!(call(&mut b, "tenant-b-again"), pid);
    drop(b);
    assert!(cache.values().all(|worker| worker.upgrade().is_none()));
    let pid_number: i32 = pid.parse().unwrap();
    assert_eq!(
        unsafe { libc::kill(pid_number, 0) },
        -1,
        "last owner did not reap cached child"
    );
    let mut replacement = Function::cached_shared(config, &mut cache).unwrap();
    assert_ne!(call(&mut replacement, "new-owner"), pid);
    assert_eq!(
        fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        2
    );
}

#[test]
fn shared_cache_readmits_source_and_runtime_and_refuses_effect_grants() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let mut original = Function::cached_shared(config.clone(), &mut cache).unwrap();
    call(&mut original, "first");
    let source = fs::read(&config.source).unwrap();
    fs::write(&config.source, "changed").unwrap();
    assert!(Function::cached_shared(config.clone(), &mut cache).is_err());
    fs::write(&config.source, source).unwrap();
    let runtime = fs::read(&config.runtime).unwrap();
    fs::write(&config.runtime, "changed").unwrap();
    assert!(Function::cached_shared(config.clone(), &mut cache).is_err());
    fs::write(&config.runtime, runtime).unwrap();
    let mut grant = config.clone();
    grant.net.push("example.invalid".into());
    assert!(Function::cached_shared(grant, &mut cache).is_err());
    let mut grant = config.clone();
    grant.fs.push(dir.path().to_string_lossy().into_owned());
    assert!(Function::cached_shared(grant, &mut cache).is_err());
    let mut grant = config.clone();
    grant
        .fs_write
        .push(dir.path().to_string_lossy().into_owned());
    assert!(Function::cached_shared(grant, &mut cache).is_err());
    let mut grant = config;
    grant.secret_env.insert("secret".into(), "SCOPE".into());
    assert!(Function::cached_shared(grant, &mut cache).is_err());
    assert_eq!(
        fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        1
    );
}

#[test]
fn different_ceilings_and_paths_never_alias_and_contention_does_not_wait() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let mut a = Function::cached_shared(config.clone(), &mut cache).unwrap();
    let first = call(&mut a, "first");
    let mut lower = config.clone();
    lower.max_fuel -= 1;
    let mut lower = Function::cached_shared(lower, &mut cache).unwrap();
    assert_ne!(call(&mut lower, "lower"), first);
    let mut alternate = config.clone();
    alternate.source = dir.path().join("alternate-source");
    fs::copy(&config.source, &alternate.source).unwrap();
    let mut alternate = Function::cached_shared(alternate, &mut cache).unwrap();
    assert_ne!(call(&mut alternate, "alternate"), first);
    let mut b = Function::cached_shared(config, &mut cache).unwrap();
    let PureExecution::SharedCached(worker) = &a.worker else {
        panic!("expected shared cache");
    };
    let held = worker.lock().unwrap();
    let seen = b.observe(
        "cannot-enter".into(),
        Instant::now() + Duration::from_secs(5),
    );
    assert_eq!(seen.result, Err("worker"));
    let facts = serde_json::to_value(&seen.facts).unwrap();
    assert_eq!(facts["fault"], "busy");
    assert_eq!(facts["boundary"], "cached_acquire");
    assert!(facts["parsed_result"].is_null());
    assert!(facts["request_may_have_run"].is_null());
    assert!(seen.facts.input_digest().is_ok());
    assert_eq!(
        fs::read_to_string(dir.path().join("calls"))
            .unwrap()
            .lines()
            .count(),
        3
    );
    drop(held);
    assert_eq!(call(&mut b, "after-contention"), first);
}

#[test]
fn recycling_counts_both_participants_and_reaps_before_the_next_process() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let mut a = Function::cached_shared(config.clone(), &mut cache).unwrap();
    let mut b = Function::cached_shared(config, &mut cache).unwrap();
    let first = call(&mut a, "first");
    for index in 1..4096 {
        assert_eq!(
            call(if index % 2 == 0 { &mut a } else { &mut b }, "next"),
            first
        );
    }
    let second = call(&mut b, "after-aggregate-limit");
    assert_ne!(first, second);
    assert_eq!(unsafe { libc::kill(first.parse().unwrap(), 0) }, -1);
    assert_eq!(
        fs::read_to_string(dir.path().join("starts"))
            .unwrap()
            .lines()
            .count(),
        2
    );
    let calls = fs::read_to_string(dir.path().join("calls")).unwrap();
    assert_eq!(calls.lines().count(), 4097);
    let last: serde_json::Value = serde_json::from_str(calls.lines().last().unwrap()).unwrap();
    assert_eq!(last["id"], 2);
}

#[test]
fn shared_timeout_and_protocol_failure_are_not_resent_and_next_caller_gets_new_process() {
    for (trigger, before, fault) in [
        (
            "timeout-request",
            "case \"$line\" in *timeout-request*) /bin/sleep 20;; esac",
            "deadline",
        ),
        (
            "protocol-request",
            "case \"$line\" in *protocol-request*) printf '%s\\n' 'bad-json'; continue;; esac",
            "protocol",
        ),
    ] {
        let (dir, config) = fixture_with(before);
        let mut cache = PureCache::new();
        let mut a = Function::cached_shared(config.clone(), &mut cache).unwrap();
        let mut b = Function::cached_shared(config, &mut cache).unwrap();
        let first = call(&mut a, "first");
        let seen = b.observe(trigger.into(), Instant::now() + Duration::from_millis(100));
        assert_eq!(seen.result, Err("worker"));
        let facts = serde_json::to_value(seen.facts).unwrap();
        assert_eq!(facts["fault"], fault);
        assert_eq!(facts["boundary"], "cached_invoke");
        assert!(facts["parsed_result"].is_null());
        assert_eq!(
            fs::read_to_string(dir.path().join("calls"))
                .unwrap()
                .lines()
                .count(),
            2
        );
        assert_eq!(
            fs::read_to_string(dir.path().join("starts"))
                .unwrap()
                .lines()
                .count(),
            1
        );
        assert_eq!(unsafe { libc::kill(first.parse().unwrap(), 0) }, -1);
        assert_ne!(call(&mut a, "new-explicit-evaluation"), first);
        let expired = b.observe("already-expired".into(), Instant::now());
        assert_eq!(expired.result, Err("deadline"));
        assert_eq!(
            fs::read_to_string(dir.path().join("calls"))
                .unwrap()
                .lines()
                .count(),
            3
        );
    }
}

#[test]
fn incomplete_admission_drops_its_previous_processes() {
    let (dir, config) = fixture();
    let mut cache = PureCache::new();
    let result: Result<()> = (|| {
        let mut first = Function::cached_shared(config.clone(), &mut cache)?;
        call(&mut first, "admitted-first");
        let mut invalid = config;
        invalid.source_sha256 = "0".repeat(64);
        let _second = Function::cached_shared(invalid, &mut cache)?;
        Ok(())
    })();
    assert_eq!(result, Err("config"));
    assert!(cache.values().all(|worker| worker.upgrade().is_none()));
    let pid = fs::read_to_string(dir.path().join("starts")).unwrap();
    assert_eq!(unsafe { libc::kill(pid.trim().parse().unwrap(), 0) }, -1);
}

#[test]
fn optional_cache_preserves_old_config_shape_and_rejects_explicit_non_strings() {
    let old = json!({"participants":[]});
    let config: automatic::Config = serde_json::from_value(old.clone()).unwrap();
    assert!(config.coordinator_cache.is_none());
    assert!(config.pure_cache.is_none());
    assert_eq!(serde_json::to_value(config).unwrap(), old);
    for bad in [json!(null), json!(false), json!(1), json!({}), json!([])] {
        assert!(
            serde_json::from_value::<automatic::Config>(
                json!({"participants":[],"coordinator_cache":bad.clone()})
            )
            .is_err()
        );
        assert!(
            serde_json::from_value::<automatic::Config>(
                json!({"participants":[],"pure_cache":bad})
            )
            .is_err()
        );
    }
}

#[test]
#[ignore = "requires an explicitly pinned real SIGIL fixed evaluator"]
fn compiled_shared_participants_receive_fresh_memory_and_per_call_fuel() {
    let (dir, mut config) = fixture();
    let runtime = std::env::var("PI_GENERATION_EVALUATOR").expect("pinned evaluator path");
    let hash = std::env::var("PI_GENERATION_EVALUATOR_SHA256").expect("pinned evaluator digest");
    assert_eq!(
        format!("{:x}", Sha256::digest(fs::read(&runtime).unwrap())),
        hash
    );
    let source = r#"module fresh;
pub fn tool_main(p: i64, n: i64) -> i64 @Internal ! { Alloc } {
    if n != 1 { return -400; }
    let mut i: i64 @Internal = 0;
    while i < 16 { i += 1; }
    let previous: i64 @Internal = load8(60000);
    store8(60000, 83);
    let out: i64 @Internal = alloc(2);
    store8(out, load8(p)); store8(out + 1, previous + 48);
    return (out << 32) | 2;
}"#;
    fs::write(&config.source, source).unwrap();
    config.source_sha256 = format!("{:x}", Sha256::digest(source));
    config.runtime = runtime.into();
    config.runtime_sha256 = hash;
    config.max_fuel = 1_000_000;
    config.max_timeout_ms = 10_000;
    let mut cache = PureCache::new();
    let mut a = Function::cached_shared(config.clone(), &mut cache).unwrap();
    let mut b = Function::cached_shared(config, &mut cache).unwrap();
    let (PureExecution::SharedCached(wa), PureExecution::SharedCached(wb)) = (&a.worker, &b.worker)
    else {
        panic!("expected shared evaluator");
    };
    assert!(Arc::ptr_eq(wa, wb));
    for (participant, input, expected) in [(&mut a, "A", "A0"), (&mut b, "B", "B0")] {
        assert_eq!(
            participant
                .invoke(input.into(), Instant::now() + Duration::from_secs(10))
                .unwrap(),
            expected
        );
    }
    b.fuel = 1;
    assert_eq!(
        b.invoke("C".into(), Instant::now() + Duration::from_secs(10)),
        Err("application")
    );
    assert_eq!(
        a.invoke("D".into(), Instant::now() + Duration::from_secs(10))
            .unwrap(),
        "D0"
    );
    drop(a);
    drop(b);
    assert!(cache.values().all(|worker| worker.upgrade().is_none()));
    assert!(
        !dir.path().join("starts").exists(),
        "controlled runtime must not run"
    );
}
