use super::*;

fn chain() -> (Frame, Frame, Frame) {
    let initial = Frame::initial([7; 32], [1; 32]);
    let pending = initial.prepare([2; 32]).unwrap();
    let committed = pending.resolve([2; 32]).unwrap();
    (initial, pending, committed)
}

#[test]
fn frame_codec_checks_every_byte_and_foreign_domain() {
    let (initial, pending, committed) = chain();
    let aborted = pending.resolve(initial.root).unwrap();
    for frame in [initial, pending, committed, aborted] {
        let bytes = frame.encode().unwrap();
        assert_eq!(Frame::decode(&bytes, [7; 32]).unwrap(), frame);
        assert_eq!(Frame::decode(&bytes, [8; 32]), Err(Failure::Domain));
        for at in 0..FRAME_BYTES {
            let mut changed = bytes;
            changed[at] ^= 1;
            assert_eq!(Frame::decode(&changed, [7; 32]), Err(Failure::Corrupt));
        }
    }
}

#[test]
fn newer_confirmation_refuses_matching_older_predecessor() {
    let (initial, pending, committed) = chain();
    for slots in [
        [Some(pending.clone()), Some(committed.clone())],
        [Some(committed.clone()), Some(pending.clone())],
    ] {
        assert_eq!(reconcile(&slots, initial.root), Err(Failure::RootMismatch));
        assert_eq!(reconcile(&slots, committed.root).unwrap(), committed);
    }
}

#[test]
fn pending_abort_and_finalize_preserve_issued_identity_and_advance_authority() {
    let (initial, pending, committed) = chain();
    let slots = [Some(initial.clone()), Some(pending.clone())];
    let aborted = reconcile(&slots, initial.root).unwrap();
    assert_eq!(aborted.kind, Kind::Aborted);
    assert_eq!(aborted.issued, pending.issued);
    assert_eq!(aborted.revision, pending.revision + 1);
    assert_eq!(aborted.parent, pending.digest());
    assert_eq!(reconcile(&slots, committed.root).unwrap(), committed);
    assert_eq!(reconcile(&slots, [3; 32]), Err(Failure::RootMismatch));
    let retry = aborted.prepare([3; 32]).unwrap();
    assert!(retry.issued > pending.issued);
    assert!(retry.revision > aborted.revision);
}

#[test]
fn persisted_resolution_is_never_reinterpreted_after_another_restore() {
    let (initial, pending, committed) = chain();
    let aborted = pending.resolve(initial.root).unwrap();
    assert_eq!(
        reconcile(&[Some(pending.clone()), Some(aborted)], committed.root),
        Err(Failure::RootMismatch)
    );
    assert_eq!(
        reconcile(&[Some(pending), Some(committed)], initial.root),
        Err(Failure::RootMismatch)
    );
}

#[test]
fn single_confirmed_copy_repairs_without_revision_inflation_but_pending_quarantines() {
    let (initial, pending, committed) = chain();
    for frame in [initial, committed] {
        for slots in [
            [Some(frame.clone()), None],
            [None, Some(frame.clone())],
            [Some(frame.clone()), Some(frame.clone())],
        ] {
            assert_eq!(reconcile(&slots, frame.root).unwrap(), frame);
        }
    }
    assert_eq!(
        reconcile(&[Some(pending.clone()), None], pending.prior),
        Err(Failure::Ambiguous)
    );
    assert_eq!(
        reconcile(&[None, Some(pending.clone())], pending.root),
        Err(Failure::Ambiguous)
    );
    assert_eq!(select(&[None, None]), Err(Failure::Ambiguous));
}

#[test]
fn impossible_record_relationships_refuse_before_database_matching() {
    let (initial, pending, committed) = chain();
    let other_pending = initial.prepare([3; 32]).unwrap();
    let other_committed = other_pending.resolve([3; 32]).unwrap();
    for slots in [
        [Some(pending.clone()), Some(pending.clone())],
        [Some(committed.clone()), Some(other_committed)],
        [Some(pending), Some(other_pending)],
        [Some(initial), Some(committed)],
    ] {
        assert_eq!(select(&slots), Err(Failure::Conflict));
    }
}

#[test]
fn counters_never_wrap_and_a_pending_transition_cannot_prepare_again() {
    let (initial, pending, _) = chain();
    assert_eq!(initial.prepare(initial.root), Err(Failure::Conflict));
    assert_eq!(pending.prepare([3; 32]), Err(Failure::Conflict));
    let mut exhausted = initial;
    exhausted.issued = u64::MAX / 2;
    exhausted.revision = exhausted.issued * 2;
    exhausted.parent = [9; 32];
    exhausted.prior = [0; 32];
    assert!(exhausted.valid());
    assert_eq!(exhausted.prepare([3; 32]), Err(Failure::Exhausted));
}

#[test]
fn repeated_protocol_resolution_uses_two_frames_and_burns_aborted_ids() {
    let mut stable = Frame::initial([7; 32], [1; 32]);
    for issued in 1u64..=1024 {
        let next: Root = Sha256::digest(issued.to_be_bytes()).into();
        let pending = stable.prepare(next).unwrap();
        let observed = if issued % 3 == 0 { stable.root } else { next };
        let selected = reconcile(&[Some(stable), Some(pending)], observed).unwrap();
        assert_eq!(selected.issued, issued);
        assert_eq!(selected.revision, issued * 2);
        let frames = [Some(selected.clone()), Some(selected.clone())];
        assert_eq!(reconcile(&frames, observed).unwrap(), selected);
        assert_eq!(
            Frame::decode(&selected.encode().unwrap(), [7; 32]).unwrap(),
            selected
        );
        stable = selected;
    }
}

#[test]
fn mixed_state_or_foreign_lineage_cannot_match_confirmed_authority() {
    let (_, _, committed) = chain();
    let mut mixed = committed.root;
    mixed[31] ^= 1;
    assert_eq!(
        reconcile(&[Some(committed.clone()), Some(committed.clone())], mixed),
        Err(Failure::RootMismatch)
    );
    let mut foreign = committed.clone();
    foreign.lineage = [8; 32];
    assert_eq!(
        select(&[Some(committed), Some(foreign)]),
        Err(Failure::Domain)
    );
}
