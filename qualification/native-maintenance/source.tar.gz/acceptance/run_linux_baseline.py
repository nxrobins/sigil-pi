"""One real local-model/tool turn on the identified Linux x86_64 baseline.

Development evidence only, not final MVP, throughput, or native-hardware
qualification. Python assembles the deployment and collects observations; the
native host and compiled SIGIL own every application transition.
"""

import argparse
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import platform
import secrets
import select
import sqlite3
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from scripts.build_workspace_deployment import build
from acceptance.capacity_evidence import inspect_capacity, assert_returned


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def fields(value, marker, count):
    raw, at, result = value.encode(), 4, []
    assert raw[:4] == marker.encode()
    for _ in range(count):
        prefix = raw[at:at + 8]
        assert len(prefix) == 8 and prefix.isdigit()
        length = int(prefix)
        at += 8
        assert at + length <= len(raw)
        result.append(raw[at:at + length].decode())
        at += length
    assert at == len(raw)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--host", required=True, type=Path)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--evaluator", required=True, type=Path)
    parser.add_argument("--stdlib", required=True, type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        parser.error("--execute is required for real local-model calls")
    assert platform.system() == "Linux" and platform.machine() == "x86_64"
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    report = {"kind": "linux-x86_64-development-baseline", "qualification": False,
              "platform": platform.platform(), "python": platform.python_version(),
              "limitations": ["Docker amd64 emulation on arm64; not native throughput qualification",
                              "Local model runs on the host; a bounded loopback relay connects it",
                              "One API task; not the frozen benchmark or onboarding gate"],
              "binaries": {}, "relay": [], "status": "started"}
    for name in ("host", "runtime", "evaluator"):
        path = getattr(args, name).resolve(strict=True)
        raw = path.read_bytes()
        assert raw[:4] == b"\x7fELF", name
        assert raw[4:6] == b"\x02\x01" and raw[18:20] == b"\x3e\x00", name
        report["binaries"][name] = {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}
    save(root / "report.json", report)

    # The effect's admitted network grant remains 127.0.0.1:11434. This test-only
    # relay has a fixed local-host destination, explicit paths, and byte/time
    # ceilings. It does not select application actions or fabricate responses.
    class Relay(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            self.forward()

        def do_POST(self):
            self.forward()

        def forward(self):
            assert (self.command, self.path) in {
                ("GET", "/api/tags"), ("GET", "/api/version"), ("POST", "/v1/messages")}
            size = int(self.headers.get("Content-Length", "0"))
            assert 0 <= size <= 2**20
            self.connection.settimeout(65)
            body = self.rfile.read(size) if size else None
            upstream = http.client.HTTPConnection("host.docker.internal", 11434, timeout=65)
            started = time.monotonic()
            try:
                upstream.request(self.command, self.path, body=body,
                    headers={k: v for k, v in self.headers.items()
                             if k.lower() in {"content-type", "authorization", "x-api-key", "anthropic-version"}})
                response = upstream.getresponse()
                raw = response.read(2**20 + 1)
                assert len(raw) <= 2**20
                report["relay"].append({"path": self.path, "status": response.status,
                    "elapsed_s": time.monotonic() - started,
                    "request_sha256": hashlib.sha256(body or b"").hexdigest(),
                    "response_sha256": hashlib.sha256(raw).hexdigest()})
                self.send_response(response.status)
                self.send_header("Content-Type", response.getheader("Content-Type", "application/json"))
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            finally:
                upstream.close()

    relay = ThreadingHTTPServer(("127.0.0.1", 11434), Relay)
    threading.Thread(target=relay.serve_forever, daemon=True).start()
    process = None
    err = (root / "host-stderr.log").open("w")
    try:
        def request(port, method, path, body=None, token=None):
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=45)
            try:
                headers = {"Content-Type": "application/json"}
                if token:
                    headers["Authorization"] = "Bearer " + token
                conn.request(method, path, json.dumps(body).encode() if body is not None else None, headers)
                response = conn.getresponse()
                raw = response.read(2**21 + 1)
                assert len(raw) <= 2**21
                return response.status, json.loads(raw)
            finally:
                conn.close()

        profile = json.loads((ROOT / "config/conversation-lifecycle-development.json").read_text())
        profile.pop("commands")
        profile["system"] = json.loads((ROOT / "config/workspace-agent-development.json").read_text())["system"]
        code, installed = request(11434, "GET", "/api/tags")
        assert code == 200
        model = next(m for m in installed["models"] if m["name"] == profile["model"])
        assert model["digest"] == profile["model_digest"]
        report["model"] = model
        workspace = root / "workspace"
        workspace.mkdir()
        marker = "linux-baseline-" + secrets.token_hex(12)
        (workspace / "README.md").write_text("The verification marker is " + marker + ".\n")
        token = "linux-baseline-fixture-token-not-for-a-pilot"
        audit_key = "linux-baseline-audit-key-not-for-a-pilot-0123456789"
        os.environ["SIGIL_PI_LOCAL_PROVIDER_TOKEN"] = "local-only-placeholder"
        os.environ["SIGIL_PI_AUDIT_KEY"] = audit_key
        deployment = root / "deployment"
        _, config = build(deployment, workspace, args.runtime, args.evaluator,
                          args.stdlib, token, profile)
        process = subprocess.Popen([str(args.host), "init", str(config), "0"],
            stdout=subprocess.PIPE, stderr=err, text=True)
        ready, _, _ = select.select([process.stdout], [], [], 120)
        assert ready, "Linux service startup did not finish"
        line = process.stdout.readline()
        assert line, "Linux service exited before readiness"
        report["ready"] = json.loads(line)
        assert report["ready"]["status"] == "ready"
        port = int(report["ready"]["address"].rsplit(":", 1)[1])
        prompt = "Read README.md using the permitted tools and report its exact verification marker. Do not edit any file."
        status, accepted = request(port, "POST", "/v1/operations",
            {"session": "linux-baseline", "message": prompt, "submission_key": "first"}, token)
        report["acceptance"] = {"status": status, "body": accepted}
        save(root / "report.json", report)
        assert status == 202, accepted
        until = time.monotonic() + 330
        while time.monotonic() < until:
            status, result = request(port, "GET", accepted["status_url"], token=token)
            assert status == 200, result
            if result["status"] != "accepted":
                break
            time.sleep(0.5)
        else:
            raise TimeoutError("operation exceeded observation deadline; no retry")
        report["result"] = result
        assert result["status"] == "done", result
        assert marker in json.dumps(result), "final response did not report the observed marker"
        with sqlite3.connect(f"file:{deployment / 'records/records.sqlite'}?mode=ro", uri=True) as db:
            rows = [{"namespace": ns, "key": key, "revision": rev, "value": bytes(value).decode()}
                    for ns, key, rev, value in db.execute("SELECT namespace,key,revision,value FROM records ORDER BY namespace,key")]
        save(root / "records.json", rows)
        state = next(row for row in rows if row["namespace"] == "workspace.state" and row["key"] == "linux-baseline")
        history = json.loads(fields(state["value"], "PT1\n", 17)[5])
        calls = [block for message in history if isinstance(message["content"], list)
                 for block in message["content"] if block.get("type") == "tool_use"]
        reads = [call for call in calls if call["name"] == "read_file"]
        assert reads, "no actual retained file-read tool call"
        results = [block for message in history if isinstance(message["content"], list)
                   for block in message["content"] if block.get("type") == "tool_result"]
        assert any(block["tool_use_id"] in {call["id"] for call in reads}
                   and marker in block["content"] and not block.get("is_error", False) for block in results)
        report["tool_names"] = [call["name"] for call in calls]
        report["capacity"] = inspect_capacity(deployment, audit_key.encode())
        assert_returned(report["capacity"])
        report["status"] = "passed"
    except BaseException as exc:
        report["status"] = "failed"
        report["error"] = repr(exc)
        raise
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        err.close()
        relay.shutdown()
        relay.server_close()
        database = root / "deployment/records/records.sqlite"
        if database.is_file():
            try:
                with sqlite3.connect(f"file:{database}?mode=ro", uri=True) as db:
                    rows = [{"namespace": ns, "key": key, "revision": rev, "value": bytes(value).decode()}
                            for ns, key, rev, value in db.execute("SELECT namespace,key,revision,value FROM records ORDER BY namespace,key")]
                save(root / "records.json", rows)
            except Exception as exc:
                report["capture_error"] = repr(exc)
        save(root / "report.json", report)


if __name__ == "__main__":
    main()
