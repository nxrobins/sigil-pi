"""Build the repository-agent profile. No runtime Python decisions or I/O.

Versioned composition keeps existing read-only profiles byte-compatible. The
native host sees only declared workers; SIGIL owns adapters and continuation.
"""

import hashlib
import re
from pathlib import Path

from scripts.compose_application import (
    ApplicationSource,
    compose_application,
    strip_line_comments,
)

ROOT = Path(__file__).resolve().parent.parent


def compose_workspace(name, stdlib_root):
    inputs = {}

    def read(path):
        raw = (ROOT / path).read_bytes()
        inputs[path] = hashlib.sha256(raw).hexdigest()
        return raw.decode()

    def replace(old, new, count=1):
        nonlocal body
        if body.count(old) != count:
            raise ValueError(f"workspace composition expected {count} sites: {old}")
        body = body.replace(old, new)

    if name in {"list_dir", "edit_file", "edit_file_checked", "grep_file"}:
        body = read(
            f"tools/{'edit_file' if name == 'edit_file_checked' else name}.sigil"
        )
        replace(
            "pub fn tool_main(input_ptr: i32, input_len: i32)",
            "fn workspace_effect(input_ptr: i32 @Internal, input_len: i32 @Internal)",
        )
        # The old public entry accepted caller bytes. This internal adapter is
        # fed retained Internal data: raise pointer/local/return labels, never
        # declassify them. The compiler verifies the resulting source normally.
        body = re.sub(r": i32(?! @)", ": i32 @Internal", body)
        body = body.replace("-> i64 !", "-> i64 @Internal !")
        helpers = read("app/shared/record_helpers.sigil").replace(
            "// UTF8_VALIDATOR", read("app/shared/utf8.sigil")
        )
        quote = """
fn quoted(value: i64 @Internal) -> i64 @Internal ! { Alloc } {
    if value < 0 { return -400; }
    return json::escape_string(ptr(value), size(value));
}
"""
        if helpers.count(quote) != 1:
            raise ValueError("exact unused inner-ring quoting helper required")
        body += helpers.replace(quote, "\n") + read("app/pi/workspace_result.sigil")
        if name == "edit_file_checked":
            replace(
                "if input_len < 1 || input_len > 200000 {",
                'if input_len == 0 { put(out, 0, text("error")); put(out, 1, text("428")); return write_record(out, "RF1\\n", 2); }\n    if input_len < 1 || input_len > 200000 {',
            )
        stdlib_hash = "0" * 24
    elif name == "read_file" or name == "check_json":
        base = compose_application("read_file_result", stdlib_root)
        return base
    else:
        base = compose_application(name, stdlib_root)
        inputs.update(base.input_hashes)
        body, stdlib_hash = base.text, base.stdlib_hash
        if name in {"turn", "turn_completion", "dispatch_cancellable"}:
            body += read("app/pi/workspace_arguments.sigil")
        if name in {"turn", "turn_completion"}:
            # Reject oversized responses before JSON normalization can exhaust
            # guest memory or duplicate a tool input past the decision frame.
            replace(
                'if size(payload) > 1048576 { return stop(s, "failed", "response_limit"); }',
                'if size(payload) > 262144 || size(payload) > number(get(cfg, 5), 1048576) { return stop(s, "failed", "response_limit"); }',
            )
            # Invalid model arguments become paired, durable tool feedback in
            # the existing reducer transaction, before any effect intent. Keep
            # permission failures and native observations on their own paths.
            replace(
                "if permitted(name, cfg) {",
                'let mut rejection: i64 @Internal = cat(text("tool not authorized: "), name);\n'
                'if permitted(name, cfg) {\nrejection = workspace_argument_error(name, field(tool, "input"));\n'
                'if size(rejection) == 0 {',
            )
            replace(
                'return decision(s, "tool", name, field(tool, "input"));',
                'return decision(s, "tool", name, field(tool, "input"));\n}',
            )
            replace(
                'let error: i64 @Internal = cat(text("tool not authorized: "), name);',
                'let error: i64 @Internal = rejection;',
            )
        if name in {"admission", "turn", "turn_completion"}:
            # Reopen only after admission has checked the terminal operation's
            # settlement. Pair pending tool IDs with explicit missing outcomes.
            replace(
                'if is_text(get(previous, 1), "done") { } else { return -409; }',
                "if !workspace_terminal(get(previous, 1)) { return -409; }",
            )
            replace(
                "history = get(previous, 5);", "history = workspace_history(previous);"
            )
            body += read("app/pi/workspace_continuation.sigil")
            if name == "admission":
                replace(
                    'if !is_text(get(prior, 1), "done") { return answer("busy", text(""), text("")); }',
                    'if !workspace_terminal(get(prior, 1)) { return answer("busy", text(""), text("")); }',
                )
        if name == "turn_completion":
            replace("fn pi_observation(", "fn pi_raw_observation(")
            replace(
                "let seen: i64 @Internal = pi_observation(",
                "let seen: i64 @Internal = pi_observation(",
            )
            body += read("app/pi/workspace_observation.sigil")
            # Pass the retained tool identity, never a result-supplied identity.
            needle = "let seen: i64 @Internal = pi_observation("
            start = body.index(needle)
            end = body.index(";", start)
            body = (
                body[: end - 1] + ", get(intent, 3), get(intent, 4)" + body[end - 1 :]
            )
        if name == "dispatch_cancellable":
            replace(
                'let artifact: i64 @Internal = read_record(get(x, 10), "EF1\\n", 7);',
                "let artifact: i64 @Internal = workspace_facts(get(x, 10));",
            )
            replace(
                'let binding: i64 @Internal = read_record(get(artifact, 1), "EB1\\n", 7);',
                "let binding: i64 @Internal = workspace_binding(get(artifact, 1));",
            )
            replace(
                'if !is_text(get(binding, 1), "model") || size(get(intent, 3)) != 0',
                'if !is_text(get(binding, 1), "model") || !is_text(get(artifact, 8), "sigil") || arr_len(get(artifact, 7)) != 0 || size(get(intent, 3)) != 0',
            )
            replace(
                '!is_text(get(binding, 1), "read_file")\n|| !is_text(get(intent, 3), "read_file")',
                "!same(get(binding, 1), get(intent, 3))",
            )
            replace(
                "payload = file_input(get(binding, 4), get(intent, 4));",
                "payload = workspace_input(binding, artifact, get(intent, 4), s);",
            )
            body += read("app/pi/workspace_dispatch.sigil")
        if name == "coordinator":
            replace('"LB3\\n", 5', '"LB4\\n", 5')
            replace(
                "arr_len(get(x, 7)) != 2",
                "(arr_len(get(x, 7)) < 2 || arr_len(get(x, 7)) > 33)",
            )
            replace(
                "while i < 5 { if !store_name(get(b, i), 64)",
                "while i < 5 { if i != 1 && !store_name(get(b, i), 64)",
            )
            start = body.index("let a0: i64 @Internal =")
            end = body.index('if is_text(get(x, 4), "boot")', start)
            body = (
                body[:start]
                + "if !workspace_aliases(get(b, 0), get(b, 1), get(x, 7)) { return -400; }\n"
                + body[end:]
            )
            replace(
                'if is_text(phase, "tool") { selected = get(b, 1); }',
                'if is_text(phase, "tool") { selected = workspace_alias(get(b, 1), field(element(get(s, 6), number(get(s, 7), 32)), "name")); if selected < 0 { return selected; } }',
            )
            replace("while i < 2 {", "while i < arr_len(get(x, 7)) {")
            body += read("app/pi/workspace_aliases.sigil")
    inputs["scripts/compose_workspace.py"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    body = strip_line_comments(body, compact_indent=True)
    if len(body.encode()) > 65536:
        raise ValueError(
            f"workspace component {name} exceeds source ceiling: {len(body.encode())}"
        )
    return ApplicationSource(body, inputs, stdlib_hash)
