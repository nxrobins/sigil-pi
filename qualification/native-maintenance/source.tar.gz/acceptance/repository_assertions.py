"""Independent per-task filesystem and durable-observation acceptance oracle."""

import json
import sqlite3
from pathlib import Path
from scripts.workspace_deployment import fields


def files(workspace):
    return {
        str(p.relative_to(workspace)): p.read_text()
        for p in Path(workspace).rglob("*")
        if p.is_file()
    }


def check_task(deployment, workspace, operation, task_id, before):
    after = files(workspace)
    target = "config/release.json" if task_id == "R01" else "config/deploy.json"
    changed = sorted(
        p for p in set(before) | set(after) if before.get(p) != after.get(p)
    )
    assert changed == [target], ("unexpected change scope", changed, target)
    expected = (
        {"service": "atlas", "port": 8080, "note": "preserve this"}
        if task_id == "R01"
        else {"environment": "staging", "replicas": 3, "note": "Keep café | unchanged"}
    )
    assert json.loads(after[target]) == expected
    with sqlite3.connect(
        f"file:{Path(deployment) / 'records/records.sqlite'}?mode=ro", uri=True
    ) as db:
        intents = [
            (k, fields(bytes(v).decode(), "SI1\n", 5))
            for k, v in db.execute(
                "select key,value from records where namespace=?", ("workspace.intent",)
            )
            if k.startswith(operation + ":")
        ]
        delivered = {
            k: fields(bytes(v).decode(), "DR1\n", 7)
            for k, v in db.execute(
                "select key,value from records where namespace=?",
                ("executor0.delivery",),
            )
        }
    observations = []
    for key, intent in sorted(intents, key=lambda x: int(x[1][1])):
        if intent[2] != "tool":
            continue
        assert key in delivered and delivered[key][5] == "returned", (
            "missing observation",
            key,
        )
        observed = fields(delivered[key][6], "RF1\n", 2)
        observations.append(
            {
                "sequence": int(intent[1]),
                "tool": intent[3],
                "input": json.loads(intent[4]),
                "status": observed[0],
                "result": observed[1],
            }
        )
    edits = [
        x for x in observations if x["tool"] == "edit_file" and x["status"] == "ok"
    ]
    assert edits and all(x["input"]["path"] == target for x in edits), (
        "missing or unrelated edit",
        edits,
    )
    checks = [
        x
        for x in observations
        if x["tool"] == "check_json"
        and x["input"]["path"] == target
        and x["status"] == "ok"
    ]
    assert checks and checks[-1]["sequence"] > edits[-1]["sequence"], (
        "no actual recheck after edit"
    )
    assert json.loads(checks[-1]["result"]) == expected, (
        "check did not read the changed file"
    )
    if task_id == "R01":
        initial = next(x for x in checks if x["sequence"] < edits[0]["sequence"])
        try:
            json.loads(initial["result"])
        except json.JSONDecodeError:
            pass
        else:
            raise AssertionError("initial failure was not reproduced")
    return {
        "task": task_id,
        "changed_paths": changed,
        "observations": observations,
        "passed": True,
    }
