"""PINR-1 combined HTTP/entry-capability checks; synthetic loopback traffic only."""

import argparse
from contextlib import ExitStack
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import selectors
import subprocess
import threading
import time


class Lines:
    def __init__(self, binary, stderr):
        self.log = stderr.open("x")
        self.proc = subprocess.Popen([str(binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=self.log, text=True, bufsize=1)

    def request(self, value):
        self.proc.stdin.write(json.dumps(value) + "\n")
        self.proc.stdin.flush()
        with selectors.DefaultSelector() as selector:
            selector.register(self.proc.stdout, selectors.EVENT_READ)
            if not selector.select(90):
                raise TimeoutError("bounded test request exceeded 90 seconds")
            line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError("probe terminated without a response")
        return json.loads(line)

    def close(self):
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait(timeout=5)
        self.proc.stdout.close()
        self.log.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mcp", type=Path, required=True)
    parser.add_argument("--runtime-probe", type=Path, required=True)
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    sources = {key: (args.fixtures / f"http-{name}.sigil").read_text()
               for key, name in (("H0", "canonical"), ("HC", "capability"))}
    report = {"schema": "sigil-pi/pinr1-http-contract/v1", "qualification": False,
              "inputs": {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in [Path(__file__), args.mcp, args.runtime_probe,
                                   args.fixtures / "http-canonical.sigil", args.fixtures / "http-capability.sigil"]},
              "cases": [], "fixture_validity": {}, "status": "running"}
    requests = []
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            with lock:
                requests.append(self.path)
            try:
                if self.path == "/redirect":
                    self.send_response(302)
                    self.send_header("Location", f"http://127.0.0.1:{self.server.server_port}/destination")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                if self.path == "/slow":
                    time.sleep(2.8)
                payload = b"exact synthetic response"
                self.send_response(200)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                if self.path == "/dribble":
                    for byte in payload:
                        self.wfile.write(bytes([byte]))
                        self.wfile.flush()
                        time.sleep(0.05)
                else:
                    self.wfile.write(payload)
            except (BrokenPipeError, ConnectionResetError):
                pass

    with ExitStack() as stack:
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        stack.callback(server.server_close)
        stack.callback(server.shutdown)
        base = f"http://127.0.0.1:{server.server_port}"
        mcp = Lines(args.mcp, args.output / "mcp.stderr")
        stack.callback(mcp.close)
        runtime = Lines(args.runtime_probe, args.output / "runtime.stderr")
        stack.callback(runtime.close)
        counter = 0

        def rpc(method, params):
            nonlocal counter
            counter += 1
            answer = mcp.request({"jsonrpc": "2.0", "id": counter, "method": method, "params": params})
            assert answer.get("id") == counter and answer.get("jsonrpc") == "2.0", answer
            return answer

        assert "result" in rpc("initialize", {})

        def invoke(surface, fixture, path="/ok", *, net=True, caps=None, budget=1000):
            if surface == "runtime":
                value = runtime.request({"source": sources[fixture], "input": base + path,
                                         "caps": ["Declassify"] if caps is None else caps,
                                         "net": net, "http_timeout_ms": budget})
                assert value.get("solver_verified") is True, value
                assert value["entry_caps"] == ([] if fixture == "H0" else ["Declassify"]), value
                return value["outcome"]
            grants = {"net": ["127.0.0.1"] if net else [], "fs": [], "secret": []}
            if caps is not None:
                grants["caps"] = caps
            if budget is not None:
                grants["http_timeout_ms"] = budget
            answer = rpc("tools/call", {"name": "sigil_forge", "arguments": {
                "source": sources[fixture], "input": base + path, "fuel": 1_000_000,
                "host_profile": "ephemeral", "grants": grants}})
            if "error" in answer:
                return {"status": "protocol_error", "error": answer["error"]}
            return json.loads(answer["result"]["content"][0]["text"])

        def success(surface, out):
            return out.get("status") == "ok" and (out.get("output") if surface == "runtime" else out.get("data", {}).get("output_text")) == "exact synthetic response"

        def refusal(surface, out, code):
            if surface == "runtime":
                return out.get("status") == "trapped" and f"tool returned error ({code})" in out.get("message", "")
            ds = out.get("diagnostics", [])
            return out.get("status") == "error" and len(ds) == 1 and ds[0].get("code") == "R803" and f"tool returned error ({code})" in ds[0].get("message", "")

        def case(name, surface, fixture, expected_count, predicate, **kw):
            before = len(requests)
            started = time.monotonic()
            try:
                out = invoke(surface, fixture, **kw)
                seen = requests[before:]
                ok = predicate(out) and len(seen) == expected_count and "/destination" not in seen
                row = {"id": name, "surface": surface, "outcome": out, "requests": seen,
                       "status": "passed" if ok else "failed"}
            except Exception as error:
                row = {"id": name, "surface": surface, "status": "failed", "error": repr(error), "requests": requests[before:]}
            row["seconds"] = time.monotonic() - started
            report["cases"].append(row)
            (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")

        try:
            # Compilation validity is separate from effect refusal: exact fresh
            # compiler metadata and the expected HTTP denial must both hold.
            for fixture, caps in (("H0", []), ("HC", ["Declassify"])):
                before = len(requests)
                out = invoke("runtime", fixture, net=False, caps=caps)
                assert refusal("runtime", out, 403) and len(requests) == before, out
                report["fixture_validity"][fixture] = {"status": "passed", "entry_caps": caps, "solver_verified": True}
            case("H01", "mcp", "H0", 1, lambda o: success("mcp", o))
            for name, caps in (("H02", None), ("H03", ["Declassify"])):
                case(name, "mcp", "HC", 0, lambda o: o.get("status") == "error" and [d.get("code") for d in o.get("diagnostics", [])] == ["R822"], caps=caps)
            case("H04", "runtime", "HC", 1, lambda o: success("runtime", o))
            for caps in ([], ["Declassify", "Declassify"]):
                case(f"H05-{len(caps)}", "runtime", "HC", 0,
                     lambda o, count=len(caps): o == {"status": "entry_caps_ungranted", "params": 3, "granted": count}, caps=caps)
            for surface, fixture in (("mcp", "H0"), ("runtime", "HC")):
                case("H06-" + surface, surface, fixture, 0, lambda o, s=surface: refusal(s, o, 403), net=False)
                case("H08-" + surface, surface, fixture, 1, lambda o, s=surface: refusal(s, o, 403), path="/redirect")
                case("H09-" + surface, surface, fixture, 1, lambda o, s=surface: refusal(s, o, 502), path="/dribble", budget=200)
                case("H10-omitted-fast-" + surface, surface, fixture, 1, lambda o, s=surface: success(s, o), budget=None)
                case("H10-omitted-slow-" + surface, surface, fixture, 1, lambda o, s=surface: refusal(s, o, 502), path="/slow", budget=None)
                case("H10-budget-slow-" + surface, surface, fixture, 1, lambda o, s=surface: success(s, o), path="/slow", budget=4000)
            for value in (0, 60001, -1, True, "1000", 1.5):
                case("H07-" + repr(value), "mcp", "H0", 0,
                     lambda o: o.get("status") == "protocol_error" and o.get("error", {}).get("code") == -32602, budget=value)
            # Endpoints exercise parsing/execution without a 1 ms network oracle.
            sources["EMPTY"] = "module tool; pub fn tool_main(input_ptr: i64, input_len: i64) -> i64 { return 0; }"
            for value in (1, 60000):
                case("budget-endpoint-" + str(value), "mcp", "EMPTY", 0,
                     lambda o: o.get("status") == "ok" and o.get("data", {}).get("output_text") == "", net=False, budget=value)
            report["status"] = "passed" if all(r["status"] == "passed" for r in report["cases"]) else "failed"
        except Exception as error:
            report["status"] = "fixture_invalid"
            report["error"] = repr(error)
        finally:
            report["requests"] = requests
            (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "cases": len(report["cases"]), "report": str(args.output / "report.json")}))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
