"""Explicit maintenance profile; decisions remain fixed SIGIL artifacts."""
import hashlib
from pathlib import Path
from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_generation_coordinator import compose_generation_coordinator
from scripts.compose_generation_retirement import compose_generation_retirement

ROOT = Path(__file__).resolve().parent.parent


def append(base, name, replacement):
    marker = "pub fn tool_main(input_ptr: i64,input_len: i64)"
    body = compact(base.text)
    if body.count(marker) != 1:
        raise ValueError("one prior entry required")
    body = body.replace(marker, replacement)
    raw = (ROOT / name).read_bytes()
    body = compact(body + "\n" + raw.decode())
    inputs = dict(base.input_hashes)
    inputs[name] = hashlib.sha256(raw).hexdigest()
    inputs["scripts/compose_generation_maintenance.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return body, inputs


def finish(body, inputs, stdlib_hash):
    if len(body.encode()) > 65536 or body.count("pub fn tool_main(") != 1:
        raise ValueError("maintenance source/entry limit")
    return ApplicationSource(body, inputs, stdlib_hash)


def compose_maintenance(stdlib):
    base = compose_generation_retirement(stdlib)
    body, inputs = append(base, "app/pi/generation_maintenance.sigil",
        "fn generation_retirement_base(input_ptr: i64 @Internal,input_len: i64 @Internal)")
    return finish(body, inputs, base.stdlib_hash)


def compose_handoff(stdlib, *, handoff_slot=31):
    if type(handoff_slot) is not int or not 0 <= handoff_slot <= 127:
        raise ValueError("handoff slot must fit catalog")
    base = compose_generation_coordinator(stdlib)
    body, inputs = append(base, "app/pi/generation_handoff.sigil",
        "fn generation_handoff_base(input_ptr: i64 @Internal,input_len: i64 @Internal)")
    if body.count("HANDOFF_SLOT") != 1:
        raise ValueError("handoff threshold marker changed")
    scan = 'command("keys",get(c,8),get(k,1),text("1"),next_step(k,"keys"),0)'
    settled = 'is_text(get(selected,0),"keys")'
    if body.count(scan) != 1 or body.count(settled) != 1:
        raise ValueError("maintenance allocation discovery site changed")
    body = body.replace(scan, 'command("reservation_keys",get(c,13),get(k,1),text("1"),next_step(k,"keys"),0)')
    body = body.replace(settled, 'is_text(get(selected,0),"reservation_keys")')
    return finish(body.replace("HANDOFF_SLOT", str(handoff_slot)), inputs, base.stdlib_hash)
