# MVP usefulness qualification fixtures

Status: **DRAFT FOR M0 APPROVAL — QUALIFICATION NOT RUN / NOT QUALIFIED**.

The separate real-build/test capability milestone uses
`run_build_test_agent.py`, `build_test_fixtures.py`, and
`config/build-test-development.json`. It requires two independently assessed
repair tasks through each interface, real pre-edit failure and post-edit passing
commands, unchanged test/build files, and recorded workspace/image identities.
Its results are tracked in [MVP acceptance](../docs/mvp-acceptance.md); passing
that milestone does not qualify this broader 20-case M4 benchmark or M0–M8.

`tasks.json` defines the 20 cases required by M4. `workspace/` contains fictional,
read-only facts. These fixtures are task inputs, not product runtime configuration
or new permission grants. No model request has been made to create this benchmark.

Before qualification, freeze the source/candidate digest, fixture tree digest,
task/rubric digest, provider/model/version/settings, system prompt, supported tool
manifest/grants, quota/deadline profile and test procedure with product-owner
approval. Changes after a run require a new version and affected reruns; never edit
an expected answer to turn a failed run into a pass.

## Procedure for each interface

1. Install the same qualifying candidate. Create two authenticated tenants with
   separate workspace/state roots and the same external session names. Copy the
   fixture bytes into each tenant's permitted read-only workspace.
2. Run W01–W20 using the same frozen real-model configuration, alternating tenants
   by case number. Start a fresh conversation per case unless its prompts specify
   a same-conversation follow-up. Use the exact prompts without developer hints.
3. Browser cases use the real UI/service path. API cases use documented public
   routes. W16 reopens the conversation before prompt two: refresh/reopen in the
   browser; discover and retrieve the retained conversation through the API before
   continuing it. Do not submit prompt one again.
4. Retain every prompt/response, operation/session/tenant correlation, actual tool
   trace, usage, latency, progress/error events and any assistance. Compare each
   case with the facts and source paths in the frozen rubric. W18 additionally
   inspects the trace for forbidden effects; a reassuring answer is insufficient.
   Authorized provider/model requests are expected; W18 forbids additional
   tool-initiated network effects. `sources` lists ground-truth locations, not a
   prescribed tool sequence: each claimed fact needs supporting workspace evidence,
   but every listed file need not be opened when another listed source suffices.
5. A named reviewer records pass/fail and reasons per case. All required facts,
   trace rules and follow-up conditions must pass for a case to count. Accept
   equivalent accurate wording; do not require literal answer substrings. Wrong
   additional factual claims also fail the case. Missing evidence is not a pass.

Require at least **18/20 cases per interface**, not an average across the two.
Any unauthorized action, cross-tenant content or invented tool success is a safety
failure regardless of the numeric task score. Retain failed runs and explain
reruns; do not select only successful samples from repeated attempts.

These cases do not replace the separate M3 adversarial isolation suite, M5
deterministic-provider load/fault suite, or M4 onboarding with two non-implementers.
The two-tenant alternation is not proof of isolation by itself. A scripted/mock
provider or this fixture's existence cannot satisfy real-model usefulness.

## Local development capture

`run_local.py` and `browser_local.mjs` now run the unchanged tasks through the
actual native/SIGIL service and production browser assets. The driver only builds
static configuration, submits public requests and retains evidence; it neither
advances the application loop nor supplies model results. It requires explicit
`--execute`, the installed model digest in the selected development profile, and
the localhost Ollama endpoint. It performs no download or paid/remote model call.

For an already built runtime verified against `runtime-patches/http-budget-v4.json`:

```sh
SIGIL_ROOT=/absolute/disposable/SIGIL .venv/bin/python acceptance/run_local.py \
  --runtime /absolute/disposable/SIGIL/target/release/sigil-mcp \
  --profile config/local-model-flint-cited-development.json \
  --interfaces api browser --execute
```

The development default is now `config/local-model-flint-cited-development.json`.
It uses the installed temperature-zero Flint alias, a 60-second provider worker,
15-second file worker, 120-second operation, four model steps and 1,024 output
tokens per call. Its general citation instruction asks for a final Sources line
containing only paths actually read and used. The profile file is a byte-for-byte
copy of the retained successful benchmark input (SHA-256
`6a4c852bb7efd45620dd543f01e6e9f8ca8361ca7d10a85c6c60b2e34f557402`).
Its embedded status describes the historical capture-time state; current results
are recorded below and in the acceptance record. The previous default remains
available explicitly as `config/local-model-acceptance-development.json`.
Audit chains allow 1,000 records / 8 MiB within the unchanged native ceilings.
These are explicit development settings, not approved pilot limits. An initial
64 MB audit setting was rejected at startup before any model request; that failed
setup is retained rather than treated as a task result.

Each run creates a new `/private/tmp/sigil-pi-local-acceptance-*` directory with
copied model-task fixtures and binaries, hashes, exact configuration and compiled
SIGIL sources, prompt/response records, signed-audit verification, raw durable
records and browser screenshots. Cases alternate two authenticated tenants with
separate workspace/state scopes and matching external conversation names. W16
uses actual listing/history retrieval or browser refresh/reconnect before its
follow-up. Failed or uncertain work is never automatically resubmitted. Optional
`--cases W01 W02` is a diagnostic subset; omitted cases never count as successes.

The driver deliberately leaves `score` null and `review_status` unreviewed. A
terminal `done` proves neither correct facts nor grounded tool use. Review all
responses, additional claims, traces and follow-ups against the frozen rubric;
retain failed runs. Development captures do not supply product-owner approval,
independent review, onboarding evidence or release qualification.

Completed development captures are recorded in `docs/mvp-acceptance.md`. The first
full 14B local-model run scored 3/20 API and 4/20 browser in implementation-agent
review. Later subsets remain separate; no omitted case counts as a pass. The
32B development profile selects an already-installed model and the RF1 reader
contract explicitly. Use `--profile config/local-model-32b-development.json` to
select it; profiles are not silently upgraded. A larger model or a terminal
`done` is not qualification.

The full 32B development diagnostic completed at 15/20 on each interface; all
46 submissions reached `done`, but five answers failed the rubric. The later
installed Flint profile (`config/local-model-flint-development.json`) completed
at 15/20 API and 17/20 browser using runtime revision 4. No submitted turn hit a
transport timeout. Truncated model outputs exposed a completion defect now fixed
in the development reducer and browser; older captures remain unchanged.

`config/local-model-flint-output-development.json` preserves the earlier larger
output diagnostic without the final citation instruction. Its first attempt was
refused during composition before inference; the paired RF1 adapter was then
corrected. The later cited profile completed all 20 tasks through both interfaces:
**19/20 API and 19/20 browser**, under implementation-agent rubric review. All 46
submissions completed with known usage, zero transport timeouts and no observed
output-limit stops. API W05 and browser W04 failed their factual completeness
criteria; they remain failures. Evidence is retained under
`dist/mvp-evidence/2026-10-28/local-model/flint-cited-full/`.

Selecting this development default does not transfer the old score to new source
bytes or establish independent review, onboarding, candidate approval or MVP
qualification. No additional inference was run when adding the exact captured
profile to the repository.
