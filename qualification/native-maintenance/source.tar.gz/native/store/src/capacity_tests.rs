use super::*;
use crate::store::authenticated_log::{AuthenticatedLog, ChainLimits};
use std::os::unix::fs::PermissionsExt;
use std::time::Instant;
use tempfile::TempDir;

fn pool(id: &str, namespaces: &[&str], records: u64, live_bytes: u64) -> Pool {
    Pool {
        id: id.into(),
        namespaces: namespaces.iter().map(|n| (*n).into()).collect(),
        records,
        live_bytes,
    }
}

fn allocation() -> Allocation {
    Allocation {
        version: 1,
        pools: vec![
            pool("first", &["a", "aa"], 2, 512),
            pool("second", &["b"], 2, 512),
        ],
    }
}

fn temp() -> TempDir {
    let dir = tempfile::tempdir().unwrap();
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    dir
}

fn fresh(allocation: Allocation) -> (TempDir, Store, Scope) {
    let dir = temp();
    let grants = allocation
        .pools
        .iter()
        .flat_map(|p| &p.namespaces)
        .map(|n| (n.clone(), Access::ReadWrite))
        .collect();
    let store = Store::open_allocated(
        dir.path(),
        OpenMode::CreateNew,
        Limits::default(),
        allocation,
    )
    .unwrap();
    let scope = store.scope(grants).unwrap();
    (dir, store, scope)
}

#[test]
fn actual_pool_observation_refuses_cross_pool_and_missing_members_without_writes() {
    let (_dir, store, _scope) = fresh(allocation());
    let before = snapshot(&store);
    assert_eq!(store.same_pool(&["a", "aa"]), Ok(()));
    assert_eq!(store.same_pool(&["b"]), Ok(()));
    assert_eq!(store.same_pool(&["a", "b"]), Err(Error::Denied));
    assert_eq!(store.same_pool(&["missing"]), Err(Error::Denied));
    assert_eq!(store.same_pool(&["a", "missing"]), Err(Error::Denied));
    assert_eq!(store.same_pool(&[]), Err(Error::Invalid));
    assert_eq!(snapshot(&store), before);
}

fn write(namespace: &str, key: &str, revision: u64, value: Option<&str>) -> Mutation {
    Mutation {
        namespace: namespace.into(),
        key: key.into(),
        revision,
        value: value.map(str::to_owned),
    }
}

fn batch(writes: Vec<Mutation>) -> Batch {
    Batch {
        checks: vec![],
        writes,
    }
}

// Include the revision and every persisted record/digest, not just the caller's
// intended mutations, so rollback assertions also cover audit and other pools.
fn snapshot(store: &Store) -> (i64, String) {
    let revision = store
        .connection
        .query_row("SELECT revision FROM meta", [], |r| r.get(0))
        .unwrap();
    let rows = store.connection.prepare("SELECT namespace,key,revision,hex(value),hex(digest) FROM records ORDER BY namespace,key").unwrap()
        .query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?, r.get::<_, i64>(2)?,
            r.get::<_, String>(3)?, r.get::<_, String>(4)?))).unwrap()
        .collect::<std::result::Result<Vec<_>, _>>().unwrap();
    (revision, serde_json::to_string(&rows).unwrap())
}

#[test]
fn exhausted_pool_cannot_borrow_but_other_pool_still_commits() {
    let (dir, mut store, scope) = fresh(allocation());
    store
        .commit(
            &scope,
            &batch(vec![
                write("a", "x", 0, Some("one")),
                write("aa", "y", 0, Some("two")),
            ]),
        )
        .unwrap();
    let full = snapshot(&store);
    assert_eq!(
        store.commit(&scope, &batch(vec![write("aa", "z", 0, Some("three"))])),
        Err(Error::Limit)
    );
    assert_eq!(snapshot(&store), full);
    store
        .commit(&scope, &batch(vec![write("b", "x", 0, Some("available"))]))
        .unwrap();
    drop(store);
    let mut reopened = Store::open_allocated(
        dir.path(),
        OpenMode::Existing,
        Limits::default(),
        allocation(),
    )
    .unwrap();
    let scope = reopened
        .scope(BTreeMap::from([
            ("a".into(), Access::ReadWrite),
            ("b".into(), Access::ReadWrite),
        ]))
        .unwrap();
    assert_eq!(
        reopened.commit(&scope, &batch(vec![write("a", "z", 0, Some("still full"))])),
        Err(Error::Limit)
    );
    reopened
        .commit(
            &scope,
            &batch(vec![write("b", "y", 0, Some("still available"))]),
        )
        .unwrap();
}

#[test]
fn byte_allowance_counts_utf8_and_sums_namespaces() {
    // a/x = 98 bytes of coordinate overhead, aa/y = 99; é = two bytes.
    let selected = Allocation {
        version: 1,
        pools: vec![pool("first", &["a", "aa"], 10, 201)],
    };
    let (_dir, mut store, scope) = fresh(selected);
    store
        .commit(
            &scope,
            &batch(vec![
                write("a", "x", 0, Some("é")),
                write("aa", "y", 0, Some("é")),
            ]),
        )
        .unwrap();
    let full = snapshot(&store);
    assert_eq!(
        store.commit(&scope, &batch(vec![write("aa", "y", 1, Some("éx"))])),
        Err(Error::Limit)
    );
    assert_eq!(snapshot(&store), full);
}

#[test]
fn replacing_payload_frees_bytes_and_tombstones_keep_record_slots() {
    let selected = Allocation {
        version: 1,
        pools: vec![pool("first", &["a"], 2, 202)],
    };
    let (_dir, mut store, scope) = fresh(selected);
    store
        .commit(
            &scope,
            &batch(vec![
                write("a", "x", 0, Some("123456")),
                write("a", "y", 0, Some("")),
            ]),
        )
        .unwrap();
    assert_eq!(
        store.commit(&scope, &batch(vec![write("a", "y", 1, Some("1"))])),
        Err(Error::Limit)
    );
    // Reduction and growth are metered on the final atomic state, not write order.
    store
        .commit(
            &scope,
            &batch(vec![
                write("a", "y", 1, Some("123456")),
                write("a", "x", 1, None),
            ]),
        )
        .unwrap();
    let full = snapshot(&store);
    assert_eq!(
        store.commit(&scope, &batch(vec![write("a", "z", 0, None)])),
        Err(Error::Limit)
    );
    assert_eq!(snapshot(&store), full);
    assert_eq!(
        store.get(&scope, "a", "x").unwrap(),
        Record {
            revision: 2,
            value: None
        }
    );
}

#[test]
fn failed_multi_pool_batch_rolls_back_other_writes_and_revision() {
    let (_dir, mut store, scope) = fresh(allocation());
    store
        .commit(
            &scope,
            &batch(vec![
                write("a", "x", 0, Some("one")),
                write("aa", "y", 0, Some("two")),
            ]),
        )
        .unwrap();
    let before = snapshot(&store);
    assert_eq!(
        store.commit(
            &scope,
            &batch(vec![
                write("b", "ok", 0, Some("must roll back")),
                write("a", "z", 0, None)
            ])
        ),
        Err(Error::Limit)
    );
    assert_eq!(snapshot(&store), before);
    assert_eq!(store.get(&scope, "b", "ok").unwrap().revision, 0);
    assert_eq!(
        store
            .commit(
                &scope,
                &batch(vec![write("b", "ok", 0, Some("now committed"))])
            )
            .unwrap()
            .revision,
        2
    );
}

#[test]
fn undeclared_namespaces_are_denied_at_scope_and_operation_boundaries() {
    let (_dir, mut store, _scope) = fresh(allocation());
    assert_eq!(
        store
            .scope(BTreeMap::from([("outside".into(), Access::ReadWrite)]))
            .err(),
        Some(Error::Denied)
    );
    // Native-only adversarial fixture bypasses minting to check the second gate.
    let forged = Scope {
        boot: store.boot,
        grants: BTreeMap::from([("outside".into(), Access::ReadWrite)]),
    };
    let before = snapshot(&store);
    assert_eq!(store.get(&forged, "outside", "x"), Err(Error::Denied));
    assert_eq!(
        store.commit(&forged, &batch(vec![write("outside", "x", 0, Some("no"))])),
        Err(Error::Denied)
    );
    assert_eq!(snapshot(&store), before);
}

#[test]
fn invalid_allocations_fail_before_creating_any_storage() {
    for kind in [
        "version",
        "empty",
        "pool_count",
        "duplicate_id",
        "empty_id",
        "bad_id",
        "long_id",
        "no_namespaces",
        "overlap",
        "repeat_namespace",
        "bad_namespace",
        "long_namespace",
        "pool_namespace_count",
        "total_namespace_count",
        "zero_records",
        "zero_bytes",
        "record_sum",
        "byte_sum",
        "record_overflow",
        "byte_overflow",
    ] {
        let mut a = allocation();
        match kind {
            "version" => a.version = 2,
            "empty" => a.pools.clear(),
            "pool_count" => {
                a.pools = (0..65)
                    .map(|i| pool(&format!("p{i}"), &[&format!("n{i}")], 1, 1))
                    .collect()
            }
            "duplicate_id" => a.pools[1].id = a.pools[0].id.clone(),
            "empty_id" => a.pools[0].id.clear(),
            "bad_id" => a.pools[0].id = "bad/id".into(),
            "long_id" => a.pools[0].id = "x".repeat(129),
            "no_namespaces" => a.pools[0].namespaces.clear(),
            "overlap" => a.pools[1].namespaces.push("a".into()),
            "repeat_namespace" => a.pools[0].namespaces.push("a".into()),
            "bad_namespace" => a.pools[0].namespaces[0] = "é".into(),
            "long_namespace" => a.pools[0].namespaces[0] = "x".repeat(129),
            "pool_namespace_count" => {
                a.pools[0].namespaces = (0..65).map(|i| format!("n{i}")).collect()
            }
            "total_namespace_count" => {
                a.pools = (0..5)
                    .map(|i| Pool {
                        id: format!("p{i}"),
                        namespaces: (0..64).map(|j| format!("n{i}_{j}")).collect(),
                        records: 1,
                        live_bytes: 1,
                    })
                    .collect()
            }
            "zero_records" => a.pools[0].records = 0,
            "zero_bytes" => a.pools[0].live_bytes = 0,
            "record_sum" => a.pools[0].records = Limits::default().records,
            "byte_sum" => a.pools[0].live_bytes = Limits::default().live_bytes,
            "record_overflow" => a.pools[0].records = u64::MAX,
            "byte_overflow" => a.pools[0].live_bytes = u64::MAX,
            _ => unreachable!(),
        }
        let dir = temp();
        assert_eq!(
            Store::open_allocated(dir.path(), OpenMode::CreateNew, Limits::default(), a).err(),
            Some(Error::Invalid),
            "{kind}"
        );
        assert_eq!(fs::read_dir(dir.path()).unwrap().count(), 0, "{kind}");
    }
}

#[test]
fn maximum_allocation_fits_bounded_metadata_and_reopens() {
    let a = Allocation {
        version: 1,
        pools: (0..64)
            .map(|i| Pool {
                id: format!("p{i:03}{}", "x".repeat(124)),
                namespaces: (0..4)
                    .map(|j| format!("n{i:03}{j}{}", "x".repeat(123)))
                    .collect(),
                records: 1,
                live_bytes: 1,
            })
            .collect(),
    };
    let dir = temp();
    let store = Store::open_allocated(
        dir.path(),
        OpenMode::CreateNew,
        Limits::default(),
        a.clone(),
    )
    .unwrap();
    let length: i64 = store
        .connection
        .query_row("SELECT length(limits) FROM meta", [], |r| r.get(0))
        .unwrap();
    assert!(length > 4096 && length <= ENCODED_BYTES as i64);
    drop(store);
    assert!(Store::open_allocated(dir.path(), OpenMode::Existing, Limits::default(), a).is_ok());
}

#[test]
fn restart_accepts_reordering_but_refuses_changed_membership_or_allowances() {
    let (dir, store, _scope) = fresh(allocation());
    drop(store);
    let mut reordered = allocation();
    reordered.pools.reverse();
    for p in &mut reordered.pools {
        p.namespaces.reverse();
    }
    drop(
        Store::open_allocated(dir.path(), OpenMode::Existing, Limits::default(), reordered)
            .unwrap(),
    );
    for kind in [
        "id",
        "records",
        "bytes",
        "namespace",
        "membership",
        "global_limit",
    ] {
        let mut a = allocation();
        let mut limits = Limits::default();
        match kind {
            "id" => a.pools[0].id = "other".into(),
            "records" => a.pools[0].records += 1,
            "bytes" => a.pools[0].live_bytes += 1,
            "namespace" => a.pools[0].namespaces[0] = "other".into(),
            "membership" => {
                a.pools[0].namespaces.pop();
                a.pools[1].namespaces.push("aa".into());
            }
            "global_limit" => limits.records -= 1,
            _ => unreachable!(),
        }
        assert_eq!(
            Store::open_allocated(dir.path(), OpenMode::Existing, limits, a).err(),
            Some(Error::Invalid),
            "{kind}"
        );
        drop(
            Store::open_allocated(
                dir.path(),
                OpenMode::Existing,
                Limits::default(),
                allocation(),
            )
            .unwrap(),
        );
    }
}

#[test]
fn bound_admission_cannot_be_changed_removed_or_added_on_reopen() {
    let dir = temp();
    let tag = [17; 32];
    let mut store = Store::open_allocated_bound(
        dir.path(),
        OpenMode::CreateNew,
        Limits::default(),
        allocation(),
        tag,
    )
    .unwrap();
    let scope = store
        .scope(BTreeMap::from([("a".into(), Access::ReadWrite)]))
        .unwrap();
    store
        .commit(&scope, &batch(vec![write("a", "x", 0, Some("retained"))]))
        .unwrap();
    let before = snapshot(&store);
    drop(store);
    assert_eq!(
        Store::open_allocated_bound(
            dir.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            [18; 32]
        )
        .err(),
        Some(Error::Invalid)
    );
    assert_eq!(
        Store::open_allocated(
            dir.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation()
        )
        .err(),
        Some(Error::Invalid)
    );
    assert_eq!(
        Store::open(dir.path(), OpenMode::Existing, Limits::default()).err(),
        Some(Error::Corrupt)
    );
    let mut reordered = allocation();
    reordered.pools.reverse();
    for p in &mut reordered.pools {
        p.namespaces.reverse();
    }
    let mut reopened = Store::open_allocated_bound(
        dir.path(),
        OpenMode::Existing,
        Limits::default(),
        reordered,
        tag,
    )
    .unwrap();
    assert_eq!(snapshot(&reopened), before);
    let scope = reopened
        .scope(BTreeMap::from([("a".into(), Access::Read)]))
        .unwrap();
    assert_eq!(
        reopened.inspect_namespaces(
            &scope,
            &["a".into()],
            Instant::now() + Duration::from_secs(1)
        ),
        Ok(())
    );
    let (unbound, store, _) = fresh(allocation());
    drop(store);
    assert_eq!(
        Store::open_allocated_bound(
            unbound.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
            tag
        )
        .err(),
        Some(Error::Invalid)
    );
    assert!(
        Store::open_allocated(
            unbound.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation()
        )
        .is_ok()
    );
}

#[test]
fn bound_admission_metadata_is_exact_bounded_and_checked_by_inspection() {
    for kind in [
        "changed", "missing", "null", "short", "long", "string", "negative",
    ] {
        let dir = temp();
        let mut store = Store::open_allocated_bound(
            dir.path(),
            OpenMode::CreateNew,
            Limits::default(),
            allocation(),
            [17; 32],
        )
        .unwrap();
        let scope = store
            .scope(BTreeMap::from([("a".into(), Access::Read)]))
            .unwrap();
        let raw = encode(&Limits::default(), Some(&allocation()), Some([17; 32])).unwrap();
        assert!(raw.len() <= ENCODED_BYTES);
        let mut value: serde_json::Value = serde_json::from_str(&raw).unwrap();
        match kind {
            "changed" => value["admission"] = serde_json::json!(vec![18; 32]),
            "missing" => {
                value.as_object_mut().unwrap().remove("admission");
            }
            "null" => value["admission"] = serde_json::Value::Null,
            "short" => value["admission"] = serde_json::json!([17]),
            "long" => value["admission"] = serde_json::json!(vec![17; 33]),
            "string" => value["admission"] = serde_json::json!("opaque"),
            "negative" => value["admission"][0] = serde_json::json!(-1),
            _ => unreachable!(),
        }
        store
            .connection
            .execute("UPDATE meta SET limits=?1", [value.to_string()])
            .unwrap();
        let before = snapshot(&store);
        assert!(
            store
                .inspect_namespaces(
                    &scope,
                    &["a".into()],
                    Instant::now() + Duration::from_secs(1)
                )
                .is_err(),
            "{kind}"
        );
        assert_eq!(snapshot(&store), before);
        drop(store);
        assert!(
            Store::open_allocated_bound(
                dir.path(),
                OpenMode::Existing,
                Limits::default(),
                allocation(),
                [17; 32]
            )
            .is_err(),
            "{kind}"
        );
    }
}

#[test]
fn legacy_metadata_encoding_is_unchanged_and_binding_requires_allocation() {
    let limits = Limits::default();
    assert_eq!(
        encode(&limits, None, None).unwrap(),
        serde_json::to_string(&limits).unwrap()
    );
    let raw = encode(&limits, Some(&allocation()), None).unwrap();
    let value: serde_json::Value = serde_json::from_str(&raw).unwrap();
    assert_eq!(value.as_object().unwrap().len(), 2);
    assert!(value.get("admission").is_none());
    assert_eq!(encode(&limits, None, Some([17; 32])), Err(Error::Invalid));
}

#[test]
fn schema_versions_never_upgrade_or_fall_back_implicitly() {
    let (allocated, store, _) = fresh(allocation());
    drop(store);
    assert_eq!(
        Store::open(allocated.path(), OpenMode::Existing, Limits::default()).err(),
        Some(Error::Corrupt)
    );
    drop(
        Store::open_allocated(
            allocated.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation(),
        )
        .unwrap(),
    );
    let legacy = temp();
    drop(Store::open(legacy.path(), OpenMode::CreateNew, Limits::default()).unwrap());
    assert_eq!(
        Store::open_allocated(
            legacy.path(),
            OpenMode::Existing,
            Limits::default(),
            allocation()
        )
        .err(),
        Some(Error::Corrupt)
    );
    drop(Store::open(legacy.path(), OpenMode::Existing, Limits::default()).unwrap());
}

#[test]
fn inspection_and_restart_refuse_corrupt_or_oversized_admission() {
    for kind in [
        "malformed",
        "overlap",
        "unknown_field",
        "changed_limit",
        "oversize_ascii",
        "oversize_utf8",
        "embedded_nul",
    ] {
        let (dir, mut store, scope) = fresh(allocation());
        let encoded = match kind {
            "malformed" => "{".into(),
            "overlap" => {
                let mut a = allocation();
                a.pools[1].namespaces.push("a".into());
                encode(&Limits::default(), Some(&a), None).unwrap()
            }
            "unknown_field" => {
                let mut v: serde_json::Value = serde_json::from_str(
                    &encode(&Limits::default(), Some(&allocation()), None).unwrap(),
                )
                .unwrap();
                v["extra"] = true.into();
                v.to_string()
            }
            "changed_limit" => {
                let mut a = allocation();
                a.pools[0].records += 1;
                encode(&Limits::default(), Some(&a), None).unwrap()
            }
            "oversize_ascii" => "x".repeat(ENCODED_BYTES + 1),
            "oversize_utf8" => "é".repeat(ENCODED_BYTES / 2 + 1),
            "embedded_nul" => format!("{{\0{}", "x".repeat(ENCODED_BYTES)),
            _ => unreachable!(),
        };
        store
            .connection
            .execute("UPDATE meta SET limits=?1", [&encoded])
            .unwrap();
        let before = snapshot(&store);
        assert!(
            store
                .inspect_namespaces(
                    &scope,
                    &["a".into()],
                    Instant::now() + Duration::from_secs(1)
                )
                .is_err(),
            "{kind}"
        );
        assert_eq!(snapshot(&store), before);
        drop(store);
        assert!(
            Store::open_allocated(
                dir.path(),
                OpenMode::Existing,
                Limits::default(),
                allocation()
            )
            .is_err(),
            "{kind}"
        );
    }
}

#[test]
fn inspection_is_content_free_and_rejects_unknown_or_overfull_pool() {
    for kind in ["valid", "unknown", "overfull"] {
        let (dir, mut store, scope) = fresh(allocation());
        store
            .commit(
                &scope,
                &batch(vec![write("a", "x", 0, Some("private-canary"))]),
            )
            .unwrap();
        if kind != "valid" {
            let namespace = if kind == "unknown" { "undeclared" } else { "a" };
            for key in ["y", "z"] {
                store
                    .connection
                    .execute(
                        "INSERT INTO records VALUES (?1,?2,1,?3,?4)",
                        params![
                            namespace,
                            key,
                            b"canary",
                            record_digest(namespace, key, 1, Some("canary"))
                        ],
                    )
                    .unwrap();
            }
        }
        let before = snapshot(&store);
        let result = store.inspect_namespaces(
            &scope,
            &["b".into()],
            Instant::now() + Duration::from_secs(1),
        );
        if kind == "valid" {
            assert_eq!(result, Ok(()));
        } else {
            assert!(result.is_err(), "{kind}");
        }
        assert_eq!(snapshot(&store), before);
        drop(store);
        assert_eq!(
            Store::open_allocated(
                dir.path(),
                OpenMode::Existing,
                Limits::default(),
                allocation()
            )
            .is_ok(),
            kind == "valid"
        );
    }
}

#[test]
fn authenticated_publication_and_domain_state_share_atomic_pool_enforcement() {
    let a = Allocation {
        version: 1,
        pools: vec![
            pool("audit", &["heads", "entries"], 2, 32768),
            pool("domain", &["domain"], 1, 4096),
        ],
    };
    let (_dir, mut store, scope) = fresh(a);
    let log = AuthenticatedLog::new(
        &store,
        "heads",
        "entries",
        ChainLimits {
            payload_bytes: 1024,
            records: 100,
            bytes: 65536,
        },
        &[7; 32],
    )
    .unwrap();
    let chain = "a".repeat(64);
    let published = log
        .append(
            &mut store,
            &scope,
            &chain,
            0,
            "first",
            &batch(vec![write("domain", "x", 0, Some("first"))]),
        )
        .unwrap();
    let before = snapshot(&store);
    assert_eq!(
        log.append(
            &mut store,
            &scope,
            &chain,
            published.checkpoint.head_revision,
            "second",
            &batch(vec![write("domain", "x", 1, Some("must roll back"))])
        )
        .err(),
        Some(Error::Limit)
    );
    assert_eq!(snapshot(&store), before);
    assert_eq!(
        log.verify(
            &mut store,
            &scope,
            &chain,
            Some(&published.checkpoint),
            Instant::now() + Duration::from_secs(1)
        )
        .unwrap(),
        published.checkpoint
    );
    // Exhausted audit pool does not block an otherwise valid domain update.
    store
        .commit(
            &scope,
            &batch(vec![write("domain", "x", 1, Some("independent"))]),
        )
        .unwrap();
}
