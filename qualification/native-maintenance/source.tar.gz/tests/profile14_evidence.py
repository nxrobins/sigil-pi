"""Fail-closed external accounting of bounded profile14 qualification."""
from collections import Counter
import hashlib
import json
import math
import statistics


def finite(value, ceiling):
    assert type(value) in (int, float) and math.isfinite(value) and 0 <= value < ceiling


def validate_reports(paths, performance_path, summary_path, raw_path):
    reports = [json.loads(p.read_text()) for p in paths]
    assert len(reports) == 20
    assert Counter(r['expected_profile'] for r in reports) == {14: 16, 13: 4}
    pids = set()
    for report in reports:
        assert report['completed'] is True
        assert report['protocol'] == f"sigil-application-host/v{report['expected_profile']}"
        finite(report['startup_ms'], 35000)
        assert report['pid'] not in pids
        pids.add(report['pid'])
        assert report['requests']
        for row in report['requests']:
            finite(row['elapsed_ms'], 30000)
            assert row['status'] in {200, 202, 401, 404, 501, 503}
    perf = json.loads(performance_path.read_text())
    assert perf['passed'] is True
    assert (perf['completed_turns'], perf['provider_requests'], perf['uninterrupted_turns'],
            perf['continued_after_reopen'], perf['physical_slots'], perf['final_slot_zero_generation']) == (576,576,512,64,128,19)
    assert all(perf[k] is True for k in ['no_state_or_authority_reset','retained_history','all_dedup_keys_replayed'])
    events = perf['handoffs']; assert len(events) == 18
    assert all(e['event'] == 'owner_handoff_complete' for e in events)
    times = [e['elapsed_ms'] for e in events]
    for value in times: finite(value, 20000)
    assert statistics.median(times[:4]) > 0
    ratio = statistics.median(times[-4:]) / statistics.median(times[:4])
    assert ratio <= 1.5 and ratio == perf['last_to_first_handoff_median_ratio']
    long_pids = perf['processes']; assert len(long_pids) == len(set(long_pids)) == 3
    long_reports = [r for r in reports if r['pid'] in long_pids]; assert len(long_reports) == 3
    actual_windows = []
    for window in range(5):
        values = sorted(row['elapsed_ms'] for r in long_reports for row in r['requests'] if row['window'] == str(window))
        assert values
        result = dict(window=window,turns=128 if window < 4 else 64,requests=len(values),
            p95_ms=values[math.ceil(.95*len(values))-1],max_ms=values[-1])
        assert result['p95_ms'] < 2000
        actual_windows.append(result)
    assert perf['windows'] == actual_windows
    summary = json.loads(summary_path.read_text())
    assert summary['stop_reason'] == 'requested' and not summary['coverage_truncated']
    assert summary['valid_process_selection_observed'] and summary['samples'] > 0
    assert summary['observed_host_instances'] == summary['observed_host_identities'] == 20
    assert summary['observed_roles'] == ['evaluator','host','runtime']
    assert not summary['identity_errors'] and not summary['unverified_instances']
    assert hashlib.sha256(raw_path.read_bytes()).hexdigest() == summary['raw_sha256']
    hosts = {r['pid'] for r in summary['executable_receipts'] if r['role']=='host' and r['native_amd64']}
    assert hosts == pids
    finite(summary['peak_sum_rss_kib'], 2097152)
    return dict(opens=len(reports),requests=sum(len(r['requests']) for r in reports),
        max_startup_ms=max(r['startup_ms'] for r in reports),
        max_http_ms=max(row['elapsed_ms'] for r in reports for row in r['requests']),
        performance=perf,process_observation=summary)
