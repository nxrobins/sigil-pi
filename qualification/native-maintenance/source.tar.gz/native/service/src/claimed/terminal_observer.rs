//! Read-only terminal observation independent of a live parent assignment.
//! Both journal facts must match their actual HMAC-verified chain records.
use super::*;
use crate::claimed::terminal_journal;
use sigil_durable_store::store::authenticated_log::AuthenticatedLog;
use sigil_durable_store::store::{Batch, Mutation};

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct DispatchFact {
    format: String,
    claimed_at_unix_ms: u64,
    intent_binding: String,
    assignment_binding: String,
    assignment_origin: String,
    assignment: String,
    claim_sha256: String,
    policy_batch_sha256: String,
    audit_chain: String,
    audit_sequence: u64,
}

/// Native observed records, not an execution, spending or publication grant.
/// Application policy interprets the retained phase/status/output.
pub struct TerminalCompletion {
    witness: Witness,
    journal_namespace: String,
    journal_key: String,
    journal_digest: String,
    terminal_digest: String,
    phase: String,
    status: String,
    output: String,
    claimed_at_unix_ms: u64,
    terminal_at_unix_ms: u64,
    intent_record: Record,
    claim_record: Record,
    delivery_record: Record,
}

// These independent coordinates are all checked against the signed payload.
#[allow(clippy::too_many_arguments)]
fn signed_fact(
    store: &mut Store,
    scope: &Scope,
    log: &AuthenticatedLog,
    chain: &str,
    sequence: u64,
    namespace: &str,
    key: &str,
    raw: &str,
    format: &str,
    deadline: Instant,
) -> Result<serde_json::Value> {
    let (_, payload) = log
        .verified_payload(store, scope, chain, sequence, deadline)
        .map_err(|_| "journal_authentication")?;
    let v: serde_json::Value =
        serde_json::from_str(&payload).map_err(|_| "journal_authentication")?;
    if v["format"] != format
        || v["journal_namespace"] != namespace
        || v["journal_key"] != key
        || v["journal_sha256"] != digest(raw.as_bytes())
    {
        return Err("journal_authentication");
    }
    Ok(v)
}

impl TerminalCompletion {
    #[allow(clippy::too_many_arguments)]
    pub fn observe(
        store: &mut Store,
        scope: &Scope,
        log: &AuthenticatedLog,
        chain: &str,
        namespace: &str,
        key: &str,
        deadline: Instant,
    ) -> Result<Self> {
        crate::digest_bytes(key)?;
        let (domain, _) = store.execution_identity().map_err(|_| "execution_fence")?;
        let domain = domain.to_owned();
        let start = store
            .get(scope, namespace, key)
            .map_err(|_| "dispatch_journal")?;
        let raw = start.value.as_deref().ok_or("dispatch_journal")?;
        if start.revision != 1 || raw.len() > 12_288 {
            return Err("dispatch_journal");
        }
        let fact: DispatchFact = serde_json::from_str(raw).map_err(|_| "dispatch_journal")?;
        if fact.format != "sigil-native-dispatch-start/v1"
            || fact.claimed_at_unix_ms == 0
            || fact.intent_binding != key
            || fact.audit_chain != chain
            || serde_json::to_string(&fact).map_err(|_| "dispatch_journal")? != raw
        {
            return Err("dispatch_journal");
        }
        let envelope = signed_fact(
            store,
            scope,
            log,
            chain,
            fact.audit_sequence,
            namespace,
            key,
            raw,
            "sigil-native-dispatch-audit/v1",
            deadline,
        )?;
        if envelope["policy_batch_sha256"] != fact.policy_batch_sha256 {
            return Err("journal_authentication");
        }
        let witness: Witness =
            serde_json::from_str(&fact.assignment).map_err(|_| "funding_witness")?;
        let owner = witness.execution.as_ref().ok_or("execution_fence")?;
        crate::digest_bytes(&owner.epoch)?;
        if owner.domain != domain
            || !matches!(
                witness.format.as_str(),
                FENCED_FORMAT | RETIREMENT_FORMAT | PARENT_FORMAT | SLOT_FORMAT
            )
            || matches!(witness.format.as_str(), PARENT_FORMAT | SLOT_FORMAT)
                != witness.intent_binding.is_some()
            || (witness.format == SLOT_FORMAT) != store.has_reservation_generations()
            || witness.reservation_generation.is_some() != store.has_reservation_generations()
            || (witness.format == SLOT_FORMAT
                && witness
                    .retirement
                    .as_ref()
                    .is_none_or(|r| r.records == 0 || r.live_bytes == 0))
            || serde_json::to_string(&witness).map_err(|_| "funding_witness")? != fact.assignment
            || assigned(
                crate::digest_bytes(&fact.assignment_origin)?,
                fact.assignment.as_bytes(),
            ) != crate::digest_bytes(&fact.assignment_binding)?
        {
            return Err("funding_witness");
        }
        let intent = store
            .get(scope, &witness.intent_namespace, &witness.key)
            .map_err(|_| "intent")?;
        let value = intent.value.as_deref().ok_or("intent")?;
        if intent.revision != witness.intent_revision
            || digest(value.as_bytes()) != witness.intent_sha256
        {
            return Err("intent");
        }
        let binding = hash(&[
            b"sigil-completion-intent/v1",
            witness.intent_namespace.as_bytes(),
            witness.key.as_bytes(),
            &intent.revision.to_be_bytes(),
            value.as_bytes(),
            witness.claim_namespace.as_bytes(),
            witness.delivery_namespace.as_bytes(),
        ]);
        if binding != crate::digest_bytes(key)?
            || binding
                != crate::digest_bytes(
                    witness
                        .intent_binding
                        .as_deref()
                        .unwrap_or(&fact.assignment_origin),
                )?
        {
            return Err("funding_identity");
        }
        let initial_claim = frame(
            "SD1\n",
            &[
                &witness.intent_namespace,
                &witness.key,
                &intent.revision.to_string(),
                &witness.generation,
                "1",
            ],
        )?;
        if digest(initial_claim.as_bytes()) != fact.claim_sha256 {
            return Err("claim");
        }
        let claim = store
            .get(scope, &witness.claim_namespace, &witness.key)
            .map_err(|_| "claim")?;
        let delivery = store
            .get(scope, &witness.delivery_namespace, &witness.key)
            .map_err(|_| "delivery")?;
        if claim.revision != 2 || delivery.revision != 1 {
            return Err("terminal");
        }
        let sd = fields(claim.value.as_deref().ok_or("claim")?, "SD1\n", 5)?;
        let dr = fields(delivery.value.as_deref().ok_or("delivery")?, "DR1\n", 7)?;
        if dr[..5] != sd
            || sd[..4]
                != [
                    &witness.intent_namespace,
                    &witness.key,
                    &intent.revision.to_string(),
                    &witness.generation,
                ]
            || !matches!(sd[4], "2" | "3" | "4" | "5" | "6")
        {
            return Err("terminal");
        }
        let batch = Batch {
            checks: vec![Check {
                namespace: witness.intent_namespace.clone(),
                key: witness.key.clone(),
                revision: intent.revision,
            }],
            writes: vec![
                Mutation {
                    namespace: witness.claim_namespace.clone(),
                    key: witness.key.clone(),
                    revision: 1,
                    value: claim.value.clone(),
                },
                Mutation {
                    namespace: witness.delivery_namespace.clone(),
                    key: witness.key.clone(),
                    revision: 0,
                    value: delivery.value.clone(),
                },
            ],
        };
        let terminal_key = format!("{key}.terminal");
        let terminal = store
            .get(scope, namespace, &terminal_key)
            .map_err(|_| "terminal_journal")?;
        let terminal_raw = terminal.value.as_deref().ok_or("terminal_journal")?;
        let t: terminal_journal::Fact =
            serde_json::from_str(terminal_raw).map_err(|_| "terminal_journal")?;
        if terminal.revision != 1
            || t.format != "sigil-native-terminal-publication/v1"
            || t.intent_binding != key
            || t.audit_chain != chain
            || t.audit_sequence <= fact.audit_sequence
            || t.observed_at_unix_ms < fact.claimed_at_unix_ms
            || t.terminal_batch_sha256
                != digest(&serde_json::to_vec(&batch).map_err(|_| "terminal_journal")?)
            || serde_json::to_string(&t).map_err(|_| "terminal_journal")? != terminal_raw
        {
            return Err("terminal_journal");
        }
        let terminal_envelope = signed_fact(
            store,
            scope,
            log,
            chain,
            t.audit_sequence,
            namespace,
            &terminal_key,
            terminal_raw,
            "sigil-native-terminal-audit/v1",
            deadline,
        )?;
        let mut related = batch;
        related.writes.push(Mutation {
            namespace: namespace.into(),
            key: terminal_key,
            revision: 0,
            value: Some(terminal_raw.into()),
        });
        if terminal_envelope["related_batch_sha256"]
            != digest(&serde_json::to_vec(&related).map_err(|_| "terminal_journal")?)
            || Instant::now() >= deadline
        {
            return Err("terminal_journal");
        }
        Ok(Self {
            witness,
            journal_namespace: namespace.into(),
            journal_key: key.into(),
            journal_digest: digest(raw.as_bytes()),
            terminal_digest: digest(terminal_raw.as_bytes()),
            phase: sd[4].into(),
            status: dr[5].into(),
            output: dr[6].into(),
            claimed_at_unix_ms: fact.claimed_at_unix_ms,
            terminal_at_unix_ms: t.observed_at_unix_ms,
            intent_record: intent.clone(),
            claim_record: claim.clone(),
            delivery_record: delivery.clone(),
        })
    }

    /// A successor may only consume a prior epoch after the actual store has
    /// acquired its exclusive execution lease. This check grants no I/O.
    pub fn check_prior_owner(&self, store: &Store, scope: &Scope) -> Result<()> {
        let (domain, epoch) = store.execution_identity().map_err(|_| "execution_fence")?;
        let previous = self.witness.execution.as_ref().ok_or("execution_fence")?;
        if previous.domain != domain || previous.epoch == epoch {
            return Err("execution_fence");
        }
        for (namespace, expected) in [
            (&self.witness.intent_namespace, &self.intent_record),
            (&self.witness.claim_namespace, &self.claim_record),
            (&self.witness.delivery_namespace, &self.delivery_record),
        ] {
            if store
                .get(scope, namespace, &self.witness.key)
                .map_err(|_| "terminal")?
                != *expected
            {
                return Err("terminal");
            }
        }
        for (key, expected) in [
            (&self.journal_key, &self.journal_digest),
            (
                &format!("{}.terminal", self.journal_key),
                &self.terminal_digest,
            ),
        ] {
            let r = store
                .get(scope, &self.journal_namespace, key)
                .map_err(|_| "terminal_journal")?;
            if r.revision != 1
                || digest(r.value.as_deref().ok_or("terminal_journal")?.as_bytes()) != *expected
            {
                return Err("terminal_journal");
            }
        }
        Ok(())
    }
    pub fn phase(&self) -> &str {
        &self.phase
    }
    pub fn status(&self) -> &str {
        &self.status
    }
    pub fn output(&self) -> &str {
        &self.output
    }
    pub fn claimed_at_unix_ms(&self) -> u64 {
        self.claimed_at_unix_ms
    }
    pub fn terminal_at_unix_ms(&self) -> u64 {
        self.terminal_at_unix_ms
    }

    /// Native-only projection inputs. No deserialized application record can
    /// construct these facts, and the actual source is rechecked before use.
    pub(in crate::claimed) fn export_facts(
        &self,
        store: &Store,
        scope: &Scope,
        admission: &crate::claimed::export_capacity::Admission,
    ) -> Result<(String, Vec<Check>)> {
        self.check_prior_owner(store, scope)?;
        let previous = self.witness.execution.as_ref().ok_or("execution_fence")?;
        if previous.domain != admission.domain
            || previous.epoch != admission.epoch
            || self.journal_key != admission.intent_binding
            || self.witness.intent_namespace != admission.intent_namespace
            || self.witness.key != admission.intent_key
            || self.witness.intent_revision != admission.intent_revision
            || self.witness.intent_sha256 != admission.intent_sha256
            || self.witness.claim_namespace != admission.claim_namespace
            || self.witness.delivery_namespace != admission.delivery_namespace
            || self.witness.reservation_generation != admission.execution_generation
        {
            return Err("export_source");
        }
        let facts = frame(
            "ET1\n",
            &[
                &self.witness.intent_namespace,
                &self.witness.key,
                &self.witness.intent_revision.to_string(),
                self.intent_record.value.as_deref().ok_or("intent")?,
                &self.journal_key,
                &self.phase,
                &self.status,
                &self.output,
                &self.claimed_at_unix_ms.to_string(),
                &self.terminal_at_unix_ms.to_string(),
                &previous.epoch,
                &self.journal_digest,
                &self.terminal_digest,
            ],
        )?;
        let checks = vec![
            Check {
                namespace: self.witness.intent_namespace.clone(),
                key: self.witness.key.clone(),
                revision: self.intent_record.revision,
            },
            Check {
                namespace: self.witness.claim_namespace.clone(),
                key: self.witness.key.clone(),
                revision: self.claim_record.revision,
            },
            Check {
                namespace: self.witness.delivery_namespace.clone(),
                key: self.witness.key.clone(),
                revision: self.delivery_record.revision,
            },
            Check {
                namespace: self.journal_namespace.clone(),
                key: self.journal_key.clone(),
                revision: 1,
            },
            Check {
                namespace: self.journal_namespace.clone(),
                key: format!("{}.terminal", self.journal_key),
                revision: 1,
            },
        ];
        Ok((facts, checks))
    }
}
