//! Frozen, opaque namespace allocations. SIGIL/its admitted bootstrap chooses
//! membership and allowances; the store only meters and enforces their bounds.
use super::*;

pub const POOLS: usize = 64;
pub const NAMESPACES: usize = 256;
pub const ENCODED_BYTES: usize = 65_536;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Pool {
    pub id: String,
    pub namespaces: Vec<String>,
    pub records: u64,
    pub live_bytes: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Allocation {
    pub version: u32,
    pub pools: Vec<Pool>,
}

impl Store {
    /// Read the actual immutable ceilings of this opened store. This snapshot
    /// cannot change limits, reserve capacity or grant data access.
    pub fn configured_limits(&self) -> Result<Limits> {
        self.verify_process()?;
        self.verify_storage_files()?;
        Ok(self.limits.clone())
    }

    /// Observe immutable membership from this actual opened store. This grants
    /// no read/write scope and does not accept a replacement allocation.
    pub fn same_pool(&self, namespaces: &[&str]) -> Result<()> {
        self.verify_files()?;
        if namespaces.is_empty() || namespaces.len() > 64 {
            return Err(Error::Invalid);
        }
        let allocation = self.allocation.as_ref().ok_or(Error::Invalid)?;
        let pool = allocation
            .pools
            .iter()
            .find(|pool| pool.namespaces.iter().any(|name| name == namespaces[0]))
            .ok_or(Error::Denied)?;
        if namespaces
            .iter()
            .all(|name| pool.namespaces.iter().any(|value| value == name))
        {
            Ok(())
        } else {
            Err(Error::Denied)
        }
    }
}

impl Allocation {
    /// Canonical order does not change membership or numeric allowances. There
    /// is no runtime reallocation, borrowing, tenant lookup or eviction policy.
    pub fn validate(&mut self, limits: &Limits) -> Result<()> {
        limits.validate()?;
        if self.version != 1 || self.pools.is_empty() || self.pools.len() > POOLS {
            return Err(Error::Invalid);
        }
        let mut ids = BTreeSet::new();
        let mut namespaces = BTreeSet::new();
        let mut records = 0u64;
        let mut bytes = 0u64;
        for pool in &mut self.pools {
            if !valid_name(&pool.id, 128)
                || !ids.insert(pool.id.clone())
                || pool.namespaces.is_empty()
                || pool.namespaces.len() > 64
                || pool.records == 0
                || pool.live_bytes == 0
            {
                return Err(Error::Invalid);
            }
            for namespace in &pool.namespaces {
                if !valid_name(namespace, 128) || !namespaces.insert(namespace.clone()) {
                    return Err(Error::Invalid);
                }
            }
            if namespaces.len() > NAMESPACES {
                return Err(Error::Invalid);
            }
            records = records.checked_add(pool.records).ok_or(Error::Invalid)?;
            bytes = bytes.checked_add(pool.live_bytes).ok_or(Error::Invalid)?;
            if records > limits.records || bytes > limits.live_bytes {
                return Err(Error::Invalid);
            }
            pool.namespaces.sort();
        }
        self.pools.sort_by(|a, b| a.id.cmp(&b.id));
        Ok(())
    }

    pub fn covers(&self, namespace: &str) -> bool {
        self.pools
            .iter()
            .any(|pool| pool.namespaces.iter().any(|n| n == namespace))
    }

    pub(super) fn check(&self, connection: &Connection) -> Result<()> {
        let owners: BTreeMap<_, _> = self
            .pools
            .iter()
            .enumerate()
            .flat_map(|(i, pool)| {
                pool.namespaces
                    .iter()
                    .map(move |namespace| (namespace.as_str(), i))
            })
            .collect();
        let mut totals = vec![(0u64, 0u64); self.pools.len()];
        // Same accounting as the global ceiling: UTF-8 value bytes, namespace
        // and key bytes, plus 96 bytes per coordinate INCLUDING tombstones.
        let mut query = connection.prepare(
            "SELECT namespace,count(*),sum(coalesce(length(value),0)+length(namespace)+length(key)+96) FROM records GROUP BY namespace"
        ).map_err(|_| Error::Corrupt)?;
        let mut rows = query.query([]).map_err(|_| Error::Corrupt)?;
        while let Some(row) = rows.next().map_err(|_| Error::Corrupt)? {
            let namespace: String = row.get(0).map_err(|_| Error::Corrupt)?;
            let count: i64 = row.get(1).map_err(|_| Error::Corrupt)?;
            let bytes: i64 = row.get(2).map_err(|_| Error::Corrupt)?;
            let index = *owners.get(namespace.as_str()).ok_or(Error::Corrupt)?;
            if count < 0 || bytes < 0 {
                return Err(Error::Corrupt);
            }
            let total = &mut totals[index];
            total.0 = total.0.checked_add(count as u64).ok_or(Error::Corrupt)?;
            total.1 = total.1.checked_add(bytes as u64).ok_or(Error::Corrupt)?;
            let pool = &self.pools[index];
            if total.0 > pool.records || total.1 > pool.live_bytes {
                return Err(Error::Limit);
            }
        }
        Ok(())
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Stored {
    limits: Limits,
    allocation: Allocation,
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "explicit_admission"
    )]
    admission: Option<[u8; 32]>,
}

fn explicit_admission<'de, D: serde::Deserializer<'de>>(
    input: D,
) -> std::result::Result<Option<[u8; 32]>, D::Error> {
    <[u8; 32]>::deserialize(input).map(Some)
}

pub(super) fn encode(
    limits: &Limits,
    allocation: Option<&Allocation>,
    admission: Option<[u8; 32]>,
) -> Result<String> {
    if allocation.is_none() && admission.is_some() {
        return Err(Error::Invalid);
    }
    let encoded = match allocation {
        None => serde_json::to_string(limits),
        Some(allocation) => serde_json::to_string(&Stored {
            limits: limits.clone(),
            allocation: allocation.clone(),
            admission,
        }),
    }
    .map_err(|_| Error::Invalid)?;
    if encoded.len() > encoded_limit(allocation) {
        return Err(Error::Limit);
    }
    Ok(encoded)
}

pub(super) fn encoded_limit(allocation: Option<&Allocation>) -> usize {
    if allocation.is_some() {
        ENCODED_BYTES
    } else {
        4096
    }
}

pub(super) fn matches(
    encoded: &str,
    limits: &Limits,
    allocation: Option<&Allocation>,
    admission: Option<[u8; 32]>,
) -> Result<bool> {
    if encoded.len() > encoded_limit(allocation) {
        return Err(Error::Corrupt);
    }
    match allocation {
        None => Ok(serde_json::from_str::<Limits>(encoded).map_err(|_| Error::Corrupt)? == *limits),
        Some(expected) => {
            let mut stored: Stored = serde_json::from_str(encoded).map_err(|_| Error::Corrupt)?;
            stored
                .allocation
                .validate(&stored.limits)
                .map_err(|_| Error::Corrupt)?;
            Ok(stored.limits == *limits
                && stored.allocation == *expected
                && stored.admission == admission)
        }
    }
}

#[cfg(test)]
#[path = "capacity_tests.rs"]
mod tests;
