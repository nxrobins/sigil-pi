"""Build-only composition of the fixed SIGIL worker-lifecycle audit policy."""
import hashlib
from pathlib import Path

from scripts.compose_application import ApplicationSource, strip_line_comments
from scripts.compose_transaction_audit import compose_transaction_audit
from scripts.compose_identity import identity_helper

ROOT = Path(__file__).resolve().parent.parent


def compose_effect_audit(repo, stdlib):
    base = compose_transaction_audit(repo, stdlib)
    # Reuse its exact pure record/JSON/audit helpers, never its TA1 entry point.
    marker = "pub fn tool_main("
    if base.text.count(marker) != 1:
        raise ValueError("require exactly one original audit entry")
    prefix = base.text.split(marker)[0]
    if prefix.count("module pi_transaction_audit;") != 1:
        raise ValueError("require the original audit module declaration")
    prefix = prefix.replace("module pi_transaction_audit;", "module pi_effect_audit;")
    path = ROOT / "app/pi/effect_audit.sigil"
    raw = path.read_bytes()
    exclusion = (ROOT / "app/shared/exclusion_facts.sigil").read_bytes()
    identity, identity_inputs = identity_helper(repo, "effect_identity_text")
    text = prefix + identity + strip_line_comments(exclusion.decode(), compact_indent=True) + strip_line_comments(raw.decode(), compact_indent=True)
    if len(text.encode()) > 65536 or text.count(marker) != 1:
        raise ValueError("preserve original compiler source and entry limits")
    inputs = {**base.input_hashes, **identity_inputs,
        "app/shared/exclusion_facts.sigil": hashlib.sha256(exclusion).hexdigest(),
        "app/pi/effect_audit.sigil": hashlib.sha256(raw).hexdigest(),
        "scripts/compose_effect_audit.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    return ApplicationSource(text, inputs, base.stdlib_hash)
