//! Versioned execution windows. Application policy chooses the bounds; this
//! mechanism checks fresh host time at preparation, claim and initiation.
use crate::action::{Guard, admit_time};
use crate::{Result, fields, now};
use std::cell::Cell;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone)]
pub(crate) enum ExecutionGuard {
    Seconds(Guard),
    Milliseconds(MillisecondGuard),
}

#[derive(Debug, Clone)]
pub(crate) struct MillisecondGuard {
    before: u64,
    until: u64,
    // Travels with the attempt, including its owned-thread handoff. Keep the
    // existing host-wide seconds watermark in its original units.
    observed: Cell<Option<u64>>,
}

impl ExecutionGuard {
    pub(crate) fn parse(raw: &str) -> Result<Self> {
        if raw.starts_with("TG1\n") {
            return Guard::parse(raw).map(Self::Seconds);
        }
        let values = fields(raw, "TG2\n", 2)?;
        fn milliseconds(raw: &str) -> Result<u64> {
            if raw.is_empty()
                || raw.len() > 16
                || !raw.bytes().all(|b| b.is_ascii_digit())
                || (raw.len() > 1 && raw.starts_with('0'))
            {
                return Err("protocol");
            }
            let value = raw.parse().map_err(|_| "protocol")?;
            if value > 9_007_199_254_740_991 {
                return Err("protocol");
            }
            Ok(value)
        }
        let before = milliseconds(values[0])?;
        let until = milliseconds(values[1])?;
        if until <= before {
            return Err("protocol");
        }
        Ok(Self::Milliseconds(MillisecondGuard {
            before,
            until,
            observed: Cell::new(None),
        }))
    }

    pub(crate) fn admit(&self, last_seconds: &mut u64, deadline: Instant) -> Result<()> {
        match self {
            Self::Seconds(guard) => admit_time(Some(guard), last_seconds, deadline, now),
            Self::Milliseconds(guard) => guard.admit_with(last_seconds, deadline, || {
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .map_err(|_| "clock")
            }),
        }
    }

    /// Return the exact native clock sample checked against this window, for
    /// retained claim evidence. Sampling twice could put the retained time on
    /// the opposite side of a narrow window from the admission check.
    pub(crate) fn admit_observed_millis(
        &self,
        last_seconds: &mut u64,
        deadline: Instant,
    ) -> Result<u64> {
        self.observe_millis_with(last_seconds, deadline, || {
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map_err(|_| "clock")
        })
    }

    fn observe_millis_with(
        &self,
        last_seconds: &mut u64,
        deadline: Instant,
        observe: impl FnOnce() -> Result<Duration>,
    ) -> Result<u64> {
        if Instant::now() >= deadline {
            return Err("deadline");
        }
        let elapsed = observe()?;
        let at = u64::try_from(elapsed.as_millis()).map_err(|_| "clock")?;
        if at == 0 {
            return Err("clock");
        }
        match self {
            Self::Seconds(guard) => {
                admit_time(
                    Some(guard),
                    last_seconds,
                    deadline,
                    || Ok(elapsed.as_secs()),
                )?
            }
            Self::Milliseconds(guard) => {
                guard.admit_with(last_seconds, deadline, || Ok(elapsed))?
            }
        }
        Ok(at)
    }
}

impl MillisecondGuard {
    fn admit_with(
        &self,
        last_seconds: &mut u64,
        deadline: Instant,
        observe: impl FnOnce() -> Result<Duration>,
    ) -> Result<()> {
        if Instant::now() >= deadline {
            return Err("deadline");
        }
        let elapsed = observe()?;
        let at = u64::try_from(elapsed.as_millis()).map_err(|_| "clock")?;
        if elapsed.as_secs() < *last_seconds
            || self.observed.get().is_some_and(|previous| at < previous)
        {
            return Err("clock");
        }
        *last_seconds = elapsed.as_secs();
        self.observed.set(Some(at));
        if at < self.before || at >= self.until {
            return Err("time_guard");
        }
        // Reading/checking wall time never renews the caller's monotonic budget.
        if Instant::now() >= deadline {
            return Err("deadline");
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests;
