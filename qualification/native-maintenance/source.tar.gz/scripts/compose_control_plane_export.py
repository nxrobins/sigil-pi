"""Build-only composition: one immutable budget/projection policy per admission."""
import hashlib
import json
from pathlib import Path
from scripts.compose_application import ApplicationSource, strip_line_comments
from scripts.sigil_omit import omit_unreferenced_functions
from sigil_compose import compose_with_stdlib

ROOT = Path(__file__).resolve().parent.parent


def compose_control_plane_export(stdlib, bootstrap, *, root=ROOT):
    if not isinstance(bootstrap, str) or not bootstrap.startswith("BO1\n") or len(bootstrap.encode()) > 512:
        raise ValueError("expected bounded first-slice bootstrap")
    inputs = {}

    def read(name):
        raw = (root / name).read_bytes()
        inputs[name] = hashlib.sha256(raw).hexdigest()
        return raw.decode()

    body = read("app/control_plane/export_policy.sigil")
    helpers = read("app/shared/record_helpers.sigil").replace("// UTF8_VALIDATOR", read("app/shared/utf8.sigil"))
    codec = read("app/control_plane/adapter_codec.sigil")
    codec = codec.split("// CP_CODEC_BEGIN")[1].split("// CP_CODEC_END")[0]
    for marker, fragment in {
        "// RECORD_HELPERS": helpers,
        "// CP_CODEC_HELPERS": codec,
        "// CP_BINDING_HELPERS": read("app/control_plane/first_slice_binding.sigil"),
        "// BOOTSTRAP": 'fn export_bootstrap() -> i64 @Internal { return text(' + json.dumps(bootstrap) + '); }',
    }.items():
        if body.count(marker) != 1:
            raise ValueError(f"expected one composition site: {marker}")
        body = body.replace(marker, fragment)
    body = omit_unreferenced_functions(strip_line_comments(body), {
        "quoted": "500bd4ffba8d77a6cee83f5d09ef6249116981ac67f3380890ff2ccf1e0fd598",
    }).text
    body += '\nextern "C" fn crypto_sha256(input: i32 @Internal, input_len: i32 @Internal) -> i64 @Internal ! { FFI, Unsafe };\n'
    composed = compose_with_stdlib(body, [], stdlib)
    text = strip_line_comments(composed.text, compact_indent=True)
    if len(text.encode()) > 65536:
        raise ValueError("export policy exceeds source bound")
    for recipe in ("scripts/compose_control_plane_export.py", "scripts/sigil_omit.py"):
        inputs[recipe] = hashlib.sha256((ROOT / recipe).read_bytes()).hexdigest()
    inputs["bootstrap"] = hashlib.sha256(bootstrap.encode()).hexdigest()
    return ApplicationSource(text, inputs, composed.stdlib_hash)
