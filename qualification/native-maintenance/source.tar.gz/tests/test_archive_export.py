"""Real compiled archive projection. Public API integration is a separate gate."""

import json

import pytest

from conftest import SIGIL_ROOT, forge_ok
from scripts.compose_archive_export import compose_archive_export
from scripts.compose_lifecycle import compose_lifecycle
from scripts.compose_workspace import compose_workspace
from settlement_support import plan as settle, snapshot
from test_history_archive import preceding, plan, row
from turn_support import Decision, FUEL, fields, record, refused, run, tool_reply


@pytest.fixture(scope="module")
def projection():
    return compose_archive_export(SIGIL_ROOT).text


def archive(mcp, phase="done"):
    admission = compose_lifecycle("admission", SIGIL_ROOT).text
    prior = preceding(mcp, admission, phase=phase)
    _, batch, _, _ = plan(mcp, admission, **prior)
    return json.loads(batch)["writes"][-1]["value"]


def request(value, *, tenant="tenant-a", session="same-session", operation="a" * 64,
            revision="1", expected="0", offset="0", limit="20", status="ok"):
    return record("AX1\n", [tenant, session, operation,
        record("SR1\n", [status, revision, value]), expected, offset, limit])


def evaluate(mcp, source, payload):
    kind, raw = fields(forge_ok(mcp, source, payload, fuel=FUEL), "AX2\n", 2)
    return kind, json.loads(raw)


@pytest.mark.parametrize("phase", ["done", "failed", "cancelled", "uncertain"])
def test_projection_preserves_actual_outcome_and_labels_overlapping_context(mcp, projection, phase):
    value = archive(mcp, phase)
    kind, out = evaluate(mcp, projection, request(value))
    assert kind == "ok" and out["operation_result"]["status"] == phase
    assert out["context_snapshot"]["history_kind"] == "operation_context_snapshot"
    assert out["context_snapshot"]["state_revision"] == "9"
    messages = out["context_snapshot"]["messages"]
    assert messages[1]["content"][0]["text"] == "retained reply"
    if phase != "done":
        assert messages[-1]["content"][0]["text"] == f"Previous operation ended with status {phase} and reason interrupted"
    assert out["operation_result"]["usage"]["known"] == (phase != "uncertain")
    for private in ["CF2", "PC1", "PS1", "PT1", "OQ3", "OR1", "read_write", "a.state", "workspace-v1"]:
        assert private not in json.dumps(out)


@pytest.mark.parametrize("change", [{"tenant": "tenant-b"}, {"session": "other"},
                                   {"operation": "b" * 64}, {"revision": "2"}])
def test_cross_bound_or_replaced_archive_is_refused(mcp, projection, change):
    refused(mcp, projection, request(archive(mcp), **change), 409)


def test_pagination_and_absence_are_explicit(mcp, projection):
    value = archive(mcp)
    _, first = evaluate(mcp, projection, request(value, limit="1"))
    assert first["context_snapshot"]["next_offset"] == 1
    _, second = evaluate(mcp, projection, request(value, expected="1", offset="1", limit="1"))
    assert second["context_snapshot"]["next_offset"] is None
    assert evaluate(mcp, projection, request(value, expected="2")) == ("stale", {})
    assert evaluate(mcp, projection, request(value, expected="1", offset="999")) == ("range", {})
    assert evaluate(mcp, projection, request("", revision="0")) == ("missing", {})
    assert evaluate(mcp, projection, request("", revision="0", status="error")) == ("unavailable", {})
    refused(mcp, projection, request(value, offset="1"), 400)


@pytest.mark.parametrize("index,replacement", [(0, "tenant-b"), (1, "other"), (2, "b" * 64), (3, "8")])
def test_forged_inner_coordinate_is_refused(mcp, projection, index, replacement):
    values = fields(archive(mcp), "HA1\n", 6)
    values[index] = replacement
    refused(mcp, projection, request(record("HA1\n", values)), 409)


@pytest.mark.parametrize("kind", ["tenant", "operation", "revision", "phase", "reply", "session", "key"])
def test_operation_and_state_cannot_be_spliced_from_different_turns(mcp, projection, kind):
    values = fields(archive(mcp), "HA1\n", 6)
    op = fields(values[5], "OQ3\n", 13)
    if kind in {"tenant", "operation", "revision", "phase"}:
        index, value = {"tenant": (1, "tenant-b"), "operation": (4, "b" * 64),
                        "revision": (12, "8"), "phase": (9, "failed")}[kind]
        op[index] = value
    elif kind == "reply":
        outcome = fields(op[11], "OR1\n", 8)
        outcome[0] = "unobserved replacement reply"
        op[11] = record("OR1\n", outcome)
    else:
        submitted = fields(op[3], "PS1\n", 3)
        submitted[0 if kind == "session" else 2] = "different"
        op[3] = record("PS1\n", submitted)
    values[5] = record("OQ3\n", op)
    refused(mcp, projection, request(record("HA1\n", values)), 409)


@pytest.mark.parametrize("terminal", ["unknown", "cancelled_unsent", "expired_unsent"])
def test_partial_batch_exports_observed_and_unknown_results_without_rewriting_archive(mcp, projection, terminal):
    admission = compose_lifecycle("admission", SIGIL_ROOT).text
    credential = row()
    _, batch, _, _ = plan(mcp, admission, row=credential)
    writes = json.loads(batch)["writes"]
    intent = fields(writes[3]["value"], "SI1\n", 5)
    started = Decision(writes[2]["value"], intent[2], intent[1], intent[3], intent[4])
    turn = compose_lifecycle("turn", SIGIL_ROOT).text
    pending = run(mcp, turn, started.result(tool_reply("read_file", "read_file", "read_file",
        usage={"input_tokens": 4, "output_tokens": 3})))
    observed = run(mcp, turn, pending.result("exact observed file content"))
    stopped = run(mcp, turn, observed.result(kind=terminal))
    settlement = settle(mcp, compose_workspace("settlement", SIGIL_ROOT).text, credential,
        [snapshot(writes[1]["value"]), snapshot(stopped.state, 9),
         snapshot(writes[5]["value"]), snapshot(writes[4]["value"])])
    outcome = settlement.request["writes"][0]["value"]
    archived = record("HA1\n", ["tenant-a", "same-session", "a" * 64, "9", stopped.state, outcome])
    kind, public = evaluate(mcp, projection, request(archived))
    assert kind == "ok"
    messages = public["context_snapshot"]["messages"]
    calls, results = messages[-3]["content"], messages[-2]["content"]
    assert [c["call_id"] for c in calls] == [r["call_id"] for r in results] == ["tool-0", "tool-1", "tool-2"]
    assert results[0] == {"type": "tool_result", "call_id": "tool-0", "text": "exact observed file content", "is_error": False}
    for result in results[1:]:
        assert result["is_error"] and "No confirmed result" in result["text"] and "may have run" in result["text"]
    assert "status " + stopped.action in messages[-1]["content"][0]["text"]
    assert fields(archived, "HA1\n", 6)[4] == stopped.state
    _, repeated = evaluate(mcp, projection, request(archived))
    assert repeated == public


@pytest.mark.parametrize("tenant", ["Équipe 一 / example.org", "a" * 128])
def test_valid_cf2_tenant_identity_is_accepted_and_still_bound(mcp, projection, tenant):
    values = fields(archive(mcp), "HA1\n", 6)
    values[0] = tenant
    op = fields(values[5], "OQ3\n", 13)
    op[1] = tenant
    values[5] = record("OQ3\n", op)
    value = record("HA1\n", values)
    assert evaluate(mcp, projection, request(value, tenant=tenant))[0] == "ok"
    refused(mcp, projection, request(value), 409)
