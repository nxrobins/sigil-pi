//! Bind actual durable scopes and an opaque allocation to a fixed, grantless
//! SIGIL admission function. No tenant identity or allowance policy is parsed here.
use crate::{CredentialConfig, Limits, Result, automatic, frame};
use serde::{Deserialize, Serialize};
use sigil_durable_store::store::capacity::Allocation;
use std::collections::BTreeSet;

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "explicit_authority"
    )]
    pub restore_authority: Option<std::path::PathBuf>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reservation_slots: Option<std::collections::BTreeMap<String, u16>>,
    pub policy: String,
    pub parameters: String,
    pub allocation: Allocation,
}

fn explicit_authority<'de, D: serde::Deserializer<'de>>(
    input: D,
) -> std::result::Result<Option<std::path::PathBuf>, D::Error> {
    std::path::PathBuf::deserialize(input).map(Some)
}

pub(crate) fn explicit<'de, D: serde::Deserializer<'de>>(
    input: D,
) -> std::result::Result<Option<Config>, D::Error> {
    Config::deserialize(input).map(Some)
}

pub(crate) fn require_profile(version: u32, config: Option<&Config>) -> Result<()> {
    if matches!(version, 10..=13) != config.is_some()
        || matches!(version, 11..=13) != config.is_some_and(|c| c.reservation_slots.is_some())
        || matches!(version, 12 | 13) != config.is_some_and(|c| c.restore_authority.is_some())
    {
        return Err("config");
    }
    Ok(())
}

impl Config {
    pub(crate) fn validate(&mut self, limits: &Limits) -> Result<()> {
        if self
            .restore_authority
            .as_ref()
            .is_some_and(|path| !path.is_absolute())
        {
            return Err("config");
        }
        if self.policy.is_empty()
            || self.policy.len() > 64
            || !self
                .policy
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_')
            || self.parameters.len() > 65_536
        {
            return Err("config");
        }
        self.allocation.validate(limits).map_err(|_| "config")
    }

    /// Facts come from the same immutable configuration used for actual scope
    /// issuance. Automatic::Admitted independently checks delegation and aliases
    /// before this function's result is used to open any durable store.
    pub(crate) fn input(
        &self,
        registry: &str,
        credentials: &[CredentialConfig],
        automatic: &automatic::Config,
        limits: &Limits,
    ) -> Result<String> {
        if credentials.is_empty()
            || credentials.len() > 64
            || automatic.participants.len() != credentials.len()
        {
            return Err("config");
        }
        let mut namespaces = Vec::new();
        for credential in credentials {
            let matches: Vec<_> = automatic
                .participants
                .iter()
                .filter(|p| p.credential_sha256 == credential.sha256)
                .collect();
            if matches.len() != 1 {
                return Err("config");
            }
            let participant = matches[0];
            let mut names: BTreeSet<_> = credential.grants.keys().cloned().collect();
            names.extend(participant.read_grants.keys().cloned());
            names.extend([
                participant.claim_namespace.clone(),
                participant.delivery_namespace.clone(),
            ]);
            names.extend(participant.dispatch_journal.iter().cloned());
            for effect in participant.effects.values() {
                names.extend(effect.grants.keys().cloned());
                names.extend(effect.policy.read_grants.keys().cloned());
                names.insert(effect.policy.claim_namespace.clone());
                names.insert(effect.recorder.delivery_namespace.clone());
            }
            for transaction in participant.transactions.values() {
                names.extend(transaction.grants.keys().cloned());
            }
            for audit in [&participant.transaction_audit, &participant.effect_audit]
                .into_iter()
                .flatten()
            {
                names.extend([audit.heads.clone(), audit.records.clone()]);
            }
            if names.len() > 64 || names.iter().any(|n| !self.allocation.covers(n)) {
                return Err("config");
            }
            namespaces.push(serde_json::to_string(&names).map_err(|_| "config")?);
        }
        let pools = self
            .allocation
            .pools
            .iter()
            .map(|pool| {
                frame(
                    "SP1\n",
                    &[
                        &pool.id,
                        &serde_json::to_string(&pool.namespaces).map_err(|_| "config")?,
                        &pool.records.to_string(),
                        &pool.live_bytes.to_string(),
                    ],
                )
            })
            .collect::<Result<Vec<_>>>()?;
        frame(
            "SA1\n",
            &[
                registry,
                &serde_json::to_string(&namespaces).map_err(|_| "config")?,
                &serde_json::to_string(&pools).map_err(|_| "config")?,
                &limits.records.to_string(),
                &limits.live_bytes.to_string(),
                &self.parameters,
            ],
        )
    }

    pub(crate) fn manifest(&self) -> Result<serde_json::Value> {
        Ok(serde_json::json!({
            "contract":"sigil-storage-admission/v1", "input":"SA1", "pool":"SP1",
            "result":"storage_validated", "database_schema":if self.restore_authority.is_some() {7} else if self.reservation_slots.is_some() {6} else {2},
            "config":serde_json::to_value(self).map_err(|_| "config")?,
            "scope_facts":"actual-configured-durable-namespaces-per-credential",
            "namespace_membership":"disjoint-immutable", "borrow":false,
            "accounting":"record-count-including-tombstones;value-and-coordinate-bytes-plus-96",
            "physical_reservation":false, "migration":false
            ,"persistent_admission":"sha256-domain-separated-length-framed-bundle-and-SA1/v1"
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn config(slots: bool, authority: Option<&str>) -> Config {
        let mut value = serde_json::json!({"policy":"storage", "parameters":"", "allocation":{
            "version":1,"pools":[{"id":"a","namespaces":["a"],"records":128,"live_bytes":1000000}]
        }});
        if slots {
            value["reservation_slots"] = serde_json::json!({"a":8});
        }
        if let Some(path) = authority {
            value["restore_authority"] = serde_json::json!(path);
        }
        serde_json::from_value(value).unwrap()
    }
    #[test]
    fn independent_authority_requires_explicit_new_profile_and_absolute_path() {
        for version in 0..=13 {
            assert_eq!(
                require_profile(version, Some(&config(true, Some("/private/authority")))).is_ok(),
                matches!(version, 12 | 13)
            );
            assert_eq!(
                require_profile(version, Some(&config(true, None))).is_ok(),
                version == 11
            );
            assert_eq!(
                require_profile(version, Some(&config(false, None))).is_ok(),
                version == 10
            );
            assert!(
                require_profile(version, Some(&config(false, Some("/private/authority")))).is_err()
            );
        }
        assert!(
            config(true, Some("relative"))
                .validate(&Limits::default())
                .is_err()
        );
        assert_eq!(
            config(true, Some("/private/authority")).manifest().unwrap()["database_schema"],
            7
        );
        assert_eq!(config(true, None).manifest().unwrap()["database_schema"], 6);
        let mut value = serde_json::to_value(config(true, None)).unwrap();
        value["restore_authority"] = serde_json::Value::Null;
        assert!(serde_json::from_value::<Config>(value).is_err());
    }
}
