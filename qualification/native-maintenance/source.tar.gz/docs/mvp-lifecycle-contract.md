# Conversation lifecycle contract, revision 2

Engineering contract established 2026-11-07. This document freezes the intended
behavior for the remaining lifecycle work; it is not evidence that the features
or M0–M8 are complete. The dependency graph is `config/mvp-work-graph.json` and
its validator is `scripts/mvp_work_graph.py`. Existing gate thresholds in
`docs/mvp-goal.md` remain authoritative.

## Preservation and context

The explicit `conversation_lifecycle: archive-v1` development profile requires
funded admission and a new, empty deployment. Existing configurations retain
their composed programs and contracts; no existing state is adopted or migrated.
Native schema 6 and the generic atomic reserve/commit mechanism are unchanged.

Before replacing a settled current conversation state, SIGIL writes an immutable
HA1 archive in the same transaction as the new admission. HA1 contains tenant,
session, operation, terminal state revision, exact terminal PT1 state and exact
settled OQ3 result. The namespace is the authenticated state namespace followed
by `.archive`; the key is `session:operation`. Session identifiers cannot contain
a colon. The archive namespace is separately granted to the API credential and
included in that tenant's storage pool, never an effect worker's grants. Archive
records cannot appear as conversations in session discovery.

The new admission checks the actual current state revision and the prior
operation's settled revision. Archive creation requires revision zero: existing
bytes are never overwritten. Denial, quota exhaustion, stale state, an existing
archive or a failed transaction publishes none of the new admission. A retry
with the original submission key follows existing deduplication. Terminal
failed/cancelled/uncertain state is preserved exactly, without manufacturing a
successful tool observation or re-dispatching an old effect.

The current turn remains in PT1 until the next accepted admission; therefore
complete conversation history consists of archives plus current state. Archives
may contain overlapping context: export must identify operations and boundaries,
not concatenate snapshots as if every repeated message were new. Raw PT1/OQ3
configuration and authority facts are internal and must be projected before any
public export. Reads must bind authenticated tenant, requested session/operation
and actual revisions. Model output supplies neither authority nor archive facts.

The initial archive slice does not truncate context. A subsequent explicit
context-window version must preserve complete model tool-call/result groups,
mark reductions to the user and model, provide bounded retrieval of older turns,
and preserve uncertainty notices. It must reset per-turn baseline authority.
Acknowledged history may leave model context only after durable preservation.
Archive expiry follows the approved retention policy, never memory pressure.

## Identity retirement, deletion and retention

Closed reservation rows and deduplication, claim and delivery records are causal
fences. They are not disposable merely because their capacity counters are zero.
Reclamation requires a versioned protocol: atomic revision-bound retirement,
proof no execution still owns the identity, rejection of stale handles and late
results, and a fence surviving restoration of older application data. Native
code provides the generic atomic/owner-fencing primitives; SIGIL decides when an
application operation is eligible. No automatic retry of a possibly delivered
effect is permitted after deletion, expiry, restore or process death.

Deletion must refuse active work or record a resumable deletion request until
execution is safely retired. It must specify which transcript, operation,
audit and backup data remains and when it expires. User-visible deletion is
complete only when those promises and accounting match observed storage.
Retention maintenance is bounded, idempotent and observable; it cannot consume
another tenant's allowance or erase an uncertain operation's execution fence.
Schedules use stable firing identities, recheck current authority/expiry/quotas
at dispatch, and never replay an uncertain firing after restart.

## Supported surface and qualification profile

The complete route inventory remains `config/api-migration.json`: all eleven
legacy routes plus operation creation/status/cancellation, session discovery
and messages, plus additive archived-operation discovery and snapshot access at
`GET /v1/sessions/{session}/archives`. The latter does not replace the legacy
session export's conversation, files, schedules and audit contract. This is a
promise to implement and qualify the inventory, not a
claim that currently unsupported routes work. Browser and API use one SIGIL
application. Runtime mechanisms must remain usable by the control-plane consumer.

The target release is Linux x86_64, one owner/worker, local POSIX storage and at
least two isolated tenant pools. Current macOS arm64 development and Linux arm64
command-container results do not qualify that target. The local-only model
selection is `sigil-pi-flint-temp0-20261028:latest`, digest
`22bba062e8fc561f179553c482c5b755f5bc3159b11f8061b6967c974367090b`;
no paid provider is implied. `SIGIL_REV` plus the identified development runtime
patch must be reconciled with release provenance, not silently substituted.

The current development envelope is at most 20 model responses, four tools per
response, 128 KiB model history, 64 KiB retained native observations, 300 seconds
per operation, 10,000 data records/512 MiB per tenant, 10,000 entries/16 MiB per
audit chain and 128 retained reservation identities. These are measured bounds,
not an approved long-lived pilot retention policy. The retirement work must
prove more than 128 sequential operations without resetting the deployment.

Product-owner decisions still needed before freezing the release candidate:
actual pilot host/access and named operators; archive/audit/backup retention and
deletion periods; tenant quotas and supported command images on Linux x86_64;
final benchmark task set/rubric and approval of the complete route/profile
contract. Independent onboarding requires two actual non-implementers. These
dependencies do not stop unrelated engineering or authorize external deployment.
