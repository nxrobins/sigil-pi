"""Explicit grantless cancellation extraction; original generation recipe retained."""
import hashlib
import json
from pathlib import Path

from scripts.compose_application import ApplicationSource
from scripts.compose_bootstrap_admission import compact
from scripts.compose_generation_api import compose_generation_api
from scripts.sigil_omit import _functions, _tokens, omit_unreferenced_functions

ROOT = Path(__file__).resolve().parent.parent


def compose_modular_cancel(stdlib):
    base = compose_generation_api(stdlib)
    pins_path = ROOT / 'scripts/modular_cancel_omissions.json'
    pins = json.loads(pins_path.read_text())
    if base.compiler_input_sha256 != pins['base_sha256']:
        raise ValueError('reviewed cancellation baseline changed')
    inputs = dict(base.input_hashes)

    def read(relative):
        raw = (ROOT / relative).read_bytes()
        inputs[relative] = hashlib.sha256(raw).hexdigest()
        return compact(raw.decode())

    helper_entry = read('app/pi/cancel_decision_entry.sigil')
    call = read('app/pi/cancel_decision_call.sigil')
    inputs['scripts/modular_cancel_omissions.json'] = hashlib.sha256(pins_path.read_bytes()).hexdigest()
    inputs['scripts/compose_modular_cancel.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    start, end, public = _functions(_tokens(base.text))['tool_main']
    assert public
    helper = base.text[:start] + helper_entry + base.text[end:]
    helper = omit_unreferenced_functions(helper, pins['helper']).text
    body = base.text

    def replace(old, new):
        nonlocal body
        if body.count(old) != 1:
            raise ValueError('reviewed cancellation composition site changed: ' + old)
        body = body.replace(old, new)

    replace('arr_len(get(x,10))!= 6', 'arr_len(get(x,10))!= 7')
    for index, name in [(5, 'storage'), (4, 'listing'), (3, 'history'), (2, 'generation_admission')]:
        replace(f'item(get(x,10),{index}),"{name}"', f'item(get(x,10),{index+1}),"{name}"')
    replace('!is_text(item(get(x,10),1),"archive_export")',
            '!is_text(item(get(x,10),1),"archive_export")|| !is_text(item(get(x,10),2),"cancel_core")')
    replace('let raw: i64 @Internal = cancel_base(x,c,operation);', call)
    replace('if !is_text(get(action,0),"spend"){return raw;}',
            'if !is_text(get(action,0),"spend"){if !is_text(get(action,0),"read")&& !is_text(get(action,0),"reply"){return -409;}return raw;}')
    body = omit_unreferenced_functions(body, pins['entry']).text
    result = {}
    for name, source in [('api_discovery', body), ('cancel_core', helper)]:
        source = compact(source)
        if len(source.encode()) > 65536 or source.count('pub fn tool_main(') != 1:
            raise ValueError('modular cancellation exceeds unchanged source/entry limits')
        result[name] = ApplicationSource(source, dict(inputs), base.stdlib_hash)
    return result
