//! Fixed-inode replicated authority. The embedding must supply actual consistent
//! store roots and execution exclusion; this module never declares effects safe.
use super::{FRAME_BYTES, Failure, Frame, Kind, Root, reconcile, select};
use sha2::{Digest, Sha256};
use std::fs::{self, File, Metadata, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt};
use std::path::{Path, PathBuf};

const LOCK_HEADER: &[u8; 16] = b"SIGIL_ANCHOR_L1\0";
const NAMES: [&str; 3] = ["restore.lock", "anchor.0", "anchor.1"];

#[derive(Clone, Copy)]
pub(in crate::store) enum Mode {
    CreateNew,
    Existing,
}

/// A private attempt token, not serializable or cloneable.
pub(in crate::store) struct Prepared {
    boot: Root,
    digest: Root,
}

pub(in crate::store) struct Anchor {
    root: PathBuf,
    directory: File,
    lock: File,
    slots: [File; 2],
    lock_content: [u8; 48],
    process: u32,
    boot: Root,
    lineage: Root,
    confirmed: Frame,
    pending: Option<Frame>,
    poisoned: bool,
}

pub(in crate::store) fn cut(_name: &str) {
    #[cfg(test)]
    if std::env::var("SIGIL_TEST_ANCHOR_CUT").ok().as_deref() == Some(_name) {
        // A real abrupt process death: no Rust destructors or buffered cleanup.
        if unsafe { libc::kill(libc::getpid(), libc::SIGKILL) } != 0 {
            std::process::abort();
        }
        // Signal delivery can be asynchronous even to this process. Do not
        // race SIGKILL with a different terminating signal or normal exit.
        loop {
            unsafe { libc::pause() };
        }
    }
}

fn random() -> Result<Root, Failure> {
    let mut value = [0; 32];
    File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut value))
        .map_err(|_| Failure::Io)?;
    Ok(value)
}

fn open_file(directory: &File, root: &Path, name: &str, mode: Mode) -> Result<File, Failure> {
    let name_c = std::ffi::CString::new(name).map_err(|_| Failure::Denied)?;
    let flags = libc::O_RDWR
        | libc::O_NOFOLLOW
        | libc::O_CLOEXEC
        | libc::O_NONBLOCK
        | if matches!(mode, Mode::CreateNew) {
            libc::O_CREAT | libc::O_EXCL
        } else {
            0
        };
    // Resolve children against the admitted directory inode, never a mutable
    // parent pathname. The pathname must still name that same inode on return.
    let fd = unsafe { libc::openat(directory.as_raw_fd(), name_c.as_ptr(), flags, 0o600) };
    if fd < 0 {
        return Err(Failure::Io);
    }
    let file = unsafe { File::from_raw_fd(fd) };
    let meta = file.metadata().map_err(|_| Failure::Io)?;
    if !private(&file, &meta, false)
        || meta.nlink() != 1
        || !same(
            &meta,
            &fs::symlink_metadata(root.join(name)).map_err(|_| Failure::Io)?,
        )
    {
        return Err(Failure::Denied);
    }
    Ok(file)
}

fn write_frame(file: &File, frame: &Frame, stage: &str) -> Result<(), Failure> {
    #[cfg(test)]
    if std::env::var("SIGIL_TEST_ANCHOR_IO").ok().as_deref()
        == Some(&format!("partial_{stage}_write"))
    {
        file.write_all_at(&frame.encode()?[..123], 0)
            .map_err(|_| Failure::Io)?;
        return Err(Failure::Io);
    }
    cut(&format!("before_{stage}_write"));
    file.write_all_at(&frame.encode()?, 0)
        .map_err(|_| Failure::Io)?;
    cut(&format!("after_{stage}_write"));
    #[cfg(test)]
    if std::env::var("SIGIL_TEST_ANCHOR_IO").ok().as_deref()
        == Some(&format!("after_{stage}_write"))
    {
        return Err(Failure::Io);
    }
    file.sync_all().map_err(|_| Failure::Io)?;
    cut(&format!("after_{stage}_sync"));
    #[cfg(test)]
    if std::env::var("SIGIL_TEST_ANCHOR_IO").ok().as_deref() == Some(&format!("after_{stage}_sync"))
    {
        return Err(Failure::Io);
    }
    Ok(())
}

impl Anchor {
    pub(in crate::store) fn open(
        root: &Path,
        mode: Mode,
        context: Root,
        observed: Root,
    ) -> Result<Self, Failure> {
        if !root.is_absolute() || root.canonicalize().map_err(|_| Failure::Denied)? != root {
            return Err(Failure::Denied);
        }
        let directory = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(root)
            .map_err(|_| Failure::Denied)?;
        let dm = directory.metadata().map_err(|_| Failure::Io)?;
        if !private(&directory, &dm, true)
            || !same(&dm, &fs::symlink_metadata(root).map_err(|_| Failure::Io)?)
        {
            return Err(Failure::Denied);
        }
        if matches!(mode, Mode::CreateNew)
            && fs::read_dir(root)
                .map_err(|_| Failure::Io)?
                .next()
                .is_some()
        {
            return Err(Failure::Denied);
        }
        let mut lock = open_file(&directory, root, NAMES[0], mode)?;
        lock.try_lock().map_err(|_| Failure::Busy)?;
        let mut lock_content = [0; 48];
        if matches!(mode, Mode::CreateNew) {
            lock_content[..16].copy_from_slice(LOCK_HEADER);
            lock_content[16..].copy_from_slice(&random()?);
            lock.write_all(&lock_content).map_err(|_| Failure::Io)?;
            lock.sync_all().map_err(|_| Failure::Io)?;
        } else {
            if lock.metadata().map_err(|_| Failure::Io)?.len() != 48 {
                return Err(Failure::Corrupt);
            }
            lock.read_exact_at(&mut lock_content, 0)
                .map_err(|_| Failure::Io)?;
            if &lock_content[..16] != LOCK_HEADER {
                return Err(Failure::Corrupt);
            }
        }
        let slots = [
            open_file(&directory, root, NAMES[1], mode)?,
            open_file(&directory, root, NAMES[2], mode)?,
        ];
        let mut hash = Sha256::new();
        hash.update(b"sigil-independent-state-authority/v1\0");
        hash.update(context);
        hash.update(lock_content);
        for file in [&directory, &lock, &slots[0], &slots[1]] {
            let meta = file.metadata().map_err(|_| Failure::Io)?;
            hash.update(meta.dev().to_be_bytes());
            hash.update(meta.ino().to_be_bytes());
        }
        let lineage: Root = hash.finalize().into();
        let initial = Frame::initial(lineage, observed);
        if matches!(mode, Mode::CreateNew) {
            write_frame(&slots[0], &initial, "initial_first")?;
            write_frame(&slots[1], &initial, "initial_mirror")?;
            directory.sync_all().map_err(|_| Failure::Io)?;
        }
        let mut anchor = Self {
            root: root.to_owned(),
            directory,
            lock,
            slots,
            lock_content,
            process: std::process::id(),
            boot: random()?,
            lineage,
            confirmed: initial,
            pending: None,
            poisoned: false,
        };
        anchor.check_files()?;
        let values = anchor.read_slots()?;
        let selected = select(&values)?;
        let resolution = reconcile(&values, observed)?;
        // Never overwrite the only surviving authoritative record first.
        if values[selected]
            .as_ref()
            .is_some_and(|f| f.kind == Kind::Prepared)
        {
            anchor.write(1 - selected, &resolution, "recovery_resolution")?;
            anchor.write(selected, &resolution, "recovery_mirror")?;
        } else if values[1 - selected].as_ref() != Some(&resolution) {
            anchor.write(1 - selected, &resolution, "recovery_repair")?;
        }
        anchor.confirmed = resolution;
        anchor.check_expected()?;
        Ok(anchor)
    }

    fn check_files(&self) -> Result<(), Failure> {
        if self.poisoned {
            return Err(Failure::ReopenRequired);
        }
        if self.process != std::process::id() {
            return Err(Failure::Denied);
        }
        let dm = self.directory.metadata().map_err(|_| Failure::Io)?;
        if !private(&self.directory, &dm, true)
            || !same(
                &dm,
                &fs::symlink_metadata(&self.root).map_err(|_| Failure::Io)?,
            )
        {
            return Err(Failure::Denied);
        }
        for (index, file) in [&self.lock, &self.slots[0], &self.slots[1]]
            .into_iter()
            .enumerate()
        {
            let meta = file.metadata().map_err(|_| Failure::Io)?;
            if !private(file, &meta, false)
                || meta.nlink() != 1
                || meta.len() != if index == 0 { 48 } else { FRAME_BYTES as u64 }
                || !same(
                    &meta,
                    &fs::symlink_metadata(self.root.join(NAMES[index])).map_err(|_| Failure::Io)?,
                )
            {
                return Err(Failure::Denied);
            }
        }
        let mut bytes = [0; 48];
        self.lock
            .read_exact_at(&mut bytes, 0)
            .map_err(|_| Failure::Io)?;
        if bytes != self.lock_content {
            return Err(Failure::Denied);
        }
        Ok(())
    }

    fn read_slots(&self) -> Result<[Option<Frame>; 2], Failure> {
        let mut result = [None, None];
        for (index, file) in self.slots.iter().enumerate() {
            let mut bytes = [0; FRAME_BYTES];
            file.read_exact_at(&mut bytes, 0).map_err(|_| Failure::Io)?;
            result[index] = match Frame::decode(&bytes, self.lineage) {
                Ok(frame) => Some(frame),
                Err(Failure::Corrupt) => None,
                Err(error) => return Err(error),
            };
        }
        Ok(result)
    }

    fn check_expected(&self) -> Result<(), Failure> {
        self.check_files()?;
        let expected = [
            Some(self.pending.as_ref().unwrap_or(&self.confirmed).clone()),
            Some(self.confirmed.clone()),
        ];
        if self.read_slots()? != expected {
            return Err(Failure::Conflict);
        }
        Ok(())
    }

    fn write(&mut self, index: usize, frame: &Frame, stage: &str) -> Result<(), Failure> {
        if let Err(error) = write_frame(&self.slots[index], frame, stage) {
            self.poisoned = true;
            return Err(error);
        }
        Ok(())
    }

    pub(in crate::store) fn check(&self, actual: Root) -> Result<(), Failure> {
        self.check_expected()?;
        if self.pending.is_some() || self.confirmed.root != actual {
            return Err(Failure::RootMismatch);
        }
        Ok(())
    }

    pub(in crate::store) fn prepare(
        &mut self,
        actual: Root,
        proposed: Root,
    ) -> Result<Prepared, Failure> {
        self.check_expected()?;
        if self.pending.is_some() || actual != self.confirmed.root {
            return Err(Failure::Conflict);
        }
        let frame = self.confirmed.prepare(proposed)?;
        self.write(0, &frame, "prepared")?;
        let ticket = Prepared {
            boot: self.boot,
            digest: frame.digest(),
        };
        self.pending = Some(frame);
        Ok(ticket)
    }

    pub(in crate::store) fn confirm(
        &mut self,
        ticket: Prepared,
        actual: Root,
    ) -> Result<(), Failure> {
        self.check_expected()?;
        let pending = self.pending.as_ref().ok_or(Failure::Conflict)?;
        if ticket.boot != self.boot || ticket.digest != pending.digest() {
            return Err(Failure::Conflict);
        }
        if actual != pending.root {
            self.poisoned = true;
            return Err(Failure::RootMismatch);
        }
        let confirmed = pending.resolve(actual)?;
        self.write(1, &confirmed, "confirmed_first")?;
        self.write(0, &confirmed, "confirmed_mirror")?;
        self.confirmed = confirmed;
        self.pending = None;
        self.check_expected()?;
        Ok(())
    }

    #[cfg(test)]
    pub(super) fn issued(&self) -> u64 {
        self.confirmed.issued
    }
}

fn same(a: &Metadata, b: &Metadata) -> bool {
    a.dev() == b.dev() && a.ino() == b.ino()
}
fn private(file: &File, meta: &Metadata, directory: bool) -> bool {
    // SAFETY: geteuid takes no memory or caller-controlled arguments.
    meta.uid() == unsafe { libc::geteuid() }
        && meta.mode() & 0o077 == 0
        && no_extended_acl(file)
        && if directory {
            meta.is_dir()
        } else {
            meta.is_file()
        }
}

// macOS ACL allows are independent of Unix mode bits, and inheritable entries
// can reach a newly created 0600 file. Inspect the actual descriptor, never a
// second pathname. This deliberately rejects even restrictive extended ACLs.
#[cfg(target_os = "macos")]
fn no_extended_acl(file: &File) -> bool {
    use libc::{c_int, c_void};
    unsafe extern "C" {
        fn acl_get_fd_np(fd: c_int, kind: c_int) -> *mut c_void;
        fn acl_valid(acl: *mut c_void) -> c_int;
        fn acl_get_entry(acl: *mut c_void, entry_id: c_int, entry: *mut *mut c_void) -> c_int;
        fn acl_free(acl: *mut c_void) -> c_int;
    }
    // SAFETY: the fd is live; ACL_TYPE_EXTENDED=0x100 and ACL_FIRST_ENTRY=0
    // follow the macOS SDK sys/acl.h ABI. The returned allocation is released
    // exactly once; the entry pointer is borrowed and never dereferenced.
    unsafe {
        let acl = acl_get_fd_np(file.as_raw_fd(), 0x100);
        if acl.is_null() {
            // macOS reports an absent extended ACL as ENOENT even though this
            // is an open descriptor. Other failures cannot establish privacy.
            return std::io::Error::last_os_error().raw_os_error() == Some(libc::ENOENT);
        }
        let mut entry = std::ptr::null_mut();
        let empty = acl_valid(acl) == 0
            && acl_get_entry(acl, 0, &mut entry) == -1
            && std::io::Error::last_os_error().raw_os_error() == Some(libc::EINVAL);
        let released = acl_free(acl) == 0;
        empty && released
    }
}

#[cfg(target_os = "linux")]
fn no_extended_acl(file: &File) -> bool {
    [c"system.posix_acl_access", c"system.posix_acl_default"]
        .into_iter()
        .all(|name| {
            // SAFETY: a live fd, static NUL-terminated name, and a null/zero
            // buffer request only the xattr size; no caller memory is written.
            let size = unsafe {
                libc::fgetxattr(file.as_raw_fd(), name.as_ptr(), std::ptr::null_mut(), 0)
            };
            size < 0
                && matches!(
                    std::io::Error::last_os_error().raw_os_error(),
                    Some(libc::ENODATA | libc::ENOTSUP)
                )
        })
}

#[cfg(not(any(target_os = "macos", target_os = "linux")))]
fn no_extended_acl(_: &File) -> bool {
    false
}
