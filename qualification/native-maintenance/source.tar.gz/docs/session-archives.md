# Archived conversation access

Development profile: `config/public-archives-development.json`. The builder is
`scripts/build_archive_export_deployment.py`; it accepts workspace, empty output
directory, pinned runtime/evaluator, stdlib root and a bearer-token environment
variable. Start the emitted service using the normal native host. Python assembles
the deployment; SIGIL implements the authenticated routes and projections.

This profile requires fresh v11/schema-6 state and the existing `archive-v1`
admission policy. It adds `GET /v1/sessions/{session}/archives` under current
`sessions:read` authority. The original archive-only profile and legacy `/export`
route retain their existing behavior. The legacy export's conversation, file,
schedule and audit compatibility requirements remain in the MVP migration gate.

The archive index returns the current state revision, a bounded lexical page of
archived operation identities, and links to the current messages and operation
result. Current-message links include their exact state revision. Archived
operations are ordered by operation ID, not time. `limit` defaults to 20 and has
a maximum of 50. Continue with `after=<operation>&revision=<state_revision>`;
if a new turn or state transition changes the collection boundary, the API
returns `409 history_changed`. A full last page can require one final empty page.

Select an immutable archived operation with
`?operation=<operation_id>`. The response contains its public terminal outcome
and an explicitly labeled `operation_context_snapshot`. Request subsequent
message pages with `revision=1&offset=<next_offset>` and the same operation ID.
Offsets cannot exceed 10,000; message limits are 1 through 50. Missing archives
return 404; stale archive revisions return 409. Empty, duplicate, unknown,
noncanonical or incompatible query fields return 400. Each read remains scoped
to the authenticated tenant, and wrong-tenant lookups reveal no archive data.

Context snapshots can overlap: they preserve what the model had for a particular
operation. Clients must retain operation boundaries and must not concatenate
snapshots as new messages. Tool requests are labeled as model requests. Terminal
projection includes observed partial-batch results and explicitly unknown
results for unfinished calls. Proposals in an output-limited model response are
labeled not executed because SIGIL refused them before dispatch. These terminal
annotations are derived at read time; the exact archived PT1 is never rewritten.
Cancelled, failed and uncertain outcomes retain
their actual status and known/unknown usage. Internal configuration, credential
facts, grants and submission keys are not part of the public projection.
Tenant names use the existing CF2 credential grammar, including Unicode and
punctuation; audit admission uses those same identity rules. Namespace names
retain their separate restricted grammar.

Reading the index or a snapshot creates no persistent data and triggers no model
or tool. Existing archive records are immutable. Expiry/deletion must introduce
an explicit collection-revision protocol before changing these pagination
guarantees. Complete retained history, archive retrieval, context reduction and
legacy export parity remain separate engineering and qualification obligations.

Fresh public-archive deployments use the same terminal-history projection for
`/messages` and archived snapshots. A cancelled or failed current turn therefore
shows retained tool observations immediately, before any follow-up. Unconfirmed
calls remain explicitly uncertain; output-limit proposals refused before dispatch
are marked not executed. Active turns retain pending calls without a synthetic
terminal result. This is a read-only view: PT1 and its revision are unchanged, and
all pages continue to require the same current-state revision.
