//! Pending-claim publication using the original reserved allowance. Actual
//! prior-owner exclusion permits local capacity reuse; SIGIL still interprets
//! the truthful abandoned observation. This never invokes the old effect.
use super::*;
use sigil_durable_store::store::reservation::Held;

pub struct FundedRecovery {
    pub recovered: Recovered,
    returned_credit: Option<Held>,
}
impl FundedRecovery {
    pub fn take_returned_credit(&mut self) -> Option<Held> {
        self.returned_credit.take()
    }
}
impl Recorder {
    /// Trusted embedding lookup within an existing scope, not public-request
    /// authority. Accepts no cleanup boolean, observation, epoch or replacement
    /// lease. Actual store acquisition and retained assignment supply them.
    pub fn recover_funded_pending(
        &mut self,
        store: &mut Store,
        scope: &Scope,
        reservation_namespace: &str,
        reservation_key: &str,
    ) -> Result<FundedRecovery> {
        if !store.has_execution_fence() {
            return Err("execution_fence");
        }
        if self.audit.is_none() {
            return Err("funding_audit");
        }
        let retained =
            AssignedCompletion::observe(store, scope, reservation_namespace, reservation_key)?;
        let mut pending = retained.pending_recovery(store, scope)?;
        pending.funding.check_delivery(&self.delivery_namespace)?;
        let deadline = self.deadline();
        let claim = store
            .get(scope, &pending.claim_namespace, &pending.intent.key)
            .map_err(|_| "storage")?;
        if !store
            .unused_create_slot(scope, &self.delivery_namespace, &pending.intent.key)
            .map_err(|_| "storage")?
        {
            return Err("delivery");
        }
        let recovery_generation = identity()?;
        // This owner did not reap the former process and knows no remote result.
        // Reuse the existing conservative SIGIL observation, retaining may-have-run.
        let facts = frame(
            "WF2\n",
            &[
                "abandoned",
                &recovery_generation,
                "1",
                "0",
                "owner_unavailable",
                "",
                "missing",
                "0",
                "",
                &pending.exclusion,
            ],
        )?;
        let proposal = self.propose_bound(
            store,
            BoundRecords {
                intent: &pending.intent,
                claim_namespace: &pending.claim_namespace,
                intent_value: pending.snapshot.value.as_deref().ok_or("intent")?,
                claim: &claim,
                generation: &recovery_generation,
                prepared_audit: None,
            },
            &facts,
            deadline,
        )?;
        if proposal.hint != "record_after_commit" {
            return Err("protocol");
        }
        let batch = commit_batch(&proposal.raw)?;
        validate_delivery(
            &batch,
            &pending.intent,
            &pending.claim_namespace,
            &self.delivery_namespace,
            &pending.claim_generation,
            &proposal.phase,
        )?;
        // Formatter/evaluation work may have failed or changed retained facts.
        // Recheck the real epoch and exact assignment immediately before the
        // atomic claim/result/audit/debit/return; the held revision is CAS checked.
        retained.check_prior_owner(store, scope)?;
        let delivery_receipt = self.commit_funded(
            store,
            scope,
            &proposal,
            &batch,
            deadline,
            None,
            &mut pending.funding,
            None,
            true,
        )?;
        Ok(FundedRecovery {
            recovered: Recovered {
                delivery_receipt,
                phase: proposal.phase,
                claim_generation: pending.claim_generation,
                recovery_generation,
            },
            returned_credit: pending.funding.take_returned(),
        })
    }
}

#[cfg(test)]
#[path = "recovery_tests.rs"]
mod tests;

/// Retirement changes only the authenticated log and reserved ledger. It cannot
/// overwrite the existing claim or result or turn uncertainty into success.
pub struct FundedRetirement {
    pub receipt: Receipt,
    returned_credit: Option<Held>,
}
impl FundedRetirement {
    pub fn take_returned_credit(&mut self) -> Option<Held> {
        self.returned_credit.take()
    }
}
impl Recorder {
    pub fn retire_funded_terminal(
        &mut self,
        store: &mut Store,
        scope: &Scope,
        reservation_namespace: &str,
        reservation_key: &str,
    ) -> Result<FundedRetirement> {
        if !store.has_execution_fence() {
            return Err("execution_fence");
        }
        let audit = self.audit.as_ref().ok_or("funding_audit")?;
        // Additional evaluator-failure obligations need their own original
        // allowance before that profile can opt in to this isolated path.
        if audit.observes_recorder_evaluations() {
            return Err("funding_evaluation");
        }
        let retained = AssignedCompletion::observe_terminal(
            store,
            scope,
            reservation_namespace,
            reservation_key,
        )?;
        let generation = identity()?;
        let retirement = retained.terminal_retirement(store, scope, &generation)?;
        if retirement.delivery_namespace != self.delivery_namespace {
            return Err("funding_identity");
        }
        let deadline = self.deadline();
        let input_digest = crate::effect_audit::digest(&retirement.input);
        let input_bytes = retirement.input.len();
        let before = now()?;
        let started = Instant::now();
        let (output, timeout_ms) = self.function.observe(retirement.input, deadline).result?;
        let parts = fields(&output, "ER1\n", 3)?;
        if parts[0] != "4" || parts[1] != "retire_after_commit" {
            return Err("recording");
        }
        let batch = commit_batch(parts[2])?;
        if batch.checks != retirement.checks || !batch.writes.is_empty() {
            return Err("recording");
        }
        let audit = self.audit.as_mut().ok_or("funding_audit")?;
        let payload = audit.propose(
            Recording {
                intent: &retirement.intent,
                claim_namespace: &retirement.claim_namespace,
                delivery_namespace: &self.delivery_namespace,
                claim_revision: 2,
                claim_generation: &retirement.claim_generation,
                worker_facts: &retirement.facts,
                prepared: None,
                input_sha256: &input_digest,
                input_bytes,
                output: &output,
                batch: parts[2],
                phase: "4",
                before,
                after: now()?,
                elapsed_ms: started.elapsed().as_millis(),
                timeout_ms,
            },
            deadline,
        )?;
        // Original read authority was checked while creating the private
        // retirement. These exact dependencies are CAS checked with the signed
        // ledger return. The private signer adds no domain-data write authority.
        retained.check_prior_owner(store, scope)?;
        let published = audit.commit_funded(
            store,
            &batch,
            &payload,
            deadline,
            None,
            &retirement.held,
            retirement.debit,
            Some(retained.origin()),
            Some(&[]),
            1,
            None,
        )?;
        Ok(FundedRetirement {
            receipt: published.publication.receipt,
            returned_credit: published.held,
        })
    }
}
