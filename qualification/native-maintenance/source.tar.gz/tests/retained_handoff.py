"""Replay acknowledged submissions; an archive count cannot prove their retention."""
import re


def verify_retained_submissions(api, expected, provider_calls):
    """Require immediate original replies and stable identities without new effects.

    ``expected`` comes from the earlier acknowledged inputs/replies. Where an
    earlier operation identity was captured, require that identity as well.
    The returned receipts permit exact comparison after another reopen.
    """
    assert expected, "no acknowledged submissions supplied"
    assert provider_calls() == 0, "provider already called during reopen"
    receipts = []
    identities = set()
    for item in expected:
        status, accepted = api.request(body=item["body"])
        assert status == 202, (status, accepted)
        operation = accepted["operation"]
        assert isinstance(operation, str) and re.fullmatch(r"[0-9a-f]{64}", operation)
        assert operation not in identities, "distinct submissions collapsed to one operation"
        identities.add(operation)
        assert accepted["status_url"] == "/v1/operations/" + operation
        if "operation" in item:
            assert operation == item["operation"], "retained operation identity changed"
        status, terminal = api.request("GET", accepted["status_url"])
        assert status == 200 and terminal["status"] == "done", (status, terminal)
        assert terminal["reply"] == item["reply"], "acknowledged reply changed"
        if "terminal" in item:
            assert terminal == item["terminal"], "retained terminal result changed"
        assert provider_calls() == 0, "replay repeated an external effect"
        replay_status, replay = api.request(body=item["body"])
        assert replay_status == 202 and replay["operation"] == operation
        assert replay["status_url"] == accepted["status_url"]
        assert api.request("GET", replay["status_url"]) == (200, terminal)
        assert provider_calls() == 0, "deduplication repeated an external effect"
        receipts.append(dict(body=item["body"], reply=item["reply"],
                             operation=operation, terminal=terminal))
    return receipts
